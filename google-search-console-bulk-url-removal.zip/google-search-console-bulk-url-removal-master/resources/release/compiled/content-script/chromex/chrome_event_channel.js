// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_event_channel');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.protocols.chrome_event_channel');
goog.require('chromex.protocols.chrome_event_subscription');
goog.require('cljs.core.async.impl.protocols');

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {chromex.protocols.chrome_event_channel.IChromeEventChannel}
*/
chromex.chrome_event_channel.ChromeEventChannel = (function (chan,subscriptions){
this.chan = chan;
this.subscriptions = subscriptions;
});
chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$register_BANG_$arity$2 = (function (_this,subscription){
var self__ = this;
var _this__$1 = this;
return self__.subscriptions = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(self__.subscriptions,subscription);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$unregister_BANG_$arity$2 = (function (_this,subscription){
var self__ = this;
var _this__$1 = this;
return self__.subscriptions = cljs.core.disj.cljs$core$IFn$_invoke$arity$2(self__.subscriptions,subscription);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.chromex$protocols$chrome_event_channel$IChromeEventChannel$unsubscribe_all_BANG_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var seq__40328_40332 = cljs.core.seq(self__.subscriptions);
var chunk__40329_40333 = null;
var count__40330_40334 = (0);
var i__40331_40335 = (0);
while(true){
if((i__40331_40335 < count__40330_40334)){
var subscription_40336 = chunk__40329_40333.cljs$core$IIndexed$_nth$arity$2(null,i__40331_40335);
chromex.protocols.chrome_event_subscription.unsubscribe_BANG_(subscription_40336);


var G__40337 = seq__40328_40332;
var G__40338 = chunk__40329_40333;
var G__40339 = count__40330_40334;
var G__40340 = (i__40331_40335 + (1));
seq__40328_40332 = G__40337;
chunk__40329_40333 = G__40338;
count__40330_40334 = G__40339;
i__40331_40335 = G__40340;
continue;
} else {
var temp__5735__auto___40341 = cljs.core.seq(seq__40328_40332);
if(temp__5735__auto___40341){
var seq__40328_40342__$1 = temp__5735__auto___40341;
if(cljs.core.chunked_seq_QMARK_(seq__40328_40342__$1)){
var c__4550__auto___40343 = cljs.core.chunk_first(seq__40328_40342__$1);
var G__40344 = cljs.core.chunk_rest(seq__40328_40342__$1);
var G__40345 = c__4550__auto___40343;
var G__40346 = cljs.core.count(c__4550__auto___40343);
var G__40347 = (0);
seq__40328_40332 = G__40344;
chunk__40329_40333 = G__40345;
count__40330_40334 = G__40346;
i__40331_40335 = G__40347;
continue;
} else {
var subscription_40348 = cljs.core.first(seq__40328_40342__$1);
chromex.protocols.chrome_event_subscription.unsubscribe_BANG_(subscription_40348);


var G__40349 = cljs.core.next(seq__40328_40342__$1);
var G__40350 = null;
var G__40351 = (0);
var G__40352 = (0);
seq__40328_40332 = G__40349;
chunk__40329_40333 = G__40350;
count__40330_40334 = G__40351;
i__40331_40335 = G__40352;
continue;
}
} else {
}
}
break;
}

return self__.subscriptions = cljs.core.PersistentHashSet.EMPTY;
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_this,val,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.chan,val,handler);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_this,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.chan,handler);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.chan);
});

chromex.chrome_event_channel.ChromeEventChannel.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
this$__$1.chromex$protocols$chrome_event_channel$IChromeEventChannel$unsubscribe_all_BANG_$arity$1(null);

return cljs.core.async.impl.protocols.close_BANG_(self__.chan);
});

chromex.chrome_event_channel.ChromeEventChannel.getBasis = (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$chan,cljs.core.with_meta(cljs.core.cst$sym$subscriptions,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$mutable,true], null))], null);
});

chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$type = true;

chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$ctorStr = "chromex.chrome-event-channel/ChromeEventChannel";

chromex.chrome_event_channel.ChromeEventChannel.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"chromex.chrome-event-channel/ChromeEventChannel");
});

/**
 * Positional factory function for chromex.chrome-event-channel/ChromeEventChannel.
 */
chromex.chrome_event_channel.__GT_ChromeEventChannel = (function chromex$chrome_event_channel$__GT_ChromeEventChannel(chan,subscriptions){
return (new chromex.chrome_event_channel.ChromeEventChannel(chan,subscriptions));
});

chromex.chrome_event_channel.make_chrome_event_channel = (function chromex$chrome_event_channel$make_chrome_event_channel(chan){
return (new chromex.chrome_event_channel.ChromeEventChannel(chan,cljs.core.PersistentHashSet.EMPTY));
});

// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_storage_area');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.protocols.chrome_storage_area');
goog.require('chromex.support');
goog.require('oops.core');

/**
* @constructor
 * @implements {chromex.protocols.chrome_storage_area.IChromeStorageArea}
*/
chromex.chrome_storage_area.ChromeStorageArea = (function (native_chrome_storage_area,channel_factory,callback_factory){
this.native_chrome_storage_area = native_chrome_storage_area;
this.channel_factory = channel_factory;
this.callback_factory = callback_factory;
});
chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_native_storage_area$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_storage_area;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return this$__$1.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$2(null,null);
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_40454_40474 = self__.native_chrome_storage_area;
var call_info_40456_40475 = [target_obj_40454_40474,(function (){var next_obj_40457 = (target_obj_40454_40474["get"]);
return next_obj_40457;
})()];
var fn_40455_40476 = (call_info_40456_40475[(1)]);
if((!((fn_40455_40476 == null)))){
fn_40455_40476.call((call_info_40456_40475[(0)]),keys,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return this$__$1.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$2(null,null);
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_40458_40477 = self__.native_chrome_storage_area;
var call_info_40460_40478 = [target_obj_40458_40477,(function (){var next_obj_40461 = (target_obj_40458_40477["getBytesInUse"]);
return next_obj_40461;
})()];
var fn_40459_40479 = (call_info_40460_40478[(1)]);
if((!((fn_40459_40479 == null)))){
fn_40459_40479.call((call_info_40460_40478[(0)]),keys,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$set$arity$2 = (function (_this,items){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_40462_40480 = self__.native_chrome_storage_area;
var call_info_40464_40481 = [target_obj_40462_40480,(function (){var next_obj_40465 = (target_obj_40462_40480["set"]);
return next_obj_40465;
})()];
var fn_40463_40482 = (call_info_40464_40481[(1)]);
if((!((fn_40463_40482 == null)))){
fn_40463_40482.call((call_info_40464_40481[(0)]),items,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$remove$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_40466_40483 = self__.native_chrome_storage_area;
var call_info_40468_40484 = [target_obj_40466_40483,(function (){var next_obj_40469 = (target_obj_40466_40483["remove"]);
return next_obj_40469;
})()];
var fn_40467_40485 = (call_info_40468_40484[(1)]);
if((!((fn_40467_40485 == null)))){
fn_40467_40485.call((call_info_40468_40484[(0)]),keys,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$clear$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_40470_40486 = self__.native_chrome_storage_area;
var call_info_40472_40487 = [target_obj_40470_40486,(function (){var next_obj_40473 = (target_obj_40470_40486["clear"]);
return next_obj_40473;
})()];
var fn_40471_40488 = (call_info_40472_40487[(1)]);
if((!((fn_40471_40488 == null)))){
fn_40471_40488.call((call_info_40472_40487[(0)]),(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$native_DASH_chrome_DASH_storage_DASH_area,cljs.core.cst$sym$channel_DASH_factory,cljs.core.cst$sym$callback_DASH_factory], null);
});

chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$type = true;

chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$ctorStr = "chromex.chrome-storage-area/ChromeStorageArea";

chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"chromex.chrome-storage-area/ChromeStorageArea");
});

/**
 * Positional factory function for chromex.chrome-storage-area/ChromeStorageArea.
 */
chromex.chrome_storage_area.__GT_ChromeStorageArea = (function chromex$chrome_storage_area$__GT_ChromeStorageArea(native_chrome_storage_area,channel_factory,callback_factory){
return (new chromex.chrome_storage_area.ChromeStorageArea(native_chrome_storage_area,channel_factory,callback_factory));
});

chromex.chrome_storage_area.make_chrome_storage_area = (function chromex$chrome_storage_area$make_chrome_storage_area(config,native_chrome_storage_area){

return (new chromex.chrome_storage_area.ChromeStorageArea(native_chrome_storage_area,(function (){var config__6212__auto__ = config;
var handler_key__6213__auto__ = cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_channel_DASH_factory;
var handler__6214__auto__ = handler_key__6213__auto__.cljs$core$IFn$_invoke$arity$1(config__6212__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6214__auto__,config__6212__auto__);
})(),(function (){var config__6212__auto__ = config;
var handler_key__6213__auto__ = cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_fn_DASH_factory;
var handler__6214__auto__ = handler_key__6213__auto__.cljs$core$IFn$_invoke$arity$1(config__6212__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6214__auto__,config__6212__auto__);
})()));
});

// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_content_setting');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.protocols.chrome_content_setting');
goog.require('chromex.support');
goog.require('oops.core');

/**
* @constructor
 * @implements {chromex.protocols.chrome_content_setting.IChromeContentSetting}
*/
chromex.chrome_content_setting.ChromeContentSetting = (function (native_chrome_content_setting,channel_factory,callback_factory){
this.native_chrome_content_setting = native_chrome_content_setting;
this.channel_factory = channel_factory;
this.callback_factory = callback_factory;
});
chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_native_content_setting$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_content_setting;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_40424_40440 = self__.native_chrome_content_setting;
var call_info_40426_40441 = [target_obj_40424_40440,(function (){var next_obj_40427 = (target_obj_40424_40440["get"]);
return next_obj_40427;
})()];
var fn_40425_40442 = (call_info_40426_40441[(1)]);
if((!((fn_40425_40442 == null)))){
fn_40425_40442.call((call_info_40426_40441[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$set$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_40428_40443 = self__.native_chrome_content_setting;
var call_info_40430_40444 = [target_obj_40428_40443,(function (){var next_obj_40431 = (target_obj_40428_40443["set"]);
return next_obj_40431;
})()];
var fn_40429_40445 = (call_info_40430_40444[(1)]);
if((!((fn_40429_40445 == null)))){
fn_40429_40445.call((call_info_40430_40444[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$clear$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_40432_40446 = self__.native_chrome_content_setting;
var call_info_40434_40447 = [target_obj_40432_40446,(function (){var next_obj_40435 = (target_obj_40432_40446["clear"]);
return next_obj_40435;
})()];
var fn_40433_40448 = (call_info_40434_40447[(1)]);
if((!((fn_40433_40448 == null)))){
fn_40433_40448.call((call_info_40434_40447[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_resource_identifiers$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_40436_40449 = self__.native_chrome_content_setting;
var call_info_40438_40450 = [target_obj_40436_40449,(function (){var next_obj_40439 = (target_obj_40436_40449["getResourceIdentifiers"]);
return next_obj_40439;
})()];
var fn_40437_40451 = (call_info_40438_40450[(1)]);
if((!((fn_40437_40451 == null)))){
fn_40437_40451.call((call_info_40438_40450[(0)]),(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$native_DASH_chrome_DASH_content_DASH_setting,cljs.core.cst$sym$channel_DASH_factory,cljs.core.cst$sym$callback_DASH_factory], null);
});

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$type = true;

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorStr = "chromex.chrome-content-setting/ChromeContentSetting";

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"chromex.chrome-content-setting/ChromeContentSetting");
});

/**
 * Positional factory function for chromex.chrome-content-setting/ChromeContentSetting.
 */
chromex.chrome_content_setting.__GT_ChromeContentSetting = (function chromex$chrome_content_setting$__GT_ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory){
return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory));
});

chromex.chrome_content_setting.make_chrome_content_setting = (function chromex$chrome_content_setting$make_chrome_content_setting(config,native_chrome_content_setting){

return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,(function (){var config__6212__auto__ = config;
var handler_key__6213__auto__ = cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_channel_DASH_factory;
var handler__6214__auto__ = handler_key__6213__auto__.cljs$core$IFn$_invoke$arity$1(config__6212__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6214__auto__,config__6212__auto__);
})(),(function (){var config__6212__auto__ = config;
var handler_key__6213__auto__ = cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_fn_DASH_factory;
var handler__6214__auto__ = handler_key__6213__auto__.cljs$core$IFn$_invoke$arity$1(config__6212__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6214__auto__,config__6212__auto__);
})()));
});

// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_port');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.protocols.chrome_port_state');
goog.require('chromex.support');
goog.require('cljs.core.async');
goog.require('cljs.core.async.impl.protocols');
goog.require('oops.core');

/**
* @constructor
 * @implements {chromex.protocols.chrome_port.IChromePort}
 * @implements {chromex.protocols.chrome_port_state.IChromePortState}
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
*/
chromex.chrome_port.ChromePort = (function (config,native_chrome_port,channel,connected_QMARK_){
this.config = config;
this.native_chrome_port = native_chrome_port;
this.channel = channel;
this.connected_QMARK_ = connected_QMARK_;
});
chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$get_native_port$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_port;
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$get_name$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var target_obj_40295 = self__.native_chrome_port;
var next_obj_40296 = (target_obj_40295["name"]);
return next_obj_40296;
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$get_sender$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var target_obj_40297 = self__.native_chrome_port;
var next_obj_40298 = (target_obj_40297["sender"]);
return next_obj_40298;
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$post_message_BANG_$arity$2 = (function (this$,message){
var self__ = this;
var this$__$1 = this;
if((message == null)){
var config__6203__auto__ = self__.config;
var handler_key__6204__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_with_DASH_nil;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$2(config__6203__auto__,this$__$1) : handler__6205__auto__.call(null,config__6203__auto__,this$__$1));
} else {
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_40299 = self__.native_chrome_port;
var call_info_40301 = [target_obj_40299,(function (){var next_obj_40302 = (target_obj_40299["postMessage"]);
return next_obj_40302;
})()];
var fn_40300 = (call_info_40301[(1)]);
if((!((fn_40300 == null)))){
return fn_40300.call((call_info_40301[(0)]),message);
} else {
return null;
}
} else {
var config__6203__auto__ = self__.config;
var handler_key__6204__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$2(config__6203__auto__,this$__$1) : handler__6205__auto__.call(null,config__6203__auto__,this$__$1));
}
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$disconnect_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_40303 = self__.native_chrome_port;
var call_info_40305 = [target_obj_40303,(function (){var next_obj_40306 = (target_obj_40303["disconnect"]);
return next_obj_40306;
})()];
var fn_40304 = (call_info_40305[(1)]);
if((!((fn_40304 == null)))){
return fn_40304.call((call_info_40305[(0)]));
} else {
return null;
}
} else {
var config__6203__auto__ = self__.config;
var handler_key__6204__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$2(config__6203__auto__,this$__$1) : handler__6205__auto__.call(null,config__6203__auto__,this$__$1));
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$on_disconnect_BANG_$arity$2 = (function (this$,callback){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_40307 = self__.native_chrome_port;
var call_info_40309 = (function (){var target_obj_40310 = (function (){var next_obj_40311 = (target_obj_40307["onDisconnect"]);
return next_obj_40311;
})();
return [target_obj_40310,(function (){var next_obj_40312 = (target_obj_40310["addListener"]);
return next_obj_40312;
})()];
})();
var fn_40308 = (call_info_40309[(1)]);
if((!((fn_40308 == null)))){
return fn_40308.call((call_info_40309[(0)]),callback);
} else {
return null;
}
} else {
var config__6203__auto__ = self__.config;
var handler_key__6204__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$2(config__6203__auto__,this$__$1) : handler__6205__auto__.call(null,config__6203__auto__,this$__$1));
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port$IChromePort$on_message_BANG_$arity$2 = (function (this$,callback){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
var target_obj_40313 = self__.native_chrome_port;
var call_info_40315 = (function (){var target_obj_40316 = (function (){var next_obj_40317 = (target_obj_40313["onMessage"]);
return next_obj_40317;
})();
return [target_obj_40316,(function (){var next_obj_40318 = (target_obj_40316["addListener"]);
return next_obj_40318;
})()];
})();
var fn_40314 = (call_info_40315[(1)]);
if((!((fn_40314 == null)))){
return fn_40314.call((call_info_40315[(0)]),callback);
} else {
return null;
}
} else {
var config__6203__auto__ = self__.config;
var handler_key__6204__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$2(config__6203__auto__,this$__$1) : handler__6205__auto__.call(null,config__6203__auto__,this$__$1));
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port_state$IChromePortState$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port_state$IChromePortState$set_connected_BANG_$arity$2 = (function (_this,val){
var self__ = this;
var _this__$1 = this;
return self__.connected_QMARK_ = val;
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port_state$IChromePortState$put_message_BANG_$arity$2 = (function (this$,message){
var self__ = this;
var this$__$1 = this;
if(cljs.core.truth_(self__.connected_QMARK_)){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(self__.channel,message);
} else {
var config__6203__auto__ = self__.config;
var handler_key__6204__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_put_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(config__6203__auto__,this$__$1,message) : handler__6205__auto__.call(null,config__6203__auto__,this$__$1,message));
}
});

chromex.chrome_port.ChromePort.prototype.chromex$protocols$chrome_port_state$IChromePortState$close_resources_BANG_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.channel);
});

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_this,handler){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.channel,handler);
});

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.channel);
});

chromex.chrome_port.ChromePort.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return this$__$1.chromex$protocols$chrome_port$IChromePort$disconnect_BANG_$arity$1(null);
});

chromex.chrome_port.ChromePort.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$config,cljs.core.cst$sym$native_DASH_chrome_DASH_port,cljs.core.cst$sym$channel,cljs.core.with_meta(cljs.core.cst$sym$connected_QMARK_,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$mutable,true], null))], null);
});

chromex.chrome_port.ChromePort.cljs$lang$type = true;

chromex.chrome_port.ChromePort.cljs$lang$ctorStr = "chromex.chrome-port/ChromePort";

chromex.chrome_port.ChromePort.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"chromex.chrome-port/ChromePort");
});

/**
 * Positional factory function for chromex.chrome-port/ChromePort.
 */
chromex.chrome_port.__GT_ChromePort = (function chromex$chrome_port$__GT_ChromePort(config,native_chrome_port,channel,connected_QMARK_){
return (new chromex.chrome_port.ChromePort(config,native_chrome_port,channel,connected_QMARK_));
});

chromex.chrome_port.make_chrome_port = (function chromex$chrome_port$make_chrome_port(config,native_chrome_port){

var channel = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var chrome_port = (new chromex.chrome_port.ChromePort(config,native_chrome_port,channel,true));
var on_message_fn_factory = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$2(config__6203__auto__,chrome_port) : handler__6205__auto__.call(null,config__6203__auto__,chrome_port));
})();
var on_disconnect_fn_factory = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$2(config__6203__auto__,chrome_port) : handler__6205__auto__.call(null,config__6203__auto__,chrome_port));
})();
chrome_port.chromex$protocols$chrome_port$IChromePort$on_message_BANG_$arity$2(null,on_message_fn_factory);

chrome_port.chromex$protocols$chrome_port$IChromePort$on_disconnect_BANG_$arity$2(null,on_disconnect_fn_factory);

return chrome_port;
});

// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('domina');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('goog.dom');
goog.require('goog.dom.xml');
goog.require('goog.dom.classes');
goog.require('goog.dom.forms');
goog.require('goog.events');
goog.require('goog.style');
goog.require('goog.string');
goog.require('cljs.core');
goog.require('clojure.string');
goog.require('domina.support');
domina.re_html = /<|&#?\w+;/;
domina.re_leading_whitespace = /^\s+/;
domina.re_xhtml_tag = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/i;
domina.re_tag_name = /<([\w:]+)/;
domina.re_no_inner_html = /<(?:script|style)/i;
domina.re_tbody = /<tbody/i;
var opt_wrapper_42718 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(1),"<select multiple='multiple'>","</select>"], null);
var table_section_wrapper_42719 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(1),"<table>","</table>"], null);
var cell_wrapper_42720 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(3),"<table><tbody><tr>","</tr></tbody></table>"], null);
domina.wrap_map = cljs.core.PersistentHashMap.fromArrays(["td","optgroup","tfoot","tr","area",cljs.core.cst$kw$default,"option","legend","thead","col","caption","th","colgroup","tbody"],[cell_wrapper_42720,opt_wrapper_42718,table_section_wrapper_42719,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(2),"<table><tbody>","</tbody></table>"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(1),"<map>","</map>"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(0),"",""], null),opt_wrapper_42718,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(1),"<fieldset>","</fieldset>"], null),table_section_wrapper_42719,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(2),"<table><tbody></tbody><colgroup>","</colgroup></table>"], null),table_section_wrapper_42719,cell_wrapper_42720,table_section_wrapper_42719,table_section_wrapper_42719]);
domina.remove_extraneous_tbody_BANG_ = (function domina$remove_extraneous_tbody_BANG_(div,html,tag_name,start_wrap){
var no_tbody_QMARK_ = cljs.core.not(cljs.core.re_find(domina.re_tbody,html));
var tbody = ((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(tag_name,"table")) && (no_tbody_QMARK_)))?(function (){var and__4120__auto__ = div.firstChild;
if(cljs.core.truth_(and__4120__auto__)){
return div.firstChild.childNodes;
} else {
return and__4120__auto__;
}
})():((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(start_wrap,"<table>")) && (no_tbody_QMARK_)))?div.childNodes:cljs.core.PersistentVector.EMPTY));
var seq__42721 = cljs.core.seq(tbody);
var chunk__42722 = null;
var count__42723 = (0);
var i__42724 = (0);
while(true){
if((i__42724 < count__42723)){
var child = chunk__42722.cljs$core$IIndexed$_nth$arity$2(null,i__42724);
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(child.nodeName,"tbody")) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(child.childNodes.length,(0))))){
child.parentNode.removeChild(child);
} else {
}


var G__42725 = seq__42721;
var G__42726 = chunk__42722;
var G__42727 = count__42723;
var G__42728 = (i__42724 + (1));
seq__42721 = G__42725;
chunk__42722 = G__42726;
count__42723 = G__42727;
i__42724 = G__42728;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__42721);
if(temp__5735__auto__){
var seq__42721__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__42721__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__42721__$1);
var G__42729 = cljs.core.chunk_rest(seq__42721__$1);
var G__42730 = c__4550__auto__;
var G__42731 = cljs.core.count(c__4550__auto__);
var G__42732 = (0);
seq__42721 = G__42729;
chunk__42722 = G__42730;
count__42723 = G__42731;
i__42724 = G__42732;
continue;
} else {
var child = cljs.core.first(seq__42721__$1);
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(child.nodeName,"tbody")) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(child.childNodes.length,(0))))){
child.parentNode.removeChild(child);
} else {
}


var G__42733 = cljs.core.next(seq__42721__$1);
var G__42734 = null;
var G__42735 = (0);
var G__42736 = (0);
seq__42721 = G__42733;
chunk__42722 = G__42734;
count__42723 = G__42735;
i__42724 = G__42736;
continue;
}
} else {
return null;
}
}
break;
}
});
domina.restore_leading_whitespace_BANG_ = (function domina$restore_leading_whitespace_BANG_(div,html){
return div.insertBefore(document.createTextNode(cljs.core.first(cljs.core.re_find(domina.re_leading_whitespace,html))),div.firstChild);
});
/**
 * takes an string of html and returns a NodeList of dom fragments
 */
domina.html_to_dom = (function domina$html_to_dom(html){
var html__$1 = clojure.string.replace(html,domina.re_xhtml_tag,"<$1></$2>");
var tag_name = cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.second(cljs.core.re_find(domina.re_tag_name,html__$1))).toLowerCase();
var vec__42737 = cljs.core.get.cljs$core$IFn$_invoke$arity$3(domina.wrap_map,tag_name,cljs.core.cst$kw$default.cljs$core$IFn$_invoke$arity$1(domina.wrap_map));
var depth = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42737,(0),null);
var start_wrap = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42737,(1),null);
var end_wrap = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42737,(2),null);
var div = (function (){var wrapper = (function (){var div = document.createElement("div");
div.innerHTML = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(start_wrap),cljs.core.str.cljs$core$IFn$_invoke$arity$1(html__$1),cljs.core.str.cljs$core$IFn$_invoke$arity$1(end_wrap)].join('');

return div;
})();
var level = depth;
while(true){
if((level > (0))){
var G__42740 = wrapper.lastChild;
var G__42741 = (level - (1));
wrapper = G__42740;
level = G__42741;
continue;
} else {
return wrapper;
}
break;
}
})();
if(domina.support.extraneous_tbody_QMARK_){
domina.remove_extraneous_tbody_BANG_(div,html__$1,tag_name,start_wrap);
} else {
}

if(cljs.core.truth_((function (){var and__4120__auto__ = (!(domina.support.leading_whitespace_QMARK_));
if(and__4120__auto__){
return cljs.core.re_find(domina.re_leading_whitespace,html__$1);
} else {
return and__4120__auto__;
}
})())){
domina.restore_leading_whitespace_BANG_(div,html__$1);
} else {
}

return div.childNodes;
});
domina.string_to_dom = (function domina$string_to_dom(s){
if(cljs.core.truth_(cljs.core.re_find(domina.re_html,s))){
return domina.html_to_dom(s);
} else {
return document.createTextNode(s);
}
});

/**
 * @interface
 */
domina.DomContent = function(){};

/**
 * Returns the content as a sequence of nodes.
 */
domina.nodes = (function domina$nodes(content){
if((((!((content == null)))) && ((!((content.domina$DomContent$nodes$arity$1 == null)))))){
return content.domina$DomContent$nodes$arity$1(content);
} else {
var x__4433__auto__ = (((content == null))?null:content);
var m__4434__auto__ = (domina.nodes[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(content) : m__4434__auto__.call(null,content));
} else {
var m__4431__auto__ = (domina.nodes["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(content) : m__4431__auto__.call(null,content));
} else {
throw cljs.core.missing_protocol("DomContent.nodes",content);
}
}
}
});

/**
 * Returns the content as a single node (the first node, if the content contains more than one
 */
domina.single_node = (function domina$single_node(nodeseq){
if((((!((nodeseq == null)))) && ((!((nodeseq.domina$DomContent$single_node$arity$1 == null)))))){
return nodeseq.domina$DomContent$single_node$arity$1(nodeseq);
} else {
var x__4433__auto__ = (((nodeseq == null))?null:nodeseq);
var m__4434__auto__ = (domina.single_node[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(nodeseq) : m__4434__auto__.call(null,nodeseq));
} else {
var m__4431__auto__ = (domina.single_node["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(nodeseq) : m__4431__auto__.call(null,nodeseq));
} else {
throw cljs.core.missing_protocol("DomContent.single-node",nodeseq);
}
}
}
});

domina._STAR_debug_STAR_ = true;
domina.log_debug = (function domina$log_debug(var_args){
var args__4736__auto__ = [];
var len__4730__auto___42743 = arguments.length;
var i__4731__auto___42744 = (0);
while(true){
if((i__4731__auto___42744 < len__4730__auto___42743)){
args__4736__auto__.push((arguments[i__4731__auto___42744]));

var G__42745 = (i__4731__auto___42744 + (1));
i__4731__auto___42744 = G__42745;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return domina.log_debug.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

domina.log_debug.cljs$core$IFn$_invoke$arity$variadic = (function (mesg){
if(((domina._STAR_debug_STAR_) && ((!(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(window.console,undefined)))))){
return console.log(cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.str,mesg));
} else {
return null;
}
});

domina.log_debug.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
domina.log_debug.cljs$lang$applyTo = (function (seq42742){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq42742));
});

domina.log = (function domina$log(var_args){
var args__4736__auto__ = [];
var len__4730__auto___42747 = arguments.length;
var i__4731__auto___42748 = (0);
while(true){
if((i__4731__auto___42748 < len__4730__auto___42747)){
args__4736__auto__.push((arguments[i__4731__auto___42748]));

var G__42749 = (i__4731__auto___42748 + (1));
i__4731__auto___42748 = G__42749;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return domina.log.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

domina.log.cljs$core$IFn$_invoke$arity$variadic = (function (mesg){
if(cljs.core.truth_(window.console)){
return console.log(cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.str,mesg));
} else {
return null;
}
});

domina.log.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
domina.log.cljs$lang$applyTo = (function (seq42746){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq42746));
});

/**
 * Returns content containing a single node by looking up the given ID
 */
domina.by_id = (function domina$by_id(id){
var G__42750 = cljs.core.name(id);
return goog.dom.getElement(G__42750);
});
/**
 * Returns content containing nodes which have the specified CSS class.
 */
domina.by_class = (function domina$by_class(class_name){
var G__42751 = (function (){var G__42752 = cljs.core.name(class_name);
return goog.dom.getElementsByClass(G__42752);
})();
return (domina.normalize_seq.cljs$core$IFn$_invoke$arity$1 ? domina.normalize_seq.cljs$core$IFn$_invoke$arity$1(G__42751) : domina.normalize_seq.call(null,G__42751));
});
/**
 * Gets all the child nodes of the elements in a content. Same as (xpath content '*') but more efficient.
 */
domina.children = (function domina$children(content){
return cljs.core.doall.cljs$core$IFn$_invoke$arity$1(cljs.core.mapcat.cljs$core$IFn$_invoke$arity$variadic(goog.dom.getChildren,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([domina.nodes(content)], 0)));
});
/**
 * Returns the deepest common ancestor of the argument contents (which are presumed to be single nodes), or nil if they are from different documents.
 */
domina.common_ancestor = (function domina$common_ancestor(var_args){
var args__4736__auto__ = [];
var len__4730__auto___42754 = arguments.length;
var i__4731__auto___42755 = (0);
while(true){
if((i__4731__auto___42755 < len__4730__auto___42754)){
args__4736__auto__.push((arguments[i__4731__auto___42755]));

var G__42756 = (i__4731__auto___42755 + (1));
i__4731__auto___42755 = G__42756;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return domina.common_ancestor.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

domina.common_ancestor.cljs$core$IFn$_invoke$arity$variadic = (function (contents){
return cljs.core.apply.cljs$core$IFn$_invoke$arity$2(goog.dom.findCommonAncestor,cljs.core.map.cljs$core$IFn$_invoke$arity$2(domina.single_node,contents));
});

domina.common_ancestor.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
domina.common_ancestor.cljs$lang$applyTo = (function (seq42753){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq42753));
});

/**
 * Returns true if the first argument is an ancestor of the second argument. Presumes both arguments are single-node contents.
 */
domina.ancestor_QMARK_ = (function domina$ancestor_QMARK_(ancestor_content,descendant_content){
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(domina.common_ancestor.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([ancestor_content,descendant_content], 0)),domina.single_node(ancestor_content));
});
/**
 * Returns a deep clone of content.
 */
domina.clone = (function domina$clone(content){
return cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p1__42757_SHARP_){
return p1__42757_SHARP_.cloneNode(true);
}),domina.nodes(content));
});
/**
 * Given a parent and child contents, appends each of the children to all of the parents. If there is more than one node in the parent content, clones the children for the additional parents. Returns the parent content.
 */
domina.append_BANG_ = (function domina$append_BANG_(parent_content,child_content){
(domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3 ? domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3(goog.dom.appendChild,parent_content,child_content) : domina.apply_with_cloning.call(null,goog.dom.appendChild,parent_content,child_content));

return parent_content;
});
/**
 * Given a parent and child contents, appends each of the children to all of the parents at the specified index. If there is more than one node in the parent content, clones the children for the additional parents. Returns the parent content.
 */
domina.insert_BANG_ = (function domina$insert_BANG_(parent_content,child_content,idx){
var G__42760_42763 = (function (p1__42758_SHARP_,p2__42759_SHARP_){
return goog.dom.insertChildAt(p1__42758_SHARP_,p2__42759_SHARP_,idx);
});
var G__42761_42764 = parent_content;
var G__42762_42765 = child_content;
(domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3 ? domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3(G__42760_42763,G__42761_42764,G__42762_42765) : domina.apply_with_cloning.call(null,G__42760_42763,G__42761_42764,G__42762_42765));

return parent_content;
});
/**
 * Given a parent and child contents, prepends each of the children to all of the parents. If there is more than one node in the parent content, clones the children for the additional parents. Returns the parent content.
 */
domina.prepend_BANG_ = (function domina$prepend_BANG_(parent_content,child_content){
domina.insert_BANG_(parent_content,child_content,(0));

return parent_content;
});
/**
 * Given a content and some new content, inserts the new content immediately before the reference content. If there is more than one node in the reference content, clones the new content for each one.
 */
domina.insert_before_BANG_ = (function domina$insert_before_BANG_(content,new_content){
var G__42768_42771 = (function (p1__42767_SHARP_,p2__42766_SHARP_){
return goog.dom.insertSiblingBefore(p2__42766_SHARP_,p1__42767_SHARP_);
});
var G__42769_42772 = content;
var G__42770_42773 = new_content;
(domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3 ? domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3(G__42768_42771,G__42769_42772,G__42770_42773) : domina.apply_with_cloning.call(null,G__42768_42771,G__42769_42772,G__42770_42773));

return content;
});
/**
 * Given a content and some new content, inserts the new content immediately after the reference content. If there is more than one node in the reference content, clones the new content for each one.
 */
domina.insert_after_BANG_ = (function domina$insert_after_BANG_(content,new_content){
var G__42776_42779 = (function (p1__42775_SHARP_,p2__42774_SHARP_){
return goog.dom.insertSiblingAfter(p2__42774_SHARP_,p1__42775_SHARP_);
});
var G__42777_42780 = content;
var G__42778_42781 = new_content;
(domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3 ? domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3(G__42776_42779,G__42777_42780,G__42778_42781) : domina.apply_with_cloning.call(null,G__42776_42779,G__42777_42780,G__42778_42781));

return content;
});
/**
 * Given some old content and some new content, replaces the old content with new content. If there are multiple nodes in the old content, replaces each of them and clones the new content as necessary.
 */
domina.swap_content_BANG_ = (function domina$swap_content_BANG_(old_content,new_content){
var G__42784_42787 = (function (p1__42783_SHARP_,p2__42782_SHARP_){
return goog.dom.replaceNode(p2__42782_SHARP_,p1__42783_SHARP_);
});
var G__42785_42788 = old_content;
var G__42786_42789 = new_content;
(domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3 ? domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3(G__42784_42787,G__42785_42788,G__42786_42789) : domina.apply_with_cloning.call(null,G__42784_42787,G__42785_42788,G__42786_42789));

return old_content;
});
/**
 * Removes all the nodes in a content from the DOM and returns them.
 */
domina.detach_BANG_ = (function domina$detach_BANG_(content){
return cljs.core.doall.cljs$core$IFn$_invoke$arity$1(cljs.core.map.cljs$core$IFn$_invoke$arity$2(goog.dom.removeNode,domina.nodes(content)));
});
/**
 * Removes all the nodes in a content from the DOM. Returns nil.
 */
domina.destroy_BANG_ = (function domina$destroy_BANG_(content){
return cljs.core.dorun.cljs$core$IFn$_invoke$arity$1(cljs.core.map.cljs$core$IFn$_invoke$arity$2(goog.dom.removeNode,domina.nodes(content)));
});
/**
 * Removes all the child nodes in a content from the DOM. Returns the original content.
 */
domina.destroy_children_BANG_ = (function domina$destroy_children_BANG_(content){
cljs.core.dorun.cljs$core$IFn$_invoke$arity$1(cljs.core.map.cljs$core$IFn$_invoke$arity$2(goog.dom.removeChildren,domina.nodes(content)));

return content;
});
/**
 * Gets the value of a CSS property. Assumes content will be a single node. Name may be a string or keyword. Returns nil if there is no value set for the style.
 */
domina.style = (function domina$style(content,name){
var s = (function (){var G__42790 = domina.single_node(content);
var G__42791 = cljs.core.name(name);
return goog.style.getStyle(G__42790,G__42791);
})();
if(clojure.string.blank_QMARK_(s)){
return null;
} else {
return s;
}
});
/**
 * Gets the value of an HTML attribute. Assumes content will be a single node. Name may be a stirng or keyword. Returns nil if there is no value set for the style.
 */
domina.attr = (function domina$attr(content,name){
return domina.single_node(content).getAttribute(cljs.core.name(name));
});
/**
 * Sets the value of a CSS property for each node in the content. Name may be a string or keyword. Value will be cast to a string, multiple values wil be concatenated.
 */
domina.set_style_BANG_ = (function domina$set_style_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___42811 = arguments.length;
var i__4731__auto___42812 = (0);
while(true){
if((i__4731__auto___42812 < len__4730__auto___42811)){
args__4736__auto__.push((arguments[i__4731__auto___42812]));

var G__42813 = (i__4731__auto___42812 + (1));
i__4731__auto___42812 = G__42813;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return domina.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

domina.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (content,name,value){
var seq__42795_42814 = cljs.core.seq(domina.nodes(content));
var chunk__42796_42815 = null;
var count__42797_42816 = (0);
var i__42798_42817 = (0);
while(true){
if((i__42798_42817 < count__42797_42816)){
var n_42818 = chunk__42796_42815.cljs$core$IIndexed$_nth$arity$2(null,i__42798_42817);
var G__42805_42819 = n_42818;
var G__42806_42820 = cljs.core.name(name);
var G__42807_42821 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.str,value);
goog.style.setStyle(G__42805_42819,G__42806_42820,G__42807_42821);


var G__42822 = seq__42795_42814;
var G__42823 = chunk__42796_42815;
var G__42824 = count__42797_42816;
var G__42825 = (i__42798_42817 + (1));
seq__42795_42814 = G__42822;
chunk__42796_42815 = G__42823;
count__42797_42816 = G__42824;
i__42798_42817 = G__42825;
continue;
} else {
var temp__5735__auto___42826 = cljs.core.seq(seq__42795_42814);
if(temp__5735__auto___42826){
var seq__42795_42827__$1 = temp__5735__auto___42826;
if(cljs.core.chunked_seq_QMARK_(seq__42795_42827__$1)){
var c__4550__auto___42828 = cljs.core.chunk_first(seq__42795_42827__$1);
var G__42829 = cljs.core.chunk_rest(seq__42795_42827__$1);
var G__42830 = c__4550__auto___42828;
var G__42831 = cljs.core.count(c__4550__auto___42828);
var G__42832 = (0);
seq__42795_42814 = G__42829;
chunk__42796_42815 = G__42830;
count__42797_42816 = G__42831;
i__42798_42817 = G__42832;
continue;
} else {
var n_42833 = cljs.core.first(seq__42795_42827__$1);
var G__42808_42834 = n_42833;
var G__42809_42835 = cljs.core.name(name);
var G__42810_42836 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.str,value);
goog.style.setStyle(G__42808_42834,G__42809_42835,G__42810_42836);


var G__42837 = cljs.core.next(seq__42795_42827__$1);
var G__42838 = null;
var G__42839 = (0);
var G__42840 = (0);
seq__42795_42814 = G__42837;
chunk__42796_42815 = G__42838;
count__42797_42816 = G__42839;
i__42798_42817 = G__42840;
continue;
}
} else {
}
}
break;
}

return content;
});

domina.set_style_BANG_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
domina.set_style_BANG_.cljs$lang$applyTo = (function (seq42792){
var G__42793 = cljs.core.first(seq42792);
var seq42792__$1 = cljs.core.next(seq42792);
var G__42794 = cljs.core.first(seq42792__$1);
var seq42792__$2 = cljs.core.next(seq42792__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__42793,G__42794,seq42792__$2);
});

/**
 * Sets the value of an HTML property for each node in the content. Name may be a string or keyword. Value will be cast to a string, multiple values wil be concatenated.
 */
domina.set_attr_BANG_ = (function domina$set_attr_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___42848 = arguments.length;
var i__4731__auto___42849 = (0);
while(true){
if((i__4731__auto___42849 < len__4730__auto___42848)){
args__4736__auto__.push((arguments[i__4731__auto___42849]));

var G__42850 = (i__4731__auto___42849 + (1));
i__4731__auto___42849 = G__42850;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return domina.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

domina.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (content,name,value){
var seq__42844_42851 = cljs.core.seq(domina.nodes(content));
var chunk__42845_42852 = null;
var count__42846_42853 = (0);
var i__42847_42854 = (0);
while(true){
if((i__42847_42854 < count__42846_42853)){
var n_42855 = chunk__42845_42852.cljs$core$IIndexed$_nth$arity$2(null,i__42847_42854);
n_42855.setAttribute(cljs.core.name(name),cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.str,value));


var G__42856 = seq__42844_42851;
var G__42857 = chunk__42845_42852;
var G__42858 = count__42846_42853;
var G__42859 = (i__42847_42854 + (1));
seq__42844_42851 = G__42856;
chunk__42845_42852 = G__42857;
count__42846_42853 = G__42858;
i__42847_42854 = G__42859;
continue;
} else {
var temp__5735__auto___42860 = cljs.core.seq(seq__42844_42851);
if(temp__5735__auto___42860){
var seq__42844_42861__$1 = temp__5735__auto___42860;
if(cljs.core.chunked_seq_QMARK_(seq__42844_42861__$1)){
var c__4550__auto___42862 = cljs.core.chunk_first(seq__42844_42861__$1);
var G__42863 = cljs.core.chunk_rest(seq__42844_42861__$1);
var G__42864 = c__4550__auto___42862;
var G__42865 = cljs.core.count(c__4550__auto___42862);
var G__42866 = (0);
seq__42844_42851 = G__42863;
chunk__42845_42852 = G__42864;
count__42846_42853 = G__42865;
i__42847_42854 = G__42866;
continue;
} else {
var n_42867 = cljs.core.first(seq__42844_42861__$1);
n_42867.setAttribute(cljs.core.name(name),cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.str,value));


var G__42868 = cljs.core.next(seq__42844_42861__$1);
var G__42869 = null;
var G__42870 = (0);
var G__42871 = (0);
seq__42844_42851 = G__42868;
chunk__42845_42852 = G__42869;
count__42846_42853 = G__42870;
i__42847_42854 = G__42871;
continue;
}
} else {
}
}
break;
}

return content;
});

domina.set_attr_BANG_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
domina.set_attr_BANG_.cljs$lang$applyTo = (function (seq42841){
var G__42842 = cljs.core.first(seq42841);
var seq42841__$1 = cljs.core.next(seq42841);
var G__42843 = cljs.core.first(seq42841__$1);
var seq42841__$2 = cljs.core.next(seq42841__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__42842,G__42843,seq42841__$2);
});

/**
 * Removes the specified HTML property for each node in the content. Name may be a string or keyword.
 */
domina.remove_attr_BANG_ = (function domina$remove_attr_BANG_(content,name){
var seq__42872_42876 = cljs.core.seq(domina.nodes(content));
var chunk__42873_42877 = null;
var count__42874_42878 = (0);
var i__42875_42879 = (0);
while(true){
if((i__42875_42879 < count__42874_42878)){
var n_42880 = chunk__42873_42877.cljs$core$IIndexed$_nth$arity$2(null,i__42875_42879);
n_42880.removeAttribute(cljs.core.name(name));


var G__42881 = seq__42872_42876;
var G__42882 = chunk__42873_42877;
var G__42883 = count__42874_42878;
var G__42884 = (i__42875_42879 + (1));
seq__42872_42876 = G__42881;
chunk__42873_42877 = G__42882;
count__42874_42878 = G__42883;
i__42875_42879 = G__42884;
continue;
} else {
var temp__5735__auto___42885 = cljs.core.seq(seq__42872_42876);
if(temp__5735__auto___42885){
var seq__42872_42886__$1 = temp__5735__auto___42885;
if(cljs.core.chunked_seq_QMARK_(seq__42872_42886__$1)){
var c__4550__auto___42887 = cljs.core.chunk_first(seq__42872_42886__$1);
var G__42888 = cljs.core.chunk_rest(seq__42872_42886__$1);
var G__42889 = c__4550__auto___42887;
var G__42890 = cljs.core.count(c__4550__auto___42887);
var G__42891 = (0);
seq__42872_42876 = G__42888;
chunk__42873_42877 = G__42889;
count__42874_42878 = G__42890;
i__42875_42879 = G__42891;
continue;
} else {
var n_42892 = cljs.core.first(seq__42872_42886__$1);
n_42892.removeAttribute(cljs.core.name(name));


var G__42893 = cljs.core.next(seq__42872_42886__$1);
var G__42894 = null;
var G__42895 = (0);
var G__42896 = (0);
seq__42872_42876 = G__42893;
chunk__42873_42877 = G__42894;
count__42874_42878 = G__42895;
i__42875_42879 = G__42896;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Parses a CSS style string and returns the properties as a map.
 */
domina.parse_style_attributes = (function domina$parse_style_attributes(style){
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3((function (acc,pair){
var vec__42897 = pair.split(/\s*:\s*/);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42897,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42897,(1),null);
if(cljs.core.truth_((function (){var and__4120__auto__ = k;
if(cljs.core.truth_(and__4120__auto__)){
return v;
} else {
return and__4120__auto__;
}
})())){
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(acc,cljs.core.keyword.cljs$core$IFn$_invoke$arity$1(k.toLowerCase()),v);
} else {
return acc;
}
}),cljs.core.PersistentArrayMap.EMPTY,style.split(/\s*;\s*/));
});
/**
 * Returns a map of the CSS styles/values. Assumes content will be a single node. Style names are returned as keywords.
 */
domina.styles = (function domina$styles(content){
var style = domina.attr(content,"style");
if(typeof style === 'string'){
return domina.parse_style_attributes(style);
} else {
if((style == null)){
return cljs.core.PersistentArrayMap.EMPTY;
} else {
if(cljs.core.truth_(style.cssText)){
return domina.parse_style_attributes(style.cssText);
} else {
return cljs.core.PersistentArrayMap.EMPTY;

}
}
}
});
/**
 * Returns a map of the HTML attributes/values. Assumes content will be a single node. Attribute names are returned as keywords.
 */
domina.attrs = (function domina$attrs(content){
var node = domina.single_node(content);
var attrs = node.attributes;
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$2(cljs.core.conj,cljs.core.filter.cljs$core$IFn$_invoke$arity$2(cljs.core.complement(cljs.core.nil_QMARK_),cljs.core.map.cljs$core$IFn$_invoke$arity$2(((function (node,attrs){
return (function (p1__42900_SHARP_){
var attr = attrs.item(p1__42900_SHARP_);
var value = attr.nodeValue;
if(((cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(null,value)) && (cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2("",value)))){
return cljs.core.PersistentArrayMap.createAsIfByAssoc([cljs.core.keyword.cljs$core$IFn$_invoke$arity$1(attr.nodeName.toLowerCase()),attr.nodeValue]);
} else {
return null;
}
});})(node,attrs))
,cljs.core.range.cljs$core$IFn$_invoke$arity$1(attrs.length))));
});
/**
 * Sets the specified CSS styles for each node in the content, given a map of names and values. Style names may be keywords or strings.
 */
domina.set_styles_BANG_ = (function domina$set_styles_BANG_(content,styles){
var seq__42901_42917 = cljs.core.seq(styles);
var chunk__42902_42918 = null;
var count__42903_42919 = (0);
var i__42904_42920 = (0);
while(true){
if((i__42904_42920 < count__42903_42919)){
var vec__42911_42921 = chunk__42902_42918.cljs$core$IIndexed$_nth$arity$2(null,i__42904_42920);
var name_42922 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42911_42921,(0),null);
var value_42923 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42911_42921,(1),null);
domina.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(content,name_42922,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([value_42923], 0));


var G__42924 = seq__42901_42917;
var G__42925 = chunk__42902_42918;
var G__42926 = count__42903_42919;
var G__42927 = (i__42904_42920 + (1));
seq__42901_42917 = G__42924;
chunk__42902_42918 = G__42925;
count__42903_42919 = G__42926;
i__42904_42920 = G__42927;
continue;
} else {
var temp__5735__auto___42928 = cljs.core.seq(seq__42901_42917);
if(temp__5735__auto___42928){
var seq__42901_42929__$1 = temp__5735__auto___42928;
if(cljs.core.chunked_seq_QMARK_(seq__42901_42929__$1)){
var c__4550__auto___42930 = cljs.core.chunk_first(seq__42901_42929__$1);
var G__42931 = cljs.core.chunk_rest(seq__42901_42929__$1);
var G__42932 = c__4550__auto___42930;
var G__42933 = cljs.core.count(c__4550__auto___42930);
var G__42934 = (0);
seq__42901_42917 = G__42931;
chunk__42902_42918 = G__42932;
count__42903_42919 = G__42933;
i__42904_42920 = G__42934;
continue;
} else {
var vec__42914_42935 = cljs.core.first(seq__42901_42929__$1);
var name_42936 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42914_42935,(0),null);
var value_42937 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42914_42935,(1),null);
domina.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(content,name_42936,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([value_42937], 0));


var G__42938 = cljs.core.next(seq__42901_42929__$1);
var G__42939 = null;
var G__42940 = (0);
var G__42941 = (0);
seq__42901_42917 = G__42938;
chunk__42902_42918 = G__42939;
count__42903_42919 = G__42940;
i__42904_42920 = G__42941;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Sets the specified attributes for each node in the content, given a map of names and values. Names may be a string or keyword. Values will be cast to a string, multiple values wil be concatenated.
 */
domina.set_attrs_BANG_ = (function domina$set_attrs_BANG_(content,attrs){
var seq__42942_42958 = cljs.core.seq(attrs);
var chunk__42943_42959 = null;
var count__42944_42960 = (0);
var i__42945_42961 = (0);
while(true){
if((i__42945_42961 < count__42944_42960)){
var vec__42952_42962 = chunk__42943_42959.cljs$core$IIndexed$_nth$arity$2(null,i__42945_42961);
var name_42963 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42952_42962,(0),null);
var value_42964 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42952_42962,(1),null);
domina.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic(content,name_42963,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([value_42964], 0));


var G__42965 = seq__42942_42958;
var G__42966 = chunk__42943_42959;
var G__42967 = count__42944_42960;
var G__42968 = (i__42945_42961 + (1));
seq__42942_42958 = G__42965;
chunk__42943_42959 = G__42966;
count__42944_42960 = G__42967;
i__42945_42961 = G__42968;
continue;
} else {
var temp__5735__auto___42969 = cljs.core.seq(seq__42942_42958);
if(temp__5735__auto___42969){
var seq__42942_42970__$1 = temp__5735__auto___42969;
if(cljs.core.chunked_seq_QMARK_(seq__42942_42970__$1)){
var c__4550__auto___42971 = cljs.core.chunk_first(seq__42942_42970__$1);
var G__42972 = cljs.core.chunk_rest(seq__42942_42970__$1);
var G__42973 = c__4550__auto___42971;
var G__42974 = cljs.core.count(c__4550__auto___42971);
var G__42975 = (0);
seq__42942_42958 = G__42972;
chunk__42943_42959 = G__42973;
count__42944_42960 = G__42974;
i__42945_42961 = G__42975;
continue;
} else {
var vec__42955_42976 = cljs.core.first(seq__42942_42970__$1);
var name_42977 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42955_42976,(0),null);
var value_42978 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__42955_42976,(1),null);
domina.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic(content,name_42977,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([value_42978], 0));


var G__42979 = cljs.core.next(seq__42942_42970__$1);
var G__42980 = null;
var G__42981 = (0);
var G__42982 = (0);
seq__42942_42958 = G__42979;
chunk__42943_42959 = G__42980;
count__42944_42960 = G__42981;
i__42945_42961 = G__42982;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Returns true if the node has the specified CSS class. Assumes content is a single node.
 */
domina.has_class_QMARK_ = (function domina$has_class_QMARK_(content,class$){
var G__42983 = domina.single_node(content);
var G__42984 = class$;
return goog.dom.classes.has(G__42983,G__42984);
});
/**
 * Adds the specified CSS class to each node in the content.
 */
domina.add_class_BANG_ = (function domina$add_class_BANG_(content,class$){
var seq__42985_42989 = cljs.core.seq(domina.nodes(content));
var chunk__42986_42990 = null;
var count__42987_42991 = (0);
var i__42988_42992 = (0);
while(true){
if((i__42988_42992 < count__42987_42991)){
var node_42993 = chunk__42986_42990.cljs$core$IIndexed$_nth$arity$2(null,i__42988_42992);
goog.dom.classes.add(node_42993,class$);


var G__42994 = seq__42985_42989;
var G__42995 = chunk__42986_42990;
var G__42996 = count__42987_42991;
var G__42997 = (i__42988_42992 + (1));
seq__42985_42989 = G__42994;
chunk__42986_42990 = G__42995;
count__42987_42991 = G__42996;
i__42988_42992 = G__42997;
continue;
} else {
var temp__5735__auto___42998 = cljs.core.seq(seq__42985_42989);
if(temp__5735__auto___42998){
var seq__42985_42999__$1 = temp__5735__auto___42998;
if(cljs.core.chunked_seq_QMARK_(seq__42985_42999__$1)){
var c__4550__auto___43000 = cljs.core.chunk_first(seq__42985_42999__$1);
var G__43001 = cljs.core.chunk_rest(seq__42985_42999__$1);
var G__43002 = c__4550__auto___43000;
var G__43003 = cljs.core.count(c__4550__auto___43000);
var G__43004 = (0);
seq__42985_42989 = G__43001;
chunk__42986_42990 = G__43002;
count__42987_42991 = G__43003;
i__42988_42992 = G__43004;
continue;
} else {
var node_43005 = cljs.core.first(seq__42985_42999__$1);
goog.dom.classes.add(node_43005,class$);


var G__43006 = cljs.core.next(seq__42985_42999__$1);
var G__43007 = null;
var G__43008 = (0);
var G__43009 = (0);
seq__42985_42989 = G__43006;
chunk__42986_42990 = G__43007;
count__42987_42991 = G__43008;
i__42988_42992 = G__43009;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Removes the specified CSS class from each node in the content.
 */
domina.remove_class_BANG_ = (function domina$remove_class_BANG_(content,class$){
var seq__43010_43014 = cljs.core.seq(domina.nodes(content));
var chunk__43011_43015 = null;
var count__43012_43016 = (0);
var i__43013_43017 = (0);
while(true){
if((i__43013_43017 < count__43012_43016)){
var node_43018 = chunk__43011_43015.cljs$core$IIndexed$_nth$arity$2(null,i__43013_43017);
goog.dom.classes.remove(node_43018,class$);


var G__43019 = seq__43010_43014;
var G__43020 = chunk__43011_43015;
var G__43021 = count__43012_43016;
var G__43022 = (i__43013_43017 + (1));
seq__43010_43014 = G__43019;
chunk__43011_43015 = G__43020;
count__43012_43016 = G__43021;
i__43013_43017 = G__43022;
continue;
} else {
var temp__5735__auto___43023 = cljs.core.seq(seq__43010_43014);
if(temp__5735__auto___43023){
var seq__43010_43024__$1 = temp__5735__auto___43023;
if(cljs.core.chunked_seq_QMARK_(seq__43010_43024__$1)){
var c__4550__auto___43025 = cljs.core.chunk_first(seq__43010_43024__$1);
var G__43026 = cljs.core.chunk_rest(seq__43010_43024__$1);
var G__43027 = c__4550__auto___43025;
var G__43028 = cljs.core.count(c__4550__auto___43025);
var G__43029 = (0);
seq__43010_43014 = G__43026;
chunk__43011_43015 = G__43027;
count__43012_43016 = G__43028;
i__43013_43017 = G__43029;
continue;
} else {
var node_43030 = cljs.core.first(seq__43010_43024__$1);
goog.dom.classes.remove(node_43030,class$);


var G__43031 = cljs.core.next(seq__43010_43024__$1);
var G__43032 = null;
var G__43033 = (0);
var G__43034 = (0);
seq__43010_43014 = G__43031;
chunk__43011_43015 = G__43032;
count__43012_43016 = G__43033;
i__43013_43017 = G__43034;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Toggles the specified CSS class from each node in the content.
 */
domina.toggle_class_BANG_ = (function domina$toggle_class_BANG_(content,class$){
var seq__43035_43039 = cljs.core.seq(domina.nodes(content));
var chunk__43036_43040 = null;
var count__43037_43041 = (0);
var i__43038_43042 = (0);
while(true){
if((i__43038_43042 < count__43037_43041)){
var node_43043 = chunk__43036_43040.cljs$core$IIndexed$_nth$arity$2(null,i__43038_43042);
goog.dom.classes.toggle(node_43043,class$);


var G__43044 = seq__43035_43039;
var G__43045 = chunk__43036_43040;
var G__43046 = count__43037_43041;
var G__43047 = (i__43038_43042 + (1));
seq__43035_43039 = G__43044;
chunk__43036_43040 = G__43045;
count__43037_43041 = G__43046;
i__43038_43042 = G__43047;
continue;
} else {
var temp__5735__auto___43048 = cljs.core.seq(seq__43035_43039);
if(temp__5735__auto___43048){
var seq__43035_43049__$1 = temp__5735__auto___43048;
if(cljs.core.chunked_seq_QMARK_(seq__43035_43049__$1)){
var c__4550__auto___43050 = cljs.core.chunk_first(seq__43035_43049__$1);
var G__43051 = cljs.core.chunk_rest(seq__43035_43049__$1);
var G__43052 = c__4550__auto___43050;
var G__43053 = cljs.core.count(c__4550__auto___43050);
var G__43054 = (0);
seq__43035_43039 = G__43051;
chunk__43036_43040 = G__43052;
count__43037_43041 = G__43053;
i__43038_43042 = G__43054;
continue;
} else {
var node_43055 = cljs.core.first(seq__43035_43049__$1);
goog.dom.classes.toggle(node_43055,class$);


var G__43056 = cljs.core.next(seq__43035_43049__$1);
var G__43057 = null;
var G__43058 = (0);
var G__43059 = (0);
seq__43035_43039 = G__43056;
chunk__43036_43040 = G__43057;
count__43037_43041 = G__43058;
i__43038_43042 = G__43059;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Returns a seq of all the CSS classes currently applied to a node. Assumes content is a single node.
 */
domina.classes = (function domina$classes(content){
return cljs.core.seq((function (){var G__43060 = domina.single_node(content);
return goog.dom.classes.get(G__43060);
})());
});
/**
 * Sets the class attribute of the content nodes to classes, which can
 *   be either a class attribute string or a seq of classname strings.
 */
domina.set_classes_BANG_ = (function domina$set_classes_BANG_(content,classes){
var classes_43065__$1 = ((cljs.core.coll_QMARK_(classes))?clojure.string.join.cljs$core$IFn$_invoke$arity$2(" ",classes):classes);
var seq__43061_43066 = cljs.core.seq(domina.nodes(content));
var chunk__43062_43067 = null;
var count__43063_43068 = (0);
var i__43064_43069 = (0);
while(true){
if((i__43064_43069 < count__43063_43068)){
var node_43070 = chunk__43062_43067.cljs$core$IIndexed$_nth$arity$2(null,i__43064_43069);
goog.dom.classes.set(node_43070,classes_43065__$1);


var G__43071 = seq__43061_43066;
var G__43072 = chunk__43062_43067;
var G__43073 = count__43063_43068;
var G__43074 = (i__43064_43069 + (1));
seq__43061_43066 = G__43071;
chunk__43062_43067 = G__43072;
count__43063_43068 = G__43073;
i__43064_43069 = G__43074;
continue;
} else {
var temp__5735__auto___43075 = cljs.core.seq(seq__43061_43066);
if(temp__5735__auto___43075){
var seq__43061_43076__$1 = temp__5735__auto___43075;
if(cljs.core.chunked_seq_QMARK_(seq__43061_43076__$1)){
var c__4550__auto___43077 = cljs.core.chunk_first(seq__43061_43076__$1);
var G__43078 = cljs.core.chunk_rest(seq__43061_43076__$1);
var G__43079 = c__4550__auto___43077;
var G__43080 = cljs.core.count(c__4550__auto___43077);
var G__43081 = (0);
seq__43061_43066 = G__43078;
chunk__43062_43067 = G__43079;
count__43063_43068 = G__43080;
i__43064_43069 = G__43081;
continue;
} else {
var node_43082 = cljs.core.first(seq__43061_43076__$1);
goog.dom.classes.set(node_43082,classes_43065__$1);


var G__43083 = cljs.core.next(seq__43061_43076__$1);
var G__43084 = null;
var G__43085 = (0);
var G__43086 = (0);
seq__43061_43066 = G__43083;
chunk__43062_43067 = G__43084;
count__43063_43068 = G__43085;
i__43064_43069 = G__43086;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Returns the text of a node. Assumes content is a single node. For consistency across browsers, will always trim whitespace of the beginning and end of the returned text.
 */
domina.text = (function domina$text(content){
var G__43087 = (function (){var G__43088 = domina.single_node(content);
return goog.dom.getTextContent(G__43088);
})();
return goog.string.trim(G__43087);
});
/**
 * Sets the text value of all the nodes in the given content.
 */
domina.set_text_BANG_ = (function domina$set_text_BANG_(content,value){
var seq__43089_43093 = cljs.core.seq(domina.nodes(content));
var chunk__43090_43094 = null;
var count__43091_43095 = (0);
var i__43092_43096 = (0);
while(true){
if((i__43092_43096 < count__43091_43095)){
var node_43097 = chunk__43090_43094.cljs$core$IIndexed$_nth$arity$2(null,i__43092_43096);
goog.dom.setTextContent(node_43097,value);


var G__43098 = seq__43089_43093;
var G__43099 = chunk__43090_43094;
var G__43100 = count__43091_43095;
var G__43101 = (i__43092_43096 + (1));
seq__43089_43093 = G__43098;
chunk__43090_43094 = G__43099;
count__43091_43095 = G__43100;
i__43092_43096 = G__43101;
continue;
} else {
var temp__5735__auto___43102 = cljs.core.seq(seq__43089_43093);
if(temp__5735__auto___43102){
var seq__43089_43103__$1 = temp__5735__auto___43102;
if(cljs.core.chunked_seq_QMARK_(seq__43089_43103__$1)){
var c__4550__auto___43104 = cljs.core.chunk_first(seq__43089_43103__$1);
var G__43105 = cljs.core.chunk_rest(seq__43089_43103__$1);
var G__43106 = c__4550__auto___43104;
var G__43107 = cljs.core.count(c__4550__auto___43104);
var G__43108 = (0);
seq__43089_43093 = G__43105;
chunk__43090_43094 = G__43106;
count__43091_43095 = G__43107;
i__43092_43096 = G__43108;
continue;
} else {
var node_43109 = cljs.core.first(seq__43089_43103__$1);
goog.dom.setTextContent(node_43109,value);


var G__43110 = cljs.core.next(seq__43089_43103__$1);
var G__43111 = null;
var G__43112 = (0);
var G__43113 = (0);
seq__43089_43093 = G__43110;
chunk__43090_43094 = G__43111;
count__43091_43095 = G__43112;
i__43092_43096 = G__43113;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Returns the value of a node (presumably a form field). Assumes content is a single node.
 */
domina.value = (function domina$value(content){
var G__43114 = domina.single_node(content);
return goog.dom.forms.getValue(G__43114);
});
/**
 * Sets the value of all the nodes (presumably form fields) in the given content.
 */
domina.set_value_BANG_ = (function domina$set_value_BANG_(content,value){
var seq__43115_43119 = cljs.core.seq(domina.nodes(content));
var chunk__43116_43120 = null;
var count__43117_43121 = (0);
var i__43118_43122 = (0);
while(true){
if((i__43118_43122 < count__43117_43121)){
var node_43123 = chunk__43116_43120.cljs$core$IIndexed$_nth$arity$2(null,i__43118_43122);
goog.dom.forms.setValue(node_43123,value);


var G__43124 = seq__43115_43119;
var G__43125 = chunk__43116_43120;
var G__43126 = count__43117_43121;
var G__43127 = (i__43118_43122 + (1));
seq__43115_43119 = G__43124;
chunk__43116_43120 = G__43125;
count__43117_43121 = G__43126;
i__43118_43122 = G__43127;
continue;
} else {
var temp__5735__auto___43128 = cljs.core.seq(seq__43115_43119);
if(temp__5735__auto___43128){
var seq__43115_43129__$1 = temp__5735__auto___43128;
if(cljs.core.chunked_seq_QMARK_(seq__43115_43129__$1)){
var c__4550__auto___43130 = cljs.core.chunk_first(seq__43115_43129__$1);
var G__43131 = cljs.core.chunk_rest(seq__43115_43129__$1);
var G__43132 = c__4550__auto___43130;
var G__43133 = cljs.core.count(c__4550__auto___43130);
var G__43134 = (0);
seq__43115_43119 = G__43131;
chunk__43116_43120 = G__43132;
count__43117_43121 = G__43133;
i__43118_43122 = G__43134;
continue;
} else {
var node_43135 = cljs.core.first(seq__43115_43129__$1);
goog.dom.forms.setValue(node_43135,value);


var G__43136 = cljs.core.next(seq__43115_43129__$1);
var G__43137 = null;
var G__43138 = (0);
var G__43139 = (0);
seq__43115_43119 = G__43136;
chunk__43116_43120 = G__43137;
count__43117_43121 = G__43138;
i__43118_43122 = G__43139;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Returns the innerHTML of a node. Assumes content is a single node.
 */
domina.html = (function domina$html(content){
return domina.single_node(content).innerHTML;
});
domina.replace_children_BANG_ = (function domina$replace_children_BANG_(content,inner_content){
return domina.append_BANG_(domina.destroy_children_BANG_(content),inner_content);
});
domina.set_inner_html_BANG_ = (function domina$set_inner_html_BANG_(content,html_string){
var allows_inner_html_QMARK_ = cljs.core.not(cljs.core.re_find(domina.re_no_inner_html,html_string));
var leading_whitespace_QMARK_ = cljs.core.re_find(domina.re_leading_whitespace,html_string);
var tag_name = cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.second(cljs.core.re_find(domina.re_tag_name,html_string))).toLowerCase();
var special_tag_QMARK_ = cljs.core.contains_QMARK_(domina.wrap_map,tag_name);
if(((allows_inner_html_QMARK_) && (((domina.support.leading_whitespace_QMARK_) || (cljs.core.not(leading_whitespace_QMARK_)))) && ((!(special_tag_QMARK_))))){
var value_43145 = clojure.string.replace(html_string,domina.re_xhtml_tag,"<$1></$2>");
try{var seq__43141_43146 = cljs.core.seq(domina.nodes(content));
var chunk__43142_43147 = null;
var count__43143_43148 = (0);
var i__43144_43149 = (0);
while(true){
if((i__43144_43149 < count__43143_43148)){
var node_43150 = chunk__43142_43147.cljs$core$IIndexed$_nth$arity$2(null,i__43144_43149);
node_43150.innerHTML = value_43145;


var G__43151 = seq__43141_43146;
var G__43152 = chunk__43142_43147;
var G__43153 = count__43143_43148;
var G__43154 = (i__43144_43149 + (1));
seq__43141_43146 = G__43151;
chunk__43142_43147 = G__43152;
count__43143_43148 = G__43153;
i__43144_43149 = G__43154;
continue;
} else {
var temp__5735__auto___43155 = cljs.core.seq(seq__43141_43146);
if(temp__5735__auto___43155){
var seq__43141_43156__$1 = temp__5735__auto___43155;
if(cljs.core.chunked_seq_QMARK_(seq__43141_43156__$1)){
var c__4550__auto___43157 = cljs.core.chunk_first(seq__43141_43156__$1);
var G__43158 = cljs.core.chunk_rest(seq__43141_43156__$1);
var G__43159 = c__4550__auto___43157;
var G__43160 = cljs.core.count(c__4550__auto___43157);
var G__43161 = (0);
seq__43141_43146 = G__43158;
chunk__43142_43147 = G__43159;
count__43143_43148 = G__43160;
i__43144_43149 = G__43161;
continue;
} else {
var node_43162 = cljs.core.first(seq__43141_43156__$1);
node_43162.innerHTML = value_43145;


var G__43163 = cljs.core.next(seq__43141_43156__$1);
var G__43164 = null;
var G__43165 = (0);
var G__43166 = (0);
seq__43141_43146 = G__43163;
chunk__43142_43147 = G__43164;
count__43143_43148 = G__43165;
i__43144_43149 = G__43166;
continue;
}
} else {
}
}
break;
}
}catch (e43140){if((e43140 instanceof Error)){
var e_43167 = e43140;
domina.replace_children_BANG_(content,value_43145);
} else {
throw e43140;

}
}} else {
domina.replace_children_BANG_(content,html_string);
}

return content;
});
/**
 * Sets the innerHTML value for all the nodes in the given content.
 */
domina.set_html_BANG_ = (function domina$set_html_BANG_(content,inner_content){
if(typeof inner_content === 'string'){
return domina.set_inner_html_BANG_(content,inner_content);
} else {
return domina.replace_children_BANG_(content,inner_content);
}
});
/**
 * Returns data associated with a node for a given key. Assumes
 *   content is a single node. If the bubble parameter is set to true,
 *   will search parent nodes if the key is not found.
 */
domina.get_data = (function domina$get_data(var_args){
var G__43169 = arguments.length;
switch (G__43169) {
case 2:
return domina.get_data.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return domina.get_data.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

domina.get_data.cljs$core$IFn$_invoke$arity$2 = (function (node,key){
return domina.get_data.cljs$core$IFn$_invoke$arity$3(node,key,false);
});

domina.get_data.cljs$core$IFn$_invoke$arity$3 = (function (node,key,bubble){
var m = domina.single_node(node).__domina_data;
var value = (cljs.core.truth_(m)?cljs.core.get.cljs$core$IFn$_invoke$arity$2(m,key):null);
if(cljs.core.truth_((function (){var and__4120__auto__ = bubble;
if(cljs.core.truth_(and__4120__auto__)){
return (value == null);
} else {
return and__4120__auto__;
}
})())){
var temp__5735__auto__ = domina.single_node(node).parentNode;
if(cljs.core.truth_(temp__5735__auto__)){
var parent = temp__5735__auto__;
return domina.get_data.cljs$core$IFn$_invoke$arity$3(parent,key,true);
} else {
return null;
}
} else {
return value;
}
});

domina.get_data.cljs$lang$maxFixedArity = 3;

/**
 * Sets a data on the node for a given key. Assumes content is a
 *   single node. Data should be ClojureScript values and data structures
 *   only; using other objects as data may result in memory leaks on some
 *   browsers.
 */
domina.set_data_BANG_ = (function domina$set_data_BANG_(node,key,value){
var m = (function (){var or__4131__auto__ = domina.single_node(node).__domina_data;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return cljs.core.PersistentArrayMap.EMPTY;
}
})();
return domina.single_node(node).__domina_data = cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(m,key,value);
});
/**
 * Takes a two-arg function, a reference DomContent and new
 *   DomContent. Applies the function for each reference / content
 *   combination. Uses clones of the new content for each additional
 *   parent after the first.
 */
domina.apply_with_cloning = (function domina$apply_with_cloning(f,parent_content,child_content){
var parents = domina.nodes(parent_content);
var children = domina.nodes(child_content);
var first_child = (function (){var frag = document.createDocumentFragment();
var seq__43173_43179 = cljs.core.seq(children);
var chunk__43174_43180 = null;
var count__43175_43181 = (0);
var i__43176_43182 = (0);
while(true){
if((i__43176_43182 < count__43175_43181)){
var child_43183 = chunk__43174_43180.cljs$core$IIndexed$_nth$arity$2(null,i__43176_43182);
frag.appendChild(child_43183);


var G__43184 = seq__43173_43179;
var G__43185 = chunk__43174_43180;
var G__43186 = count__43175_43181;
var G__43187 = (i__43176_43182 + (1));
seq__43173_43179 = G__43184;
chunk__43174_43180 = G__43185;
count__43175_43181 = G__43186;
i__43176_43182 = G__43187;
continue;
} else {
var temp__5735__auto___43188 = cljs.core.seq(seq__43173_43179);
if(temp__5735__auto___43188){
var seq__43173_43189__$1 = temp__5735__auto___43188;
if(cljs.core.chunked_seq_QMARK_(seq__43173_43189__$1)){
var c__4550__auto___43190 = cljs.core.chunk_first(seq__43173_43189__$1);
var G__43191 = cljs.core.chunk_rest(seq__43173_43189__$1);
var G__43192 = c__4550__auto___43190;
var G__43193 = cljs.core.count(c__4550__auto___43190);
var G__43194 = (0);
seq__43173_43179 = G__43191;
chunk__43174_43180 = G__43192;
count__43175_43181 = G__43193;
i__43176_43182 = G__43194;
continue;
} else {
var child_43195 = cljs.core.first(seq__43173_43189__$1);
frag.appendChild(child_43195);


var G__43196 = cljs.core.next(seq__43173_43189__$1);
var G__43197 = null;
var G__43198 = (0);
var G__43199 = (0);
seq__43173_43179 = G__43196;
chunk__43174_43180 = G__43197;
count__43175_43181 = G__43198;
i__43176_43182 = G__43199;
continue;
}
} else {
}
}
break;
}

return frag;
})();
var other_children = cljs.core.doall.cljs$core$IFn$_invoke$arity$1(cljs.core.repeatedly.cljs$core$IFn$_invoke$arity$2((cljs.core.count(parents) - (1)),((function (parents,children,first_child){
return (function (){
return first_child.cloneNode(true);
});})(parents,children,first_child))
));
if(cljs.core.seq(parents)){
var G__43177_43200 = cljs.core.first(parents);
var G__43178_43201 = first_child;
(f.cljs$core$IFn$_invoke$arity$2 ? f.cljs$core$IFn$_invoke$arity$2(G__43177_43200,G__43178_43201) : f.call(null,G__43177_43200,G__43178_43201));

return cljs.core.doall.cljs$core$IFn$_invoke$arity$1(cljs.core.map.cljs$core$IFn$_invoke$arity$3(((function (parents,children,first_child,other_children){
return (function (p1__43171_SHARP_,p2__43172_SHARP_){
return (f.cljs$core$IFn$_invoke$arity$2 ? f.cljs$core$IFn$_invoke$arity$2(p1__43171_SHARP_,p2__43172_SHARP_) : f.call(null,p1__43171_SHARP_,p2__43172_SHARP_));
});})(parents,children,first_child,other_children))
,cljs.core.rest(parents),other_children));
} else {
return null;
}
});
domina.lazy_nl_via_item = (function domina$lazy_nl_via_item(var_args){
var G__43203 = arguments.length;
switch (G__43203) {
case 1:
return domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$1 = (function (nl){
return domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$2(nl,(0));
});

domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$2 = (function (nl,n){
if((n < nl.length)){
return (new cljs.core.LazySeq(null,(function (){
return cljs.core.cons(nl.item(n),domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$2(nl,(n + (1))));
}),null,null));
} else {
return null;
}
});

domina.lazy_nl_via_item.cljs$lang$maxFixedArity = 2;

domina.lazy_nl_via_array_ref = (function domina$lazy_nl_via_array_ref(var_args){
var G__43206 = arguments.length;
switch (G__43206) {
case 1:
return domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$1 = (function (nl){
return domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$2(nl,(0));
});

domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$2 = (function (nl,n){
if((n < nl.length)){
return (new cljs.core.LazySeq(null,(function (){
return cljs.core.cons((nl[n]),domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$2(nl,(n + (1))));
}),null,null));
} else {
return null;
}
});

domina.lazy_nl_via_array_ref.cljs$lang$maxFixedArity = 2;

/**
 * A lazy seq view of a js/NodeList, or other array-like javascript things
 */
domina.lazy_nodelist = (function domina$lazy_nodelist(nl){
if(cljs.core.truth_(nl.item)){
return domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$1(nl);
} else {
return domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$1(nl);
}
});
domina.array_like_QMARK_ = (function domina$array_like_QMARK_(obj){
var and__4120__auto__ = obj;
if(cljs.core.truth_(and__4120__auto__)){
var and__4120__auto____$1 = cljs.core.not(obj.nodeName);
if(and__4120__auto____$1){
return obj.length;
} else {
return and__4120__auto____$1;
}
} else {
return and__4120__auto__;
}
});
/**
 * Some versions of IE have things that are like arrays in that they
 *   respond to .length, but are not arrays nor NodeSets. This returns a
 *   real sequence view of such objects. If passed an object that is not
 *   a logical sequence at all, returns a single-item seq containing the
 *   object.
 */
domina.normalize_seq = (function domina$normalize_seq(list_thing){
if((list_thing == null)){
return cljs.core.List.EMPTY;
} else {
if((((!((list_thing == null))))?(((((list_thing.cljs$lang$protocol_mask$partition0$ & (8388608))) || ((cljs.core.PROTOCOL_SENTINEL === list_thing.cljs$core$ISeqable$))))?true:(((!list_thing.cljs$lang$protocol_mask$partition0$))?cljs.core.native_satisfies_QMARK_(cljs.core.ISeqable,list_thing):false)):cljs.core.native_satisfies_QMARK_(cljs.core.ISeqable,list_thing))){
return cljs.core.seq(list_thing);
} else {
if(cljs.core.truth_(domina.array_like_QMARK_(list_thing))){
return domina.lazy_nodelist(list_thing);
} else {
return cljs.core.seq(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [list_thing], null));

}
}
}
});
goog.object.set(domina.DomContent,"string",true);

var G__43209_43223 = domina.nodes;
var G__43210_43224 = "string";
var G__43211_43225 = ((function (G__43209_43223,G__43210_43224){
return (function (s){
return cljs.core.doall.cljs$core$IFn$_invoke$arity$1(domina.nodes(domina.string_to_dom(s)));
});})(G__43209_43223,G__43210_43224))
;
goog.object.set(G__43209_43223,G__43210_43224,G__43211_43225);

var G__43212_43226 = domina.single_node;
var G__43213_43227 = "string";
var G__43214_43228 = ((function (G__43212_43226,G__43213_43227){
return (function (s){
return domina.single_node(domina.string_to_dom(s));
});})(G__43212_43226,G__43213_43227))
;
goog.object.set(G__43212_43226,G__43213_43227,G__43214_43228);

goog.object.set(domina.DomContent,"_",true);

var G__43215_43229 = domina.nodes;
var G__43216_43230 = "_";
var G__43217_43231 = ((function (G__43215_43229,G__43216_43230){
return (function (content){
if((content == null)){
return cljs.core.List.EMPTY;
} else {
if((((!((content == null))))?(((((content.cljs$lang$protocol_mask$partition0$ & (8388608))) || ((cljs.core.PROTOCOL_SENTINEL === content.cljs$core$ISeqable$))))?true:(((!content.cljs$lang$protocol_mask$partition0$))?cljs.core.native_satisfies_QMARK_(cljs.core.ISeqable,content):false)):cljs.core.native_satisfies_QMARK_(cljs.core.ISeqable,content))){
return cljs.core.seq(content);
} else {
if(cljs.core.truth_(domina.array_like_QMARK_(content))){
return domina.lazy_nodelist(content);
} else {
return cljs.core.seq(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [content], null));

}
}
}
});})(G__43215_43229,G__43216_43230))
;
goog.object.set(G__43215_43229,G__43216_43230,G__43217_43231);

var G__43219_43232 = domina.single_node;
var G__43220_43233 = "_";
var G__43221_43234 = ((function (G__43219_43232,G__43220_43233){
return (function (content){
if((content == null)){
return null;
} else {
if((((!((content == null))))?(((((content.cljs$lang$protocol_mask$partition0$ & (8388608))) || ((cljs.core.PROTOCOL_SENTINEL === content.cljs$core$ISeqable$))))?true:(((!content.cljs$lang$protocol_mask$partition0$))?cljs.core.native_satisfies_QMARK_(cljs.core.ISeqable,content):false)):cljs.core.native_satisfies_QMARK_(cljs.core.ISeqable,content))){
return cljs.core.first(content);
} else {
if(cljs.core.truth_(domina.array_like_QMARK_(content))){
return content.item((0));
} else {
return content;

}
}
}
});})(G__43219_43232,G__43220_43233))
;
goog.object.set(G__43219_43232,G__43220_43233,G__43221_43234);
if(cljs.core.truth_((typeof NodeList != 'undefined'))){
NodeList.prototype.cljs$core$ICounted$ = cljs.core.PROTOCOL_SENTINEL;

NodeList.prototype.cljs$core$ICounted$_count$arity$1 = (function (nodelist){
var nodelist__$1 = this;
return nodelist__$1.length;
});

NodeList.prototype.cljs$core$IIndexed$ = cljs.core.PROTOCOL_SENTINEL;

NodeList.prototype.cljs$core$IIndexed$_nth$arity$2 = (function (nodelist,n){
var nodelist__$1 = this;
return nodelist__$1.item(n);
});

NodeList.prototype.cljs$core$IIndexed$_nth$arity$3 = (function (nodelist,n,not_found){
var nodelist__$1 = this;
if((nodelist__$1.length <= n)){
return not_found;
} else {
return cljs.core.nth.cljs$core$IFn$_invoke$arity$2(nodelist__$1,n);
}
});

NodeList.prototype.cljs$core$ISeqable$ = cljs.core.PROTOCOL_SENTINEL;

NodeList.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (nodelist){
var nodelist__$1 = this;
return domina.lazy_nodelist(nodelist__$1);
});
} else {
}
if(cljs.core.truth_((typeof StaticNodeList != 'undefined'))){
StaticNodeList.prototype.cljs$core$ICounted$ = cljs.core.PROTOCOL_SENTINEL;

StaticNodeList.prototype.cljs$core$ICounted$_count$arity$1 = (function (nodelist){
var nodelist__$1 = this;
return nodelist__$1.length;
});

StaticNodeList.prototype.cljs$core$IIndexed$ = cljs.core.PROTOCOL_SENTINEL;

StaticNodeList.prototype.cljs$core$IIndexed$_nth$arity$2 = (function (nodelist,n){
var nodelist__$1 = this;
return nodelist__$1.item(n);
});

StaticNodeList.prototype.cljs$core$IIndexed$_nth$arity$3 = (function (nodelist,n,not_found){
var nodelist__$1 = this;
if((nodelist__$1.length <= n)){
return not_found;
} else {
return cljs.core.nth.cljs$core$IFn$_invoke$arity$2(nodelist__$1,n);
}
});

StaticNodeList.prototype.cljs$core$ISeqable$ = cljs.core.PROTOCOL_SENTINEL;

StaticNodeList.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (nodelist){
var nodelist__$1 = this;
return domina.lazy_nodelist(nodelist__$1);
});
} else {
}
if(cljs.core.truth_((typeof HTMLCollection != 'undefined'))){
HTMLCollection.prototype.cljs$core$ICounted$ = cljs.core.PROTOCOL_SENTINEL;

HTMLCollection.prototype.cljs$core$ICounted$_count$arity$1 = (function (coll){
var coll__$1 = this;
return coll__$1.length;
});

HTMLCollection.prototype.cljs$core$IIndexed$ = cljs.core.PROTOCOL_SENTINEL;

HTMLCollection.prototype.cljs$core$IIndexed$_nth$arity$2 = (function (coll,n){
var coll__$1 = this;
return coll__$1.item(n);
});

HTMLCollection.prototype.cljs$core$IIndexed$_nth$arity$3 = (function (coll,n,not_found){
var coll__$1 = this;
if((coll__$1.length <= n)){
return not_found;
} else {
return cljs.core.nth.cljs$core$IFn$_invoke$arity$2(coll__$1,n);
}
});

HTMLCollection.prototype.cljs$core$ISeqable$ = cljs.core.PROTOCOL_SENTINEL;

HTMLCollection.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (coll){
var coll__$1 = this;
return domina.lazy_nodelist(coll__$1);
});
} else {
}

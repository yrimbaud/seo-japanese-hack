// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('dommy.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('clojure.string');
goog.require('dommy.utils');
/**
 * Returns a selector in string format.
 * Accepts string, keyword, or collection.
 */
dommy.core.selector = (function dommy$core$selector(data){
if(cljs.core.coll_QMARK_(data)){
return clojure.string.join.cljs$core$IFn$_invoke$arity$2(" ",cljs.core.map.cljs$core$IFn$_invoke$arity$2(dommy.core.selector,data));
} else {
if(((typeof data === 'string') || ((data instanceof cljs.core.Keyword)))){
return cljs.core.name(data);
} else {
return null;
}
}
});
dommy.core.text = (function dommy$core$text(elem){
var or__4131__auto__ = elem.textContent;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return elem.innerText;
}
});
dommy.core.html = (function dommy$core$html(elem){
return elem.innerHTML;
});
dommy.core.value = (function dommy$core$value(elem){
return elem.value;
});
dommy.core.class$ = (function dommy$core$class(elem){
return elem.className;
});
dommy.core.attr = (function dommy$core$attr(elem,k){
if(cljs.core.truth_(k)){
return elem.getAttribute(dommy.utils.as_str(k));
} else {
return null;
}
});
/**
 * The computed style of `elem`, optionally specifying the key of
 * a particular style to return
 */
dommy.core.style = (function dommy$core$style(var_args){
var G__43512 = arguments.length;
switch (G__43512) {
case 1:
return dommy.core.style.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return dommy.core.style.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.style.cljs$core$IFn$_invoke$arity$1 = (function (elem){
return cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(window.getComputedStyle(elem));
});

dommy.core.style.cljs$core$IFn$_invoke$arity$2 = (function (elem,k){
return (window.getComputedStyle(elem)[dommy.utils.as_str(k)]);
});

dommy.core.style.cljs$lang$maxFixedArity = 2;

dommy.core.px = (function dommy$core$px(elem,k){

var pixels = dommy.core.style.cljs$core$IFn$_invoke$arity$2(elem,k);
if(cljs.core.seq(pixels)){
return parseInt(pixels);
} else {
return null;
}
});
/**
 * Does `elem` contain `c` in its class list
 */
dommy.core.has_class_QMARK_ = (function dommy$core$has_class_QMARK_(elem,c){
var c__$1 = dommy.utils.as_str(c);
var temp__5733__auto__ = elem.classList;
if(cljs.core.truth_(temp__5733__auto__)){
var class_list = temp__5733__auto__;
return class_list.contains(c__$1);
} else {
var temp__5735__auto__ = dommy.core.class$(elem);
if(cljs.core.truth_(temp__5735__auto__)){
var class_name = temp__5735__auto__;
var temp__5735__auto____$1 = dommy.utils.class_index(class_name,c__$1);
if(cljs.core.truth_(temp__5735__auto____$1)){
var i = temp__5735__auto____$1;
return (i >= (0));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Is `elem` hidden (as associated with hide!/show!/toggle!, using display: none)
 */
dommy.core.hidden_QMARK_ = (function dommy$core$hidden_QMARK_(elem){
return (dommy.core.style.cljs$core$IFn$_invoke$arity$2(elem,cljs.core.cst$kw$display) === "none");
});
/**
 * Returns a map of the bounding client rect of `elem`
 * as a map with [:top :left :right :bottom :width :height]
 */
dommy.core.bounding_client_rect = (function dommy$core$bounding_client_rect(elem){
var r = elem.getBoundingClientRect();
return new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$top,r.top,cljs.core.cst$kw$bottom,r.bottom,cljs.core.cst$kw$left,r.left,cljs.core.cst$kw$right,r.right,cljs.core.cst$kw$width,r.width,cljs.core.cst$kw$height,r.height], null);
});
dommy.core.parent = (function dommy$core$parent(elem){
return elem.parentNode;
});
dommy.core.children = (function dommy$core$children(elem){
return elem.children;
});
/**
 * Lazy seq of the ancestors of `elem`
 */
dommy.core.ancestors = (function dommy$core$ancestors(elem){
return cljs.core.take_while.cljs$core$IFn$_invoke$arity$2(cljs.core.identity,cljs.core.iterate(dommy.core.parent,elem));
});
dommy.core.ancestor_nodes = dommy.core.ancestors;
/**
 * Returns a predicate on nodes that match `selector` at the
 * time of this `matches-pred` call (may return outdated results
 * if you fuck with the DOM)
 */
dommy.core.matches_pred = (function dommy$core$matches_pred(var_args){
var G__43515 = arguments.length;
switch (G__43515) {
case 2:
return dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 1:
return dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$2 = (function (base,selector){
var matches = dommy.utils.__GT_Array(base.querySelectorAll(dommy.core.selector(selector)));
return ((function (matches){
return (function (elem){
return (matches.indexOf(elem) >= (0));
});
;})(matches))
});

dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$1 = (function (selector){
return dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$2(document,selector);
});

dommy.core.matches_pred.cljs$lang$maxFixedArity = 2;

/**
 * Closest ancestor of `elem` (up to `base`, if provided)
 * that matches `selector`
 */
dommy.core.closest = (function dommy$core$closest(var_args){
var G__43519 = arguments.length;
switch (G__43519) {
case 3:
return dommy.core.closest.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 2:
return dommy.core.closest.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.closest.cljs$core$IFn$_invoke$arity$3 = (function (base,elem,selector){
return cljs.core.first(cljs.core.filter.cljs$core$IFn$_invoke$arity$2(dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$2(base,selector),cljs.core.take_while.cljs$core$IFn$_invoke$arity$2((function (p1__43517_SHARP_){
return (!((p1__43517_SHARP_ === base)));
}),dommy.core.ancestors(elem))));
});

dommy.core.closest.cljs$core$IFn$_invoke$arity$2 = (function (elem,selector){
return dommy.core.closest.cljs$core$IFn$_invoke$arity$3(document.body,elem,selector);
});

dommy.core.closest.cljs$lang$maxFixedArity = 3;

/**
 * Is `descendant` a descendant of `ancestor`?
 * (http://goo.gl/T8pgCX)
 */
dommy.core.descendant_QMARK_ = (function dommy$core$descendant_QMARK_(descendant,ancestor){
if(cljs.core.truth_(ancestor.contains)){
return ancestor.contains(descendant);
} else {
if(cljs.core.truth_(ancestor.compareDocumentPosition)){
return ((ancestor.compareDocumentPosition(descendant) & (1 << (4))) != 0);
} else {
return null;
}
}
});
/**
 * Set the textContent of `elem` to `text`, fall back to innerText
 */
dommy.core.set_text_BANG_ = (function dommy$core$set_text_BANG_(elem,text){
if((!((void 0 === elem.textContent)))){
elem.textContent = text;
} else {
elem.innerText = text;
}

return elem;
});
/**
 * Set the innerHTML of `elem` to `html`
 */
dommy.core.set_html_BANG_ = (function dommy$core$set_html_BANG_(elem,html){
elem.innerHTML = html;

return elem;
});
/**
 * Set the value of `elem` to `value`
 */
dommy.core.set_value_BANG_ = (function dommy$core$set_value_BANG_(elem,value){
elem.value = value;

return elem;
});
/**
 * Set the css class of `elem` to `elem`
 */
dommy.core.set_class_BANG_ = (function dommy$core$set_class_BANG_(elem,c){
return elem.className = c;
});
/**
 * Set the style of `elem` using key-value pairs:
 * 
 *    (set-style! elem :display "block" :color "red")
 */
dommy.core.set_style_BANG_ = (function dommy$core$set_style_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___43539 = arguments.length;
var i__4731__auto___43540 = (0);
while(true){
if((i__4731__auto___43540 < len__4730__auto___43539)){
args__4736__auto__.push((arguments[i__4731__auto___43540]));

var G__43541 = (i__4731__auto___43540 + (1));
i__4731__auto___43540 = G__43541;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,kvs){

var style = elem.style;
var seq__43523_43542 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),kvs));
var chunk__43524_43543 = null;
var count__43525_43544 = (0);
var i__43526_43545 = (0);
while(true){
if((i__43526_43545 < count__43525_43544)){
var vec__43533_43546 = chunk__43524_43543.cljs$core$IIndexed$_nth$arity$2(null,i__43526_43545);
var k_43547 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43533_43546,(0),null);
var v_43548 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43533_43546,(1),null);
style.setProperty(dommy.utils.as_str(k_43547),v_43548);


var G__43549 = seq__43523_43542;
var G__43550 = chunk__43524_43543;
var G__43551 = count__43525_43544;
var G__43552 = (i__43526_43545 + (1));
seq__43523_43542 = G__43549;
chunk__43524_43543 = G__43550;
count__43525_43544 = G__43551;
i__43526_43545 = G__43552;
continue;
} else {
var temp__5735__auto___43553 = cljs.core.seq(seq__43523_43542);
if(temp__5735__auto___43553){
var seq__43523_43554__$1 = temp__5735__auto___43553;
if(cljs.core.chunked_seq_QMARK_(seq__43523_43554__$1)){
var c__4550__auto___43555 = cljs.core.chunk_first(seq__43523_43554__$1);
var G__43556 = cljs.core.chunk_rest(seq__43523_43554__$1);
var G__43557 = c__4550__auto___43555;
var G__43558 = cljs.core.count(c__4550__auto___43555);
var G__43559 = (0);
seq__43523_43542 = G__43556;
chunk__43524_43543 = G__43557;
count__43525_43544 = G__43558;
i__43526_43545 = G__43559;
continue;
} else {
var vec__43536_43560 = cljs.core.first(seq__43523_43554__$1);
var k_43561 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43536_43560,(0),null);
var v_43562 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43536_43560,(1),null);
style.setProperty(dommy.utils.as_str(k_43561),v_43562);


var G__43563 = cljs.core.next(seq__43523_43554__$1);
var G__43564 = null;
var G__43565 = (0);
var G__43566 = (0);
seq__43523_43542 = G__43563;
chunk__43524_43543 = G__43564;
count__43525_43544 = G__43565;
i__43526_43545 = G__43566;
continue;
}
} else {
}
}
break;
}

return elem;
});

dommy.core.set_style_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
dommy.core.set_style_BANG_.cljs$lang$applyTo = (function (seq43521){
var G__43522 = cljs.core.first(seq43521);
var seq43521__$1 = cljs.core.next(seq43521);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__43522,seq43521__$1);
});

/**
 * Remove the style of `elem` using keywords:
 *   
 *    (remove-style! elem :display :color)
 */
dommy.core.remove_style_BANG_ = (function dommy$core$remove_style_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___43573 = arguments.length;
var i__4731__auto___43574 = (0);
while(true){
if((i__4731__auto___43574 < len__4730__auto___43573)){
args__4736__auto__.push((arguments[i__4731__auto___43574]));

var G__43575 = (i__4731__auto___43574 + (1));
i__4731__auto___43574 = G__43575;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return dommy.core.remove_style_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

dommy.core.remove_style_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,keywords){
var style = elem.style;
var seq__43569_43576 = cljs.core.seq(keywords);
var chunk__43570_43577 = null;
var count__43571_43578 = (0);
var i__43572_43579 = (0);
while(true){
if((i__43572_43579 < count__43571_43578)){
var kw_43580 = chunk__43570_43577.cljs$core$IIndexed$_nth$arity$2(null,i__43572_43579);
style.removeProperty(dommy.utils.as_str(kw_43580));


var G__43581 = seq__43569_43576;
var G__43582 = chunk__43570_43577;
var G__43583 = count__43571_43578;
var G__43584 = (i__43572_43579 + (1));
seq__43569_43576 = G__43581;
chunk__43570_43577 = G__43582;
count__43571_43578 = G__43583;
i__43572_43579 = G__43584;
continue;
} else {
var temp__5735__auto___43585 = cljs.core.seq(seq__43569_43576);
if(temp__5735__auto___43585){
var seq__43569_43586__$1 = temp__5735__auto___43585;
if(cljs.core.chunked_seq_QMARK_(seq__43569_43586__$1)){
var c__4550__auto___43587 = cljs.core.chunk_first(seq__43569_43586__$1);
var G__43588 = cljs.core.chunk_rest(seq__43569_43586__$1);
var G__43589 = c__4550__auto___43587;
var G__43590 = cljs.core.count(c__4550__auto___43587);
var G__43591 = (0);
seq__43569_43576 = G__43588;
chunk__43570_43577 = G__43589;
count__43571_43578 = G__43590;
i__43572_43579 = G__43591;
continue;
} else {
var kw_43592 = cljs.core.first(seq__43569_43586__$1);
style.removeProperty(dommy.utils.as_str(kw_43592));


var G__43593 = cljs.core.next(seq__43569_43586__$1);
var G__43594 = null;
var G__43595 = (0);
var G__43596 = (0);
seq__43569_43576 = G__43593;
chunk__43570_43577 = G__43594;
count__43571_43578 = G__43595;
i__43572_43579 = G__43596;
continue;
}
} else {
}
}
break;
}

return elem;
});

dommy.core.remove_style_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
dommy.core.remove_style_BANG_.cljs$lang$applyTo = (function (seq43567){
var G__43568 = cljs.core.first(seq43567);
var seq43567__$1 = cljs.core.next(seq43567);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__43568,seq43567__$1);
});

dommy.core.set_px_BANG_ = (function dommy$core$set_px_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___43615 = arguments.length;
var i__4731__auto___43616 = (0);
while(true){
if((i__4731__auto___43616 < len__4730__auto___43615)){
args__4736__auto__.push((arguments[i__4731__auto___43616]));

var G__43617 = (i__4731__auto___43616 + (1));
i__4731__auto___43616 = G__43617;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return dommy.core.set_px_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

dommy.core.set_px_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,kvs){


var seq__43599_43618 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),kvs));
var chunk__43600_43619 = null;
var count__43601_43620 = (0);
var i__43602_43621 = (0);
while(true){
if((i__43602_43621 < count__43601_43620)){
var vec__43609_43622 = chunk__43600_43619.cljs$core$IIndexed$_nth$arity$2(null,i__43602_43621);
var k_43623 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43609_43622,(0),null);
var v_43624 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43609_43622,(1),null);
dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([k_43623,[cljs.core.str.cljs$core$IFn$_invoke$arity$1(v_43624),"px"].join('')], 0));


var G__43625 = seq__43599_43618;
var G__43626 = chunk__43600_43619;
var G__43627 = count__43601_43620;
var G__43628 = (i__43602_43621 + (1));
seq__43599_43618 = G__43625;
chunk__43600_43619 = G__43626;
count__43601_43620 = G__43627;
i__43602_43621 = G__43628;
continue;
} else {
var temp__5735__auto___43629 = cljs.core.seq(seq__43599_43618);
if(temp__5735__auto___43629){
var seq__43599_43630__$1 = temp__5735__auto___43629;
if(cljs.core.chunked_seq_QMARK_(seq__43599_43630__$1)){
var c__4550__auto___43631 = cljs.core.chunk_first(seq__43599_43630__$1);
var G__43632 = cljs.core.chunk_rest(seq__43599_43630__$1);
var G__43633 = c__4550__auto___43631;
var G__43634 = cljs.core.count(c__4550__auto___43631);
var G__43635 = (0);
seq__43599_43618 = G__43632;
chunk__43600_43619 = G__43633;
count__43601_43620 = G__43634;
i__43602_43621 = G__43635;
continue;
} else {
var vec__43612_43636 = cljs.core.first(seq__43599_43630__$1);
var k_43637 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43612_43636,(0),null);
var v_43638 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43612_43636,(1),null);
dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([k_43637,[cljs.core.str.cljs$core$IFn$_invoke$arity$1(v_43638),"px"].join('')], 0));


var G__43639 = cljs.core.next(seq__43599_43630__$1);
var G__43640 = null;
var G__43641 = (0);
var G__43642 = (0);
seq__43599_43618 = G__43639;
chunk__43600_43619 = G__43640;
count__43601_43620 = G__43641;
i__43602_43621 = G__43642;
continue;
}
} else {
}
}
break;
}

return elem;
});

dommy.core.set_px_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
dommy.core.set_px_BANG_.cljs$lang$applyTo = (function (seq43597){
var G__43598 = cljs.core.first(seq43597);
var seq43597__$1 = cljs.core.next(seq43597);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__43598,seq43597__$1);
});

/**
 * Sets dom attributes on and returns `elem`.
 * Attributes without values will be set to their name:
 * 
 *     (set-attr! elem :disabled)
 * 
 * With values, the function takes variadic kv pairs:
 * 
 *     (set-attr! elem :id "some-id"
 *                     :name "some-name")
 */
dommy.core.set_attr_BANG_ = (function dommy$core$set_attr_BANG_(var_args){
var G__43648 = arguments.length;
switch (G__43648) {
case 2:
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
var args_arr__4751__auto__ = [];
var len__4730__auto___43668 = arguments.length;
var i__4731__auto___43669 = (0);
while(true){
if((i__4731__auto___43669 < len__4730__auto___43668)){
args_arr__4751__auto__.push((arguments[i__4731__auto___43669]));

var G__43670 = (i__4731__auto___43669 + (1));
i__4731__auto___43669 = G__43670;
continue;
} else {
}
break;
}

var argseq__4752__auto__ = (new cljs.core.IndexedSeq(args_arr__4751__auto__.slice((3)),(0),null));
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__4752__auto__);

}
});

dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,k){
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3(elem,k,dommy.utils.as_str(k));
});

dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (elem,k,v){
var k__$1 = dommy.utils.as_str(k);
if(cljs.core.truth_(v)){
if(cljs.core.fn_QMARK_(v)){
var G__43649 = elem;
(G__43649[k__$1] = v);

return G__43649;
} else {
var G__43650 = elem;
G__43650.setAttribute(k__$1,v);

return G__43650;
}
} else {
return null;
}
});

dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,k,v,kvs){

var seq__43651_43671 = cljs.core.seq(cljs.core.cons(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [k,v], null),cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),kvs)));
var chunk__43652_43672 = null;
var count__43653_43673 = (0);
var i__43654_43674 = (0);
while(true){
if((i__43654_43674 < count__43653_43673)){
var vec__43661_43675 = chunk__43652_43672.cljs$core$IIndexed$_nth$arity$2(null,i__43654_43674);
var k_43676__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43661_43675,(0),null);
var v_43677__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43661_43675,(1),null);
dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3(elem,k_43676__$1,v_43677__$1);


var G__43678 = seq__43651_43671;
var G__43679 = chunk__43652_43672;
var G__43680 = count__43653_43673;
var G__43681 = (i__43654_43674 + (1));
seq__43651_43671 = G__43678;
chunk__43652_43672 = G__43679;
count__43653_43673 = G__43680;
i__43654_43674 = G__43681;
continue;
} else {
var temp__5735__auto___43682 = cljs.core.seq(seq__43651_43671);
if(temp__5735__auto___43682){
var seq__43651_43683__$1 = temp__5735__auto___43682;
if(cljs.core.chunked_seq_QMARK_(seq__43651_43683__$1)){
var c__4550__auto___43684 = cljs.core.chunk_first(seq__43651_43683__$1);
var G__43685 = cljs.core.chunk_rest(seq__43651_43683__$1);
var G__43686 = c__4550__auto___43684;
var G__43687 = cljs.core.count(c__4550__auto___43684);
var G__43688 = (0);
seq__43651_43671 = G__43685;
chunk__43652_43672 = G__43686;
count__43653_43673 = G__43687;
i__43654_43674 = G__43688;
continue;
} else {
var vec__43664_43689 = cljs.core.first(seq__43651_43683__$1);
var k_43690__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43664_43689,(0),null);
var v_43691__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43664_43689,(1),null);
dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3(elem,k_43690__$1,v_43691__$1);


var G__43692 = cljs.core.next(seq__43651_43683__$1);
var G__43693 = null;
var G__43694 = (0);
var G__43695 = (0);
seq__43651_43671 = G__43692;
chunk__43652_43672 = G__43693;
count__43653_43673 = G__43694;
i__43654_43674 = G__43695;
continue;
}
} else {
}
}
break;
}

return elem;
});

/** @this {Function} */
dommy.core.set_attr_BANG_.cljs$lang$applyTo = (function (seq43644){
var G__43645 = cljs.core.first(seq43644);
var seq43644__$1 = cljs.core.next(seq43644);
var G__43646 = cljs.core.first(seq43644__$1);
var seq43644__$2 = cljs.core.next(seq43644__$1);
var G__43647 = cljs.core.first(seq43644__$2);
var seq43644__$3 = cljs.core.next(seq43644__$2);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__43645,G__43646,G__43647,seq43644__$3);
});

dommy.core.set_attr_BANG_.cljs$lang$maxFixedArity = (3);

/**
 * Removes dom attributes on and returns `elem`.
 * `class` and `classes` are special cases which clear
 * out the class name on removal.
 */
dommy.core.remove_attr_BANG_ = (function dommy$core$remove_attr_BANG_(var_args){
var G__43700 = arguments.length;
switch (G__43700) {
case 2:
return dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4751__auto__ = [];
var len__4730__auto___43707 = arguments.length;
var i__4731__auto___43708 = (0);
while(true){
if((i__4731__auto___43708 < len__4730__auto___43707)){
args_arr__4751__auto__.push((arguments[i__4731__auto___43708]));

var G__43709 = (i__4731__auto___43708 + (1));
i__4731__auto___43708 = G__43709;
continue;
} else {
}
break;
}

var argseq__4752__auto__ = (new cljs.core.IndexedSeq(args_arr__4751__auto__.slice((2)),(0),null));
return dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4752__auto__);

}
});

dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,k){
var k_43710__$1 = dommy.utils.as_str(k);
if(cljs.core.truth_((function (){var fexpr__43701 = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, ["class",null,"classes",null], null), null);
return (fexpr__43701.cljs$core$IFn$_invoke$arity$1 ? fexpr__43701.cljs$core$IFn$_invoke$arity$1(k_43710__$1) : fexpr__43701.call(null,k_43710__$1));
})())){
dommy.core.set_class_BANG_(elem,"");
} else {
elem.removeAttribute(k_43710__$1);
}

return elem;
});

dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,k,ks){
var seq__43702_43711 = cljs.core.seq(cljs.core.cons(k,ks));
var chunk__43703_43712 = null;
var count__43704_43713 = (0);
var i__43705_43714 = (0);
while(true){
if((i__43705_43714 < count__43704_43713)){
var k_43715__$1 = chunk__43703_43712.cljs$core$IIndexed$_nth$arity$2(null,i__43705_43714);
dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2(elem,k_43715__$1);


var G__43716 = seq__43702_43711;
var G__43717 = chunk__43703_43712;
var G__43718 = count__43704_43713;
var G__43719 = (i__43705_43714 + (1));
seq__43702_43711 = G__43716;
chunk__43703_43712 = G__43717;
count__43704_43713 = G__43718;
i__43705_43714 = G__43719;
continue;
} else {
var temp__5735__auto___43720 = cljs.core.seq(seq__43702_43711);
if(temp__5735__auto___43720){
var seq__43702_43721__$1 = temp__5735__auto___43720;
if(cljs.core.chunked_seq_QMARK_(seq__43702_43721__$1)){
var c__4550__auto___43722 = cljs.core.chunk_first(seq__43702_43721__$1);
var G__43723 = cljs.core.chunk_rest(seq__43702_43721__$1);
var G__43724 = c__4550__auto___43722;
var G__43725 = cljs.core.count(c__4550__auto___43722);
var G__43726 = (0);
seq__43702_43711 = G__43723;
chunk__43703_43712 = G__43724;
count__43704_43713 = G__43725;
i__43705_43714 = G__43726;
continue;
} else {
var k_43727__$1 = cljs.core.first(seq__43702_43721__$1);
dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2(elem,k_43727__$1);


var G__43728 = cljs.core.next(seq__43702_43721__$1);
var G__43729 = null;
var G__43730 = (0);
var G__43731 = (0);
seq__43702_43711 = G__43728;
chunk__43703_43712 = G__43729;
count__43704_43713 = G__43730;
i__43705_43714 = G__43731;
continue;
}
} else {
}
}
break;
}

return elem;
});

/** @this {Function} */
dommy.core.remove_attr_BANG_.cljs$lang$applyTo = (function (seq43697){
var G__43698 = cljs.core.first(seq43697);
var seq43697__$1 = cljs.core.next(seq43697);
var G__43699 = cljs.core.first(seq43697__$1);
var seq43697__$2 = cljs.core.next(seq43697__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__43698,G__43699,seq43697__$2);
});

dommy.core.remove_attr_BANG_.cljs$lang$maxFixedArity = (2);

/**
 * Toggles a dom attribute `k` on `elem`, optionally specifying
 * the boolean value with `add?`
 */
dommy.core.toggle_attr_BANG_ = (function dommy$core$toggle_attr_BANG_(var_args){
var G__43733 = arguments.length;
switch (G__43733) {
case 2:
return dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,k){
return dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$3(elem,k,cljs.core.boolean$(dommy.core.attr(elem,k)));
});

dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (elem,k,add_QMARK_){
if(add_QMARK_){
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$2(elem,k);
} else {
return dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2(elem,k);
}
});

dommy.core.toggle_attr_BANG_.cljs$lang$maxFixedArity = 3;

/**
 * Add `classes` to `elem`, trying to use Element::classList, and
 * falling back to fast string parsing/manipulation
 */
dommy.core.add_class_BANG_ = (function dommy$core$add_class_BANG_(var_args){
var G__43739 = arguments.length;
switch (G__43739) {
case 2:
return dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4751__auto__ = [];
var len__4730__auto___43753 = arguments.length;
var i__4731__auto___43754 = (0);
while(true){
if((i__4731__auto___43754 < len__4730__auto___43753)){
args_arr__4751__auto__.push((arguments[i__4731__auto___43754]));

var G__43755 = (i__4731__auto___43754 + (1));
i__4731__auto___43754 = G__43755;
continue;
} else {
}
break;
}

var argseq__4752__auto__ = (new cljs.core.IndexedSeq(args_arr__4751__auto__.slice((2)),(0),null));
return dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4752__auto__);

}
});

dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,classes){
var classes__$1 = clojure.string.trim(dommy.utils.as_str(classes)).split(/\s+/);
if(cljs.core.seq(classes__$1)){
var temp__5733__auto___43756 = elem.classList;
if(cljs.core.truth_(temp__5733__auto___43756)){
var class_list_43757 = temp__5733__auto___43756;
var seq__43740_43758 = cljs.core.seq(classes__$1);
var chunk__43741_43759 = null;
var count__43742_43760 = (0);
var i__43743_43761 = (0);
while(true){
if((i__43743_43761 < count__43742_43760)){
var c_43762 = chunk__43741_43759.cljs$core$IIndexed$_nth$arity$2(null,i__43743_43761);
class_list_43757.add(c_43762);


var G__43763 = seq__43740_43758;
var G__43764 = chunk__43741_43759;
var G__43765 = count__43742_43760;
var G__43766 = (i__43743_43761 + (1));
seq__43740_43758 = G__43763;
chunk__43741_43759 = G__43764;
count__43742_43760 = G__43765;
i__43743_43761 = G__43766;
continue;
} else {
var temp__5735__auto___43767 = cljs.core.seq(seq__43740_43758);
if(temp__5735__auto___43767){
var seq__43740_43768__$1 = temp__5735__auto___43767;
if(cljs.core.chunked_seq_QMARK_(seq__43740_43768__$1)){
var c__4550__auto___43769 = cljs.core.chunk_first(seq__43740_43768__$1);
var G__43770 = cljs.core.chunk_rest(seq__43740_43768__$1);
var G__43771 = c__4550__auto___43769;
var G__43772 = cljs.core.count(c__4550__auto___43769);
var G__43773 = (0);
seq__43740_43758 = G__43770;
chunk__43741_43759 = G__43771;
count__43742_43760 = G__43772;
i__43743_43761 = G__43773;
continue;
} else {
var c_43774 = cljs.core.first(seq__43740_43768__$1);
class_list_43757.add(c_43774);


var G__43775 = cljs.core.next(seq__43740_43768__$1);
var G__43776 = null;
var G__43777 = (0);
var G__43778 = (0);
seq__43740_43758 = G__43775;
chunk__43741_43759 = G__43776;
count__43742_43760 = G__43777;
i__43743_43761 = G__43778;
continue;
}
} else {
}
}
break;
}
} else {
var seq__43744_43779 = cljs.core.seq(classes__$1);
var chunk__43745_43780 = null;
var count__43746_43781 = (0);
var i__43747_43782 = (0);
while(true){
if((i__43747_43782 < count__43746_43781)){
var c_43783 = chunk__43745_43780.cljs$core$IIndexed$_nth$arity$2(null,i__43747_43782);
var class_name_43784 = dommy.core.class$(elem);
if(cljs.core.truth_(dommy.utils.class_index(class_name_43784,c_43783))){
} else {
dommy.core.set_class_BANG_(elem,(((class_name_43784 === ""))?c_43783:[cljs.core.str.cljs$core$IFn$_invoke$arity$1(class_name_43784)," ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(c_43783)].join('')));
}


var G__43785 = seq__43744_43779;
var G__43786 = chunk__43745_43780;
var G__43787 = count__43746_43781;
var G__43788 = (i__43747_43782 + (1));
seq__43744_43779 = G__43785;
chunk__43745_43780 = G__43786;
count__43746_43781 = G__43787;
i__43747_43782 = G__43788;
continue;
} else {
var temp__5735__auto___43789 = cljs.core.seq(seq__43744_43779);
if(temp__5735__auto___43789){
var seq__43744_43790__$1 = temp__5735__auto___43789;
if(cljs.core.chunked_seq_QMARK_(seq__43744_43790__$1)){
var c__4550__auto___43791 = cljs.core.chunk_first(seq__43744_43790__$1);
var G__43792 = cljs.core.chunk_rest(seq__43744_43790__$1);
var G__43793 = c__4550__auto___43791;
var G__43794 = cljs.core.count(c__4550__auto___43791);
var G__43795 = (0);
seq__43744_43779 = G__43792;
chunk__43745_43780 = G__43793;
count__43746_43781 = G__43794;
i__43747_43782 = G__43795;
continue;
} else {
var c_43796 = cljs.core.first(seq__43744_43790__$1);
var class_name_43797 = dommy.core.class$(elem);
if(cljs.core.truth_(dommy.utils.class_index(class_name_43797,c_43796))){
} else {
dommy.core.set_class_BANG_(elem,(((class_name_43797 === ""))?c_43796:[cljs.core.str.cljs$core$IFn$_invoke$arity$1(class_name_43797)," ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(c_43796)].join('')));
}


var G__43798 = cljs.core.next(seq__43744_43790__$1);
var G__43799 = null;
var G__43800 = (0);
var G__43801 = (0);
seq__43744_43779 = G__43798;
chunk__43745_43780 = G__43799;
count__43746_43781 = G__43800;
i__43747_43782 = G__43801;
continue;
}
} else {
}
}
break;
}
}
} else {
}

return elem;
});

dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,classes,more_classes){
var seq__43748_43802 = cljs.core.seq(cljs.core.conj.cljs$core$IFn$_invoke$arity$2(more_classes,classes));
var chunk__43749_43803 = null;
var count__43750_43804 = (0);
var i__43751_43805 = (0);
while(true){
if((i__43751_43805 < count__43750_43804)){
var c_43806 = chunk__43749_43803.cljs$core$IIndexed$_nth$arity$2(null,i__43751_43805);
dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,c_43806);


var G__43807 = seq__43748_43802;
var G__43808 = chunk__43749_43803;
var G__43809 = count__43750_43804;
var G__43810 = (i__43751_43805 + (1));
seq__43748_43802 = G__43807;
chunk__43749_43803 = G__43808;
count__43750_43804 = G__43809;
i__43751_43805 = G__43810;
continue;
} else {
var temp__5735__auto___43811 = cljs.core.seq(seq__43748_43802);
if(temp__5735__auto___43811){
var seq__43748_43812__$1 = temp__5735__auto___43811;
if(cljs.core.chunked_seq_QMARK_(seq__43748_43812__$1)){
var c__4550__auto___43813 = cljs.core.chunk_first(seq__43748_43812__$1);
var G__43814 = cljs.core.chunk_rest(seq__43748_43812__$1);
var G__43815 = c__4550__auto___43813;
var G__43816 = cljs.core.count(c__4550__auto___43813);
var G__43817 = (0);
seq__43748_43802 = G__43814;
chunk__43749_43803 = G__43815;
count__43750_43804 = G__43816;
i__43751_43805 = G__43817;
continue;
} else {
var c_43818 = cljs.core.first(seq__43748_43812__$1);
dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,c_43818);


var G__43819 = cljs.core.next(seq__43748_43812__$1);
var G__43820 = null;
var G__43821 = (0);
var G__43822 = (0);
seq__43748_43802 = G__43819;
chunk__43749_43803 = G__43820;
count__43750_43804 = G__43821;
i__43751_43805 = G__43822;
continue;
}
} else {
}
}
break;
}

return elem;
});

/** @this {Function} */
dommy.core.add_class_BANG_.cljs$lang$applyTo = (function (seq43736){
var G__43737 = cljs.core.first(seq43736);
var seq43736__$1 = cljs.core.next(seq43736);
var G__43738 = cljs.core.first(seq43736__$1);
var seq43736__$2 = cljs.core.next(seq43736__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__43737,G__43738,seq43736__$2);
});

dommy.core.add_class_BANG_.cljs$lang$maxFixedArity = (2);

/**
 * Remove `c` from `elem` class list
 */
dommy.core.remove_class_BANG_ = (function dommy$core$remove_class_BANG_(var_args){
var G__43827 = arguments.length;
switch (G__43827) {
case 2:
return dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4751__auto__ = [];
var len__4730__auto___43833 = arguments.length;
var i__4731__auto___43834 = (0);
while(true){
if((i__4731__auto___43834 < len__4730__auto___43833)){
args_arr__4751__auto__.push((arguments[i__4731__auto___43834]));

var G__43835 = (i__4731__auto___43834 + (1));
i__4731__auto___43834 = G__43835;
continue;
} else {
}
break;
}

var argseq__4752__auto__ = (new cljs.core.IndexedSeq(args_arr__4751__auto__.slice((2)),(0),null));
return dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4752__auto__);

}
});

dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,c){
var c__$1 = dommy.utils.as_str(c);
var temp__5733__auto___43836 = elem.classList;
if(cljs.core.truth_(temp__5733__auto___43836)){
var class_list_43837 = temp__5733__auto___43836;
class_list_43837.remove(c__$1);
} else {
var class_name_43838 = dommy.core.class$(elem);
var new_class_name_43839 = dommy.utils.remove_class_str(class_name_43838,c__$1);
if((class_name_43838 === new_class_name_43839)){
} else {
dommy.core.set_class_BANG_(elem,new_class_name_43839);
}
}

return elem;
});

dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,class$,classes){
var seq__43828 = cljs.core.seq(cljs.core.conj.cljs$core$IFn$_invoke$arity$2(classes,class$));
var chunk__43829 = null;
var count__43830 = (0);
var i__43831 = (0);
while(true){
if((i__43831 < count__43830)){
var c = chunk__43829.cljs$core$IIndexed$_nth$arity$2(null,i__43831);
dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,c);


var G__43840 = seq__43828;
var G__43841 = chunk__43829;
var G__43842 = count__43830;
var G__43843 = (i__43831 + (1));
seq__43828 = G__43840;
chunk__43829 = G__43841;
count__43830 = G__43842;
i__43831 = G__43843;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__43828);
if(temp__5735__auto__){
var seq__43828__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__43828__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__43828__$1);
var G__43844 = cljs.core.chunk_rest(seq__43828__$1);
var G__43845 = c__4550__auto__;
var G__43846 = cljs.core.count(c__4550__auto__);
var G__43847 = (0);
seq__43828 = G__43844;
chunk__43829 = G__43845;
count__43830 = G__43846;
i__43831 = G__43847;
continue;
} else {
var c = cljs.core.first(seq__43828__$1);
dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,c);


var G__43848 = cljs.core.next(seq__43828__$1);
var G__43849 = null;
var G__43850 = (0);
var G__43851 = (0);
seq__43828 = G__43848;
chunk__43829 = G__43849;
count__43830 = G__43850;
i__43831 = G__43851;
continue;
}
} else {
return null;
}
}
break;
}
});

/** @this {Function} */
dommy.core.remove_class_BANG_.cljs$lang$applyTo = (function (seq43824){
var G__43825 = cljs.core.first(seq43824);
var seq43824__$1 = cljs.core.next(seq43824);
var G__43826 = cljs.core.first(seq43824__$1);
var seq43824__$2 = cljs.core.next(seq43824__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__43825,G__43826,seq43824__$2);
});

dommy.core.remove_class_BANG_.cljs$lang$maxFixedArity = (2);

/**
 * (toggle-class! elem class) will add-class! if elem does not have class
 * and remove-class! otherwise.
 * (toggle-class! elem class add?) will add-class! if add? is truthy,
 * otherwise it will remove-class!
 */
dommy.core.toggle_class_BANG_ = (function dommy$core$toggle_class_BANG_(var_args){
var G__43853 = arguments.length;
switch (G__43853) {
case 2:
return dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,c){
var c__$1 = dommy.utils.as_str(c);
var temp__5733__auto___43855 = elem.classList;
if(cljs.core.truth_(temp__5733__auto___43855)){
var class_list_43856 = temp__5733__auto___43855;
class_list_43856.toggle(c__$1);
} else {
dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$3(elem,c__$1,(!(dommy.core.has_class_QMARK_(elem,c__$1))));
}

return elem;
});

dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (elem,class$,add_QMARK_){
if(add_QMARK_){
dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,class$);
} else {
dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,class$);
}

return elem;
});

dommy.core.toggle_class_BANG_.cljs$lang$maxFixedArity = 3;

/**
 * Display or hide the given `elem` (using display: none).
 * Takes an optional boolean `show?`
 */
dommy.core.toggle_BANG_ = (function dommy$core$toggle_BANG_(var_args){
var G__43858 = arguments.length;
switch (G__43858) {
case 2:
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 1:
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,show_QMARK_){
return dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([cljs.core.cst$kw$display,((show_QMARK_)?"":"none")], 0));
});

dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$1 = (function (elem){
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2(elem,dommy.core.hidden_QMARK_(elem));
});

dommy.core.toggle_BANG_.cljs$lang$maxFixedArity = 2;

dommy.core.hide_BANG_ = (function dommy$core$hide_BANG_(elem){
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2(elem,false);
});
dommy.core.show_BANG_ = (function dommy$core$show_BANG_(elem){
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2(elem,true);
});
dommy.core.scroll_into_view = (function dommy$core$scroll_into_view(elem,align_with_top_QMARK_){
var top = cljs.core.cst$kw$top.cljs$core$IFn$_invoke$arity$1(dommy.core.bounding_client_rect(elem));
if((window.innerHeight < (top + elem.offsetHeight))){
return elem.scrollIntoView(align_with_top_QMARK_);
} else {
return null;
}
});
dommy.core.create_element = (function dommy$core$create_element(var_args){
var G__43861 = arguments.length;
switch (G__43861) {
case 1:
return dommy.core.create_element.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return dommy.core.create_element.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.create_element.cljs$core$IFn$_invoke$arity$1 = (function (tag){
return document.createElement(dommy.utils.as_str(tag));
});

dommy.core.create_element.cljs$core$IFn$_invoke$arity$2 = (function (tag_ns,tag){
return document.createElementNS(dommy.utils.as_str(tag_ns),dommy.utils.as_str(tag));
});

dommy.core.create_element.cljs$lang$maxFixedArity = 2;

dommy.core.create_text_node = (function dommy$core$create_text_node(text){
return document.createTextNode(text);
});
/**
 * Clears all children from `elem`
 */
dommy.core.clear_BANG_ = (function dommy$core$clear_BANG_(elem){
return dommy.core.set_html_BANG_(elem,"");
});
/**
 * Append `child` to `parent`
 */
dommy.core.append_BANG_ = (function dommy$core$append_BANG_(var_args){
var G__43867 = arguments.length;
switch (G__43867) {
case 2:
return dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4751__auto__ = [];
var len__4730__auto___43874 = arguments.length;
var i__4731__auto___43875 = (0);
while(true){
if((i__4731__auto___43875 < len__4730__auto___43874)){
args_arr__4751__auto__.push((arguments[i__4731__auto___43875]));

var G__43876 = (i__4731__auto___43875 + (1));
i__4731__auto___43875 = G__43876;
continue;
} else {
}
break;
}

var argseq__4752__auto__ = (new cljs.core.IndexedSeq(args_arr__4751__auto__.slice((2)),(0),null));
return dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4752__auto__);

}
});

dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (parent,child){
var G__43868 = parent;
G__43868.appendChild(child);

return G__43868;
});

dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (parent,child,more_children){
var seq__43869_43877 = cljs.core.seq(cljs.core.cons(child,more_children));
var chunk__43870_43878 = null;
var count__43871_43879 = (0);
var i__43872_43880 = (0);
while(true){
if((i__43872_43880 < count__43871_43879)){
var c_43881 = chunk__43870_43878.cljs$core$IIndexed$_nth$arity$2(null,i__43872_43880);
dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2(parent,c_43881);


var G__43882 = seq__43869_43877;
var G__43883 = chunk__43870_43878;
var G__43884 = count__43871_43879;
var G__43885 = (i__43872_43880 + (1));
seq__43869_43877 = G__43882;
chunk__43870_43878 = G__43883;
count__43871_43879 = G__43884;
i__43872_43880 = G__43885;
continue;
} else {
var temp__5735__auto___43886 = cljs.core.seq(seq__43869_43877);
if(temp__5735__auto___43886){
var seq__43869_43887__$1 = temp__5735__auto___43886;
if(cljs.core.chunked_seq_QMARK_(seq__43869_43887__$1)){
var c__4550__auto___43888 = cljs.core.chunk_first(seq__43869_43887__$1);
var G__43889 = cljs.core.chunk_rest(seq__43869_43887__$1);
var G__43890 = c__4550__auto___43888;
var G__43891 = cljs.core.count(c__4550__auto___43888);
var G__43892 = (0);
seq__43869_43877 = G__43889;
chunk__43870_43878 = G__43890;
count__43871_43879 = G__43891;
i__43872_43880 = G__43892;
continue;
} else {
var c_43893 = cljs.core.first(seq__43869_43887__$1);
dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2(parent,c_43893);


var G__43894 = cljs.core.next(seq__43869_43887__$1);
var G__43895 = null;
var G__43896 = (0);
var G__43897 = (0);
seq__43869_43877 = G__43894;
chunk__43870_43878 = G__43895;
count__43871_43879 = G__43896;
i__43872_43880 = G__43897;
continue;
}
} else {
}
}
break;
}

return parent;
});

/** @this {Function} */
dommy.core.append_BANG_.cljs$lang$applyTo = (function (seq43864){
var G__43865 = cljs.core.first(seq43864);
var seq43864__$1 = cljs.core.next(seq43864);
var G__43866 = cljs.core.first(seq43864__$1);
var seq43864__$2 = cljs.core.next(seq43864__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__43865,G__43866,seq43864__$2);
});

dommy.core.append_BANG_.cljs$lang$maxFixedArity = (2);

/**
 * Prepend `child` to `parent`
 */
dommy.core.prepend_BANG_ = (function dommy$core$prepend_BANG_(var_args){
var G__43902 = arguments.length;
switch (G__43902) {
case 2:
return dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4751__auto__ = [];
var len__4730__auto___43909 = arguments.length;
var i__4731__auto___43910 = (0);
while(true){
if((i__4731__auto___43910 < len__4730__auto___43909)){
args_arr__4751__auto__.push((arguments[i__4731__auto___43910]));

var G__43911 = (i__4731__auto___43910 + (1));
i__4731__auto___43910 = G__43911;
continue;
} else {
}
break;
}

var argseq__4752__auto__ = (new cljs.core.IndexedSeq(args_arr__4751__auto__.slice((2)),(0),null));
return dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4752__auto__);

}
});

dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (parent,child){
var G__43903 = parent;
G__43903.insertBefore(child,parent.firstChild);

return G__43903;
});

dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (parent,child,more_children){
var seq__43904_43912 = cljs.core.seq(cljs.core.cons(child,more_children));
var chunk__43905_43913 = null;
var count__43906_43914 = (0);
var i__43907_43915 = (0);
while(true){
if((i__43907_43915 < count__43906_43914)){
var c_43916 = chunk__43905_43913.cljs$core$IIndexed$_nth$arity$2(null,i__43907_43915);
dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$2(parent,c_43916);


var G__43917 = seq__43904_43912;
var G__43918 = chunk__43905_43913;
var G__43919 = count__43906_43914;
var G__43920 = (i__43907_43915 + (1));
seq__43904_43912 = G__43917;
chunk__43905_43913 = G__43918;
count__43906_43914 = G__43919;
i__43907_43915 = G__43920;
continue;
} else {
var temp__5735__auto___43921 = cljs.core.seq(seq__43904_43912);
if(temp__5735__auto___43921){
var seq__43904_43922__$1 = temp__5735__auto___43921;
if(cljs.core.chunked_seq_QMARK_(seq__43904_43922__$1)){
var c__4550__auto___43923 = cljs.core.chunk_first(seq__43904_43922__$1);
var G__43924 = cljs.core.chunk_rest(seq__43904_43922__$1);
var G__43925 = c__4550__auto___43923;
var G__43926 = cljs.core.count(c__4550__auto___43923);
var G__43927 = (0);
seq__43904_43912 = G__43924;
chunk__43905_43913 = G__43925;
count__43906_43914 = G__43926;
i__43907_43915 = G__43927;
continue;
} else {
var c_43928 = cljs.core.first(seq__43904_43922__$1);
dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$2(parent,c_43928);


var G__43929 = cljs.core.next(seq__43904_43922__$1);
var G__43930 = null;
var G__43931 = (0);
var G__43932 = (0);
seq__43904_43912 = G__43929;
chunk__43905_43913 = G__43930;
count__43906_43914 = G__43931;
i__43907_43915 = G__43932;
continue;
}
} else {
}
}
break;
}

return parent;
});

/** @this {Function} */
dommy.core.prepend_BANG_.cljs$lang$applyTo = (function (seq43899){
var G__43900 = cljs.core.first(seq43899);
var seq43899__$1 = cljs.core.next(seq43899);
var G__43901 = cljs.core.first(seq43899__$1);
var seq43899__$2 = cljs.core.next(seq43899__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__43900,G__43901,seq43899__$2);
});

dommy.core.prepend_BANG_.cljs$lang$maxFixedArity = (2);

/**
 * Insert `elem` before `other`, `other` must have a parent
 */
dommy.core.insert_before_BANG_ = (function dommy$core$insert_before_BANG_(elem,other){
var p = dommy.core.parent(other);

p.insertBefore(elem,other);

return elem;
});
/**
 * Insert `elem` after `other`, `other` must have a parent
 */
dommy.core.insert_after_BANG_ = (function dommy$core$insert_after_BANG_(elem,other){
var temp__5733__auto___43933 = other.nextSibling;
if(cljs.core.truth_(temp__5733__auto___43933)){
var next_43934 = temp__5733__auto___43933;
dommy.core.insert_before_BANG_(elem,next_43934);
} else {
dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2(dommy.core.parent(other),elem);
}

return elem;
});
/**
 * Replace `elem` with `new`, return `new`
 */
dommy.core.replace_BANG_ = (function dommy$core$replace_BANG_(elem,new$){
var p = dommy.core.parent(elem);

p.replaceChild(new$,elem);

return new$;
});
/**
 * Replace children of `elem` with `child`
 */
dommy.core.replace_contents_BANG_ = (function dommy$core$replace_contents_BANG_(p,child){
return dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2(dommy.core.clear_BANG_(p),child);
});
/**
 * Remove `elem` from `parent`, return `parent`
 */
dommy.core.remove_BANG_ = (function dommy$core$remove_BANG_(var_args){
var G__43936 = arguments.length;
switch (G__43936) {
case 1:
return dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$1 = (function (elem){
var p = dommy.core.parent(elem);

return dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$2(p,elem);
});

dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (p,elem){
var G__43937 = p;
G__43937.removeChild(elem);

return G__43937;
});

dommy.core.remove_BANG_.cljs$lang$maxFixedArity = 2;

dommy.core.special_listener_makers = cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p__43939){
var vec__43940 = p__43939;
var special_mouse_event = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43940,(0),null);
var real_mouse_event = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43940,(1),null);
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [special_mouse_event,cljs.core.PersistentArrayMap.createAsIfByAssoc([real_mouse_event,((function (vec__43940,special_mouse_event,real_mouse_event){
return (function (f){
return ((function (vec__43940,special_mouse_event,real_mouse_event){
return (function (event){
var related_target = event.relatedTarget;
var listener_target = (function (){var or__4131__auto__ = event.selectedTarget;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return event.currentTarget;
}
})();
if(cljs.core.truth_((function (){var and__4120__auto__ = related_target;
if(cljs.core.truth_(and__4120__auto__)){
return dommy.core.descendant_QMARK_(related_target,listener_target);
} else {
return and__4120__auto__;
}
})())){
return null;
} else {
return (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(event) : f.call(null,event));
}
});
;})(vec__43940,special_mouse_event,real_mouse_event))
});})(vec__43940,special_mouse_event,real_mouse_event))
])], null);
}),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$mouseenter,cljs.core.cst$kw$mouseover,cljs.core.cst$kw$mouseleave,cljs.core.cst$kw$mouseout], null)));
/**
 * fires f if event.target is found with `selector`
 */
dommy.core.live_listener = (function dommy$core$live_listener(elem,selector,f){
return (function (event){
var selected_target = dommy.core.closest.cljs$core$IFn$_invoke$arity$3(elem,event.target,selector);
if(cljs.core.truth_((function (){var and__4120__auto__ = selected_target;
if(cljs.core.truth_(and__4120__auto__)){
return cljs.core.not(dommy.core.attr(selected_target,cljs.core.cst$kw$disabled));
} else {
return and__4120__auto__;
}
})())){
event.selectedTarget = selected_target;

return (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(event) : f.call(null,event));
} else {
return null;
}
});
});
/**
 * Returns a nested map of event listeners on `elem`
 */
dommy.core.event_listeners = (function dommy$core$event_listeners(elem){
var or__4131__auto__ = elem.dommyEventListeners;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return cljs.core.PersistentArrayMap.EMPTY;
}
});
dommy.core.update_event_listeners_BANG_ = (function dommy$core$update_event_listeners_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___43946 = arguments.length;
var i__4731__auto___43947 = (0);
while(true){
if((i__4731__auto___43947 < len__4730__auto___43946)){
args__4736__auto__.push((arguments[i__4731__auto___43947]));

var G__43948 = (i__4731__auto___43947 + (1));
i__4731__auto___43947 = G__43948;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,f,args){
var elem__$1 = elem;
return elem__$1.dommyEventListeners = cljs.core.apply.cljs$core$IFn$_invoke$arity$3(f,dommy.core.event_listeners(elem__$1),args);
});

dommy.core.update_event_listeners_BANG_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
dommy.core.update_event_listeners_BANG_.cljs$lang$applyTo = (function (seq43943){
var G__43944 = cljs.core.first(seq43943);
var seq43943__$1 = cljs.core.next(seq43943);
var G__43945 = cljs.core.first(seq43943__$1);
var seq43943__$2 = cljs.core.next(seq43943__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__43944,G__43945,seq43943__$2);
});

dommy.core.elem_and_selector = (function dommy$core$elem_and_selector(elem_sel){
if(cljs.core.sequential_QMARK_(elem_sel)){
var fexpr__43949 = cljs.core.juxt.cljs$core$IFn$_invoke$arity$2(cljs.core.first,cljs.core.rest);
return (fexpr__43949.cljs$core$IFn$_invoke$arity$1 ? fexpr__43949.cljs$core$IFn$_invoke$arity$1(elem_sel) : fexpr__43949.call(null,elem_sel));
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [elem_sel,null], null);
}
});
/**
 * Adds `f` as a listener for events of type `event-type` on
 * `elem-sel`, which must either be a DOM node, or a sequence
 * whose first item is a DOM node.
 * 
 * In other words, the call to `listen!` can take two forms:
 * 
 * If `elem-sel` is a DOM node, i.e., you're doing something like:
 * 
 *     (listen! elem :click click-handler)
 * 
 * then `click-handler` will be set as a listener for `click` events
 * on the `elem`.
 * 
 * If `elem-sel` is a sequence:
 * 
 *     (listen! [elem :.selector.for :.some.descendants] :click click-handler)
 * 
 * then `click-handler` will be set as a listener for `click` events
 * on descendants of `elem` that match the selector
 * 
 * Also accepts any number of event-type and handler pairs for setting
 * multiple listeners at once:
 * 
 *     (listen! some-elem :click click-handler :hover hover-handler)
 */
dommy.core.listen_BANG_ = (function dommy$core$listen_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___44063 = arguments.length;
var i__4731__auto___44064 = (0);
while(true){
if((i__4731__auto___44064 < len__4730__auto___44063)){
args__4736__auto__.push((arguments[i__4731__auto___44064]));

var G__44065 = (i__4731__auto___44064 + (1));
i__4731__auto___44064 = G__44065;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return dommy.core.listen_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

dommy.core.listen_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem_sel,type_fs){

var vec__43952_44066 = dommy.core.elem_and_selector(elem_sel);
var elem_44067 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43952_44066,(0),null);
var selector_44068 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43952_44066,(1),null);
var seq__43955_44069 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),type_fs));
var chunk__43962_44070 = null;
var count__43963_44071 = (0);
var i__43964_44072 = (0);
while(true){
if((i__43964_44072 < count__43963_44071)){
var vec__44017_44073 = chunk__43962_44070.cljs$core$IIndexed$_nth$arity$2(null,i__43964_44072);
var orig_type_44074 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44017_44073,(0),null);
var f_44075 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44017_44073,(1),null);
var seq__43965_44076 = cljs.core.seq(cljs.core.get.cljs$core$IFn$_invoke$arity$3(dommy.core.special_listener_makers,orig_type_44074,cljs.core.PersistentArrayMap.createAsIfByAssoc([orig_type_44074,cljs.core.identity])));
var chunk__43967_44077 = null;
var count__43968_44078 = (0);
var i__43969_44079 = (0);
while(true){
if((i__43969_44079 < count__43968_44078)){
var vec__44030_44080 = chunk__43967_44077.cljs$core$IIndexed$_nth$arity$2(null,i__43969_44079);
var actual_type_44081 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44030_44080,(0),null);
var factory_44082 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44030_44080,(1),null);
var canonical_f_44083 = (function (){var G__44034 = (factory_44082.cljs$core$IFn$_invoke$arity$1 ? factory_44082.cljs$core$IFn$_invoke$arity$1(f_44075) : factory_44082.call(null,f_44075));
var fexpr__44033 = (cljs.core.truth_(selector_44068)?cljs.core.partial.cljs$core$IFn$_invoke$arity$3(dommy.core.live_listener,elem_44067,selector_44068):cljs.core.identity);
return (fexpr__44033.cljs$core$IFn$_invoke$arity$1 ? fexpr__44033.cljs$core$IFn$_invoke$arity$1(G__44034) : fexpr__44033.call(null,G__44034));
})();
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_44067,cljs.core.assoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_44068,actual_type_44081,f_44075], null),canonical_f_44083], 0));

if(cljs.core.truth_(elem_44067.addEventListener)){
elem_44067.addEventListener(cljs.core.name(actual_type_44081),canonical_f_44083);
} else {
elem_44067.attachEvent(cljs.core.name(actual_type_44081),canonical_f_44083);
}


var G__44084 = seq__43965_44076;
var G__44085 = chunk__43967_44077;
var G__44086 = count__43968_44078;
var G__44087 = (i__43969_44079 + (1));
seq__43965_44076 = G__44084;
chunk__43967_44077 = G__44085;
count__43968_44078 = G__44086;
i__43969_44079 = G__44087;
continue;
} else {
var temp__5735__auto___44088 = cljs.core.seq(seq__43965_44076);
if(temp__5735__auto___44088){
var seq__43965_44089__$1 = temp__5735__auto___44088;
if(cljs.core.chunked_seq_QMARK_(seq__43965_44089__$1)){
var c__4550__auto___44090 = cljs.core.chunk_first(seq__43965_44089__$1);
var G__44091 = cljs.core.chunk_rest(seq__43965_44089__$1);
var G__44092 = c__4550__auto___44090;
var G__44093 = cljs.core.count(c__4550__auto___44090);
var G__44094 = (0);
seq__43965_44076 = G__44091;
chunk__43967_44077 = G__44092;
count__43968_44078 = G__44093;
i__43969_44079 = G__44094;
continue;
} else {
var vec__44035_44095 = cljs.core.first(seq__43965_44089__$1);
var actual_type_44096 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44035_44095,(0),null);
var factory_44097 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44035_44095,(1),null);
var canonical_f_44098 = (function (){var G__44039 = (factory_44097.cljs$core$IFn$_invoke$arity$1 ? factory_44097.cljs$core$IFn$_invoke$arity$1(f_44075) : factory_44097.call(null,f_44075));
var fexpr__44038 = (cljs.core.truth_(selector_44068)?cljs.core.partial.cljs$core$IFn$_invoke$arity$3(dommy.core.live_listener,elem_44067,selector_44068):cljs.core.identity);
return (fexpr__44038.cljs$core$IFn$_invoke$arity$1 ? fexpr__44038.cljs$core$IFn$_invoke$arity$1(G__44039) : fexpr__44038.call(null,G__44039));
})();
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_44067,cljs.core.assoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_44068,actual_type_44096,f_44075], null),canonical_f_44098], 0));

if(cljs.core.truth_(elem_44067.addEventListener)){
elem_44067.addEventListener(cljs.core.name(actual_type_44096),canonical_f_44098);
} else {
elem_44067.attachEvent(cljs.core.name(actual_type_44096),canonical_f_44098);
}


var G__44099 = cljs.core.next(seq__43965_44089__$1);
var G__44100 = null;
var G__44101 = (0);
var G__44102 = (0);
seq__43965_44076 = G__44099;
chunk__43967_44077 = G__44100;
count__43968_44078 = G__44101;
i__43969_44079 = G__44102;
continue;
}
} else {
}
}
break;
}

var G__44103 = seq__43955_44069;
var G__44104 = chunk__43962_44070;
var G__44105 = count__43963_44071;
var G__44106 = (i__43964_44072 + (1));
seq__43955_44069 = G__44103;
chunk__43962_44070 = G__44104;
count__43963_44071 = G__44105;
i__43964_44072 = G__44106;
continue;
} else {
var temp__5735__auto___44107 = cljs.core.seq(seq__43955_44069);
if(temp__5735__auto___44107){
var seq__43955_44108__$1 = temp__5735__auto___44107;
if(cljs.core.chunked_seq_QMARK_(seq__43955_44108__$1)){
var c__4550__auto___44109 = cljs.core.chunk_first(seq__43955_44108__$1);
var G__44110 = cljs.core.chunk_rest(seq__43955_44108__$1);
var G__44111 = c__4550__auto___44109;
var G__44112 = cljs.core.count(c__4550__auto___44109);
var G__44113 = (0);
seq__43955_44069 = G__44110;
chunk__43962_44070 = G__44111;
count__43963_44071 = G__44112;
i__43964_44072 = G__44113;
continue;
} else {
var vec__44040_44114 = cljs.core.first(seq__43955_44108__$1);
var orig_type_44115 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44040_44114,(0),null);
var f_44116 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44040_44114,(1),null);
var seq__43956_44117 = cljs.core.seq(cljs.core.get.cljs$core$IFn$_invoke$arity$3(dommy.core.special_listener_makers,orig_type_44115,cljs.core.PersistentArrayMap.createAsIfByAssoc([orig_type_44115,cljs.core.identity])));
var chunk__43958_44118 = null;
var count__43959_44119 = (0);
var i__43960_44120 = (0);
while(true){
if((i__43960_44120 < count__43959_44119)){
var vec__44053_44121 = chunk__43958_44118.cljs$core$IIndexed$_nth$arity$2(null,i__43960_44120);
var actual_type_44122 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44053_44121,(0),null);
var factory_44123 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44053_44121,(1),null);
var canonical_f_44124 = (function (){var G__44057 = (factory_44123.cljs$core$IFn$_invoke$arity$1 ? factory_44123.cljs$core$IFn$_invoke$arity$1(f_44116) : factory_44123.call(null,f_44116));
var fexpr__44056 = (cljs.core.truth_(selector_44068)?cljs.core.partial.cljs$core$IFn$_invoke$arity$3(dommy.core.live_listener,elem_44067,selector_44068):cljs.core.identity);
return (fexpr__44056.cljs$core$IFn$_invoke$arity$1 ? fexpr__44056.cljs$core$IFn$_invoke$arity$1(G__44057) : fexpr__44056.call(null,G__44057));
})();
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_44067,cljs.core.assoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_44068,actual_type_44122,f_44116], null),canonical_f_44124], 0));

if(cljs.core.truth_(elem_44067.addEventListener)){
elem_44067.addEventListener(cljs.core.name(actual_type_44122),canonical_f_44124);
} else {
elem_44067.attachEvent(cljs.core.name(actual_type_44122),canonical_f_44124);
}


var G__44125 = seq__43956_44117;
var G__44126 = chunk__43958_44118;
var G__44127 = count__43959_44119;
var G__44128 = (i__43960_44120 + (1));
seq__43956_44117 = G__44125;
chunk__43958_44118 = G__44126;
count__43959_44119 = G__44127;
i__43960_44120 = G__44128;
continue;
} else {
var temp__5735__auto___44129__$1 = cljs.core.seq(seq__43956_44117);
if(temp__5735__auto___44129__$1){
var seq__43956_44130__$1 = temp__5735__auto___44129__$1;
if(cljs.core.chunked_seq_QMARK_(seq__43956_44130__$1)){
var c__4550__auto___44131 = cljs.core.chunk_first(seq__43956_44130__$1);
var G__44132 = cljs.core.chunk_rest(seq__43956_44130__$1);
var G__44133 = c__4550__auto___44131;
var G__44134 = cljs.core.count(c__4550__auto___44131);
var G__44135 = (0);
seq__43956_44117 = G__44132;
chunk__43958_44118 = G__44133;
count__43959_44119 = G__44134;
i__43960_44120 = G__44135;
continue;
} else {
var vec__44058_44136 = cljs.core.first(seq__43956_44130__$1);
var actual_type_44137 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44058_44136,(0),null);
var factory_44138 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44058_44136,(1),null);
var canonical_f_44139 = (function (){var G__44062 = (factory_44138.cljs$core$IFn$_invoke$arity$1 ? factory_44138.cljs$core$IFn$_invoke$arity$1(f_44116) : factory_44138.call(null,f_44116));
var fexpr__44061 = (cljs.core.truth_(selector_44068)?cljs.core.partial.cljs$core$IFn$_invoke$arity$3(dommy.core.live_listener,elem_44067,selector_44068):cljs.core.identity);
return (fexpr__44061.cljs$core$IFn$_invoke$arity$1 ? fexpr__44061.cljs$core$IFn$_invoke$arity$1(G__44062) : fexpr__44061.call(null,G__44062));
})();
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_44067,cljs.core.assoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_44068,actual_type_44137,f_44116], null),canonical_f_44139], 0));

if(cljs.core.truth_(elem_44067.addEventListener)){
elem_44067.addEventListener(cljs.core.name(actual_type_44137),canonical_f_44139);
} else {
elem_44067.attachEvent(cljs.core.name(actual_type_44137),canonical_f_44139);
}


var G__44140 = cljs.core.next(seq__43956_44130__$1);
var G__44141 = null;
var G__44142 = (0);
var G__44143 = (0);
seq__43956_44117 = G__44140;
chunk__43958_44118 = G__44141;
count__43959_44119 = G__44142;
i__43960_44120 = G__44143;
continue;
}
} else {
}
}
break;
}

var G__44144 = cljs.core.next(seq__43955_44108__$1);
var G__44145 = null;
var G__44146 = (0);
var G__44147 = (0);
seq__43955_44069 = G__44144;
chunk__43962_44070 = G__44145;
count__43963_44071 = G__44146;
i__43964_44072 = G__44147;
continue;
}
} else {
}
}
break;
}

return elem_sel;
});

dommy.core.listen_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
dommy.core.listen_BANG_.cljs$lang$applyTo = (function (seq43950){
var G__43951 = cljs.core.first(seq43950);
var seq43950__$1 = cljs.core.next(seq43950);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__43951,seq43950__$1);
});

/**
 * Removes event listener for the element defined in `elem-sel`,
 * which is the same format as listen!.
 * 
 *   The following forms are allowed, and will remove all handlers
 *   that match the parameters passed in:
 * 
 *    (unlisten! [elem :.selector] :click event-listener)
 * 
 *    (unlisten! [elem :.selector]
 *      :click event-listener
 *      :mouseover other-event-listener)
 */
dommy.core.unlisten_BANG_ = (function dommy$core$unlisten_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___44229 = arguments.length;
var i__4731__auto___44230 = (0);
while(true){
if((i__4731__auto___44230 < len__4730__auto___44229)){
args__4736__auto__.push((arguments[i__4731__auto___44230]));

var G__44231 = (i__4731__auto___44230 + (1));
i__4731__auto___44230 = G__44231;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return dommy.core.unlisten_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

dommy.core.unlisten_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem_sel,type_fs){

var vec__44150_44232 = dommy.core.elem_and_selector(elem_sel);
var elem_44233 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44150_44232,(0),null);
var selector_44234 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44150_44232,(1),null);
var seq__44153_44235 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),type_fs));
var chunk__44160_44236 = null;
var count__44161_44237 = (0);
var i__44162_44238 = (0);
while(true){
if((i__44162_44238 < count__44161_44237)){
var vec__44199_44239 = chunk__44160_44236.cljs$core$IIndexed$_nth$arity$2(null,i__44162_44238);
var orig_type_44240 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44199_44239,(0),null);
var f_44241 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44199_44239,(1),null);
var seq__44163_44242 = cljs.core.seq(cljs.core.get.cljs$core$IFn$_invoke$arity$3(dommy.core.special_listener_makers,orig_type_44240,cljs.core.PersistentArrayMap.createAsIfByAssoc([orig_type_44240,cljs.core.identity])));
var chunk__44165_44243 = null;
var count__44166_44244 = (0);
var i__44167_44245 = (0);
while(true){
if((i__44167_44245 < count__44166_44244)){
var vec__44208_44246 = chunk__44165_44243.cljs$core$IIndexed$_nth$arity$2(null,i__44167_44245);
var actual_type_44247 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44208_44246,(0),null);
var __44248 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44208_44246,(1),null);
var keys_44249 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_44234,actual_type_44247,f_44241], null);
var canonical_f_44250 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(dommy.core.event_listeners(elem_44233),keys_44249);
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_44233,dommy.utils.dissoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([keys_44249], 0));

if(cljs.core.truth_(elem_44233.removeEventListener)){
elem_44233.removeEventListener(cljs.core.name(actual_type_44247),canonical_f_44250);
} else {
elem_44233.detachEvent(cljs.core.name(actual_type_44247),canonical_f_44250);
}


var G__44251 = seq__44163_44242;
var G__44252 = chunk__44165_44243;
var G__44253 = count__44166_44244;
var G__44254 = (i__44167_44245 + (1));
seq__44163_44242 = G__44251;
chunk__44165_44243 = G__44252;
count__44166_44244 = G__44253;
i__44167_44245 = G__44254;
continue;
} else {
var temp__5735__auto___44255 = cljs.core.seq(seq__44163_44242);
if(temp__5735__auto___44255){
var seq__44163_44256__$1 = temp__5735__auto___44255;
if(cljs.core.chunked_seq_QMARK_(seq__44163_44256__$1)){
var c__4550__auto___44257 = cljs.core.chunk_first(seq__44163_44256__$1);
var G__44258 = cljs.core.chunk_rest(seq__44163_44256__$1);
var G__44259 = c__4550__auto___44257;
var G__44260 = cljs.core.count(c__4550__auto___44257);
var G__44261 = (0);
seq__44163_44242 = G__44258;
chunk__44165_44243 = G__44259;
count__44166_44244 = G__44260;
i__44167_44245 = G__44261;
continue;
} else {
var vec__44211_44262 = cljs.core.first(seq__44163_44256__$1);
var actual_type_44263 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44211_44262,(0),null);
var __44264 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44211_44262,(1),null);
var keys_44265 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_44234,actual_type_44263,f_44241], null);
var canonical_f_44266 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(dommy.core.event_listeners(elem_44233),keys_44265);
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_44233,dommy.utils.dissoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([keys_44265], 0));

if(cljs.core.truth_(elem_44233.removeEventListener)){
elem_44233.removeEventListener(cljs.core.name(actual_type_44263),canonical_f_44266);
} else {
elem_44233.detachEvent(cljs.core.name(actual_type_44263),canonical_f_44266);
}


var G__44267 = cljs.core.next(seq__44163_44256__$1);
var G__44268 = null;
var G__44269 = (0);
var G__44270 = (0);
seq__44163_44242 = G__44267;
chunk__44165_44243 = G__44268;
count__44166_44244 = G__44269;
i__44167_44245 = G__44270;
continue;
}
} else {
}
}
break;
}

var G__44271 = seq__44153_44235;
var G__44272 = chunk__44160_44236;
var G__44273 = count__44161_44237;
var G__44274 = (i__44162_44238 + (1));
seq__44153_44235 = G__44271;
chunk__44160_44236 = G__44272;
count__44161_44237 = G__44273;
i__44162_44238 = G__44274;
continue;
} else {
var temp__5735__auto___44275 = cljs.core.seq(seq__44153_44235);
if(temp__5735__auto___44275){
var seq__44153_44276__$1 = temp__5735__auto___44275;
if(cljs.core.chunked_seq_QMARK_(seq__44153_44276__$1)){
var c__4550__auto___44277 = cljs.core.chunk_first(seq__44153_44276__$1);
var G__44278 = cljs.core.chunk_rest(seq__44153_44276__$1);
var G__44279 = c__4550__auto___44277;
var G__44280 = cljs.core.count(c__4550__auto___44277);
var G__44281 = (0);
seq__44153_44235 = G__44278;
chunk__44160_44236 = G__44279;
count__44161_44237 = G__44280;
i__44162_44238 = G__44281;
continue;
} else {
var vec__44214_44282 = cljs.core.first(seq__44153_44276__$1);
var orig_type_44283 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44214_44282,(0),null);
var f_44284 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44214_44282,(1),null);
var seq__44154_44285 = cljs.core.seq(cljs.core.get.cljs$core$IFn$_invoke$arity$3(dommy.core.special_listener_makers,orig_type_44283,cljs.core.PersistentArrayMap.createAsIfByAssoc([orig_type_44283,cljs.core.identity])));
var chunk__44156_44286 = null;
var count__44157_44287 = (0);
var i__44158_44288 = (0);
while(true){
if((i__44158_44288 < count__44157_44287)){
var vec__44223_44289 = chunk__44156_44286.cljs$core$IIndexed$_nth$arity$2(null,i__44158_44288);
var actual_type_44290 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44223_44289,(0),null);
var __44291 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44223_44289,(1),null);
var keys_44292 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_44234,actual_type_44290,f_44284], null);
var canonical_f_44293 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(dommy.core.event_listeners(elem_44233),keys_44292);
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_44233,dommy.utils.dissoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([keys_44292], 0));

if(cljs.core.truth_(elem_44233.removeEventListener)){
elem_44233.removeEventListener(cljs.core.name(actual_type_44290),canonical_f_44293);
} else {
elem_44233.detachEvent(cljs.core.name(actual_type_44290),canonical_f_44293);
}


var G__44294 = seq__44154_44285;
var G__44295 = chunk__44156_44286;
var G__44296 = count__44157_44287;
var G__44297 = (i__44158_44288 + (1));
seq__44154_44285 = G__44294;
chunk__44156_44286 = G__44295;
count__44157_44287 = G__44296;
i__44158_44288 = G__44297;
continue;
} else {
var temp__5735__auto___44298__$1 = cljs.core.seq(seq__44154_44285);
if(temp__5735__auto___44298__$1){
var seq__44154_44299__$1 = temp__5735__auto___44298__$1;
if(cljs.core.chunked_seq_QMARK_(seq__44154_44299__$1)){
var c__4550__auto___44300 = cljs.core.chunk_first(seq__44154_44299__$1);
var G__44301 = cljs.core.chunk_rest(seq__44154_44299__$1);
var G__44302 = c__4550__auto___44300;
var G__44303 = cljs.core.count(c__4550__auto___44300);
var G__44304 = (0);
seq__44154_44285 = G__44301;
chunk__44156_44286 = G__44302;
count__44157_44287 = G__44303;
i__44158_44288 = G__44304;
continue;
} else {
var vec__44226_44305 = cljs.core.first(seq__44154_44299__$1);
var actual_type_44306 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44226_44305,(0),null);
var __44307 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44226_44305,(1),null);
var keys_44308 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_44234,actual_type_44306,f_44284], null);
var canonical_f_44309 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(dommy.core.event_listeners(elem_44233),keys_44308);
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_44233,dommy.utils.dissoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([keys_44308], 0));

if(cljs.core.truth_(elem_44233.removeEventListener)){
elem_44233.removeEventListener(cljs.core.name(actual_type_44306),canonical_f_44309);
} else {
elem_44233.detachEvent(cljs.core.name(actual_type_44306),canonical_f_44309);
}


var G__44310 = cljs.core.next(seq__44154_44299__$1);
var G__44311 = null;
var G__44312 = (0);
var G__44313 = (0);
seq__44154_44285 = G__44310;
chunk__44156_44286 = G__44311;
count__44157_44287 = G__44312;
i__44158_44288 = G__44313;
continue;
}
} else {
}
}
break;
}

var G__44314 = cljs.core.next(seq__44153_44276__$1);
var G__44315 = null;
var G__44316 = (0);
var G__44317 = (0);
seq__44153_44235 = G__44314;
chunk__44160_44236 = G__44315;
count__44161_44237 = G__44316;
i__44162_44238 = G__44317;
continue;
}
} else {
}
}
break;
}

return elem_sel;
});

dommy.core.unlisten_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
dommy.core.unlisten_BANG_.cljs$lang$applyTo = (function (seq44148){
var G__44149 = cljs.core.first(seq44148);
var seq44148__$1 = cljs.core.next(seq44148);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__44149,seq44148__$1);
});

/**
 * Behaves like `listen!`, but removes the listener after the first event occurs.
 */
dommy.core.listen_once_BANG_ = (function dommy$core$listen_once_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___44339 = arguments.length;
var i__4731__auto___44340 = (0);
while(true){
if((i__4731__auto___44340 < len__4730__auto___44339)){
args__4736__auto__.push((arguments[i__4731__auto___44340]));

var G__44341 = (i__4731__auto___44340 + (1));
i__4731__auto___44340 = G__44341;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return dommy.core.listen_once_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

dommy.core.listen_once_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem_sel,type_fs){

var vec__44320_44342 = dommy.core.elem_and_selector(elem_sel);
var elem_44343 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44320_44342,(0),null);
var selector_44344 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44320_44342,(1),null);
var seq__44323_44345 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),type_fs));
var chunk__44324_44346 = null;
var count__44325_44347 = (0);
var i__44326_44348 = (0);
while(true){
if((i__44326_44348 < count__44325_44347)){
var vec__44333_44349 = chunk__44324_44346.cljs$core$IIndexed$_nth$arity$2(null,i__44326_44348);
var type_44350 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44333_44349,(0),null);
var f_44351 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44333_44349,(1),null);
dommy.core.listen_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_sel,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([type_44350,((function (seq__44323_44345,chunk__44324_44346,count__44325_44347,i__44326_44348,vec__44333_44349,type_44350,f_44351,vec__44320_44342,elem_44343,selector_44344){
return (function dommy$core$this_fn(e){
dommy.core.unlisten_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_sel,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([type_44350,dommy$core$this_fn], 0));

return (f_44351.cljs$core$IFn$_invoke$arity$1 ? f_44351.cljs$core$IFn$_invoke$arity$1(e) : f_44351.call(null,e));
});})(seq__44323_44345,chunk__44324_44346,count__44325_44347,i__44326_44348,vec__44333_44349,type_44350,f_44351,vec__44320_44342,elem_44343,selector_44344))
], 0));


var G__44352 = seq__44323_44345;
var G__44353 = chunk__44324_44346;
var G__44354 = count__44325_44347;
var G__44355 = (i__44326_44348 + (1));
seq__44323_44345 = G__44352;
chunk__44324_44346 = G__44353;
count__44325_44347 = G__44354;
i__44326_44348 = G__44355;
continue;
} else {
var temp__5735__auto___44356 = cljs.core.seq(seq__44323_44345);
if(temp__5735__auto___44356){
var seq__44323_44357__$1 = temp__5735__auto___44356;
if(cljs.core.chunked_seq_QMARK_(seq__44323_44357__$1)){
var c__4550__auto___44358 = cljs.core.chunk_first(seq__44323_44357__$1);
var G__44359 = cljs.core.chunk_rest(seq__44323_44357__$1);
var G__44360 = c__4550__auto___44358;
var G__44361 = cljs.core.count(c__4550__auto___44358);
var G__44362 = (0);
seq__44323_44345 = G__44359;
chunk__44324_44346 = G__44360;
count__44325_44347 = G__44361;
i__44326_44348 = G__44362;
continue;
} else {
var vec__44336_44363 = cljs.core.first(seq__44323_44357__$1);
var type_44364 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44336_44363,(0),null);
var f_44365 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__44336_44363,(1),null);
dommy.core.listen_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_sel,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([type_44364,((function (seq__44323_44345,chunk__44324_44346,count__44325_44347,i__44326_44348,vec__44336_44363,type_44364,f_44365,seq__44323_44357__$1,temp__5735__auto___44356,vec__44320_44342,elem_44343,selector_44344){
return (function dommy$core$this_fn(e){
dommy.core.unlisten_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_sel,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([type_44364,dommy$core$this_fn], 0));

return (f_44365.cljs$core$IFn$_invoke$arity$1 ? f_44365.cljs$core$IFn$_invoke$arity$1(e) : f_44365.call(null,e));
});})(seq__44323_44345,chunk__44324_44346,count__44325_44347,i__44326_44348,vec__44336_44363,type_44364,f_44365,seq__44323_44357__$1,temp__5735__auto___44356,vec__44320_44342,elem_44343,selector_44344))
], 0));


var G__44366 = cljs.core.next(seq__44323_44357__$1);
var G__44367 = null;
var G__44368 = (0);
var G__44369 = (0);
seq__44323_44345 = G__44366;
chunk__44324_44346 = G__44367;
count__44325_44347 = G__44368;
i__44326_44348 = G__44369;
continue;
}
} else {
}
}
break;
}

return elem_sel;
});

dommy.core.listen_once_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
dommy.core.listen_once_BANG_.cljs$lang$applyTo = (function (seq44318){
var G__44319 = cljs.core.first(seq44318);
var seq44318__$1 = cljs.core.next(seq44318);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__44319,seq44318__$1);
});


// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('domina.events');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('domina');
goog.require('goog.object');
goog.require('goog.events');

/**
 * @interface
 */
domina.events.Event = function(){};

/**
 * Prevents the default action, for example a link redirecting to a URL
 */
domina.events.prevent_default = (function domina$events$prevent_default(evt){
if((((!((evt == null)))) && ((!((evt.domina$events$Event$prevent_default$arity$1 == null)))))){
return evt.domina$events$Event$prevent_default$arity$1(evt);
} else {
var x__4433__auto__ = (((evt == null))?null:evt);
var m__4434__auto__ = (domina.events.prevent_default[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(evt) : m__4434__auto__.call(null,evt));
} else {
var m__4431__auto__ = (domina.events.prevent_default["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(evt) : m__4431__auto__.call(null,evt));
} else {
throw cljs.core.missing_protocol("Event.prevent-default",evt);
}
}
}
});

/**
 * Stops event propagation
 */
domina.events.stop_propagation = (function domina$events$stop_propagation(evt){
if((((!((evt == null)))) && ((!((evt.domina$events$Event$stop_propagation$arity$1 == null)))))){
return evt.domina$events$Event$stop_propagation$arity$1(evt);
} else {
var x__4433__auto__ = (((evt == null))?null:evt);
var m__4434__auto__ = (domina.events.stop_propagation[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(evt) : m__4434__auto__.call(null,evt));
} else {
var m__4431__auto__ = (domina.events.stop_propagation["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(evt) : m__4431__auto__.call(null,evt));
} else {
throw cljs.core.missing_protocol("Event.stop-propagation",evt);
}
}
}
});

/**
 * Returns the target of the event
 */
domina.events.target = (function domina$events$target(evt){
if((((!((evt == null)))) && ((!((evt.domina$events$Event$target$arity$1 == null)))))){
return evt.domina$events$Event$target$arity$1(evt);
} else {
var x__4433__auto__ = (((evt == null))?null:evt);
var m__4434__auto__ = (domina.events.target[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(evt) : m__4434__auto__.call(null,evt));
} else {
var m__4431__auto__ = (domina.events.target["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(evt) : m__4431__auto__.call(null,evt));
} else {
throw cljs.core.missing_protocol("Event.target",evt);
}
}
}
});

/**
 * Returns the object that had the listener attached
 */
domina.events.current_target = (function domina$events$current_target(evt){
if((((!((evt == null)))) && ((!((evt.domina$events$Event$current_target$arity$1 == null)))))){
return evt.domina$events$Event$current_target$arity$1(evt);
} else {
var x__4433__auto__ = (((evt == null))?null:evt);
var m__4434__auto__ = (domina.events.current_target[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(evt) : m__4434__auto__.call(null,evt));
} else {
var m__4431__auto__ = (domina.events.current_target["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(evt) : m__4431__auto__.call(null,evt));
} else {
throw cljs.core.missing_protocol("Event.current-target",evt);
}
}
}
});

/**
 * Returns the type of the the event
 */
domina.events.event_type = (function domina$events$event_type(evt){
if((((!((evt == null)))) && ((!((evt.domina$events$Event$event_type$arity$1 == null)))))){
return evt.domina$events$Event$event_type$arity$1(evt);
} else {
var x__4433__auto__ = (((evt == null))?null:evt);
var m__4434__auto__ = (domina.events.event_type[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(evt) : m__4434__auto__.call(null,evt));
} else {
var m__4431__auto__ = (domina.events.event_type["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(evt) : m__4431__auto__.call(null,evt));
} else {
throw cljs.core.missing_protocol("Event.event-type",evt);
}
}
}
});

/**
 * Returns the original GClosure event
 */
domina.events.raw_event = (function domina$events$raw_event(evt){
if((((!((evt == null)))) && ((!((evt.domina$events$Event$raw_event$arity$1 == null)))))){
return evt.domina$events$Event$raw_event$arity$1(evt);
} else {
var x__4433__auto__ = (((evt == null))?null:evt);
var m__4434__auto__ = (domina.events.raw_event[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(evt) : m__4434__auto__.call(null,evt));
} else {
var m__4431__auto__ = (domina.events.raw_event["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(evt) : m__4431__auto__.call(null,evt));
} else {
throw cljs.core.missing_protocol("Event.raw-event",evt);
}
}
}
});

domina.events.root_element = window.document.documentElement;
domina.events.create_listener_function = (function domina$events$create_listener_function(f){
return (function (evt){
var G__43237_43241 = (function (){
if((typeof domina !== 'undefined') && (typeof domina.events !== 'undefined') && (typeof domina.events.t_domina$events43238 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {domina.events.Event}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
 * @implements {cljs.core.ILookup}
*/
domina.events.t_domina$events43238 = (function (f,evt,meta43239){
this.f = f;
this.evt = evt;
this.meta43239 = meta43239;
this.cljs$lang$protocol_mask$partition0$ = 393472;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
domina.events.t_domina$events43238.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_43240,meta43239__$1){
var self__ = this;
var _43240__$1 = this;
return (new domina.events.t_domina$events43238(self__.f,self__.evt,meta43239__$1));
});

domina.events.t_domina$events43238.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_43240){
var self__ = this;
var _43240__$1 = this;
return self__.meta43239;
});

domina.events.t_domina$events43238.prototype.domina$events$Event$ = cljs.core.PROTOCOL_SENTINEL;

domina.events.t_domina$events43238.prototype.domina$events$Event$prevent_default$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.evt.preventDefault();
});

domina.events.t_domina$events43238.prototype.domina$events$Event$stop_propagation$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.evt.stopPropagation();
});

domina.events.t_domina$events43238.prototype.domina$events$Event$target$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.evt.target;
});

domina.events.t_domina$events43238.prototype.domina$events$Event$current_target$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.evt.currentTarget;
});

domina.events.t_domina$events43238.prototype.domina$events$Event$event_type$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.evt.type;
});

domina.events.t_domina$events43238.prototype.domina$events$Event$raw_event$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.evt;
});

domina.events.t_domina$events43238.prototype.cljs$core$ILookup$_lookup$arity$2 = (function (o,k){
var self__ = this;
var o__$1 = this;
var temp__5733__auto__ = (self__.evt[k]);
if(cljs.core.truth_(temp__5733__auto__)){
var val = temp__5733__auto__;
return val;
} else {
return (self__.evt[cljs.core.name(k)]);
}
});

domina.events.t_domina$events43238.prototype.cljs$core$ILookup$_lookup$arity$3 = (function (o,k,not_found){
var self__ = this;
var o__$1 = this;
var or__4131__auto__ = o__$1.cljs$core$ILookup$_lookup$arity$2(null,k);
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return not_found;
}
});

domina.events.t_domina$events43238.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$evt,cljs.core.cst$sym$meta43239], null);
});

domina.events.t_domina$events43238.cljs$lang$type = true;

domina.events.t_domina$events43238.cljs$lang$ctorStr = "domina.events/t_domina$events43238";

domina.events.t_domina$events43238.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"domina.events/t_domina$events43238");
});

/**
 * Positional factory function for domina.events/t_domina$events43238.
 */
domina.events.__GT_t_domina$events43238 = (function domina$events$create_listener_function_$___GT_t_domina$events43238(f__$1,evt__$1,meta43239){
return (new domina.events.t_domina$events43238(f__$1,evt__$1,meta43239));
});

}

return (new domina.events.t_domina$events43238(f,evt,cljs.core.PersistentArrayMap.EMPTY));
})()
;
(f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(G__43237_43241) : f.call(null,G__43237_43241));

return true;
});
});
domina.events.listen_internal_BANG_ = (function domina$events$listen_internal_BANG_(content,type,listener,capture,once){
var f = domina.events.create_listener_function(listener);
var t = cljs.core.name(type);
return cljs.core.doall.cljs$core$IFn$_invoke$arity$1((function (){var iter__4523__auto__ = ((function (f,t){
return (function domina$events$listen_internal_BANG__$_iter__43242(s__43243){
return (new cljs.core.LazySeq(null,((function (f,t){
return (function (){
var s__43243__$1 = s__43243;
while(true){
var temp__5735__auto__ = cljs.core.seq(s__43243__$1);
if(temp__5735__auto__){
var s__43243__$2 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(s__43243__$2)){
var c__4521__auto__ = cljs.core.chunk_first(s__43243__$2);
var size__4522__auto__ = cljs.core.count(c__4521__auto__);
var b__43245 = cljs.core.chunk_buffer(size__4522__auto__);
if((function (){var i__43244 = (0);
while(true){
if((i__43244 < size__4522__auto__)){
var node = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(c__4521__auto__,i__43244);
cljs.core.chunk_append(b__43245,(cljs.core.truth_(once)?goog.events.listenOnce(node,t,f,capture):goog.events.listen(node,t,f,capture)));

var G__43246 = (i__43244 + (1));
i__43244 = G__43246;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__43245),domina$events$listen_internal_BANG__$_iter__43242(cljs.core.chunk_rest(s__43243__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__43245),null);
}
} else {
var node = cljs.core.first(s__43243__$2);
return cljs.core.cons((cljs.core.truth_(once)?goog.events.listenOnce(node,t,f,capture):goog.events.listen(node,t,f,capture)),domina$events$listen_internal_BANG__$_iter__43242(cljs.core.rest(s__43243__$2)));
}
} else {
return null;
}
break;
}
});})(f,t))
,null,null));
});})(f,t))
;
return iter__4523__auto__(domina.nodes(content));
})());
});
/**
 * Add an event listener to each node in a DomContent. Listens for events during the bubble phase. Returns a sequence of listener keys (one for each item in the content). If content is omitted, binds a listener to the document's root element.
 */
domina.events.listen_BANG_ = (function domina$events$listen_BANG_(var_args){
var G__43248 = arguments.length;
switch (G__43248) {
case 2:
return domina.events.listen_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return domina.events.listen_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

domina.events.listen_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (type,listener){
return domina.events.listen_BANG_.cljs$core$IFn$_invoke$arity$3(domina.events.root_element,type,listener);
});

domina.events.listen_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (content,type,listener){
return domina.events.listen_internal_BANG_(content,type,listener,false,false);
});

domina.events.listen_BANG_.cljs$lang$maxFixedArity = 3;

/**
 * Add an event listener to each node in a DomContent. Listens for events during the capture phase.  Returns a sequence of listener keys (one for each item in the content). If content is omitted, binds a listener to the document's root element.
 */
domina.events.capture_BANG_ = (function domina$events$capture_BANG_(var_args){
var G__43251 = arguments.length;
switch (G__43251) {
case 2:
return domina.events.capture_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return domina.events.capture_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

domina.events.capture_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (type,listener){
return domina.events.capture_BANG_.cljs$core$IFn$_invoke$arity$3(domina.events.root_element,type,listener);
});

domina.events.capture_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (content,type,listener){
return domina.events.listen_internal_BANG_(content,type,listener,true,false);
});

domina.events.capture_BANG_.cljs$lang$maxFixedArity = 3;

/**
 * Add an event listener to each node in a DomContent. Listens for events during the bubble phase. De-registers the listener after the first time it is invoked.  Returns a sequence of listener keys (one for each item in the content). If content is omitted, binds a listener to the document's root element.
 */
domina.events.listen_once_BANG_ = (function domina$events$listen_once_BANG_(var_args){
var G__43254 = arguments.length;
switch (G__43254) {
case 2:
return domina.events.listen_once_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return domina.events.listen_once_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

domina.events.listen_once_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (type,listener){
return domina.events.listen_once_BANG_.cljs$core$IFn$_invoke$arity$3(domina.events.root_element,type,listener);
});

domina.events.listen_once_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (content,type,listener){
return domina.events.listen_internal_BANG_(content,type,listener,false,true);
});

domina.events.listen_once_BANG_.cljs$lang$maxFixedArity = 3;

/**
 * Add an event listener to each node in a DomContent. Listens for events during the capture phase. De-registers the listener after the first time it is invoked.  Returns a sequence of listener keys (one for each item in the content). If content is omitted, binds a listener to the document's root element.
 */
domina.events.capture_once_BANG_ = (function domina$events$capture_once_BANG_(var_args){
var G__43257 = arguments.length;
switch (G__43257) {
case 2:
return domina.events.capture_once_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return domina.events.capture_once_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

domina.events.capture_once_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (type,listener){
return domina.events.capture_once_BANG_.cljs$core$IFn$_invoke$arity$3(domina.events.root_element,type,listener);
});

domina.events.capture_once_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (content,type,listener){
return domina.events.listen_internal_BANG_(content,type,listener,true,true);
});

domina.events.capture_once_BANG_.cljs$lang$maxFixedArity = 3;

/**
 * Removes event listeners from each node in the content. If a listener type is supplied, removes only listeners of that type. If content is omitted, it will remove listeners from the document's root element.
 */
domina.events.unlisten_BANG_ = (function domina$events$unlisten_BANG_(var_args){
var G__43260 = arguments.length;
switch (G__43260) {
case 0:
return domina.events.unlisten_BANG_.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return domina.events.unlisten_BANG_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return domina.events.unlisten_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

domina.events.unlisten_BANG_.cljs$core$IFn$_invoke$arity$0 = (function (){
return domina.events.unlisten_BANG_.cljs$core$IFn$_invoke$arity$1(domina.events.root_element);
});

domina.events.unlisten_BANG_.cljs$core$IFn$_invoke$arity$1 = (function (content){
var seq__43261 = cljs.core.seq(domina.nodes(content));
var chunk__43262 = null;
var count__43263 = (0);
var i__43264 = (0);
while(true){
if((i__43264 < count__43263)){
var node = chunk__43262.cljs$core$IIndexed$_nth$arity$2(null,i__43264);
goog.events.removeAll(node);


var G__43270 = seq__43261;
var G__43271 = chunk__43262;
var G__43272 = count__43263;
var G__43273 = (i__43264 + (1));
seq__43261 = G__43270;
chunk__43262 = G__43271;
count__43263 = G__43272;
i__43264 = G__43273;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__43261);
if(temp__5735__auto__){
var seq__43261__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__43261__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__43261__$1);
var G__43274 = cljs.core.chunk_rest(seq__43261__$1);
var G__43275 = c__4550__auto__;
var G__43276 = cljs.core.count(c__4550__auto__);
var G__43277 = (0);
seq__43261 = G__43274;
chunk__43262 = G__43275;
count__43263 = G__43276;
i__43264 = G__43277;
continue;
} else {
var node = cljs.core.first(seq__43261__$1);
goog.events.removeAll(node);


var G__43278 = cljs.core.next(seq__43261__$1);
var G__43279 = null;
var G__43280 = (0);
var G__43281 = (0);
seq__43261 = G__43278;
chunk__43262 = G__43279;
count__43263 = G__43280;
i__43264 = G__43281;
continue;
}
} else {
return null;
}
}
break;
}
});

domina.events.unlisten_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (content,type){
var type__$1 = cljs.core.name(type);
var seq__43265 = cljs.core.seq(domina.nodes(content));
var chunk__43266 = null;
var count__43267 = (0);
var i__43268 = (0);
while(true){
if((i__43268 < count__43267)){
var node = chunk__43266.cljs$core$IIndexed$_nth$arity$2(null,i__43268);
goog.events.removeAll(node,type__$1);


var G__43282 = seq__43265;
var G__43283 = chunk__43266;
var G__43284 = count__43267;
var G__43285 = (i__43268 + (1));
seq__43265 = G__43282;
chunk__43266 = G__43283;
count__43267 = G__43284;
i__43268 = G__43285;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__43265);
if(temp__5735__auto__){
var seq__43265__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__43265__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__43265__$1);
var G__43286 = cljs.core.chunk_rest(seq__43265__$1);
var G__43287 = c__4550__auto__;
var G__43288 = cljs.core.count(c__4550__auto__);
var G__43289 = (0);
seq__43265 = G__43286;
chunk__43266 = G__43287;
count__43267 = G__43288;
i__43268 = G__43289;
continue;
} else {
var node = cljs.core.first(seq__43265__$1);
goog.events.removeAll(node,type__$1);


var G__43290 = cljs.core.next(seq__43265__$1);
var G__43291 = null;
var G__43292 = (0);
var G__43293 = (0);
seq__43265 = G__43290;
chunk__43266 = G__43291;
count__43267 = G__43292;
i__43268 = G__43293;
continue;
}
} else {
return null;
}
}
break;
}
});

domina.events.unlisten_BANG_.cljs$lang$maxFixedArity = 2;

/**
 * Returns a seq of a node and its ancestors, starting with the document root.
 */
domina.events.ancestor_nodes = (function domina$events$ancestor_nodes(var_args){
var G__43295 = arguments.length;
switch (G__43295) {
case 1:
return domina.events.ancestor_nodes.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return domina.events.ancestor_nodes.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

domina.events.ancestor_nodes.cljs$core$IFn$_invoke$arity$1 = (function (n){
return domina.events.ancestor_nodes.cljs$core$IFn$_invoke$arity$2(n,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [n], null));
});

domina.events.ancestor_nodes.cljs$core$IFn$_invoke$arity$2 = (function (n,so_far){
while(true){
var temp__5733__auto__ = n.parentNode;
if(cljs.core.truth_(temp__5733__auto__)){
var parent = temp__5733__auto__;
var G__43297 = parent;
var G__43298 = cljs.core.cons(parent,so_far);
n = G__43297;
so_far = G__43298;
continue;
} else {
return so_far;
}
break;
}
});

domina.events.ancestor_nodes.cljs$lang$maxFixedArity = 2;

/**
 * Intended for internal/testing use only. Clients should prefer dispatch!. Dispatches an event as a simulated browser event from the given source node. Emulates capture/bubble behavior. Returns false if any handlers called prevent-default, otherwise true.
 */
domina.events.dispatch_browser_BANG_ = (function domina$events$dispatch_browser_BANG_(source,evt){
evt.target = domina.single_node(source);

var ancestors = domina.events.ancestor_nodes.cljs$core$IFn$_invoke$arity$1(domina.single_node(source));
var seq__43299_43339 = cljs.core.seq(ancestors);
var chunk__43300_43340 = null;
var count__43301_43341 = (0);
var i__43302_43342 = (0);
while(true){
if((i__43302_43342 < count__43301_43341)){
var n_43343 = chunk__43300_43340.cljs$core$IIndexed$_nth$arity$2(null,i__43302_43342);
if(cljs.core.truth_(evt.propagationStopped_)){
} else {
evt.currentTarget = n_43343;

var G__43311_43344 = n_43343;
var G__43312_43345 = evt.type;
var G__43313_43346 = true;
var G__43314_43347 = evt;
goog.events.fireListeners(G__43311_43344,G__43312_43345,G__43313_43346,G__43314_43347);
}


var G__43348 = seq__43299_43339;
var G__43349 = chunk__43300_43340;
var G__43350 = count__43301_43341;
var G__43351 = (i__43302_43342 + (1));
seq__43299_43339 = G__43348;
chunk__43300_43340 = G__43349;
count__43301_43341 = G__43350;
i__43302_43342 = G__43351;
continue;
} else {
var temp__5735__auto___43352 = cljs.core.seq(seq__43299_43339);
if(temp__5735__auto___43352){
var seq__43299_43353__$1 = temp__5735__auto___43352;
if(cljs.core.chunked_seq_QMARK_(seq__43299_43353__$1)){
var c__4550__auto___43354 = cljs.core.chunk_first(seq__43299_43353__$1);
var G__43355 = cljs.core.chunk_rest(seq__43299_43353__$1);
var G__43356 = c__4550__auto___43354;
var G__43357 = cljs.core.count(c__4550__auto___43354);
var G__43358 = (0);
seq__43299_43339 = G__43355;
chunk__43300_43340 = G__43356;
count__43301_43341 = G__43357;
i__43302_43342 = G__43358;
continue;
} else {
var n_43359 = cljs.core.first(seq__43299_43353__$1);
if(cljs.core.truth_(evt.propagationStopped_)){
} else {
evt.currentTarget = n_43359;

var G__43315_43360 = n_43359;
var G__43316_43361 = evt.type;
var G__43317_43362 = true;
var G__43318_43363 = evt;
goog.events.fireListeners(G__43315_43360,G__43316_43361,G__43317_43362,G__43318_43363);
}


var G__43364 = cljs.core.next(seq__43299_43353__$1);
var G__43365 = null;
var G__43366 = (0);
var G__43367 = (0);
seq__43299_43339 = G__43364;
chunk__43300_43340 = G__43365;
count__43301_43341 = G__43366;
i__43302_43342 = G__43367;
continue;
}
} else {
}
}
break;
}

var seq__43319_43368 = cljs.core.seq(cljs.core.reverse(ancestors));
var chunk__43320_43369 = null;
var count__43321_43370 = (0);
var i__43322_43371 = (0);
while(true){
if((i__43322_43371 < count__43321_43370)){
var n_43372 = chunk__43320_43369.cljs$core$IIndexed$_nth$arity$2(null,i__43322_43371);
if(cljs.core.truth_(evt.propagationStopped_)){
} else {
evt.currentTarget = n_43372;

var G__43331_43373 = n_43372;
var G__43332_43374 = evt.type;
var G__43333_43375 = false;
var G__43334_43376 = evt;
goog.events.fireListeners(G__43331_43373,G__43332_43374,G__43333_43375,G__43334_43376);
}


var G__43377 = seq__43319_43368;
var G__43378 = chunk__43320_43369;
var G__43379 = count__43321_43370;
var G__43380 = (i__43322_43371 + (1));
seq__43319_43368 = G__43377;
chunk__43320_43369 = G__43378;
count__43321_43370 = G__43379;
i__43322_43371 = G__43380;
continue;
} else {
var temp__5735__auto___43381 = cljs.core.seq(seq__43319_43368);
if(temp__5735__auto___43381){
var seq__43319_43382__$1 = temp__5735__auto___43381;
if(cljs.core.chunked_seq_QMARK_(seq__43319_43382__$1)){
var c__4550__auto___43383 = cljs.core.chunk_first(seq__43319_43382__$1);
var G__43384 = cljs.core.chunk_rest(seq__43319_43382__$1);
var G__43385 = c__4550__auto___43383;
var G__43386 = cljs.core.count(c__4550__auto___43383);
var G__43387 = (0);
seq__43319_43368 = G__43384;
chunk__43320_43369 = G__43385;
count__43321_43370 = G__43386;
i__43322_43371 = G__43387;
continue;
} else {
var n_43388 = cljs.core.first(seq__43319_43382__$1);
if(cljs.core.truth_(evt.propagationStopped_)){
} else {
evt.currentTarget = n_43388;

var G__43335_43389 = n_43388;
var G__43336_43390 = evt.type;
var G__43337_43391 = false;
var G__43338_43392 = evt;
goog.events.fireListeners(G__43335_43389,G__43336_43390,G__43337_43391,G__43338_43392);
}


var G__43393 = cljs.core.next(seq__43319_43382__$1);
var G__43394 = null;
var G__43395 = (0);
var G__43396 = (0);
seq__43319_43368 = G__43393;
chunk__43320_43369 = G__43394;
count__43321_43370 = G__43395;
i__43322_43371 = G__43396;
continue;
}
} else {
}
}
break;
}

return evt.returnValue_;
});
/**
 * Intended for internal/testing use only. Clients should prefer dispatch!. Dispatches an event using GClosure's event handling. The event source must extend goog.event.EventTarget
 */
domina.events.dispatch_event_target_BANG_ = (function domina$events$dispatch_event_target_BANG_(source,evt){
return goog.events.dispatchEvent(source,evt);
});
/**
 * Tests whether the object is a goog.event.EventTarget
 */
domina.events.is_event_target_QMARK_ = (function domina$events$is_event_target_QMARK_(o){
var and__4120__auto__ = o.getParentEventTarget;
if(cljs.core.truth_(and__4120__auto__)){
return o.dispatchEvent;
} else {
return and__4120__auto__;
}
});
/**
 * Dispatches an event of the given type, adding the values in event map to the event object. Optionally takes an event source. If none is provided, dispatches on the document's root element. Returns false if any handlers called prevent-default, otherwise true.
 */
domina.events.dispatch_BANG_ = (function domina$events$dispatch_BANG_(var_args){
var G__43398 = arguments.length;
switch (G__43398) {
case 2:
return domina.events.dispatch_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return domina.events.dispatch_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

domina.events.dispatch_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (type,evt_map){
return domina.events.dispatch_BANG_.cljs$core$IFn$_invoke$arity$3(domina.events.root_element,type,evt_map);
});

domina.events.dispatch_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (source,type,evt_map){
var evt = (new goog.events.Event(cljs.core.name(type)));
var seq__43399_43416 = cljs.core.seq(evt_map);
var chunk__43400_43417 = null;
var count__43401_43418 = (0);
var i__43402_43419 = (0);
while(true){
if((i__43402_43419 < count__43401_43418)){
var vec__43409_43420 = chunk__43400_43417.cljs$core$IIndexed$_nth$arity$2(null,i__43402_43419);
var k_43421 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43409_43420,(0),null);
var v_43422 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43409_43420,(1),null);
(evt[k_43421] = v_43422);


var G__43423 = seq__43399_43416;
var G__43424 = chunk__43400_43417;
var G__43425 = count__43401_43418;
var G__43426 = (i__43402_43419 + (1));
seq__43399_43416 = G__43423;
chunk__43400_43417 = G__43424;
count__43401_43418 = G__43425;
i__43402_43419 = G__43426;
continue;
} else {
var temp__5735__auto___43427 = cljs.core.seq(seq__43399_43416);
if(temp__5735__auto___43427){
var seq__43399_43428__$1 = temp__5735__auto___43427;
if(cljs.core.chunked_seq_QMARK_(seq__43399_43428__$1)){
var c__4550__auto___43429 = cljs.core.chunk_first(seq__43399_43428__$1);
var G__43430 = cljs.core.chunk_rest(seq__43399_43428__$1);
var G__43431 = c__4550__auto___43429;
var G__43432 = cljs.core.count(c__4550__auto___43429);
var G__43433 = (0);
seq__43399_43416 = G__43430;
chunk__43400_43417 = G__43431;
count__43401_43418 = G__43432;
i__43402_43419 = G__43433;
continue;
} else {
var vec__43412_43434 = cljs.core.first(seq__43399_43428__$1);
var k_43435 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43412_43434,(0),null);
var v_43436 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__43412_43434,(1),null);
(evt[k_43435] = v_43436);


var G__43437 = cljs.core.next(seq__43399_43428__$1);
var G__43438 = null;
var G__43439 = (0);
var G__43440 = (0);
seq__43399_43416 = G__43437;
chunk__43400_43417 = G__43438;
count__43401_43418 = G__43439;
i__43402_43419 = G__43440;
continue;
}
} else {
}
}
break;
}

if(cljs.core.truth_(domina.events.is_event_target_QMARK_(source))){
return domina.events.dispatch_event_target_BANG_(source,evt);
} else {
return domina.events.dispatch_browser_BANG_(source,evt);
}
});

domina.events.dispatch_BANG_.cljs$lang$maxFixedArity = 3;

/**
 * Given a listener key, removes the listener.
 */
domina.events.unlisten_by_key_BANG_ = (function domina$events$unlisten_by_key_BANG_(key){
return goog.events.unlistenByKey(key);
});
/**
 * Returns a sequence of event listeners for all the nodes in the
 * content of a given type.
 */
domina.events.get_listeners = (function domina$events$get_listeners(content,type){
var type__$1 = cljs.core.name(type);
return cljs.core.mapcat.cljs$core$IFn$_invoke$arity$variadic(((function (type__$1){
return (function (p1__43441_SHARP_){
return goog.events.getListeners(p1__43441_SHARP_,type__$1,false);
});})(type__$1))
,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([domina.nodes(content)], 0));
});

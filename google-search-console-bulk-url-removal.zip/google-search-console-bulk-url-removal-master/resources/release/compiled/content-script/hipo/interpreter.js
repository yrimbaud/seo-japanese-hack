// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('hipo.interpreter');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('clojure.set');
goog.require('hipo.attribute');
goog.require('hipo.dom');
goog.require('hipo.hiccup');
goog.require('hipo.interceptor');
hipo.interpreter.set_attribute_BANG_ = (function hipo$interpreter$set_attribute_BANG_(el,ns,tag,sok,ov,nv,p__41384){
var map__41385 = p__41384;
var map__41385__$1 = (((((!((map__41385 == null))))?(((((map__41385.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__41385.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__41385):map__41385);
var m = map__41385__$1;
var interceptors = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__41385__$1,cljs.core.cst$kw$interceptors);
if((!((ov === nv)))){
var temp__5733__auto__ = hipo.hiccup.listener_name__GT_event_name(cljs.core.name(sok));
if(cljs.core.truth_(temp__5733__auto__)){
var en = temp__5733__auto__;
if((!(((cljs.core.map_QMARK_(ov)) && (cljs.core.map_QMARK_(nv)) && ((cljs.core.cst$kw$name.cljs$core$IFn$_invoke$arity$1(ov) === cljs.core.cst$kw$name.cljs$core$IFn$_invoke$arity$1(nv))))))){
var b__26951__auto__ = ((function (en,temp__5733__auto__,map__41385,map__41385__$1,m,interceptors){
return (function (){
var hn = ["hipo_listener_",cljs.core.str.cljs$core$IFn$_invoke$arity$1(en)].join('');
var temp__5733__auto___41387__$1 = (el[hn]);
if(cljs.core.truth_(temp__5733__auto___41387__$1)){
var l_41388 = temp__5733__auto___41387__$1;
el.removeEventListener(en,l_41388);
} else {
}

var temp__5735__auto__ = (function (){var or__4131__auto__ = cljs.core.cst$kw$fn.cljs$core$IFn$_invoke$arity$1(nv);
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return nv;
}
})();
if(cljs.core.truth_(temp__5735__auto__)){
var nv__$1 = temp__5735__auto__;
el.addEventListener(en,nv__$1);

return (el[hn] = nv__$1);
} else {
return null;
}
});})(en,temp__5733__auto__,map__41385,map__41385__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,(cljs.core.truth_(nv)?cljs.core.cst$kw$update_DASH_handler:cljs.core.cst$kw$remove_DASH_handler),cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$name,sok,cljs.core.cst$kw$old_DASH_value,ov], null),(cljs.core.truth_(nv)?new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$new_DASH_value,nv], null):null)], 0)));
}
} else {
return null;
}
} else {
var b__26951__auto__ = ((function (temp__5733__auto__,map__41385,map__41385__$1,m,interceptors){
return (function (){
return hipo.attribute.set_value_BANG_(el,m,ns,tag,sok,ov,nv);
});})(temp__5733__auto__,map__41385,map__41385__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,(cljs.core.truth_(nv)?cljs.core.cst$kw$update_DASH_attribute:cljs.core.cst$kw$remove_DASH_attribute),cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$name,sok,cljs.core.cst$kw$old_DASH_value,ov], null),(cljs.core.truth_(nv)?new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$new_DASH_value,nv], null):null)], 0)));
}
}
} else {
return null;
}
});
hipo.interpreter.append_children_BANG_ = (function hipo$interpreter$append_children_BANG_(el,v,m){

var v__$1 = hipo.hiccup.flatten_children(v);
while(true){
if(cljs.core.empty_QMARK_(v__$1)){
return null;
} else {
var temp__5733__auto___41389 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(v__$1,(0));
if(cljs.core.truth_(temp__5733__auto___41389)){
var h_41390 = temp__5733__auto___41389;
el.appendChild((hipo.interpreter.create_child.cljs$core$IFn$_invoke$arity$2 ? hipo.interpreter.create_child.cljs$core$IFn$_invoke$arity$2(h_41390,m) : hipo.interpreter.create_child.call(null,h_41390,m)));
} else {
}

var G__41391 = cljs.core.rest(v__$1);
v__$1 = G__41391;
continue;
}
break;
}
});
hipo.interpreter.default_create_element = (function hipo$interpreter$default_create_element(ns,tag,attrs,m){
var el = hipo.dom.create_element(ns,tag);
var seq__41392_41408 = cljs.core.seq(attrs);
var chunk__41393_41409 = null;
var count__41394_41410 = (0);
var i__41395_41411 = (0);
while(true){
if((i__41395_41411 < count__41394_41410)){
var vec__41402_41412 = chunk__41393_41409.cljs$core$IIndexed$_nth$arity$2(null,i__41395_41411);
var sok_41413 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41402_41412,(0),null);
var v_41414 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41402_41412,(1),null);
if(cljs.core.truth_(v_41414)){
hipo.interpreter.set_attribute_BANG_(el,ns,tag,sok_41413,null,v_41414,m);
} else {
}


var G__41415 = seq__41392_41408;
var G__41416 = chunk__41393_41409;
var G__41417 = count__41394_41410;
var G__41418 = (i__41395_41411 + (1));
seq__41392_41408 = G__41415;
chunk__41393_41409 = G__41416;
count__41394_41410 = G__41417;
i__41395_41411 = G__41418;
continue;
} else {
var temp__5735__auto___41419 = cljs.core.seq(seq__41392_41408);
if(temp__5735__auto___41419){
var seq__41392_41420__$1 = temp__5735__auto___41419;
if(cljs.core.chunked_seq_QMARK_(seq__41392_41420__$1)){
var c__4550__auto___41421 = cljs.core.chunk_first(seq__41392_41420__$1);
var G__41422 = cljs.core.chunk_rest(seq__41392_41420__$1);
var G__41423 = c__4550__auto___41421;
var G__41424 = cljs.core.count(c__4550__auto___41421);
var G__41425 = (0);
seq__41392_41408 = G__41422;
chunk__41393_41409 = G__41423;
count__41394_41410 = G__41424;
i__41395_41411 = G__41425;
continue;
} else {
var vec__41405_41426 = cljs.core.first(seq__41392_41420__$1);
var sok_41427 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41405_41426,(0),null);
var v_41428 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41405_41426,(1),null);
if(cljs.core.truth_(v_41428)){
hipo.interpreter.set_attribute_BANG_(el,ns,tag,sok_41427,null,v_41428,m);
} else {
}


var G__41429 = cljs.core.next(seq__41392_41420__$1);
var G__41430 = null;
var G__41431 = (0);
var G__41432 = (0);
seq__41392_41408 = G__41429;
chunk__41393_41409 = G__41430;
count__41394_41410 = G__41431;
i__41395_41411 = G__41432;
continue;
}
} else {
}
}
break;
}

return el;
});
hipo.interpreter.create_element = (function hipo$interpreter$create_element(ns,tag,attrs,m){
var temp__5733__auto__ = cljs.core.cst$kw$create_DASH_element_DASH_fn.cljs$core$IFn$_invoke$arity$1(m);
if(cljs.core.truth_(temp__5733__auto__)){
var f = temp__5733__auto__;
return (f.cljs$core$IFn$_invoke$arity$4 ? f.cljs$core$IFn$_invoke$arity$4(ns,tag,attrs,m) : f.call(null,ns,tag,attrs,m));
} else {
return hipo.interpreter.default_create_element(ns,tag,attrs,m);
}
});
hipo.interpreter.create_vector = (function hipo$interpreter$create_vector(h,m){

var key = hipo.hiccup.keyns(h);
var tag = hipo.hiccup.tag(h);
var attrs = hipo.hiccup.attributes(h);
var children = hipo.hiccup.children(h);
var el = hipo.interpreter.create_element(hipo.hiccup.key__GT_namespace(key,m),tag,attrs,m);
if(cljs.core.truth_(children)){
hipo.interpreter.append_children_BANG_(el,children,m);
} else {
}

return el;
});
hipo.interpreter.create_child = (function hipo$interpreter$create_child(o,m){

if(hipo.hiccup.literal_QMARK_(o)){
return document.createTextNode(o);
} else {
return hipo.interpreter.create_vector(o,m);
}
});
hipo.interpreter.append_to_parent = (function hipo$interpreter$append_to_parent(el,o,m){
if(cljs.core.seq_QMARK_(o)){
return hipo.interpreter.append_children_BANG_(el,cljs.core.vec(o),m);
} else {
if((!((o == null)))){
return el.appendChild(hipo.interpreter.create_child(o,m));
} else {
return null;
}
}
});
hipo.interpreter.create = (function hipo$interpreter$create(o,m){
if(cljs.core.seq_QMARK_(o)){
var f = document.createDocumentFragment();
hipo.interpreter.append_children_BANG_(f,cljs.core.vec(o),m);

return f;
} else {
if((!((o == null)))){
return hipo.interpreter.create_child(o,m);
} else {
return null;
}
}
});
hipo.interpreter.reconciliate_attributes_BANG_ = (function hipo$interpreter$reconciliate_attributes_BANG_(el,ns,tag,om,nm,m){
var seq__41433_41455 = cljs.core.seq(nm);
var chunk__41435_41456 = null;
var count__41436_41457 = (0);
var i__41437_41458 = (0);
while(true){
if((i__41437_41458 < count__41436_41457)){
var vec__41445_41459 = chunk__41435_41456.cljs$core$IIndexed$_nth$arity$2(null,i__41437_41458);
var sok_41460 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41445_41459,(0),null);
var nv_41461 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41445_41459,(1),null);
var ov_41462 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(om,sok_41460);
hipo.interpreter.set_attribute_BANG_(el,ns,tag,sok_41460,ov_41462,nv_41461,m);


var G__41463 = seq__41433_41455;
var G__41464 = chunk__41435_41456;
var G__41465 = count__41436_41457;
var G__41466 = (i__41437_41458 + (1));
seq__41433_41455 = G__41463;
chunk__41435_41456 = G__41464;
count__41436_41457 = G__41465;
i__41437_41458 = G__41466;
continue;
} else {
var temp__5735__auto___41467 = cljs.core.seq(seq__41433_41455);
if(temp__5735__auto___41467){
var seq__41433_41468__$1 = temp__5735__auto___41467;
if(cljs.core.chunked_seq_QMARK_(seq__41433_41468__$1)){
var c__4550__auto___41469 = cljs.core.chunk_first(seq__41433_41468__$1);
var G__41470 = cljs.core.chunk_rest(seq__41433_41468__$1);
var G__41471 = c__4550__auto___41469;
var G__41472 = cljs.core.count(c__4550__auto___41469);
var G__41473 = (0);
seq__41433_41455 = G__41470;
chunk__41435_41456 = G__41471;
count__41436_41457 = G__41472;
i__41437_41458 = G__41473;
continue;
} else {
var vec__41448_41474 = cljs.core.first(seq__41433_41468__$1);
var sok_41475 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41448_41474,(0),null);
var nv_41476 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41448_41474,(1),null);
var ov_41477 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(om,sok_41475);
hipo.interpreter.set_attribute_BANG_(el,ns,tag,sok_41475,ov_41477,nv_41476,m);


var G__41478 = cljs.core.next(seq__41433_41468__$1);
var G__41479 = null;
var G__41480 = (0);
var G__41481 = (0);
seq__41433_41455 = G__41478;
chunk__41435_41456 = G__41479;
count__41436_41457 = G__41480;
i__41437_41458 = G__41481;
continue;
}
} else {
}
}
break;
}

var seq__41451 = cljs.core.seq(clojure.set.difference.cljs$core$IFn$_invoke$arity$2(cljs.core.set(cljs.core.keys(om)),cljs.core.set(cljs.core.keys(nm))));
var chunk__41452 = null;
var count__41453 = (0);
var i__41454 = (0);
while(true){
if((i__41454 < count__41453)){
var sok = chunk__41452.cljs$core$IIndexed$_nth$arity$2(null,i__41454);
hipo.interpreter.set_attribute_BANG_(el,ns,tag,sok,cljs.core.get.cljs$core$IFn$_invoke$arity$2(om,sok),null,m);


var G__41482 = seq__41451;
var G__41483 = chunk__41452;
var G__41484 = count__41453;
var G__41485 = (i__41454 + (1));
seq__41451 = G__41482;
chunk__41452 = G__41483;
count__41453 = G__41484;
i__41454 = G__41485;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__41451);
if(temp__5735__auto__){
var seq__41451__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__41451__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__41451__$1);
var G__41486 = cljs.core.chunk_rest(seq__41451__$1);
var G__41487 = c__4550__auto__;
var G__41488 = cljs.core.count(c__4550__auto__);
var G__41489 = (0);
seq__41451 = G__41486;
chunk__41452 = G__41487;
count__41453 = G__41488;
i__41454 = G__41489;
continue;
} else {
var sok = cljs.core.first(seq__41451__$1);
hipo.interpreter.set_attribute_BANG_(el,ns,tag,sok,cljs.core.get.cljs$core$IFn$_invoke$arity$2(om,sok),null,m);


var G__41490 = cljs.core.next(seq__41451__$1);
var G__41491 = null;
var G__41492 = (0);
var G__41493 = (0);
seq__41451 = G__41490;
chunk__41452 = G__41491;
count__41453 = G__41492;
i__41454 = G__41493;
continue;
}
} else {
return null;
}
}
break;
}
});
hipo.interpreter.child_key = (function hipo$interpreter$child_key(h){
return cljs.core.cst$kw$hipo_SLASH_key.cljs$core$IFn$_invoke$arity$1(cljs.core.meta(h));
});
hipo.interpreter.keyed_children__GT_indexed_map = (function hipo$interpreter$keyed_children__GT_indexed_map(v){
return cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,(function (){var iter__4523__auto__ = (function hipo$interpreter$keyed_children__GT_indexed_map_$_iter__41494(s__41495){
return (new cljs.core.LazySeq(null,(function (){
var s__41495__$1 = s__41495;
while(true){
var temp__5735__auto__ = cljs.core.seq(s__41495__$1);
if(temp__5735__auto__){
var s__41495__$2 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(s__41495__$2)){
var c__4521__auto__ = cljs.core.chunk_first(s__41495__$2);
var size__4522__auto__ = cljs.core.count(c__4521__auto__);
var b__41497 = cljs.core.chunk_buffer(size__4522__auto__);
if((function (){var i__41496 = (0);
while(true){
if((i__41496 < size__4522__auto__)){
var ih = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(c__4521__auto__,i__41496);
cljs.core.chunk_append(b__41497,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [hipo.interpreter.child_key(cljs.core.nth.cljs$core$IFn$_invoke$arity$2(ih,(1))),ih], null));

var G__41498 = (i__41496 + (1));
i__41496 = G__41498;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__41497),hipo$interpreter$keyed_children__GT_indexed_map_$_iter__41494(cljs.core.chunk_rest(s__41495__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__41497),null);
}
} else {
var ih = cljs.core.first(s__41495__$2);
return cljs.core.cons(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [hipo.interpreter.child_key(cljs.core.nth.cljs$core$IFn$_invoke$arity$2(ih,(1))),ih], null),hipo$interpreter$keyed_children__GT_indexed_map_$_iter__41494(cljs.core.rest(s__41495__$2)));
}
} else {
return null;
}
break;
}
}),null,null));
});
return iter__4523__auto__(cljs.core.map_indexed.cljs$core$IFn$_invoke$arity$2(((function (iter__4523__auto__){
return (function (idx,itm){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [idx,itm], null);
});})(iter__4523__auto__))
,v));
})());
});
/**
 * Reconciliate a vector of children based on their associated key.
 */
hipo.interpreter.reconciliate_keyed_children_BANG_ = (function hipo$interpreter$reconciliate_keyed_children_BANG_(el,och,nch,p__41499){
var map__41500 = p__41499;
var map__41500__$1 = (((((!((map__41500 == null))))?(((((map__41500.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__41500.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__41500):map__41500);
var m = map__41500__$1;
var interceptors = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__41500__$1,cljs.core.cst$kw$interceptors);
var om = hipo.interpreter.keyed_children__GT_indexed_map(och);
var nm = hipo.interpreter.keyed_children__GT_indexed_map(nch);
var cs = hipo.dom.children.cljs$core$IFn$_invoke$arity$2(el,cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.max,clojure.set.intersection.cljs$core$IFn$_invoke$arity$2(cljs.core.set(cljs.core.keys(nm)),cljs.core.set(cljs.core.keys(om)))));
var seq__41502_41542 = cljs.core.seq(nm);
var chunk__41503_41543 = null;
var count__41504_41544 = (0);
var i__41505_41545 = (0);
while(true){
if((i__41505_41545 < count__41504_41544)){
var vec__41524_41546 = chunk__41503_41543.cljs$core$IIndexed$_nth$arity$2(null,i__41505_41545);
var i_41547 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41524_41546,(0),null);
var vec__41527_41548 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41524_41546,(1),null);
var ii_41549 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41527_41548,(0),null);
var h_41550 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41527_41548,(1),null);
var temp__5733__auto___41551 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(om,i_41547);
if(cljs.core.truth_(temp__5733__auto___41551)){
var vec__41530_41552 = temp__5733__auto___41551;
var iii_41553 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41530_41552,(0),null);
var oh_41554 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41530_41552,(1),null);
var cel_41555 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(cs,iii_41553);
if((ii_41549 === iii_41553)){
(hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4 ? hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4(cel_41555,oh_41554,h_41550,m) : hipo.interpreter.reconciliate_BANG_.call(null,cel_41555,oh_41554,h_41550,m));
} else {
var b__26951__auto___41556 = ((function (seq__41502_41542,chunk__41503_41543,count__41504_41544,i__41505_41545,cel_41555,vec__41530_41552,iii_41553,oh_41554,temp__5733__auto___41551,vec__41524_41546,i_41547,vec__41527_41548,ii_41549,h_41550,om,nm,cs,map__41500,map__41500__$1,m,interceptors){
return (function (){
var ncel = el.removeChild(cel_41555);
(hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4 ? hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4(ncel,oh_41554,h_41550,m) : hipo.interpreter.reconciliate_BANG_.call(null,ncel,oh_41554,h_41550,m));

return hipo.dom.insert_child_BANG_(el,ii_41549,ncel);
});})(seq__41502_41542,chunk__41503_41543,count__41504_41544,i__41505_41545,cel_41555,vec__41530_41552,iii_41553,oh_41554,temp__5733__auto___41551,vec__41524_41546,i_41547,vec__41527_41548,ii_41549,h_41550,om,nm,cs,map__41500,map__41500__$1,m,interceptors))
;
var v__26952__auto___41557 = interceptors;
if(((cljs.core.not(v__26952__auto___41557)) || (cljs.core.empty_QMARK_(v__26952__auto___41557)))){
b__26951__auto___41556();
} else {
hipo.interceptor.call(b__26951__auto___41556,v__26952__auto___41557,cljs.core.cst$kw$move,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,h_41550,cljs.core.cst$kw$index,ii_41549], null));
}
}
} else {
var b__26951__auto___41558 = ((function (seq__41502_41542,chunk__41503_41543,count__41504_41544,i__41505_41545,temp__5733__auto___41551,vec__41524_41546,i_41547,vec__41527_41548,ii_41549,h_41550,om,nm,cs,map__41500,map__41500__$1,m,interceptors){
return (function (){
return hipo.dom.insert_child_BANG_(el,ii_41549,hipo.interpreter.create_child(h_41550,m));
});})(seq__41502_41542,chunk__41503_41543,count__41504_41544,i__41505_41545,temp__5733__auto___41551,vec__41524_41546,i_41547,vec__41527_41548,ii_41549,h_41550,om,nm,cs,map__41500,map__41500__$1,m,interceptors))
;
var v__26952__auto___41559 = interceptors;
if(((cljs.core.not(v__26952__auto___41559)) || (cljs.core.empty_QMARK_(v__26952__auto___41559)))){
b__26951__auto___41558();
} else {
hipo.interceptor.call(b__26951__auto___41558,v__26952__auto___41559,cljs.core.cst$kw$insert,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,h_41550,cljs.core.cst$kw$index,ii_41549], null));
}
}


var G__41560 = seq__41502_41542;
var G__41561 = chunk__41503_41543;
var G__41562 = count__41504_41544;
var G__41563 = (i__41505_41545 + (1));
seq__41502_41542 = G__41560;
chunk__41503_41543 = G__41561;
count__41504_41544 = G__41562;
i__41505_41545 = G__41563;
continue;
} else {
var temp__5735__auto___41564 = cljs.core.seq(seq__41502_41542);
if(temp__5735__auto___41564){
var seq__41502_41565__$1 = temp__5735__auto___41564;
if(cljs.core.chunked_seq_QMARK_(seq__41502_41565__$1)){
var c__4550__auto___41566 = cljs.core.chunk_first(seq__41502_41565__$1);
var G__41567 = cljs.core.chunk_rest(seq__41502_41565__$1);
var G__41568 = c__4550__auto___41566;
var G__41569 = cljs.core.count(c__4550__auto___41566);
var G__41570 = (0);
seq__41502_41542 = G__41567;
chunk__41503_41543 = G__41568;
count__41504_41544 = G__41569;
i__41505_41545 = G__41570;
continue;
} else {
var vec__41533_41571 = cljs.core.first(seq__41502_41565__$1);
var i_41572 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41533_41571,(0),null);
var vec__41536_41573 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41533_41571,(1),null);
var ii_41574 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41536_41573,(0),null);
var h_41575 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41536_41573,(1),null);
var temp__5733__auto___41576 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(om,i_41572);
if(cljs.core.truth_(temp__5733__auto___41576)){
var vec__41539_41577 = temp__5733__auto___41576;
var iii_41578 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41539_41577,(0),null);
var oh_41579 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__41539_41577,(1),null);
var cel_41580 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(cs,iii_41578);
if((ii_41574 === iii_41578)){
(hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4 ? hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4(cel_41580,oh_41579,h_41575,m) : hipo.interpreter.reconciliate_BANG_.call(null,cel_41580,oh_41579,h_41575,m));
} else {
var b__26951__auto___41581 = ((function (seq__41502_41542,chunk__41503_41543,count__41504_41544,i__41505_41545,cel_41580,vec__41539_41577,iii_41578,oh_41579,temp__5733__auto___41576,vec__41533_41571,i_41572,vec__41536_41573,ii_41574,h_41575,seq__41502_41565__$1,temp__5735__auto___41564,om,nm,cs,map__41500,map__41500__$1,m,interceptors){
return (function (){
var ncel = el.removeChild(cel_41580);
(hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4 ? hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4(ncel,oh_41579,h_41575,m) : hipo.interpreter.reconciliate_BANG_.call(null,ncel,oh_41579,h_41575,m));

return hipo.dom.insert_child_BANG_(el,ii_41574,ncel);
});})(seq__41502_41542,chunk__41503_41543,count__41504_41544,i__41505_41545,cel_41580,vec__41539_41577,iii_41578,oh_41579,temp__5733__auto___41576,vec__41533_41571,i_41572,vec__41536_41573,ii_41574,h_41575,seq__41502_41565__$1,temp__5735__auto___41564,om,nm,cs,map__41500,map__41500__$1,m,interceptors))
;
var v__26952__auto___41582 = interceptors;
if(((cljs.core.not(v__26952__auto___41582)) || (cljs.core.empty_QMARK_(v__26952__auto___41582)))){
b__26951__auto___41581();
} else {
hipo.interceptor.call(b__26951__auto___41581,v__26952__auto___41582,cljs.core.cst$kw$move,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,h_41575,cljs.core.cst$kw$index,ii_41574], null));
}
}
} else {
var b__26951__auto___41583 = ((function (seq__41502_41542,chunk__41503_41543,count__41504_41544,i__41505_41545,temp__5733__auto___41576,vec__41533_41571,i_41572,vec__41536_41573,ii_41574,h_41575,seq__41502_41565__$1,temp__5735__auto___41564,om,nm,cs,map__41500,map__41500__$1,m,interceptors){
return (function (){
return hipo.dom.insert_child_BANG_(el,ii_41574,hipo.interpreter.create_child(h_41575,m));
});})(seq__41502_41542,chunk__41503_41543,count__41504_41544,i__41505_41545,temp__5733__auto___41576,vec__41533_41571,i_41572,vec__41536_41573,ii_41574,h_41575,seq__41502_41565__$1,temp__5735__auto___41564,om,nm,cs,map__41500,map__41500__$1,m,interceptors))
;
var v__26952__auto___41584 = interceptors;
if(((cljs.core.not(v__26952__auto___41584)) || (cljs.core.empty_QMARK_(v__26952__auto___41584)))){
b__26951__auto___41583();
} else {
hipo.interceptor.call(b__26951__auto___41583,v__26952__auto___41584,cljs.core.cst$kw$insert,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,h_41575,cljs.core.cst$kw$index,ii_41574], null));
}
}


var G__41585 = cljs.core.next(seq__41502_41565__$1);
var G__41586 = null;
var G__41587 = (0);
var G__41588 = (0);
seq__41502_41542 = G__41585;
chunk__41503_41543 = G__41586;
count__41504_41544 = G__41587;
i__41505_41545 = G__41588;
continue;
}
} else {
}
}
break;
}

var d = cljs.core.count(clojure.set.difference.cljs$core$IFn$_invoke$arity$2(cljs.core.set(cljs.core.keys(om)),cljs.core.set(cljs.core.keys(nm))));
if((d > (0))){
var b__26951__auto__ = ((function (d,om,nm,cs,map__41500,map__41500__$1,m,interceptors){
return (function (){
return hipo.dom.remove_trailing_children_BANG_(el,d);
});})(d,om,nm,cs,map__41500,map__41500__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,cljs.core.cst$kw$remove_DASH_trailing,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$count,d], null));
}
} else {
return null;
}
});
hipo.interpreter.reconciliate_non_keyed_children_BANG_ = (function hipo$interpreter$reconciliate_non_keyed_children_BANG_(el,och,nch,p__41589){
var map__41590 = p__41589;
var map__41590__$1 = (((((!((map__41590 == null))))?(((((map__41590.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__41590.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__41590):map__41590);
var m = map__41590__$1;
var interceptors = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__41590__$1,cljs.core.cst$kw$interceptors);
var oc = cljs.core.count(och);
var nc = cljs.core.count(nch);
var d = (oc - nc);
if((d > (0))){
var b__26951__auto___41592 = ((function (oc,nc,d,map__41590,map__41590__$1,m,interceptors){
return (function (){
return hipo.dom.remove_trailing_children_BANG_(el,d);
});})(oc,nc,d,map__41590,map__41590__$1,m,interceptors))
;
var v__26952__auto___41593 = interceptors;
if(((cljs.core.not(v__26952__auto___41593)) || (cljs.core.empty_QMARK_(v__26952__auto___41593)))){
b__26951__auto___41592();
} else {
hipo.interceptor.call(b__26951__auto___41592,v__26952__auto___41593,cljs.core.cst$kw$remove_DASH_trailing,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$count,d], null));
}
} else {
}

var n__4607__auto___41594 = (function (){var x__4222__auto__ = oc;
var y__4223__auto__ = nc;
return ((x__4222__auto__ < y__4223__auto__) ? x__4222__auto__ : y__4223__auto__);
})();
var i_41595 = (0);
while(true){
if((i_41595 < n__4607__auto___41594)){
var ov_41596 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(och,i_41595);
var nv_41597 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(nch,i_41595);
if((!((((ov_41596 == null)) && ((nv_41597 == null)))))){
if((ov_41596 == null)){
var b__26951__auto___41598 = ((function (i_41595,ov_41596,nv_41597,n__4607__auto___41594,oc,nc,d,map__41590,map__41590__$1,m,interceptors){
return (function (){
return hipo.dom.insert_child_BANG_(el,i_41595,hipo.interpreter.create_child(nv_41597,m));
});})(i_41595,ov_41596,nv_41597,n__4607__auto___41594,oc,nc,d,map__41590,map__41590__$1,m,interceptors))
;
var v__26952__auto___41599 = interceptors;
if(((cljs.core.not(v__26952__auto___41599)) || (cljs.core.empty_QMARK_(v__26952__auto___41599)))){
b__26951__auto___41598();
} else {
hipo.interceptor.call(b__26951__auto___41598,v__26952__auto___41599,cljs.core.cst$kw$insert,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,nv_41597,cljs.core.cst$kw$index,i_41595], null));
}
} else {
if((nv_41597 == null)){
var b__26951__auto___41600 = ((function (i_41595,ov_41596,nv_41597,n__4607__auto___41594,oc,nc,d,map__41590,map__41590__$1,m,interceptors){
return (function (){
return hipo.dom.remove_child_BANG_(el,i_41595);
});})(i_41595,ov_41596,nv_41597,n__4607__auto___41594,oc,nc,d,map__41590,map__41590__$1,m,interceptors))
;
var v__26952__auto___41601 = interceptors;
if(((cljs.core.not(v__26952__auto___41601)) || (cljs.core.empty_QMARK_(v__26952__auto___41601)))){
b__26951__auto___41600();
} else {
hipo.interceptor.call(b__26951__auto___41600,v__26952__auto___41601,cljs.core.cst$kw$remove,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$index,i_41595], null));
}
} else {
var temp__5733__auto___41602 = hipo.dom.child(el,i_41595);
if(cljs.core.truth_(temp__5733__auto___41602)){
var cel_41603 = temp__5733__auto___41602;
(hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4 ? hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4(cel_41603,ov_41596,nv_41597,m) : hipo.interpreter.reconciliate_BANG_.call(null,cel_41603,ov_41596,nv_41597,m));
} else {
}

}
}
} else {
}

var G__41604 = (i_41595 + (1));
i_41595 = G__41604;
continue;
} else {
}
break;
}

if((d < (0))){
if(((-1) === d)){
var temp__5733__auto__ = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(nch,oc);
if(cljs.core.truth_(temp__5733__auto__)){
var h = temp__5733__auto__;
var b__26951__auto__ = ((function (h,temp__5733__auto__,oc,nc,d,map__41590,map__41590__$1,m,interceptors){
return (function (){
return el.appendChild(hipo.interpreter.create_child(h,m));
});})(h,temp__5733__auto__,oc,nc,d,map__41590,map__41590__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,cljs.core.cst$kw$append,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,h], null));
}
} else {
return null;
}
} else {
var f = document.createDocumentFragment();
var cs = ((((0) === oc))?nch:cljs.core.subvec.cljs$core$IFn$_invoke$arity$2(nch,oc));
var b__26951__auto___41605 = ((function (f,cs,oc,nc,d,map__41590,map__41590__$1,m,interceptors){
return (function (){
return hipo.interpreter.append_children_BANG_(f,cs,m);
});})(f,cs,oc,nc,d,map__41590,map__41590__$1,m,interceptors))
;
var v__26952__auto___41606 = interceptors;
if(((cljs.core.not(v__26952__auto___41606)) || (cljs.core.empty_QMARK_(v__26952__auto___41606)))){
b__26951__auto___41605();
} else {
hipo.interceptor.call(b__26951__auto___41605,v__26952__auto___41606,cljs.core.cst$kw$append,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,cs], null));
}

return el.appendChild(f);
}
} else {
return null;
}
});
hipo.interpreter.keyed_children_QMARK_ = (function hipo$interpreter$keyed_children_QMARK_(v){
return (!((hipo.interpreter.child_key(cljs.core.nth.cljs$core$IFn$_invoke$arity$2(v,(0))) == null)));
});
hipo.interpreter.reconciliate_children_BANG_ = (function hipo$interpreter$reconciliate_children_BANG_(el,och,nch,p__41607){
var map__41608 = p__41607;
var map__41608__$1 = (((((!((map__41608 == null))))?(((((map__41608.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__41608.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__41608):map__41608);
var m = map__41608__$1;
var interceptors = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__41608__$1,cljs.core.cst$kw$interceptors);
if(cljs.core.empty_QMARK_(nch)){
if((!(cljs.core.empty_QMARK_(och)))){
var b__26951__auto__ = ((function (map__41608,map__41608__$1,m,interceptors){
return (function (){
return hipo.dom.clear_BANG_(el);
});})(map__41608,map__41608__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,cljs.core.cst$kw$clear,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$target,el], null));
}
} else {
return null;
}
} else {
if(hipo.interpreter.keyed_children_QMARK_(nch)){
return hipo.interpreter.reconciliate_keyed_children_BANG_(el,och,nch,m);
} else {
return hipo.interpreter.reconciliate_non_keyed_children_BANG_(el,och,nch,m);
}
}
});
hipo.interpreter.reconciliate_vector_BANG_ = (function hipo$interpreter$reconciliate_vector_BANG_(el,oh,nh,p__41610){
var map__41611 = p__41610;
var map__41611__$1 = (((((!((map__41611 == null))))?(((((map__41611.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__41611.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__41611):map__41611);
var m = map__41611__$1;
var interceptors = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__41611__$1,cljs.core.cst$kw$interceptors);

if(((hipo.hiccup.literal_QMARK_(oh)) || ((!((hipo.hiccup.tag(nh) === hipo.hiccup.tag(oh))))))){
var nel = hipo.interpreter.create_child(nh,m);
var b__26951__auto__ = ((function (nel,map__41611,map__41611__$1,m,interceptors){
return (function (){

return hipo.dom.replace_BANG_(el,nel);
});})(nel,map__41611,map__41611__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,cljs.core.cst$kw$replace,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,nh], null));
}
} else {
var om = hipo.hiccup.attributes(oh);
var nm = hipo.hiccup.attributes(nh);
var och = hipo.hiccup.children(oh);
var nch = hipo.hiccup.children(nh);
var b__26951__auto___41613 = ((function (om,nm,och,nch,map__41611,map__41611__$1,m,interceptors){
return (function (){
return hipo.interpreter.reconciliate_children_BANG_(el,hipo.hiccup.flatten_children(och),hipo.hiccup.flatten_children(nch),m);
});})(om,nm,och,nch,map__41611,map__41611__$1,m,interceptors))
;
var v__26952__auto___41614 = interceptors;
if(((cljs.core.not(v__26952__auto___41614)) || (cljs.core.empty_QMARK_(v__26952__auto___41614)))){
b__26951__auto___41613();
} else {
hipo.interceptor.call(b__26951__auto___41613,v__26952__auto___41614,cljs.core.cst$kw$reconciliate,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$old_DASH_value,och,cljs.core.cst$kw$new_DASH_value,nch], null));
}

return hipo.interpreter.reconciliate_attributes_BANG_(el,hipo.hiccup.keyns(nh),hipo.hiccup.tag(nh),om,nm,m);
}
});
hipo.interpreter.reconciliate_BANG_ = (function hipo$interpreter$reconciliate_BANG_(el,oh,nh,p__41615){
var map__41616 = p__41615;
var map__41616__$1 = (((((!((map__41616 == null))))?(((((map__41616.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__41616.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__41616):map__41616);
var m = map__41616__$1;
var interceptors = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__41616__$1,cljs.core.cst$kw$interceptors);


var b__26951__auto__ = ((function (map__41616,map__41616__$1,m,interceptors){
return (function (){
if(hipo.hiccup.literal_QMARK_(nh)){
if((!((oh === nh)))){
var b__26951__auto__ = ((function (map__41616,map__41616__$1,m,interceptors){
return (function (){

return hipo.dom.replace_text_BANG_(el,cljs.core.str.cljs$core$IFn$_invoke$arity$1(nh));
});})(map__41616,map__41616__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,cljs.core.cst$kw$replace,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,nh], null));
}
} else {
return null;
}
} else {
return hipo.interpreter.reconciliate_vector_BANG_(el,oh,nh,m);
}
});})(map__41616,map__41616__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,cljs.core.cst$kw$reconciliate,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$old_DASH_value,oh,cljs.core.cst$kw$new_DASH_value,nh], null));
}
});

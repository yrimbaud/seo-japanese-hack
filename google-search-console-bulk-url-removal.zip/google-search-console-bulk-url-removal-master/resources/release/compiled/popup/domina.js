// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('domina');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('goog.dom');
goog.require('goog.dom.xml');
goog.require('goog.dom.classes');
goog.require('goog.dom.forms');
goog.require('goog.events');
goog.require('goog.style');
goog.require('goog.string');
goog.require('cljs.core');
goog.require('clojure.string');
goog.require('domina.support');
domina.re_html = /<|&#?\w+;/;
domina.re_leading_whitespace = /^\s+/;
domina.re_xhtml_tag = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/i;
domina.re_tag_name = /<([\w:]+)/;
domina.re_no_inner_html = /<(?:script|style)/i;
domina.re_tbody = /<tbody/i;
var opt_wrapper_30008 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(1),"<select multiple='multiple'>","</select>"], null);
var table_section_wrapper_30009 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(1),"<table>","</table>"], null);
var cell_wrapper_30010 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(3),"<table><tbody><tr>","</tr></tbody></table>"], null);
domina.wrap_map = cljs.core.PersistentHashMap.fromArrays(["td","optgroup","tfoot","tr","area",cljs.core.cst$kw$default,"option","legend","thead","col","caption","th","colgroup","tbody"],[cell_wrapper_30010,opt_wrapper_30008,table_section_wrapper_30009,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(2),"<table><tbody>","</tbody></table>"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(1),"<map>","</map>"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(0),"",""], null),opt_wrapper_30008,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(1),"<fieldset>","</fieldset>"], null),table_section_wrapper_30009,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [(2),"<table><tbody></tbody><colgroup>","</colgroup></table>"], null),table_section_wrapper_30009,cell_wrapper_30010,table_section_wrapper_30009,table_section_wrapper_30009]);
domina.remove_extraneous_tbody_BANG_ = (function domina$remove_extraneous_tbody_BANG_(div,html,tag_name,start_wrap){
var no_tbody_QMARK_ = cljs.core.not(cljs.core.re_find(domina.re_tbody,html));
var tbody = ((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(tag_name,"table")) && (no_tbody_QMARK_)))?(function (){var and__4120__auto__ = div.firstChild;
if(cljs.core.truth_(and__4120__auto__)){
return div.firstChild.childNodes;
} else {
return and__4120__auto__;
}
})():((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(start_wrap,"<table>")) && (no_tbody_QMARK_)))?div.childNodes:cljs.core.PersistentVector.EMPTY));
var seq__30011 = cljs.core.seq(tbody);
var chunk__30012 = null;
var count__30013 = (0);
var i__30014 = (0);
while(true){
if((i__30014 < count__30013)){
var child = chunk__30012.cljs$core$IIndexed$_nth$arity$2(null,i__30014);
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(child.nodeName,"tbody")) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(child.childNodes.length,(0))))){
child.parentNode.removeChild(child);
} else {
}


var G__30015 = seq__30011;
var G__30016 = chunk__30012;
var G__30017 = count__30013;
var G__30018 = (i__30014 + (1));
seq__30011 = G__30015;
chunk__30012 = G__30016;
count__30013 = G__30017;
i__30014 = G__30018;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__30011);
if(temp__5735__auto__){
var seq__30011__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__30011__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__30011__$1);
var G__30019 = cljs.core.chunk_rest(seq__30011__$1);
var G__30020 = c__4550__auto__;
var G__30021 = cljs.core.count(c__4550__auto__);
var G__30022 = (0);
seq__30011 = G__30019;
chunk__30012 = G__30020;
count__30013 = G__30021;
i__30014 = G__30022;
continue;
} else {
var child = cljs.core.first(seq__30011__$1);
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(child.nodeName,"tbody")) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(child.childNodes.length,(0))))){
child.parentNode.removeChild(child);
} else {
}


var G__30023 = cljs.core.next(seq__30011__$1);
var G__30024 = null;
var G__30025 = (0);
var G__30026 = (0);
seq__30011 = G__30023;
chunk__30012 = G__30024;
count__30013 = G__30025;
i__30014 = G__30026;
continue;
}
} else {
return null;
}
}
break;
}
});
domina.restore_leading_whitespace_BANG_ = (function domina$restore_leading_whitespace_BANG_(div,html){
return div.insertBefore(document.createTextNode(cljs.core.first(cljs.core.re_find(domina.re_leading_whitespace,html))),div.firstChild);
});
/**
 * takes an string of html and returns a NodeList of dom fragments
 */
domina.html_to_dom = (function domina$html_to_dom(html){
var html__$1 = clojure.string.replace(html,domina.re_xhtml_tag,"<$1></$2>");
var tag_name = cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.second(cljs.core.re_find(domina.re_tag_name,html__$1))).toLowerCase();
var vec__30027 = cljs.core.get.cljs$core$IFn$_invoke$arity$3(domina.wrap_map,tag_name,cljs.core.cst$kw$default.cljs$core$IFn$_invoke$arity$1(domina.wrap_map));
var depth = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__30027,(0),null);
var start_wrap = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__30027,(1),null);
var end_wrap = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__30027,(2),null);
var div = (function (){var wrapper = (function (){var div = document.createElement("div");
div.innerHTML = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(start_wrap),cljs.core.str.cljs$core$IFn$_invoke$arity$1(html__$1),cljs.core.str.cljs$core$IFn$_invoke$arity$1(end_wrap)].join('');

return div;
})();
var level = depth;
while(true){
if((level > (0))){
var G__30030 = wrapper.lastChild;
var G__30031 = (level - (1));
wrapper = G__30030;
level = G__30031;
continue;
} else {
return wrapper;
}
break;
}
})();
if(domina.support.extraneous_tbody_QMARK_){
domina.remove_extraneous_tbody_BANG_(div,html__$1,tag_name,start_wrap);
} else {
}

if(cljs.core.truth_((function (){var and__4120__auto__ = (!(domina.support.leading_whitespace_QMARK_));
if(and__4120__auto__){
return cljs.core.re_find(domina.re_leading_whitespace,html__$1);
} else {
return and__4120__auto__;
}
})())){
domina.restore_leading_whitespace_BANG_(div,html__$1);
} else {
}

return div.childNodes;
});
domina.string_to_dom = (function domina$string_to_dom(s){
if(cljs.core.truth_(cljs.core.re_find(domina.re_html,s))){
return domina.html_to_dom(s);
} else {
return document.createTextNode(s);
}
});

/**
 * @interface
 */
domina.DomContent = function(){};

/**
 * Returns the content as a sequence of nodes.
 */
domina.nodes = (function domina$nodes(content){
if((((!((content == null)))) && ((!((content.domina$DomContent$nodes$arity$1 == null)))))){
return content.domina$DomContent$nodes$arity$1(content);
} else {
var x__4433__auto__ = (((content == null))?null:content);
var m__4434__auto__ = (domina.nodes[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(content) : m__4434__auto__.call(null,content));
} else {
var m__4431__auto__ = (domina.nodes["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(content) : m__4431__auto__.call(null,content));
} else {
throw cljs.core.missing_protocol("DomContent.nodes",content);
}
}
}
});

/**
 * Returns the content as a single node (the first node, if the content contains more than one
 */
domina.single_node = (function domina$single_node(nodeseq){
if((((!((nodeseq == null)))) && ((!((nodeseq.domina$DomContent$single_node$arity$1 == null)))))){
return nodeseq.domina$DomContent$single_node$arity$1(nodeseq);
} else {
var x__4433__auto__ = (((nodeseq == null))?null:nodeseq);
var m__4434__auto__ = (domina.single_node[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(nodeseq) : m__4434__auto__.call(null,nodeseq));
} else {
var m__4431__auto__ = (domina.single_node["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(nodeseq) : m__4431__auto__.call(null,nodeseq));
} else {
throw cljs.core.missing_protocol("DomContent.single-node",nodeseq);
}
}
}
});

domina._STAR_debug_STAR_ = true;
domina.log_debug = (function domina$log_debug(var_args){
var args__4736__auto__ = [];
var len__4730__auto___30033 = arguments.length;
var i__4731__auto___30034 = (0);
while(true){
if((i__4731__auto___30034 < len__4730__auto___30033)){
args__4736__auto__.push((arguments[i__4731__auto___30034]));

var G__30035 = (i__4731__auto___30034 + (1));
i__4731__auto___30034 = G__30035;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return domina.log_debug.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

domina.log_debug.cljs$core$IFn$_invoke$arity$variadic = (function (mesg){
if(((domina._STAR_debug_STAR_) && ((!(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(window.console,undefined)))))){
return console.log(cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.str,mesg));
} else {
return null;
}
});

domina.log_debug.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
domina.log_debug.cljs$lang$applyTo = (function (seq30032){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq30032));
});

domina.log = (function domina$log(var_args){
var args__4736__auto__ = [];
var len__4730__auto___30037 = arguments.length;
var i__4731__auto___30038 = (0);
while(true){
if((i__4731__auto___30038 < len__4730__auto___30037)){
args__4736__auto__.push((arguments[i__4731__auto___30038]));

var G__30039 = (i__4731__auto___30038 + (1));
i__4731__auto___30038 = G__30039;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return domina.log.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

domina.log.cljs$core$IFn$_invoke$arity$variadic = (function (mesg){
if(cljs.core.truth_(window.console)){
return console.log(cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.str,mesg));
} else {
return null;
}
});

domina.log.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
domina.log.cljs$lang$applyTo = (function (seq30036){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq30036));
});

/**
 * Returns content containing a single node by looking up the given ID
 */
domina.by_id = (function domina$by_id(id){
var G__30040 = cljs.core.name(id);
return goog.dom.getElement(G__30040);
});
/**
 * Returns content containing nodes which have the specified CSS class.
 */
domina.by_class = (function domina$by_class(class_name){
var G__30041 = (function (){var G__30042 = cljs.core.name(class_name);
return goog.dom.getElementsByClass(G__30042);
})();
return (domina.normalize_seq.cljs$core$IFn$_invoke$arity$1 ? domina.normalize_seq.cljs$core$IFn$_invoke$arity$1(G__30041) : domina.normalize_seq.call(null,G__30041));
});
/**
 * Gets all the child nodes of the elements in a content. Same as (xpath content '*') but more efficient.
 */
domina.children = (function domina$children(content){
return cljs.core.doall.cljs$core$IFn$_invoke$arity$1(cljs.core.mapcat.cljs$core$IFn$_invoke$arity$variadic(goog.dom.getChildren,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([domina.nodes(content)], 0)));
});
/**
 * Returns the deepest common ancestor of the argument contents (which are presumed to be single nodes), or nil if they are from different documents.
 */
domina.common_ancestor = (function domina$common_ancestor(var_args){
var args__4736__auto__ = [];
var len__4730__auto___30044 = arguments.length;
var i__4731__auto___30045 = (0);
while(true){
if((i__4731__auto___30045 < len__4730__auto___30044)){
args__4736__auto__.push((arguments[i__4731__auto___30045]));

var G__30046 = (i__4731__auto___30045 + (1));
i__4731__auto___30045 = G__30046;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return domina.common_ancestor.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

domina.common_ancestor.cljs$core$IFn$_invoke$arity$variadic = (function (contents){
return cljs.core.apply.cljs$core$IFn$_invoke$arity$2(goog.dom.findCommonAncestor,cljs.core.map.cljs$core$IFn$_invoke$arity$2(domina.single_node,contents));
});

domina.common_ancestor.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
domina.common_ancestor.cljs$lang$applyTo = (function (seq30043){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq30043));
});

/**
 * Returns true if the first argument is an ancestor of the second argument. Presumes both arguments are single-node contents.
 */
domina.ancestor_QMARK_ = (function domina$ancestor_QMARK_(ancestor_content,descendant_content){
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(domina.common_ancestor.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([ancestor_content,descendant_content], 0)),domina.single_node(ancestor_content));
});
/**
 * Returns a deep clone of content.
 */
domina.clone = (function domina$clone(content){
return cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p1__30047_SHARP_){
return p1__30047_SHARP_.cloneNode(true);
}),domina.nodes(content));
});
/**
 * Given a parent and child contents, appends each of the children to all of the parents. If there is more than one node in the parent content, clones the children for the additional parents. Returns the parent content.
 */
domina.append_BANG_ = (function domina$append_BANG_(parent_content,child_content){
(domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3 ? domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3(goog.dom.appendChild,parent_content,child_content) : domina.apply_with_cloning.call(null,goog.dom.appendChild,parent_content,child_content));

return parent_content;
});
/**
 * Given a parent and child contents, appends each of the children to all of the parents at the specified index. If there is more than one node in the parent content, clones the children for the additional parents. Returns the parent content.
 */
domina.insert_BANG_ = (function domina$insert_BANG_(parent_content,child_content,idx){
var G__30050_30053 = (function (p1__30048_SHARP_,p2__30049_SHARP_){
return goog.dom.insertChildAt(p1__30048_SHARP_,p2__30049_SHARP_,idx);
});
var G__30051_30054 = parent_content;
var G__30052_30055 = child_content;
(domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3 ? domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3(G__30050_30053,G__30051_30054,G__30052_30055) : domina.apply_with_cloning.call(null,G__30050_30053,G__30051_30054,G__30052_30055));

return parent_content;
});
/**
 * Given a parent and child contents, prepends each of the children to all of the parents. If there is more than one node in the parent content, clones the children for the additional parents. Returns the parent content.
 */
domina.prepend_BANG_ = (function domina$prepend_BANG_(parent_content,child_content){
domina.insert_BANG_(parent_content,child_content,(0));

return parent_content;
});
/**
 * Given a content and some new content, inserts the new content immediately before the reference content. If there is more than one node in the reference content, clones the new content for each one.
 */
domina.insert_before_BANG_ = (function domina$insert_before_BANG_(content,new_content){
var G__30058_30061 = (function (p1__30057_SHARP_,p2__30056_SHARP_){
return goog.dom.insertSiblingBefore(p2__30056_SHARP_,p1__30057_SHARP_);
});
var G__30059_30062 = content;
var G__30060_30063 = new_content;
(domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3 ? domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3(G__30058_30061,G__30059_30062,G__30060_30063) : domina.apply_with_cloning.call(null,G__30058_30061,G__30059_30062,G__30060_30063));

return content;
});
/**
 * Given a content and some new content, inserts the new content immediately after the reference content. If there is more than one node in the reference content, clones the new content for each one.
 */
domina.insert_after_BANG_ = (function domina$insert_after_BANG_(content,new_content){
var G__30066_30069 = (function (p1__30065_SHARP_,p2__30064_SHARP_){
return goog.dom.insertSiblingAfter(p2__30064_SHARP_,p1__30065_SHARP_);
});
var G__30067_30070 = content;
var G__30068_30071 = new_content;
(domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3 ? domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3(G__30066_30069,G__30067_30070,G__30068_30071) : domina.apply_with_cloning.call(null,G__30066_30069,G__30067_30070,G__30068_30071));

return content;
});
/**
 * Given some old content and some new content, replaces the old content with new content. If there are multiple nodes in the old content, replaces each of them and clones the new content as necessary.
 */
domina.swap_content_BANG_ = (function domina$swap_content_BANG_(old_content,new_content){
var G__30074_30077 = (function (p1__30073_SHARP_,p2__30072_SHARP_){
return goog.dom.replaceNode(p2__30072_SHARP_,p1__30073_SHARP_);
});
var G__30075_30078 = old_content;
var G__30076_30079 = new_content;
(domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3 ? domina.apply_with_cloning.cljs$core$IFn$_invoke$arity$3(G__30074_30077,G__30075_30078,G__30076_30079) : domina.apply_with_cloning.call(null,G__30074_30077,G__30075_30078,G__30076_30079));

return old_content;
});
/**
 * Removes all the nodes in a content from the DOM and returns them.
 */
domina.detach_BANG_ = (function domina$detach_BANG_(content){
return cljs.core.doall.cljs$core$IFn$_invoke$arity$1(cljs.core.map.cljs$core$IFn$_invoke$arity$2(goog.dom.removeNode,domina.nodes(content)));
});
/**
 * Removes all the nodes in a content from the DOM. Returns nil.
 */
domina.destroy_BANG_ = (function domina$destroy_BANG_(content){
return cljs.core.dorun.cljs$core$IFn$_invoke$arity$1(cljs.core.map.cljs$core$IFn$_invoke$arity$2(goog.dom.removeNode,domina.nodes(content)));
});
/**
 * Removes all the child nodes in a content from the DOM. Returns the original content.
 */
domina.destroy_children_BANG_ = (function domina$destroy_children_BANG_(content){
cljs.core.dorun.cljs$core$IFn$_invoke$arity$1(cljs.core.map.cljs$core$IFn$_invoke$arity$2(goog.dom.removeChildren,domina.nodes(content)));

return content;
});
/**
 * Gets the value of a CSS property. Assumes content will be a single node. Name may be a string or keyword. Returns nil if there is no value set for the style.
 */
domina.style = (function domina$style(content,name){
var s = (function (){var G__30080 = domina.single_node(content);
var G__30081 = cljs.core.name(name);
return goog.style.getStyle(G__30080,G__30081);
})();
if(clojure.string.blank_QMARK_(s)){
return null;
} else {
return s;
}
});
/**
 * Gets the value of an HTML attribute. Assumes content will be a single node. Name may be a stirng or keyword. Returns nil if there is no value set for the style.
 */
domina.attr = (function domina$attr(content,name){
return domina.single_node(content).getAttribute(cljs.core.name(name));
});
/**
 * Sets the value of a CSS property for each node in the content. Name may be a string or keyword. Value will be cast to a string, multiple values wil be concatenated.
 */
domina.set_style_BANG_ = (function domina$set_style_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___30101 = arguments.length;
var i__4731__auto___30102 = (0);
while(true){
if((i__4731__auto___30102 < len__4730__auto___30101)){
args__4736__auto__.push((arguments[i__4731__auto___30102]));

var G__30103 = (i__4731__auto___30102 + (1));
i__4731__auto___30102 = G__30103;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return domina.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

domina.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (content,name,value){
var seq__30085_30104 = cljs.core.seq(domina.nodes(content));
var chunk__30086_30105 = null;
var count__30087_30106 = (0);
var i__30088_30107 = (0);
while(true){
if((i__30088_30107 < count__30087_30106)){
var n_30108 = chunk__30086_30105.cljs$core$IIndexed$_nth$arity$2(null,i__30088_30107);
var G__30095_30109 = n_30108;
var G__30096_30110 = cljs.core.name(name);
var G__30097_30111 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.str,value);
goog.style.setStyle(G__30095_30109,G__30096_30110,G__30097_30111);


var G__30112 = seq__30085_30104;
var G__30113 = chunk__30086_30105;
var G__30114 = count__30087_30106;
var G__30115 = (i__30088_30107 + (1));
seq__30085_30104 = G__30112;
chunk__30086_30105 = G__30113;
count__30087_30106 = G__30114;
i__30088_30107 = G__30115;
continue;
} else {
var temp__5735__auto___30116 = cljs.core.seq(seq__30085_30104);
if(temp__5735__auto___30116){
var seq__30085_30117__$1 = temp__5735__auto___30116;
if(cljs.core.chunked_seq_QMARK_(seq__30085_30117__$1)){
var c__4550__auto___30118 = cljs.core.chunk_first(seq__30085_30117__$1);
var G__30119 = cljs.core.chunk_rest(seq__30085_30117__$1);
var G__30120 = c__4550__auto___30118;
var G__30121 = cljs.core.count(c__4550__auto___30118);
var G__30122 = (0);
seq__30085_30104 = G__30119;
chunk__30086_30105 = G__30120;
count__30087_30106 = G__30121;
i__30088_30107 = G__30122;
continue;
} else {
var n_30123 = cljs.core.first(seq__30085_30117__$1);
var G__30098_30124 = n_30123;
var G__30099_30125 = cljs.core.name(name);
var G__30100_30126 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.str,value);
goog.style.setStyle(G__30098_30124,G__30099_30125,G__30100_30126);


var G__30127 = cljs.core.next(seq__30085_30117__$1);
var G__30128 = null;
var G__30129 = (0);
var G__30130 = (0);
seq__30085_30104 = G__30127;
chunk__30086_30105 = G__30128;
count__30087_30106 = G__30129;
i__30088_30107 = G__30130;
continue;
}
} else {
}
}
break;
}

return content;
});

domina.set_style_BANG_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
domina.set_style_BANG_.cljs$lang$applyTo = (function (seq30082){
var G__30083 = cljs.core.first(seq30082);
var seq30082__$1 = cljs.core.next(seq30082);
var G__30084 = cljs.core.first(seq30082__$1);
var seq30082__$2 = cljs.core.next(seq30082__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__30083,G__30084,seq30082__$2);
});

/**
 * Sets the value of an HTML property for each node in the content. Name may be a string or keyword. Value will be cast to a string, multiple values wil be concatenated.
 */
domina.set_attr_BANG_ = (function domina$set_attr_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___30138 = arguments.length;
var i__4731__auto___30139 = (0);
while(true){
if((i__4731__auto___30139 < len__4730__auto___30138)){
args__4736__auto__.push((arguments[i__4731__auto___30139]));

var G__30140 = (i__4731__auto___30139 + (1));
i__4731__auto___30139 = G__30140;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return domina.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

domina.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (content,name,value){
var seq__30134_30141 = cljs.core.seq(domina.nodes(content));
var chunk__30135_30142 = null;
var count__30136_30143 = (0);
var i__30137_30144 = (0);
while(true){
if((i__30137_30144 < count__30136_30143)){
var n_30145 = chunk__30135_30142.cljs$core$IIndexed$_nth$arity$2(null,i__30137_30144);
n_30145.setAttribute(cljs.core.name(name),cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.str,value));


var G__30146 = seq__30134_30141;
var G__30147 = chunk__30135_30142;
var G__30148 = count__30136_30143;
var G__30149 = (i__30137_30144 + (1));
seq__30134_30141 = G__30146;
chunk__30135_30142 = G__30147;
count__30136_30143 = G__30148;
i__30137_30144 = G__30149;
continue;
} else {
var temp__5735__auto___30150 = cljs.core.seq(seq__30134_30141);
if(temp__5735__auto___30150){
var seq__30134_30151__$1 = temp__5735__auto___30150;
if(cljs.core.chunked_seq_QMARK_(seq__30134_30151__$1)){
var c__4550__auto___30152 = cljs.core.chunk_first(seq__30134_30151__$1);
var G__30153 = cljs.core.chunk_rest(seq__30134_30151__$1);
var G__30154 = c__4550__auto___30152;
var G__30155 = cljs.core.count(c__4550__auto___30152);
var G__30156 = (0);
seq__30134_30141 = G__30153;
chunk__30135_30142 = G__30154;
count__30136_30143 = G__30155;
i__30137_30144 = G__30156;
continue;
} else {
var n_30157 = cljs.core.first(seq__30134_30151__$1);
n_30157.setAttribute(cljs.core.name(name),cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.str,value));


var G__30158 = cljs.core.next(seq__30134_30151__$1);
var G__30159 = null;
var G__30160 = (0);
var G__30161 = (0);
seq__30134_30141 = G__30158;
chunk__30135_30142 = G__30159;
count__30136_30143 = G__30160;
i__30137_30144 = G__30161;
continue;
}
} else {
}
}
break;
}

return content;
});

domina.set_attr_BANG_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
domina.set_attr_BANG_.cljs$lang$applyTo = (function (seq30131){
var G__30132 = cljs.core.first(seq30131);
var seq30131__$1 = cljs.core.next(seq30131);
var G__30133 = cljs.core.first(seq30131__$1);
var seq30131__$2 = cljs.core.next(seq30131__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__30132,G__30133,seq30131__$2);
});

/**
 * Removes the specified HTML property for each node in the content. Name may be a string or keyword.
 */
domina.remove_attr_BANG_ = (function domina$remove_attr_BANG_(content,name){
var seq__30162_30166 = cljs.core.seq(domina.nodes(content));
var chunk__30163_30167 = null;
var count__30164_30168 = (0);
var i__30165_30169 = (0);
while(true){
if((i__30165_30169 < count__30164_30168)){
var n_30170 = chunk__30163_30167.cljs$core$IIndexed$_nth$arity$2(null,i__30165_30169);
n_30170.removeAttribute(cljs.core.name(name));


var G__30171 = seq__30162_30166;
var G__30172 = chunk__30163_30167;
var G__30173 = count__30164_30168;
var G__30174 = (i__30165_30169 + (1));
seq__30162_30166 = G__30171;
chunk__30163_30167 = G__30172;
count__30164_30168 = G__30173;
i__30165_30169 = G__30174;
continue;
} else {
var temp__5735__auto___30175 = cljs.core.seq(seq__30162_30166);
if(temp__5735__auto___30175){
var seq__30162_30176__$1 = temp__5735__auto___30175;
if(cljs.core.chunked_seq_QMARK_(seq__30162_30176__$1)){
var c__4550__auto___30177 = cljs.core.chunk_first(seq__30162_30176__$1);
var G__30178 = cljs.core.chunk_rest(seq__30162_30176__$1);
var G__30179 = c__4550__auto___30177;
var G__30180 = cljs.core.count(c__4550__auto___30177);
var G__30181 = (0);
seq__30162_30166 = G__30178;
chunk__30163_30167 = G__30179;
count__30164_30168 = G__30180;
i__30165_30169 = G__30181;
continue;
} else {
var n_30182 = cljs.core.first(seq__30162_30176__$1);
n_30182.removeAttribute(cljs.core.name(name));


var G__30183 = cljs.core.next(seq__30162_30176__$1);
var G__30184 = null;
var G__30185 = (0);
var G__30186 = (0);
seq__30162_30166 = G__30183;
chunk__30163_30167 = G__30184;
count__30164_30168 = G__30185;
i__30165_30169 = G__30186;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Parses a CSS style string and returns the properties as a map.
 */
domina.parse_style_attributes = (function domina$parse_style_attributes(style){
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3((function (acc,pair){
var vec__30187 = pair.split(/\s*:\s*/);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__30187,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__30187,(1),null);
if(cljs.core.truth_((function (){var and__4120__auto__ = k;
if(cljs.core.truth_(and__4120__auto__)){
return v;
} else {
return and__4120__auto__;
}
})())){
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(acc,cljs.core.keyword.cljs$core$IFn$_invoke$arity$1(k.toLowerCase()),v);
} else {
return acc;
}
}),cljs.core.PersistentArrayMap.EMPTY,style.split(/\s*;\s*/));
});
/**
 * Returns a map of the CSS styles/values. Assumes content will be a single node. Style names are returned as keywords.
 */
domina.styles = (function domina$styles(content){
var style = domina.attr(content,"style");
if(typeof style === 'string'){
return domina.parse_style_attributes(style);
} else {
if((style == null)){
return cljs.core.PersistentArrayMap.EMPTY;
} else {
if(cljs.core.truth_(style.cssText)){
return domina.parse_style_attributes(style.cssText);
} else {
return cljs.core.PersistentArrayMap.EMPTY;

}
}
}
});
/**
 * Returns a map of the HTML attributes/values. Assumes content will be a single node. Attribute names are returned as keywords.
 */
domina.attrs = (function domina$attrs(content){
var node = domina.single_node(content);
var attrs = node.attributes;
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$2(cljs.core.conj,cljs.core.filter.cljs$core$IFn$_invoke$arity$2(cljs.core.complement(cljs.core.nil_QMARK_),cljs.core.map.cljs$core$IFn$_invoke$arity$2(((function (node,attrs){
return (function (p1__30190_SHARP_){
var attr = attrs.item(p1__30190_SHARP_);
var value = attr.nodeValue;
if(((cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(null,value)) && (cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2("",value)))){
return cljs.core.PersistentArrayMap.createAsIfByAssoc([cljs.core.keyword.cljs$core$IFn$_invoke$arity$1(attr.nodeName.toLowerCase()),attr.nodeValue]);
} else {
return null;
}
});})(node,attrs))
,cljs.core.range.cljs$core$IFn$_invoke$arity$1(attrs.length))));
});
/**
 * Sets the specified CSS styles for each node in the content, given a map of names and values. Style names may be keywords or strings.
 */
domina.set_styles_BANG_ = (function domina$set_styles_BANG_(content,styles){
var seq__30191_30207 = cljs.core.seq(styles);
var chunk__30192_30208 = null;
var count__30193_30209 = (0);
var i__30194_30210 = (0);
while(true){
if((i__30194_30210 < count__30193_30209)){
var vec__30201_30211 = chunk__30192_30208.cljs$core$IIndexed$_nth$arity$2(null,i__30194_30210);
var name_30212 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__30201_30211,(0),null);
var value_30213 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__30201_30211,(1),null);
domina.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(content,name_30212,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([value_30213], 0));


var G__30214 = seq__30191_30207;
var G__30215 = chunk__30192_30208;
var G__30216 = count__30193_30209;
var G__30217 = (i__30194_30210 + (1));
seq__30191_30207 = G__30214;
chunk__30192_30208 = G__30215;
count__30193_30209 = G__30216;
i__30194_30210 = G__30217;
continue;
} else {
var temp__5735__auto___30218 = cljs.core.seq(seq__30191_30207);
if(temp__5735__auto___30218){
var seq__30191_30219__$1 = temp__5735__auto___30218;
if(cljs.core.chunked_seq_QMARK_(seq__30191_30219__$1)){
var c__4550__auto___30220 = cljs.core.chunk_first(seq__30191_30219__$1);
var G__30221 = cljs.core.chunk_rest(seq__30191_30219__$1);
var G__30222 = c__4550__auto___30220;
var G__30223 = cljs.core.count(c__4550__auto___30220);
var G__30224 = (0);
seq__30191_30207 = G__30221;
chunk__30192_30208 = G__30222;
count__30193_30209 = G__30223;
i__30194_30210 = G__30224;
continue;
} else {
var vec__30204_30225 = cljs.core.first(seq__30191_30219__$1);
var name_30226 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__30204_30225,(0),null);
var value_30227 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__30204_30225,(1),null);
domina.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(content,name_30226,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([value_30227], 0));


var G__30228 = cljs.core.next(seq__30191_30219__$1);
var G__30229 = null;
var G__30230 = (0);
var G__30231 = (0);
seq__30191_30207 = G__30228;
chunk__30192_30208 = G__30229;
count__30193_30209 = G__30230;
i__30194_30210 = G__30231;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Sets the specified attributes for each node in the content, given a map of names and values. Names may be a string or keyword. Values will be cast to a string, multiple values wil be concatenated.
 */
domina.set_attrs_BANG_ = (function domina$set_attrs_BANG_(content,attrs){
var seq__30232_30248 = cljs.core.seq(attrs);
var chunk__30233_30249 = null;
var count__30234_30250 = (0);
var i__30235_30251 = (0);
while(true){
if((i__30235_30251 < count__30234_30250)){
var vec__30242_30252 = chunk__30233_30249.cljs$core$IIndexed$_nth$arity$2(null,i__30235_30251);
var name_30253 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__30242_30252,(0),null);
var value_30254 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__30242_30252,(1),null);
domina.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic(content,name_30253,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([value_30254], 0));


var G__30255 = seq__30232_30248;
var G__30256 = chunk__30233_30249;
var G__30257 = count__30234_30250;
var G__30258 = (i__30235_30251 + (1));
seq__30232_30248 = G__30255;
chunk__30233_30249 = G__30256;
count__30234_30250 = G__30257;
i__30235_30251 = G__30258;
continue;
} else {
var temp__5735__auto___30259 = cljs.core.seq(seq__30232_30248);
if(temp__5735__auto___30259){
var seq__30232_30260__$1 = temp__5735__auto___30259;
if(cljs.core.chunked_seq_QMARK_(seq__30232_30260__$1)){
var c__4550__auto___30261 = cljs.core.chunk_first(seq__30232_30260__$1);
var G__30262 = cljs.core.chunk_rest(seq__30232_30260__$1);
var G__30263 = c__4550__auto___30261;
var G__30264 = cljs.core.count(c__4550__auto___30261);
var G__30265 = (0);
seq__30232_30248 = G__30262;
chunk__30233_30249 = G__30263;
count__30234_30250 = G__30264;
i__30235_30251 = G__30265;
continue;
} else {
var vec__30245_30266 = cljs.core.first(seq__30232_30260__$1);
var name_30267 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__30245_30266,(0),null);
var value_30268 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__30245_30266,(1),null);
domina.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic(content,name_30267,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([value_30268], 0));


var G__30269 = cljs.core.next(seq__30232_30260__$1);
var G__30270 = null;
var G__30271 = (0);
var G__30272 = (0);
seq__30232_30248 = G__30269;
chunk__30233_30249 = G__30270;
count__30234_30250 = G__30271;
i__30235_30251 = G__30272;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Returns true if the node has the specified CSS class. Assumes content is a single node.
 */
domina.has_class_QMARK_ = (function domina$has_class_QMARK_(content,class$){
var G__30273 = domina.single_node(content);
var G__30274 = class$;
return goog.dom.classes.has(G__30273,G__30274);
});
/**
 * Adds the specified CSS class to each node in the content.
 */
domina.add_class_BANG_ = (function domina$add_class_BANG_(content,class$){
var seq__30275_30279 = cljs.core.seq(domina.nodes(content));
var chunk__30276_30280 = null;
var count__30277_30281 = (0);
var i__30278_30282 = (0);
while(true){
if((i__30278_30282 < count__30277_30281)){
var node_30283 = chunk__30276_30280.cljs$core$IIndexed$_nth$arity$2(null,i__30278_30282);
goog.dom.classes.add(node_30283,class$);


var G__30284 = seq__30275_30279;
var G__30285 = chunk__30276_30280;
var G__30286 = count__30277_30281;
var G__30287 = (i__30278_30282 + (1));
seq__30275_30279 = G__30284;
chunk__30276_30280 = G__30285;
count__30277_30281 = G__30286;
i__30278_30282 = G__30287;
continue;
} else {
var temp__5735__auto___30288 = cljs.core.seq(seq__30275_30279);
if(temp__5735__auto___30288){
var seq__30275_30289__$1 = temp__5735__auto___30288;
if(cljs.core.chunked_seq_QMARK_(seq__30275_30289__$1)){
var c__4550__auto___30290 = cljs.core.chunk_first(seq__30275_30289__$1);
var G__30291 = cljs.core.chunk_rest(seq__30275_30289__$1);
var G__30292 = c__4550__auto___30290;
var G__30293 = cljs.core.count(c__4550__auto___30290);
var G__30294 = (0);
seq__30275_30279 = G__30291;
chunk__30276_30280 = G__30292;
count__30277_30281 = G__30293;
i__30278_30282 = G__30294;
continue;
} else {
var node_30295 = cljs.core.first(seq__30275_30289__$1);
goog.dom.classes.add(node_30295,class$);


var G__30296 = cljs.core.next(seq__30275_30289__$1);
var G__30297 = null;
var G__30298 = (0);
var G__30299 = (0);
seq__30275_30279 = G__30296;
chunk__30276_30280 = G__30297;
count__30277_30281 = G__30298;
i__30278_30282 = G__30299;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Removes the specified CSS class from each node in the content.
 */
domina.remove_class_BANG_ = (function domina$remove_class_BANG_(content,class$){
var seq__30300_30304 = cljs.core.seq(domina.nodes(content));
var chunk__30301_30305 = null;
var count__30302_30306 = (0);
var i__30303_30307 = (0);
while(true){
if((i__30303_30307 < count__30302_30306)){
var node_30308 = chunk__30301_30305.cljs$core$IIndexed$_nth$arity$2(null,i__30303_30307);
goog.dom.classes.remove(node_30308,class$);


var G__30309 = seq__30300_30304;
var G__30310 = chunk__30301_30305;
var G__30311 = count__30302_30306;
var G__30312 = (i__30303_30307 + (1));
seq__30300_30304 = G__30309;
chunk__30301_30305 = G__30310;
count__30302_30306 = G__30311;
i__30303_30307 = G__30312;
continue;
} else {
var temp__5735__auto___30313 = cljs.core.seq(seq__30300_30304);
if(temp__5735__auto___30313){
var seq__30300_30314__$1 = temp__5735__auto___30313;
if(cljs.core.chunked_seq_QMARK_(seq__30300_30314__$1)){
var c__4550__auto___30315 = cljs.core.chunk_first(seq__30300_30314__$1);
var G__30316 = cljs.core.chunk_rest(seq__30300_30314__$1);
var G__30317 = c__4550__auto___30315;
var G__30318 = cljs.core.count(c__4550__auto___30315);
var G__30319 = (0);
seq__30300_30304 = G__30316;
chunk__30301_30305 = G__30317;
count__30302_30306 = G__30318;
i__30303_30307 = G__30319;
continue;
} else {
var node_30320 = cljs.core.first(seq__30300_30314__$1);
goog.dom.classes.remove(node_30320,class$);


var G__30321 = cljs.core.next(seq__30300_30314__$1);
var G__30322 = null;
var G__30323 = (0);
var G__30324 = (0);
seq__30300_30304 = G__30321;
chunk__30301_30305 = G__30322;
count__30302_30306 = G__30323;
i__30303_30307 = G__30324;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Toggles the specified CSS class from each node in the content.
 */
domina.toggle_class_BANG_ = (function domina$toggle_class_BANG_(content,class$){
var seq__30325_30329 = cljs.core.seq(domina.nodes(content));
var chunk__30326_30330 = null;
var count__30327_30331 = (0);
var i__30328_30332 = (0);
while(true){
if((i__30328_30332 < count__30327_30331)){
var node_30333 = chunk__30326_30330.cljs$core$IIndexed$_nth$arity$2(null,i__30328_30332);
goog.dom.classes.toggle(node_30333,class$);


var G__30334 = seq__30325_30329;
var G__30335 = chunk__30326_30330;
var G__30336 = count__30327_30331;
var G__30337 = (i__30328_30332 + (1));
seq__30325_30329 = G__30334;
chunk__30326_30330 = G__30335;
count__30327_30331 = G__30336;
i__30328_30332 = G__30337;
continue;
} else {
var temp__5735__auto___30338 = cljs.core.seq(seq__30325_30329);
if(temp__5735__auto___30338){
var seq__30325_30339__$1 = temp__5735__auto___30338;
if(cljs.core.chunked_seq_QMARK_(seq__30325_30339__$1)){
var c__4550__auto___30340 = cljs.core.chunk_first(seq__30325_30339__$1);
var G__30341 = cljs.core.chunk_rest(seq__30325_30339__$1);
var G__30342 = c__4550__auto___30340;
var G__30343 = cljs.core.count(c__4550__auto___30340);
var G__30344 = (0);
seq__30325_30329 = G__30341;
chunk__30326_30330 = G__30342;
count__30327_30331 = G__30343;
i__30328_30332 = G__30344;
continue;
} else {
var node_30345 = cljs.core.first(seq__30325_30339__$1);
goog.dom.classes.toggle(node_30345,class$);


var G__30346 = cljs.core.next(seq__30325_30339__$1);
var G__30347 = null;
var G__30348 = (0);
var G__30349 = (0);
seq__30325_30329 = G__30346;
chunk__30326_30330 = G__30347;
count__30327_30331 = G__30348;
i__30328_30332 = G__30349;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Returns a seq of all the CSS classes currently applied to a node. Assumes content is a single node.
 */
domina.classes = (function domina$classes(content){
return cljs.core.seq((function (){var G__30350 = domina.single_node(content);
return goog.dom.classes.get(G__30350);
})());
});
/**
 * Sets the class attribute of the content nodes to classes, which can
 *   be either a class attribute string or a seq of classname strings.
 */
domina.set_classes_BANG_ = (function domina$set_classes_BANG_(content,classes){
var classes_30355__$1 = ((cljs.core.coll_QMARK_(classes))?clojure.string.join.cljs$core$IFn$_invoke$arity$2(" ",classes):classes);
var seq__30351_30356 = cljs.core.seq(domina.nodes(content));
var chunk__30352_30357 = null;
var count__30353_30358 = (0);
var i__30354_30359 = (0);
while(true){
if((i__30354_30359 < count__30353_30358)){
var node_30360 = chunk__30352_30357.cljs$core$IIndexed$_nth$arity$2(null,i__30354_30359);
goog.dom.classes.set(node_30360,classes_30355__$1);


var G__30361 = seq__30351_30356;
var G__30362 = chunk__30352_30357;
var G__30363 = count__30353_30358;
var G__30364 = (i__30354_30359 + (1));
seq__30351_30356 = G__30361;
chunk__30352_30357 = G__30362;
count__30353_30358 = G__30363;
i__30354_30359 = G__30364;
continue;
} else {
var temp__5735__auto___30365 = cljs.core.seq(seq__30351_30356);
if(temp__5735__auto___30365){
var seq__30351_30366__$1 = temp__5735__auto___30365;
if(cljs.core.chunked_seq_QMARK_(seq__30351_30366__$1)){
var c__4550__auto___30367 = cljs.core.chunk_first(seq__30351_30366__$1);
var G__30368 = cljs.core.chunk_rest(seq__30351_30366__$1);
var G__30369 = c__4550__auto___30367;
var G__30370 = cljs.core.count(c__4550__auto___30367);
var G__30371 = (0);
seq__30351_30356 = G__30368;
chunk__30352_30357 = G__30369;
count__30353_30358 = G__30370;
i__30354_30359 = G__30371;
continue;
} else {
var node_30372 = cljs.core.first(seq__30351_30366__$1);
goog.dom.classes.set(node_30372,classes_30355__$1);


var G__30373 = cljs.core.next(seq__30351_30366__$1);
var G__30374 = null;
var G__30375 = (0);
var G__30376 = (0);
seq__30351_30356 = G__30373;
chunk__30352_30357 = G__30374;
count__30353_30358 = G__30375;
i__30354_30359 = G__30376;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Returns the text of a node. Assumes content is a single node. For consistency across browsers, will always trim whitespace of the beginning and end of the returned text.
 */
domina.text = (function domina$text(content){
var G__30377 = (function (){var G__30378 = domina.single_node(content);
return goog.dom.getTextContent(G__30378);
})();
return goog.string.trim(G__30377);
});
/**
 * Sets the text value of all the nodes in the given content.
 */
domina.set_text_BANG_ = (function domina$set_text_BANG_(content,value){
var seq__30379_30383 = cljs.core.seq(domina.nodes(content));
var chunk__30380_30384 = null;
var count__30381_30385 = (0);
var i__30382_30386 = (0);
while(true){
if((i__30382_30386 < count__30381_30385)){
var node_30387 = chunk__30380_30384.cljs$core$IIndexed$_nth$arity$2(null,i__30382_30386);
goog.dom.setTextContent(node_30387,value);


var G__30388 = seq__30379_30383;
var G__30389 = chunk__30380_30384;
var G__30390 = count__30381_30385;
var G__30391 = (i__30382_30386 + (1));
seq__30379_30383 = G__30388;
chunk__30380_30384 = G__30389;
count__30381_30385 = G__30390;
i__30382_30386 = G__30391;
continue;
} else {
var temp__5735__auto___30392 = cljs.core.seq(seq__30379_30383);
if(temp__5735__auto___30392){
var seq__30379_30393__$1 = temp__5735__auto___30392;
if(cljs.core.chunked_seq_QMARK_(seq__30379_30393__$1)){
var c__4550__auto___30394 = cljs.core.chunk_first(seq__30379_30393__$1);
var G__30395 = cljs.core.chunk_rest(seq__30379_30393__$1);
var G__30396 = c__4550__auto___30394;
var G__30397 = cljs.core.count(c__4550__auto___30394);
var G__30398 = (0);
seq__30379_30383 = G__30395;
chunk__30380_30384 = G__30396;
count__30381_30385 = G__30397;
i__30382_30386 = G__30398;
continue;
} else {
var node_30399 = cljs.core.first(seq__30379_30393__$1);
goog.dom.setTextContent(node_30399,value);


var G__30400 = cljs.core.next(seq__30379_30393__$1);
var G__30401 = null;
var G__30402 = (0);
var G__30403 = (0);
seq__30379_30383 = G__30400;
chunk__30380_30384 = G__30401;
count__30381_30385 = G__30402;
i__30382_30386 = G__30403;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Returns the value of a node (presumably a form field). Assumes content is a single node.
 */
domina.value = (function domina$value(content){
var G__30404 = domina.single_node(content);
return goog.dom.forms.getValue(G__30404);
});
/**
 * Sets the value of all the nodes (presumably form fields) in the given content.
 */
domina.set_value_BANG_ = (function domina$set_value_BANG_(content,value){
var seq__30405_30409 = cljs.core.seq(domina.nodes(content));
var chunk__30406_30410 = null;
var count__30407_30411 = (0);
var i__30408_30412 = (0);
while(true){
if((i__30408_30412 < count__30407_30411)){
var node_30413 = chunk__30406_30410.cljs$core$IIndexed$_nth$arity$2(null,i__30408_30412);
goog.dom.forms.setValue(node_30413,value);


var G__30414 = seq__30405_30409;
var G__30415 = chunk__30406_30410;
var G__30416 = count__30407_30411;
var G__30417 = (i__30408_30412 + (1));
seq__30405_30409 = G__30414;
chunk__30406_30410 = G__30415;
count__30407_30411 = G__30416;
i__30408_30412 = G__30417;
continue;
} else {
var temp__5735__auto___30418 = cljs.core.seq(seq__30405_30409);
if(temp__5735__auto___30418){
var seq__30405_30419__$1 = temp__5735__auto___30418;
if(cljs.core.chunked_seq_QMARK_(seq__30405_30419__$1)){
var c__4550__auto___30420 = cljs.core.chunk_first(seq__30405_30419__$1);
var G__30421 = cljs.core.chunk_rest(seq__30405_30419__$1);
var G__30422 = c__4550__auto___30420;
var G__30423 = cljs.core.count(c__4550__auto___30420);
var G__30424 = (0);
seq__30405_30409 = G__30421;
chunk__30406_30410 = G__30422;
count__30407_30411 = G__30423;
i__30408_30412 = G__30424;
continue;
} else {
var node_30425 = cljs.core.first(seq__30405_30419__$1);
goog.dom.forms.setValue(node_30425,value);


var G__30426 = cljs.core.next(seq__30405_30419__$1);
var G__30427 = null;
var G__30428 = (0);
var G__30429 = (0);
seq__30405_30409 = G__30426;
chunk__30406_30410 = G__30427;
count__30407_30411 = G__30428;
i__30408_30412 = G__30429;
continue;
}
} else {
}
}
break;
}

return content;
});
/**
 * Returns the innerHTML of a node. Assumes content is a single node.
 */
domina.html = (function domina$html(content){
return domina.single_node(content).innerHTML;
});
domina.replace_children_BANG_ = (function domina$replace_children_BANG_(content,inner_content){
return domina.append_BANG_(domina.destroy_children_BANG_(content),inner_content);
});
domina.set_inner_html_BANG_ = (function domina$set_inner_html_BANG_(content,html_string){
var allows_inner_html_QMARK_ = cljs.core.not(cljs.core.re_find(domina.re_no_inner_html,html_string));
var leading_whitespace_QMARK_ = cljs.core.re_find(domina.re_leading_whitespace,html_string);
var tag_name = cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.second(cljs.core.re_find(domina.re_tag_name,html_string))).toLowerCase();
var special_tag_QMARK_ = cljs.core.contains_QMARK_(domina.wrap_map,tag_name);
if(((allows_inner_html_QMARK_) && (((domina.support.leading_whitespace_QMARK_) || (cljs.core.not(leading_whitespace_QMARK_)))) && ((!(special_tag_QMARK_))))){
var value_30435 = clojure.string.replace(html_string,domina.re_xhtml_tag,"<$1></$2>");
try{var seq__30431_30436 = cljs.core.seq(domina.nodes(content));
var chunk__30432_30437 = null;
var count__30433_30438 = (0);
var i__30434_30439 = (0);
while(true){
if((i__30434_30439 < count__30433_30438)){
var node_30440 = chunk__30432_30437.cljs$core$IIndexed$_nth$arity$2(null,i__30434_30439);
node_30440.innerHTML = value_30435;


var G__30441 = seq__30431_30436;
var G__30442 = chunk__30432_30437;
var G__30443 = count__30433_30438;
var G__30444 = (i__30434_30439 + (1));
seq__30431_30436 = G__30441;
chunk__30432_30437 = G__30442;
count__30433_30438 = G__30443;
i__30434_30439 = G__30444;
continue;
} else {
var temp__5735__auto___30445 = cljs.core.seq(seq__30431_30436);
if(temp__5735__auto___30445){
var seq__30431_30446__$1 = temp__5735__auto___30445;
if(cljs.core.chunked_seq_QMARK_(seq__30431_30446__$1)){
var c__4550__auto___30447 = cljs.core.chunk_first(seq__30431_30446__$1);
var G__30448 = cljs.core.chunk_rest(seq__30431_30446__$1);
var G__30449 = c__4550__auto___30447;
var G__30450 = cljs.core.count(c__4550__auto___30447);
var G__30451 = (0);
seq__30431_30436 = G__30448;
chunk__30432_30437 = G__30449;
count__30433_30438 = G__30450;
i__30434_30439 = G__30451;
continue;
} else {
var node_30452 = cljs.core.first(seq__30431_30446__$1);
node_30452.innerHTML = value_30435;


var G__30453 = cljs.core.next(seq__30431_30446__$1);
var G__30454 = null;
var G__30455 = (0);
var G__30456 = (0);
seq__30431_30436 = G__30453;
chunk__30432_30437 = G__30454;
count__30433_30438 = G__30455;
i__30434_30439 = G__30456;
continue;
}
} else {
}
}
break;
}
}catch (e30430){if((e30430 instanceof Error)){
var e_30457 = e30430;
domina.replace_children_BANG_(content,value_30435);
} else {
throw e30430;

}
}} else {
domina.replace_children_BANG_(content,html_string);
}

return content;
});
/**
 * Sets the innerHTML value for all the nodes in the given content.
 */
domina.set_html_BANG_ = (function domina$set_html_BANG_(content,inner_content){
if(typeof inner_content === 'string'){
return domina.set_inner_html_BANG_(content,inner_content);
} else {
return domina.replace_children_BANG_(content,inner_content);
}
});
/**
 * Returns data associated with a node for a given key. Assumes
 *   content is a single node. If the bubble parameter is set to true,
 *   will search parent nodes if the key is not found.
 */
domina.get_data = (function domina$get_data(var_args){
var G__30459 = arguments.length;
switch (G__30459) {
case 2:
return domina.get_data.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return domina.get_data.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

domina.get_data.cljs$core$IFn$_invoke$arity$2 = (function (node,key){
return domina.get_data.cljs$core$IFn$_invoke$arity$3(node,key,false);
});

domina.get_data.cljs$core$IFn$_invoke$arity$3 = (function (node,key,bubble){
var m = domina.single_node(node).__domina_data;
var value = (cljs.core.truth_(m)?cljs.core.get.cljs$core$IFn$_invoke$arity$2(m,key):null);
if(cljs.core.truth_((function (){var and__4120__auto__ = bubble;
if(cljs.core.truth_(and__4120__auto__)){
return (value == null);
} else {
return and__4120__auto__;
}
})())){
var temp__5735__auto__ = domina.single_node(node).parentNode;
if(cljs.core.truth_(temp__5735__auto__)){
var parent = temp__5735__auto__;
return domina.get_data.cljs$core$IFn$_invoke$arity$3(parent,key,true);
} else {
return null;
}
} else {
return value;
}
});

domina.get_data.cljs$lang$maxFixedArity = 3;

/**
 * Sets a data on the node for a given key. Assumes content is a
 *   single node. Data should be ClojureScript values and data structures
 *   only; using other objects as data may result in memory leaks on some
 *   browsers.
 */
domina.set_data_BANG_ = (function domina$set_data_BANG_(node,key,value){
var m = (function (){var or__4131__auto__ = domina.single_node(node).__domina_data;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return cljs.core.PersistentArrayMap.EMPTY;
}
})();
return domina.single_node(node).__domina_data = cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(m,key,value);
});
/**
 * Takes a two-arg function, a reference DomContent and new
 *   DomContent. Applies the function for each reference / content
 *   combination. Uses clones of the new content for each additional
 *   parent after the first.
 */
domina.apply_with_cloning = (function domina$apply_with_cloning(f,parent_content,child_content){
var parents = domina.nodes(parent_content);
var children = domina.nodes(child_content);
var first_child = (function (){var frag = document.createDocumentFragment();
var seq__30463_30469 = cljs.core.seq(children);
var chunk__30464_30470 = null;
var count__30465_30471 = (0);
var i__30466_30472 = (0);
while(true){
if((i__30466_30472 < count__30465_30471)){
var child_30473 = chunk__30464_30470.cljs$core$IIndexed$_nth$arity$2(null,i__30466_30472);
frag.appendChild(child_30473);


var G__30474 = seq__30463_30469;
var G__30475 = chunk__30464_30470;
var G__30476 = count__30465_30471;
var G__30477 = (i__30466_30472 + (1));
seq__30463_30469 = G__30474;
chunk__30464_30470 = G__30475;
count__30465_30471 = G__30476;
i__30466_30472 = G__30477;
continue;
} else {
var temp__5735__auto___30478 = cljs.core.seq(seq__30463_30469);
if(temp__5735__auto___30478){
var seq__30463_30479__$1 = temp__5735__auto___30478;
if(cljs.core.chunked_seq_QMARK_(seq__30463_30479__$1)){
var c__4550__auto___30480 = cljs.core.chunk_first(seq__30463_30479__$1);
var G__30481 = cljs.core.chunk_rest(seq__30463_30479__$1);
var G__30482 = c__4550__auto___30480;
var G__30483 = cljs.core.count(c__4550__auto___30480);
var G__30484 = (0);
seq__30463_30469 = G__30481;
chunk__30464_30470 = G__30482;
count__30465_30471 = G__30483;
i__30466_30472 = G__30484;
continue;
} else {
var child_30485 = cljs.core.first(seq__30463_30479__$1);
frag.appendChild(child_30485);


var G__30486 = cljs.core.next(seq__30463_30479__$1);
var G__30487 = null;
var G__30488 = (0);
var G__30489 = (0);
seq__30463_30469 = G__30486;
chunk__30464_30470 = G__30487;
count__30465_30471 = G__30488;
i__30466_30472 = G__30489;
continue;
}
} else {
}
}
break;
}

return frag;
})();
var other_children = cljs.core.doall.cljs$core$IFn$_invoke$arity$1(cljs.core.repeatedly.cljs$core$IFn$_invoke$arity$2((cljs.core.count(parents) - (1)),((function (parents,children,first_child){
return (function (){
return first_child.cloneNode(true);
});})(parents,children,first_child))
));
if(cljs.core.seq(parents)){
var G__30467_30490 = cljs.core.first(parents);
var G__30468_30491 = first_child;
(f.cljs$core$IFn$_invoke$arity$2 ? f.cljs$core$IFn$_invoke$arity$2(G__30467_30490,G__30468_30491) : f.call(null,G__30467_30490,G__30468_30491));

return cljs.core.doall.cljs$core$IFn$_invoke$arity$1(cljs.core.map.cljs$core$IFn$_invoke$arity$3(((function (parents,children,first_child,other_children){
return (function (p1__30461_SHARP_,p2__30462_SHARP_){
return (f.cljs$core$IFn$_invoke$arity$2 ? f.cljs$core$IFn$_invoke$arity$2(p1__30461_SHARP_,p2__30462_SHARP_) : f.call(null,p1__30461_SHARP_,p2__30462_SHARP_));
});})(parents,children,first_child,other_children))
,cljs.core.rest(parents),other_children));
} else {
return null;
}
});
domina.lazy_nl_via_item = (function domina$lazy_nl_via_item(var_args){
var G__30493 = arguments.length;
switch (G__30493) {
case 1:
return domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$1 = (function (nl){
return domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$2(nl,(0));
});

domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$2 = (function (nl,n){
if((n < nl.length)){
return (new cljs.core.LazySeq(null,(function (){
return cljs.core.cons(nl.item(n),domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$2(nl,(n + (1))));
}),null,null));
} else {
return null;
}
});

domina.lazy_nl_via_item.cljs$lang$maxFixedArity = 2;

domina.lazy_nl_via_array_ref = (function domina$lazy_nl_via_array_ref(var_args){
var G__30496 = arguments.length;
switch (G__30496) {
case 1:
return domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$1 = (function (nl){
return domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$2(nl,(0));
});

domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$2 = (function (nl,n){
if((n < nl.length)){
return (new cljs.core.LazySeq(null,(function (){
return cljs.core.cons((nl[n]),domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$2(nl,(n + (1))));
}),null,null));
} else {
return null;
}
});

domina.lazy_nl_via_array_ref.cljs$lang$maxFixedArity = 2;

/**
 * A lazy seq view of a js/NodeList, or other array-like javascript things
 */
domina.lazy_nodelist = (function domina$lazy_nodelist(nl){
if(cljs.core.truth_(nl.item)){
return domina.lazy_nl_via_item.cljs$core$IFn$_invoke$arity$1(nl);
} else {
return domina.lazy_nl_via_array_ref.cljs$core$IFn$_invoke$arity$1(nl);
}
});
domina.array_like_QMARK_ = (function domina$array_like_QMARK_(obj){
var and__4120__auto__ = obj;
if(cljs.core.truth_(and__4120__auto__)){
var and__4120__auto____$1 = cljs.core.not(obj.nodeName);
if(and__4120__auto____$1){
return obj.length;
} else {
return and__4120__auto____$1;
}
} else {
return and__4120__auto__;
}
});
/**
 * Some versions of IE have things that are like arrays in that they
 *   respond to .length, but are not arrays nor NodeSets. This returns a
 *   real sequence view of such objects. If passed an object that is not
 *   a logical sequence at all, returns a single-item seq containing the
 *   object.
 */
domina.normalize_seq = (function domina$normalize_seq(list_thing){
if((list_thing == null)){
return cljs.core.List.EMPTY;
} else {
if((((!((list_thing == null))))?(((((list_thing.cljs$lang$protocol_mask$partition0$ & (8388608))) || ((cljs.core.PROTOCOL_SENTINEL === list_thing.cljs$core$ISeqable$))))?true:(((!list_thing.cljs$lang$protocol_mask$partition0$))?cljs.core.native_satisfies_QMARK_(cljs.core.ISeqable,list_thing):false)):cljs.core.native_satisfies_QMARK_(cljs.core.ISeqable,list_thing))){
return cljs.core.seq(list_thing);
} else {
if(cljs.core.truth_(domina.array_like_QMARK_(list_thing))){
return domina.lazy_nodelist(list_thing);
} else {
return cljs.core.seq(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [list_thing], null));

}
}
}
});
goog.object.set(domina.DomContent,"string",true);

var G__30499_30513 = domina.nodes;
var G__30500_30514 = "string";
var G__30501_30515 = ((function (G__30499_30513,G__30500_30514){
return (function (s){
return cljs.core.doall.cljs$core$IFn$_invoke$arity$1(domina.nodes(domina.string_to_dom(s)));
});})(G__30499_30513,G__30500_30514))
;
goog.object.set(G__30499_30513,G__30500_30514,G__30501_30515);

var G__30502_30516 = domina.single_node;
var G__30503_30517 = "string";
var G__30504_30518 = ((function (G__30502_30516,G__30503_30517){
return (function (s){
return domina.single_node(domina.string_to_dom(s));
});})(G__30502_30516,G__30503_30517))
;
goog.object.set(G__30502_30516,G__30503_30517,G__30504_30518);

goog.object.set(domina.DomContent,"_",true);

var G__30505_30519 = domina.nodes;
var G__30506_30520 = "_";
var G__30507_30521 = ((function (G__30505_30519,G__30506_30520){
return (function (content){
if((content == null)){
return cljs.core.List.EMPTY;
} else {
if((((!((content == null))))?(((((content.cljs$lang$protocol_mask$partition0$ & (8388608))) || ((cljs.core.PROTOCOL_SENTINEL === content.cljs$core$ISeqable$))))?true:(((!content.cljs$lang$protocol_mask$partition0$))?cljs.core.native_satisfies_QMARK_(cljs.core.ISeqable,content):false)):cljs.core.native_satisfies_QMARK_(cljs.core.ISeqable,content))){
return cljs.core.seq(content);
} else {
if(cljs.core.truth_(domina.array_like_QMARK_(content))){
return domina.lazy_nodelist(content);
} else {
return cljs.core.seq(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [content], null));

}
}
}
});})(G__30505_30519,G__30506_30520))
;
goog.object.set(G__30505_30519,G__30506_30520,G__30507_30521);

var G__30509_30522 = domina.single_node;
var G__30510_30523 = "_";
var G__30511_30524 = ((function (G__30509_30522,G__30510_30523){
return (function (content){
if((content == null)){
return null;
} else {
if((((!((content == null))))?(((((content.cljs$lang$protocol_mask$partition0$ & (8388608))) || ((cljs.core.PROTOCOL_SENTINEL === content.cljs$core$ISeqable$))))?true:(((!content.cljs$lang$protocol_mask$partition0$))?cljs.core.native_satisfies_QMARK_(cljs.core.ISeqable,content):false)):cljs.core.native_satisfies_QMARK_(cljs.core.ISeqable,content))){
return cljs.core.first(content);
} else {
if(cljs.core.truth_(domina.array_like_QMARK_(content))){
return content.item((0));
} else {
return content;

}
}
}
});})(G__30509_30522,G__30510_30523))
;
goog.object.set(G__30509_30522,G__30510_30523,G__30511_30524);
if(cljs.core.truth_((typeof NodeList != 'undefined'))){
NodeList.prototype.cljs$core$ICounted$ = cljs.core.PROTOCOL_SENTINEL;

NodeList.prototype.cljs$core$ICounted$_count$arity$1 = (function (nodelist){
var nodelist__$1 = this;
return nodelist__$1.length;
});

NodeList.prototype.cljs$core$IIndexed$ = cljs.core.PROTOCOL_SENTINEL;

NodeList.prototype.cljs$core$IIndexed$_nth$arity$2 = (function (nodelist,n){
var nodelist__$1 = this;
return nodelist__$1.item(n);
});

NodeList.prototype.cljs$core$IIndexed$_nth$arity$3 = (function (nodelist,n,not_found){
var nodelist__$1 = this;
if((nodelist__$1.length <= n)){
return not_found;
} else {
return cljs.core.nth.cljs$core$IFn$_invoke$arity$2(nodelist__$1,n);
}
});

NodeList.prototype.cljs$core$ISeqable$ = cljs.core.PROTOCOL_SENTINEL;

NodeList.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (nodelist){
var nodelist__$1 = this;
return domina.lazy_nodelist(nodelist__$1);
});
} else {
}
if(cljs.core.truth_((typeof StaticNodeList != 'undefined'))){
StaticNodeList.prototype.cljs$core$ICounted$ = cljs.core.PROTOCOL_SENTINEL;

StaticNodeList.prototype.cljs$core$ICounted$_count$arity$1 = (function (nodelist){
var nodelist__$1 = this;
return nodelist__$1.length;
});

StaticNodeList.prototype.cljs$core$IIndexed$ = cljs.core.PROTOCOL_SENTINEL;

StaticNodeList.prototype.cljs$core$IIndexed$_nth$arity$2 = (function (nodelist,n){
var nodelist__$1 = this;
return nodelist__$1.item(n);
});

StaticNodeList.prototype.cljs$core$IIndexed$_nth$arity$3 = (function (nodelist,n,not_found){
var nodelist__$1 = this;
if((nodelist__$1.length <= n)){
return not_found;
} else {
return cljs.core.nth.cljs$core$IFn$_invoke$arity$2(nodelist__$1,n);
}
});

StaticNodeList.prototype.cljs$core$ISeqable$ = cljs.core.PROTOCOL_SENTINEL;

StaticNodeList.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (nodelist){
var nodelist__$1 = this;
return domina.lazy_nodelist(nodelist__$1);
});
} else {
}
if(cljs.core.truth_((typeof HTMLCollection != 'undefined'))){
HTMLCollection.prototype.cljs$core$ICounted$ = cljs.core.PROTOCOL_SENTINEL;

HTMLCollection.prototype.cljs$core$ICounted$_count$arity$1 = (function (coll){
var coll__$1 = this;
return coll__$1.length;
});

HTMLCollection.prototype.cljs$core$IIndexed$ = cljs.core.PROTOCOL_SENTINEL;

HTMLCollection.prototype.cljs$core$IIndexed$_nth$arity$2 = (function (coll,n){
var coll__$1 = this;
return coll__$1.item(n);
});

HTMLCollection.prototype.cljs$core$IIndexed$_nth$arity$3 = (function (coll,n,not_found){
var coll__$1 = this;
if((coll__$1.length <= n)){
return not_found;
} else {
return cljs.core.nth.cljs$core$IFn$_invoke$arity$2(coll__$1,n);
}
});

HTMLCollection.prototype.cljs$core$ISeqable$ = cljs.core.PROTOCOL_SENTINEL;

HTMLCollection.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (coll){
var coll__$1 = this;
return domina.lazy_nodelist(coll__$1);
});
} else {
}

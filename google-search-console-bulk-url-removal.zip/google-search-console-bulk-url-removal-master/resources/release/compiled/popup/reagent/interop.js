// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('reagent.interop');
goog.require('cljs.core');
goog.require('cljs.core.constants');

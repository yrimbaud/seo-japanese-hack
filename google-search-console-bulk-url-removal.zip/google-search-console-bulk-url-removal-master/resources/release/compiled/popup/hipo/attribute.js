// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('hipo.attribute');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('hipo.hiccup');
hipo.attribute.style_handler = new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$attr,"style"], null),cljs.core.cst$kw$fn,(function (p1__26965_SHARP_,p2__26966_SHARP_,p3__26967_SHARP_,p4__26964_SHARP_){
var seq__26968 = cljs.core.seq(p4__26964_SHARP_);
var chunk__26969 = null;
var count__26970 = (0);
var i__26971 = (0);
while(true){
if((i__26971 < count__26970)){
var vec__26978 = chunk__26969.cljs$core$IIndexed$_nth$arity$2(null,i__26971);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__26978,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__26978,(1),null);
(p1__26965_SHARP_["style"][cljs.core.name(k)] = v);


var G__26984 = seq__26968;
var G__26985 = chunk__26969;
var G__26986 = count__26970;
var G__26987 = (i__26971 + (1));
seq__26968 = G__26984;
chunk__26969 = G__26985;
count__26970 = G__26986;
i__26971 = G__26987;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__26968);
if(temp__5735__auto__){
var seq__26968__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__26968__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__26968__$1);
var G__26988 = cljs.core.chunk_rest(seq__26968__$1);
var G__26989 = c__4550__auto__;
var G__26990 = cljs.core.count(c__4550__auto__);
var G__26991 = (0);
seq__26968 = G__26988;
chunk__26969 = G__26989;
count__26970 = G__26990;
i__26971 = G__26991;
continue;
} else {
var vec__26981 = cljs.core.first(seq__26968__$1);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__26981,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__26981,(1),null);
(p1__26965_SHARP_["style"][cljs.core.name(k)] = v);


var G__26992 = cljs.core.next(seq__26968__$1);
var G__26993 = null;
var G__26994 = (0);
var G__26995 = (0);
seq__26968 = G__26992;
chunk__26969 = G__26993;
count__26970 = G__26994;
i__26971 = G__26995;
continue;
}
} else {
return null;
}
}
break;
}
})], null);
hipo.attribute.property_name__GT_js_property_name = (function hipo$attribute$property_name__GT_js_property_name(n){
return n.replace("-","_");
});
hipo.attribute.set_property_value = (function hipo$attribute$set_property_value(el,k,v){
return (el[hipo.attribute.property_name__GT_js_property_name(cljs.core.name(k))] = v);
});
hipo.attribute.set_attribute_BANG_ = (function hipo$attribute$set_attribute_BANG_(el,k,v,m){
var temp__5733__auto__ = (((k instanceof cljs.core.Keyword))?hipo.hiccup.key__GT_namespace(cljs.core.namespace(k),m):null);
if(cljs.core.truth_(temp__5733__auto__)){
var nns = temp__5733__auto__;
return el.setAttributeNS(nns,cljs.core.name(k),v);
} else {
return el.setAttribute(cljs.core.name(k),v);
}
});
hipo.attribute.remove_attribute_BANG_ = (function hipo$attribute$remove_attribute_BANG_(el,k,m){
var temp__5733__auto__ = (((k instanceof cljs.core.Keyword))?hipo.hiccup.key__GT_namespace(cljs.core.namespace(k),m):null);
if(cljs.core.truth_(temp__5733__auto__)){
var nns = temp__5733__auto__;
return el.removeAttributeNS(nns,cljs.core.name(k));
} else {
return el.removeAttribute(cljs.core.name(k));
}
});
hipo.attribute.default_handler_fns = new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$prop,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$fn,(function (p1__26996_SHARP_,p2__26997_SHARP_,p3__26999_SHARP_,p4__26998_SHARP_){
return hipo.attribute.set_property_value(p1__26996_SHARP_,p2__26997_SHARP_,p4__26998_SHARP_);
})], null),cljs.core.cst$kw$attr,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$fn,(function (p1__27001_SHARP_,p2__27002_SHARP_,p3__27004_SHARP_,p4__27000_SHARP_,p5__27003_SHARP_){
if(cljs.core.truth_(p4__27000_SHARP_)){
return hipo.attribute.set_attribute_BANG_(p1__27001_SHARP_,p2__27002_SHARP_,p4__27000_SHARP_,p5__27003_SHARP_);
} else {
return hipo.attribute.remove_attribute_BANG_(p1__27001_SHARP_,p2__27002_SHARP_,p5__27003_SHARP_);
}
})], null)], null);
hipo.attribute.default_handlers = new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$ns,"svg",cljs.core.cst$kw$attr,"class"], null),cljs.core.cst$kw$type,cljs.core.cst$kw$attr], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$tag,"input",cljs.core.cst$kw$attr,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, ["value",null,"checked",null], null), null)], null),cljs.core.cst$kw$type,cljs.core.cst$kw$prop], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$tag,"input",cljs.core.cst$kw$attr,"autofocus"], null),cljs.core.cst$kw$fn,(function (p1__27006_SHARP_,p2__27007_SHARP_,p3__27008_SHARP_,p4__27005_SHARP_){
if(cljs.core.truth_(p4__27005_SHARP_)){
p1__27006_SHARP_.focus();

return p1__27006_SHARP_.setAttribute(p2__27007_SHARP_,p4__27005_SHARP_);
} else {
return null;
}
})], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$tag,"option",cljs.core.cst$kw$attr,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, ["selected",null], null), null)], null),cljs.core.cst$kw$type,cljs.core.cst$kw$prop], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$tag,"select",cljs.core.cst$kw$attr,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, ["value",null,"selectIndex",null], null), null)], null),cljs.core.cst$kw$type,cljs.core.cst$kw$prop], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$tag,"textarea",cljs.core.cst$kw$attr,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, ["value",null], null), null)], null),cljs.core.cst$kw$type,cljs.core.cst$kw$prop], null)], null);
hipo.attribute.matches_QMARK_ = (function hipo$attribute$matches_QMARK_(expr,s){
if(cljs.core.truth_(expr)){
if(cljs.core.set_QMARK_(expr)){
return cljs.core.contains_QMARK_(expr,s);
} else {
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(s,expr);

}
} else {
return true;
}
});
hipo.attribute.target_matches_QMARK_ = (function hipo$attribute$target_matches_QMARK_(m,ns,tag,attr){
return ((hipo.attribute.matches_QMARK_(cljs.core.cst$kw$ns.cljs$core$IFn$_invoke$arity$1(m),ns)) && (hipo.attribute.matches_QMARK_(cljs.core.cst$kw$tag.cljs$core$IFn$_invoke$arity$1(m),tag)) && (hipo.attribute.matches_QMARK_(cljs.core.cst$kw$attr.cljs$core$IFn$_invoke$arity$1(m),attr)));
});
hipo.attribute.handler = (function hipo$attribute$handler(m,ns,tag,attr){
var v = cljs.core.concat.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$attribute_DASH_handlers.cljs$core$IFn$_invoke$arity$1(m),hipo.attribute.default_handlers);
var h = cljs.core.some(((function (v){
return (function (p1__27009_SHARP_){
var t = cljs.core.cst$kw$target.cljs$core$IFn$_invoke$arity$1(p1__27009_SHARP_);
if(hipo.attribute.target_matches_QMARK_(t,ns,tag,cljs.core.name(attr))){
return p1__27009_SHARP_;
} else {
return null;
}
});})(v))
,v);
if(cljs.core.contains_QMARK_(h,cljs.core.cst$kw$type)){
var fexpr__27010 = cljs.core.cst$kw$type.cljs$core$IFn$_invoke$arity$1(h);
return (fexpr__27010.cljs$core$IFn$_invoke$arity$1 ? fexpr__27010.cljs$core$IFn$_invoke$arity$1(hipo.attribute.default_handler_fns) : fexpr__27010.call(null,hipo.attribute.default_handler_fns));
} else {
return h;
}
});
hipo.attribute.default_set_value_BANG_ = (function hipo$attribute$default_set_value_BANG_(el,attr,ov,nv,m){
if(((hipo.hiccup.literal_QMARK_(ov)) || (hipo.hiccup.literal_QMARK_(nv)))){
if(cljs.core.truth_(nv)){
return hipo.attribute.set_attribute_BANG_(el,attr,nv,m);
} else {
return hipo.attribute.remove_attribute_BANG_(el,attr,m);
}
} else {
return (el[attr] = hipo.attribute.set_property_value(el,attr,nv));
}
});
hipo.attribute.set_value_BANG_ = (function hipo$attribute$set_value_BANG_(el,m,ns,tag,attr,ov,nv){
var h = hipo.attribute.handler(m,ns,tag,attr);
var f = (function (){var or__4131__auto__ = cljs.core.cst$kw$fn.cljs$core$IFn$_invoke$arity$1(h);
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return hipo.attribute.default_set_value_BANG_;
}
})();
return (f.cljs$core$IFn$_invoke$arity$5 ? f.cljs$core$IFn$_invoke$arity$5(el,attr,ov,nv,m) : f.call(null,el,attr,ov,nv,m));
});

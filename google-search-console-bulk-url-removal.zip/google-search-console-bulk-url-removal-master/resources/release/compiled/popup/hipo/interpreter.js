// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('hipo.interpreter');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('clojure.set');
goog.require('hipo.attribute');
goog.require('hipo.dom');
goog.require('hipo.hiccup');
goog.require('hipo.interceptor');
hipo.interpreter.set_attribute_BANG_ = (function hipo$interpreter$set_attribute_BANG_(el,ns,tag,sok,ov,nv,p__27013){
var map__27014 = p__27013;
var map__27014__$1 = (((((!((map__27014 == null))))?(((((map__27014.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__27014.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__27014):map__27014);
var m = map__27014__$1;
var interceptors = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27014__$1,cljs.core.cst$kw$interceptors);
if((!((ov === nv)))){
var temp__5733__auto__ = hipo.hiccup.listener_name__GT_event_name(cljs.core.name(sok));
if(cljs.core.truth_(temp__5733__auto__)){
var en = temp__5733__auto__;
if((!(((cljs.core.map_QMARK_(ov)) && (cljs.core.map_QMARK_(nv)) && ((cljs.core.cst$kw$name.cljs$core$IFn$_invoke$arity$1(ov) === cljs.core.cst$kw$name.cljs$core$IFn$_invoke$arity$1(nv))))))){
var b__26951__auto__ = ((function (en,temp__5733__auto__,map__27014,map__27014__$1,m,interceptors){
return (function (){
var hn = ["hipo_listener_",cljs.core.str.cljs$core$IFn$_invoke$arity$1(en)].join('');
var temp__5733__auto___27016__$1 = (el[hn]);
if(cljs.core.truth_(temp__5733__auto___27016__$1)){
var l_27017 = temp__5733__auto___27016__$1;
el.removeEventListener(en,l_27017);
} else {
}

var temp__5735__auto__ = (function (){var or__4131__auto__ = cljs.core.cst$kw$fn.cljs$core$IFn$_invoke$arity$1(nv);
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return nv;
}
})();
if(cljs.core.truth_(temp__5735__auto__)){
var nv__$1 = temp__5735__auto__;
el.addEventListener(en,nv__$1);

return (el[hn] = nv__$1);
} else {
return null;
}
});})(en,temp__5733__auto__,map__27014,map__27014__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,(cljs.core.truth_(nv)?cljs.core.cst$kw$update_DASH_handler:cljs.core.cst$kw$remove_DASH_handler),cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$name,sok,cljs.core.cst$kw$old_DASH_value,ov], null),(cljs.core.truth_(nv)?new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$new_DASH_value,nv], null):null)], 0)));
}
} else {
return null;
}
} else {
var b__26951__auto__ = ((function (temp__5733__auto__,map__27014,map__27014__$1,m,interceptors){
return (function (){
return hipo.attribute.set_value_BANG_(el,m,ns,tag,sok,ov,nv);
});})(temp__5733__auto__,map__27014,map__27014__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,(cljs.core.truth_(nv)?cljs.core.cst$kw$update_DASH_attribute:cljs.core.cst$kw$remove_DASH_attribute),cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$name,sok,cljs.core.cst$kw$old_DASH_value,ov], null),(cljs.core.truth_(nv)?new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$new_DASH_value,nv], null):null)], 0)));
}
}
} else {
return null;
}
});
hipo.interpreter.append_children_BANG_ = (function hipo$interpreter$append_children_BANG_(el,v,m){

var v__$1 = hipo.hiccup.flatten_children(v);
while(true){
if(cljs.core.empty_QMARK_(v__$1)){
return null;
} else {
var temp__5733__auto___27018 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(v__$1,(0));
if(cljs.core.truth_(temp__5733__auto___27018)){
var h_27019 = temp__5733__auto___27018;
el.appendChild((hipo.interpreter.create_child.cljs$core$IFn$_invoke$arity$2 ? hipo.interpreter.create_child.cljs$core$IFn$_invoke$arity$2(h_27019,m) : hipo.interpreter.create_child.call(null,h_27019,m)));
} else {
}

var G__27020 = cljs.core.rest(v__$1);
v__$1 = G__27020;
continue;
}
break;
}
});
hipo.interpreter.default_create_element = (function hipo$interpreter$default_create_element(ns,tag,attrs,m){
var el = hipo.dom.create_element(ns,tag);
var seq__27021_27037 = cljs.core.seq(attrs);
var chunk__27022_27038 = null;
var count__27023_27039 = (0);
var i__27024_27040 = (0);
while(true){
if((i__27024_27040 < count__27023_27039)){
var vec__27031_27041 = chunk__27022_27038.cljs$core$IIndexed$_nth$arity$2(null,i__27024_27040);
var sok_27042 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27031_27041,(0),null);
var v_27043 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27031_27041,(1),null);
if(cljs.core.truth_(v_27043)){
hipo.interpreter.set_attribute_BANG_(el,ns,tag,sok_27042,null,v_27043,m);
} else {
}


var G__27044 = seq__27021_27037;
var G__27045 = chunk__27022_27038;
var G__27046 = count__27023_27039;
var G__27047 = (i__27024_27040 + (1));
seq__27021_27037 = G__27044;
chunk__27022_27038 = G__27045;
count__27023_27039 = G__27046;
i__27024_27040 = G__27047;
continue;
} else {
var temp__5735__auto___27048 = cljs.core.seq(seq__27021_27037);
if(temp__5735__auto___27048){
var seq__27021_27049__$1 = temp__5735__auto___27048;
if(cljs.core.chunked_seq_QMARK_(seq__27021_27049__$1)){
var c__4550__auto___27050 = cljs.core.chunk_first(seq__27021_27049__$1);
var G__27051 = cljs.core.chunk_rest(seq__27021_27049__$1);
var G__27052 = c__4550__auto___27050;
var G__27053 = cljs.core.count(c__4550__auto___27050);
var G__27054 = (0);
seq__27021_27037 = G__27051;
chunk__27022_27038 = G__27052;
count__27023_27039 = G__27053;
i__27024_27040 = G__27054;
continue;
} else {
var vec__27034_27055 = cljs.core.first(seq__27021_27049__$1);
var sok_27056 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27034_27055,(0),null);
var v_27057 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27034_27055,(1),null);
if(cljs.core.truth_(v_27057)){
hipo.interpreter.set_attribute_BANG_(el,ns,tag,sok_27056,null,v_27057,m);
} else {
}


var G__27058 = cljs.core.next(seq__27021_27049__$1);
var G__27059 = null;
var G__27060 = (0);
var G__27061 = (0);
seq__27021_27037 = G__27058;
chunk__27022_27038 = G__27059;
count__27023_27039 = G__27060;
i__27024_27040 = G__27061;
continue;
}
} else {
}
}
break;
}

return el;
});
hipo.interpreter.create_element = (function hipo$interpreter$create_element(ns,tag,attrs,m){
var temp__5733__auto__ = cljs.core.cst$kw$create_DASH_element_DASH_fn.cljs$core$IFn$_invoke$arity$1(m);
if(cljs.core.truth_(temp__5733__auto__)){
var f = temp__5733__auto__;
return (f.cljs$core$IFn$_invoke$arity$4 ? f.cljs$core$IFn$_invoke$arity$4(ns,tag,attrs,m) : f.call(null,ns,tag,attrs,m));
} else {
return hipo.interpreter.default_create_element(ns,tag,attrs,m);
}
});
hipo.interpreter.create_vector = (function hipo$interpreter$create_vector(h,m){

var key = hipo.hiccup.keyns(h);
var tag = hipo.hiccup.tag(h);
var attrs = hipo.hiccup.attributes(h);
var children = hipo.hiccup.children(h);
var el = hipo.interpreter.create_element(hipo.hiccup.key__GT_namespace(key,m),tag,attrs,m);
if(cljs.core.truth_(children)){
hipo.interpreter.append_children_BANG_(el,children,m);
} else {
}

return el;
});
hipo.interpreter.create_child = (function hipo$interpreter$create_child(o,m){

if(hipo.hiccup.literal_QMARK_(o)){
return document.createTextNode(o);
} else {
return hipo.interpreter.create_vector(o,m);
}
});
hipo.interpreter.append_to_parent = (function hipo$interpreter$append_to_parent(el,o,m){
if(cljs.core.seq_QMARK_(o)){
return hipo.interpreter.append_children_BANG_(el,cljs.core.vec(o),m);
} else {
if((!((o == null)))){
return el.appendChild(hipo.interpreter.create_child(o,m));
} else {
return null;
}
}
});
hipo.interpreter.create = (function hipo$interpreter$create(o,m){
if(cljs.core.seq_QMARK_(o)){
var f = document.createDocumentFragment();
hipo.interpreter.append_children_BANG_(f,cljs.core.vec(o),m);

return f;
} else {
if((!((o == null)))){
return hipo.interpreter.create_child(o,m);
} else {
return null;
}
}
});
hipo.interpreter.reconciliate_attributes_BANG_ = (function hipo$interpreter$reconciliate_attributes_BANG_(el,ns,tag,om,nm,m){
var seq__27062_27084 = cljs.core.seq(nm);
var chunk__27064_27085 = null;
var count__27065_27086 = (0);
var i__27066_27087 = (0);
while(true){
if((i__27066_27087 < count__27065_27086)){
var vec__27074_27088 = chunk__27064_27085.cljs$core$IIndexed$_nth$arity$2(null,i__27066_27087);
var sok_27089 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27074_27088,(0),null);
var nv_27090 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27074_27088,(1),null);
var ov_27091 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(om,sok_27089);
hipo.interpreter.set_attribute_BANG_(el,ns,tag,sok_27089,ov_27091,nv_27090,m);


var G__27092 = seq__27062_27084;
var G__27093 = chunk__27064_27085;
var G__27094 = count__27065_27086;
var G__27095 = (i__27066_27087 + (1));
seq__27062_27084 = G__27092;
chunk__27064_27085 = G__27093;
count__27065_27086 = G__27094;
i__27066_27087 = G__27095;
continue;
} else {
var temp__5735__auto___27096 = cljs.core.seq(seq__27062_27084);
if(temp__5735__auto___27096){
var seq__27062_27097__$1 = temp__5735__auto___27096;
if(cljs.core.chunked_seq_QMARK_(seq__27062_27097__$1)){
var c__4550__auto___27098 = cljs.core.chunk_first(seq__27062_27097__$1);
var G__27099 = cljs.core.chunk_rest(seq__27062_27097__$1);
var G__27100 = c__4550__auto___27098;
var G__27101 = cljs.core.count(c__4550__auto___27098);
var G__27102 = (0);
seq__27062_27084 = G__27099;
chunk__27064_27085 = G__27100;
count__27065_27086 = G__27101;
i__27066_27087 = G__27102;
continue;
} else {
var vec__27077_27103 = cljs.core.first(seq__27062_27097__$1);
var sok_27104 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27077_27103,(0),null);
var nv_27105 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27077_27103,(1),null);
var ov_27106 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(om,sok_27104);
hipo.interpreter.set_attribute_BANG_(el,ns,tag,sok_27104,ov_27106,nv_27105,m);


var G__27107 = cljs.core.next(seq__27062_27097__$1);
var G__27108 = null;
var G__27109 = (0);
var G__27110 = (0);
seq__27062_27084 = G__27107;
chunk__27064_27085 = G__27108;
count__27065_27086 = G__27109;
i__27066_27087 = G__27110;
continue;
}
} else {
}
}
break;
}

var seq__27080 = cljs.core.seq(clojure.set.difference.cljs$core$IFn$_invoke$arity$2(cljs.core.set(cljs.core.keys(om)),cljs.core.set(cljs.core.keys(nm))));
var chunk__27081 = null;
var count__27082 = (0);
var i__27083 = (0);
while(true){
if((i__27083 < count__27082)){
var sok = chunk__27081.cljs$core$IIndexed$_nth$arity$2(null,i__27083);
hipo.interpreter.set_attribute_BANG_(el,ns,tag,sok,cljs.core.get.cljs$core$IFn$_invoke$arity$2(om,sok),null,m);


var G__27111 = seq__27080;
var G__27112 = chunk__27081;
var G__27113 = count__27082;
var G__27114 = (i__27083 + (1));
seq__27080 = G__27111;
chunk__27081 = G__27112;
count__27082 = G__27113;
i__27083 = G__27114;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__27080);
if(temp__5735__auto__){
var seq__27080__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__27080__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__27080__$1);
var G__27115 = cljs.core.chunk_rest(seq__27080__$1);
var G__27116 = c__4550__auto__;
var G__27117 = cljs.core.count(c__4550__auto__);
var G__27118 = (0);
seq__27080 = G__27115;
chunk__27081 = G__27116;
count__27082 = G__27117;
i__27083 = G__27118;
continue;
} else {
var sok = cljs.core.first(seq__27080__$1);
hipo.interpreter.set_attribute_BANG_(el,ns,tag,sok,cljs.core.get.cljs$core$IFn$_invoke$arity$2(om,sok),null,m);


var G__27119 = cljs.core.next(seq__27080__$1);
var G__27120 = null;
var G__27121 = (0);
var G__27122 = (0);
seq__27080 = G__27119;
chunk__27081 = G__27120;
count__27082 = G__27121;
i__27083 = G__27122;
continue;
}
} else {
return null;
}
}
break;
}
});
hipo.interpreter.child_key = (function hipo$interpreter$child_key(h){
return cljs.core.cst$kw$hipo_SLASH_key.cljs$core$IFn$_invoke$arity$1(cljs.core.meta(h));
});
hipo.interpreter.keyed_children__GT_indexed_map = (function hipo$interpreter$keyed_children__GT_indexed_map(v){
return cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,(function (){var iter__4523__auto__ = (function hipo$interpreter$keyed_children__GT_indexed_map_$_iter__27123(s__27124){
return (new cljs.core.LazySeq(null,(function (){
var s__27124__$1 = s__27124;
while(true){
var temp__5735__auto__ = cljs.core.seq(s__27124__$1);
if(temp__5735__auto__){
var s__27124__$2 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(s__27124__$2)){
var c__4521__auto__ = cljs.core.chunk_first(s__27124__$2);
var size__4522__auto__ = cljs.core.count(c__4521__auto__);
var b__27126 = cljs.core.chunk_buffer(size__4522__auto__);
if((function (){var i__27125 = (0);
while(true){
if((i__27125 < size__4522__auto__)){
var ih = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(c__4521__auto__,i__27125);
cljs.core.chunk_append(b__27126,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [hipo.interpreter.child_key(cljs.core.nth.cljs$core$IFn$_invoke$arity$2(ih,(1))),ih], null));

var G__27127 = (i__27125 + (1));
i__27125 = G__27127;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__27126),hipo$interpreter$keyed_children__GT_indexed_map_$_iter__27123(cljs.core.chunk_rest(s__27124__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__27126),null);
}
} else {
var ih = cljs.core.first(s__27124__$2);
return cljs.core.cons(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [hipo.interpreter.child_key(cljs.core.nth.cljs$core$IFn$_invoke$arity$2(ih,(1))),ih], null),hipo$interpreter$keyed_children__GT_indexed_map_$_iter__27123(cljs.core.rest(s__27124__$2)));
}
} else {
return null;
}
break;
}
}),null,null));
});
return iter__4523__auto__(cljs.core.map_indexed.cljs$core$IFn$_invoke$arity$2(((function (iter__4523__auto__){
return (function (idx,itm){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [idx,itm], null);
});})(iter__4523__auto__))
,v));
})());
});
/**
 * Reconciliate a vector of children based on their associated key.
 */
hipo.interpreter.reconciliate_keyed_children_BANG_ = (function hipo$interpreter$reconciliate_keyed_children_BANG_(el,och,nch,p__27128){
var map__27129 = p__27128;
var map__27129__$1 = (((((!((map__27129 == null))))?(((((map__27129.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__27129.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__27129):map__27129);
var m = map__27129__$1;
var interceptors = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27129__$1,cljs.core.cst$kw$interceptors);
var om = hipo.interpreter.keyed_children__GT_indexed_map(och);
var nm = hipo.interpreter.keyed_children__GT_indexed_map(nch);
var cs = hipo.dom.children.cljs$core$IFn$_invoke$arity$2(el,cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.max,clojure.set.intersection.cljs$core$IFn$_invoke$arity$2(cljs.core.set(cljs.core.keys(nm)),cljs.core.set(cljs.core.keys(om)))));
var seq__27131_27171 = cljs.core.seq(nm);
var chunk__27132_27172 = null;
var count__27133_27173 = (0);
var i__27134_27174 = (0);
while(true){
if((i__27134_27174 < count__27133_27173)){
var vec__27153_27175 = chunk__27132_27172.cljs$core$IIndexed$_nth$arity$2(null,i__27134_27174);
var i_27176 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27153_27175,(0),null);
var vec__27156_27177 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27153_27175,(1),null);
var ii_27178 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27156_27177,(0),null);
var h_27179 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27156_27177,(1),null);
var temp__5733__auto___27180 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(om,i_27176);
if(cljs.core.truth_(temp__5733__auto___27180)){
var vec__27159_27181 = temp__5733__auto___27180;
var iii_27182 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27159_27181,(0),null);
var oh_27183 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27159_27181,(1),null);
var cel_27184 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(cs,iii_27182);
if((ii_27178 === iii_27182)){
(hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4 ? hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4(cel_27184,oh_27183,h_27179,m) : hipo.interpreter.reconciliate_BANG_.call(null,cel_27184,oh_27183,h_27179,m));
} else {
var b__26951__auto___27185 = ((function (seq__27131_27171,chunk__27132_27172,count__27133_27173,i__27134_27174,cel_27184,vec__27159_27181,iii_27182,oh_27183,temp__5733__auto___27180,vec__27153_27175,i_27176,vec__27156_27177,ii_27178,h_27179,om,nm,cs,map__27129,map__27129__$1,m,interceptors){
return (function (){
var ncel = el.removeChild(cel_27184);
(hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4 ? hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4(ncel,oh_27183,h_27179,m) : hipo.interpreter.reconciliate_BANG_.call(null,ncel,oh_27183,h_27179,m));

return hipo.dom.insert_child_BANG_(el,ii_27178,ncel);
});})(seq__27131_27171,chunk__27132_27172,count__27133_27173,i__27134_27174,cel_27184,vec__27159_27181,iii_27182,oh_27183,temp__5733__auto___27180,vec__27153_27175,i_27176,vec__27156_27177,ii_27178,h_27179,om,nm,cs,map__27129,map__27129__$1,m,interceptors))
;
var v__26952__auto___27186 = interceptors;
if(((cljs.core.not(v__26952__auto___27186)) || (cljs.core.empty_QMARK_(v__26952__auto___27186)))){
b__26951__auto___27185();
} else {
hipo.interceptor.call(b__26951__auto___27185,v__26952__auto___27186,cljs.core.cst$kw$move,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,h_27179,cljs.core.cst$kw$index,ii_27178], null));
}
}
} else {
var b__26951__auto___27187 = ((function (seq__27131_27171,chunk__27132_27172,count__27133_27173,i__27134_27174,temp__5733__auto___27180,vec__27153_27175,i_27176,vec__27156_27177,ii_27178,h_27179,om,nm,cs,map__27129,map__27129__$1,m,interceptors){
return (function (){
return hipo.dom.insert_child_BANG_(el,ii_27178,hipo.interpreter.create_child(h_27179,m));
});})(seq__27131_27171,chunk__27132_27172,count__27133_27173,i__27134_27174,temp__5733__auto___27180,vec__27153_27175,i_27176,vec__27156_27177,ii_27178,h_27179,om,nm,cs,map__27129,map__27129__$1,m,interceptors))
;
var v__26952__auto___27188 = interceptors;
if(((cljs.core.not(v__26952__auto___27188)) || (cljs.core.empty_QMARK_(v__26952__auto___27188)))){
b__26951__auto___27187();
} else {
hipo.interceptor.call(b__26951__auto___27187,v__26952__auto___27188,cljs.core.cst$kw$insert,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,h_27179,cljs.core.cst$kw$index,ii_27178], null));
}
}


var G__27189 = seq__27131_27171;
var G__27190 = chunk__27132_27172;
var G__27191 = count__27133_27173;
var G__27192 = (i__27134_27174 + (1));
seq__27131_27171 = G__27189;
chunk__27132_27172 = G__27190;
count__27133_27173 = G__27191;
i__27134_27174 = G__27192;
continue;
} else {
var temp__5735__auto___27193 = cljs.core.seq(seq__27131_27171);
if(temp__5735__auto___27193){
var seq__27131_27194__$1 = temp__5735__auto___27193;
if(cljs.core.chunked_seq_QMARK_(seq__27131_27194__$1)){
var c__4550__auto___27195 = cljs.core.chunk_first(seq__27131_27194__$1);
var G__27196 = cljs.core.chunk_rest(seq__27131_27194__$1);
var G__27197 = c__4550__auto___27195;
var G__27198 = cljs.core.count(c__4550__auto___27195);
var G__27199 = (0);
seq__27131_27171 = G__27196;
chunk__27132_27172 = G__27197;
count__27133_27173 = G__27198;
i__27134_27174 = G__27199;
continue;
} else {
var vec__27162_27200 = cljs.core.first(seq__27131_27194__$1);
var i_27201 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27162_27200,(0),null);
var vec__27165_27202 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27162_27200,(1),null);
var ii_27203 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27165_27202,(0),null);
var h_27204 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27165_27202,(1),null);
var temp__5733__auto___27205 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(om,i_27201);
if(cljs.core.truth_(temp__5733__auto___27205)){
var vec__27168_27206 = temp__5733__auto___27205;
var iii_27207 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27168_27206,(0),null);
var oh_27208 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__27168_27206,(1),null);
var cel_27209 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(cs,iii_27207);
if((ii_27203 === iii_27207)){
(hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4 ? hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4(cel_27209,oh_27208,h_27204,m) : hipo.interpreter.reconciliate_BANG_.call(null,cel_27209,oh_27208,h_27204,m));
} else {
var b__26951__auto___27210 = ((function (seq__27131_27171,chunk__27132_27172,count__27133_27173,i__27134_27174,cel_27209,vec__27168_27206,iii_27207,oh_27208,temp__5733__auto___27205,vec__27162_27200,i_27201,vec__27165_27202,ii_27203,h_27204,seq__27131_27194__$1,temp__5735__auto___27193,om,nm,cs,map__27129,map__27129__$1,m,interceptors){
return (function (){
var ncel = el.removeChild(cel_27209);
(hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4 ? hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4(ncel,oh_27208,h_27204,m) : hipo.interpreter.reconciliate_BANG_.call(null,ncel,oh_27208,h_27204,m));

return hipo.dom.insert_child_BANG_(el,ii_27203,ncel);
});})(seq__27131_27171,chunk__27132_27172,count__27133_27173,i__27134_27174,cel_27209,vec__27168_27206,iii_27207,oh_27208,temp__5733__auto___27205,vec__27162_27200,i_27201,vec__27165_27202,ii_27203,h_27204,seq__27131_27194__$1,temp__5735__auto___27193,om,nm,cs,map__27129,map__27129__$1,m,interceptors))
;
var v__26952__auto___27211 = interceptors;
if(((cljs.core.not(v__26952__auto___27211)) || (cljs.core.empty_QMARK_(v__26952__auto___27211)))){
b__26951__auto___27210();
} else {
hipo.interceptor.call(b__26951__auto___27210,v__26952__auto___27211,cljs.core.cst$kw$move,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,h_27204,cljs.core.cst$kw$index,ii_27203], null));
}
}
} else {
var b__26951__auto___27212 = ((function (seq__27131_27171,chunk__27132_27172,count__27133_27173,i__27134_27174,temp__5733__auto___27205,vec__27162_27200,i_27201,vec__27165_27202,ii_27203,h_27204,seq__27131_27194__$1,temp__5735__auto___27193,om,nm,cs,map__27129,map__27129__$1,m,interceptors){
return (function (){
return hipo.dom.insert_child_BANG_(el,ii_27203,hipo.interpreter.create_child(h_27204,m));
});})(seq__27131_27171,chunk__27132_27172,count__27133_27173,i__27134_27174,temp__5733__auto___27205,vec__27162_27200,i_27201,vec__27165_27202,ii_27203,h_27204,seq__27131_27194__$1,temp__5735__auto___27193,om,nm,cs,map__27129,map__27129__$1,m,interceptors))
;
var v__26952__auto___27213 = interceptors;
if(((cljs.core.not(v__26952__auto___27213)) || (cljs.core.empty_QMARK_(v__26952__auto___27213)))){
b__26951__auto___27212();
} else {
hipo.interceptor.call(b__26951__auto___27212,v__26952__auto___27213,cljs.core.cst$kw$insert,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,h_27204,cljs.core.cst$kw$index,ii_27203], null));
}
}


var G__27214 = cljs.core.next(seq__27131_27194__$1);
var G__27215 = null;
var G__27216 = (0);
var G__27217 = (0);
seq__27131_27171 = G__27214;
chunk__27132_27172 = G__27215;
count__27133_27173 = G__27216;
i__27134_27174 = G__27217;
continue;
}
} else {
}
}
break;
}

var d = cljs.core.count(clojure.set.difference.cljs$core$IFn$_invoke$arity$2(cljs.core.set(cljs.core.keys(om)),cljs.core.set(cljs.core.keys(nm))));
if((d > (0))){
var b__26951__auto__ = ((function (d,om,nm,cs,map__27129,map__27129__$1,m,interceptors){
return (function (){
return hipo.dom.remove_trailing_children_BANG_(el,d);
});})(d,om,nm,cs,map__27129,map__27129__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,cljs.core.cst$kw$remove_DASH_trailing,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$count,d], null));
}
} else {
return null;
}
});
hipo.interpreter.reconciliate_non_keyed_children_BANG_ = (function hipo$interpreter$reconciliate_non_keyed_children_BANG_(el,och,nch,p__27218){
var map__27219 = p__27218;
var map__27219__$1 = (((((!((map__27219 == null))))?(((((map__27219.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__27219.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__27219):map__27219);
var m = map__27219__$1;
var interceptors = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27219__$1,cljs.core.cst$kw$interceptors);
var oc = cljs.core.count(och);
var nc = cljs.core.count(nch);
var d = (oc - nc);
if((d > (0))){
var b__26951__auto___27221 = ((function (oc,nc,d,map__27219,map__27219__$1,m,interceptors){
return (function (){
return hipo.dom.remove_trailing_children_BANG_(el,d);
});})(oc,nc,d,map__27219,map__27219__$1,m,interceptors))
;
var v__26952__auto___27222 = interceptors;
if(((cljs.core.not(v__26952__auto___27222)) || (cljs.core.empty_QMARK_(v__26952__auto___27222)))){
b__26951__auto___27221();
} else {
hipo.interceptor.call(b__26951__auto___27221,v__26952__auto___27222,cljs.core.cst$kw$remove_DASH_trailing,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$count,d], null));
}
} else {
}

var n__4607__auto___27223 = (function (){var x__4222__auto__ = oc;
var y__4223__auto__ = nc;
return ((x__4222__auto__ < y__4223__auto__) ? x__4222__auto__ : y__4223__auto__);
})();
var i_27224 = (0);
while(true){
if((i_27224 < n__4607__auto___27223)){
var ov_27225 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(och,i_27224);
var nv_27226 = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(nch,i_27224);
if((!((((ov_27225 == null)) && ((nv_27226 == null)))))){
if((ov_27225 == null)){
var b__26951__auto___27227 = ((function (i_27224,ov_27225,nv_27226,n__4607__auto___27223,oc,nc,d,map__27219,map__27219__$1,m,interceptors){
return (function (){
return hipo.dom.insert_child_BANG_(el,i_27224,hipo.interpreter.create_child(nv_27226,m));
});})(i_27224,ov_27225,nv_27226,n__4607__auto___27223,oc,nc,d,map__27219,map__27219__$1,m,interceptors))
;
var v__26952__auto___27228 = interceptors;
if(((cljs.core.not(v__26952__auto___27228)) || (cljs.core.empty_QMARK_(v__26952__auto___27228)))){
b__26951__auto___27227();
} else {
hipo.interceptor.call(b__26951__auto___27227,v__26952__auto___27228,cljs.core.cst$kw$insert,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,nv_27226,cljs.core.cst$kw$index,i_27224], null));
}
} else {
if((nv_27226 == null)){
var b__26951__auto___27229 = ((function (i_27224,ov_27225,nv_27226,n__4607__auto___27223,oc,nc,d,map__27219,map__27219__$1,m,interceptors){
return (function (){
return hipo.dom.remove_child_BANG_(el,i_27224);
});})(i_27224,ov_27225,nv_27226,n__4607__auto___27223,oc,nc,d,map__27219,map__27219__$1,m,interceptors))
;
var v__26952__auto___27230 = interceptors;
if(((cljs.core.not(v__26952__auto___27230)) || (cljs.core.empty_QMARK_(v__26952__auto___27230)))){
b__26951__auto___27229();
} else {
hipo.interceptor.call(b__26951__auto___27229,v__26952__auto___27230,cljs.core.cst$kw$remove,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$index,i_27224], null));
}
} else {
var temp__5733__auto___27231 = hipo.dom.child(el,i_27224);
if(cljs.core.truth_(temp__5733__auto___27231)){
var cel_27232 = temp__5733__auto___27231;
(hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4 ? hipo.interpreter.reconciliate_BANG_.cljs$core$IFn$_invoke$arity$4(cel_27232,ov_27225,nv_27226,m) : hipo.interpreter.reconciliate_BANG_.call(null,cel_27232,ov_27225,nv_27226,m));
} else {
}

}
}
} else {
}

var G__27233 = (i_27224 + (1));
i_27224 = G__27233;
continue;
} else {
}
break;
}

if((d < (0))){
if(((-1) === d)){
var temp__5733__auto__ = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(nch,oc);
if(cljs.core.truth_(temp__5733__auto__)){
var h = temp__5733__auto__;
var b__26951__auto__ = ((function (h,temp__5733__auto__,oc,nc,d,map__27219,map__27219__$1,m,interceptors){
return (function (){
return el.appendChild(hipo.interpreter.create_child(h,m));
});})(h,temp__5733__auto__,oc,nc,d,map__27219,map__27219__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,cljs.core.cst$kw$append,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,h], null));
}
} else {
return null;
}
} else {
var f = document.createDocumentFragment();
var cs = ((((0) === oc))?nch:cljs.core.subvec.cljs$core$IFn$_invoke$arity$2(nch,oc));
var b__26951__auto___27234 = ((function (f,cs,oc,nc,d,map__27219,map__27219__$1,m,interceptors){
return (function (){
return hipo.interpreter.append_children_BANG_(f,cs,m);
});})(f,cs,oc,nc,d,map__27219,map__27219__$1,m,interceptors))
;
var v__26952__auto___27235 = interceptors;
if(((cljs.core.not(v__26952__auto___27235)) || (cljs.core.empty_QMARK_(v__26952__auto___27235)))){
b__26951__auto___27234();
} else {
hipo.interceptor.call(b__26951__auto___27234,v__26952__auto___27235,cljs.core.cst$kw$append,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,cs], null));
}

return el.appendChild(f);
}
} else {
return null;
}
});
hipo.interpreter.keyed_children_QMARK_ = (function hipo$interpreter$keyed_children_QMARK_(v){
return (!((hipo.interpreter.child_key(cljs.core.nth.cljs$core$IFn$_invoke$arity$2(v,(0))) == null)));
});
hipo.interpreter.reconciliate_children_BANG_ = (function hipo$interpreter$reconciliate_children_BANG_(el,och,nch,p__27236){
var map__27237 = p__27236;
var map__27237__$1 = (((((!((map__27237 == null))))?(((((map__27237.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__27237.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__27237):map__27237);
var m = map__27237__$1;
var interceptors = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27237__$1,cljs.core.cst$kw$interceptors);
if(cljs.core.empty_QMARK_(nch)){
if((!(cljs.core.empty_QMARK_(och)))){
var b__26951__auto__ = ((function (map__27237,map__27237__$1,m,interceptors){
return (function (){
return hipo.dom.clear_BANG_(el);
});})(map__27237,map__27237__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,cljs.core.cst$kw$clear,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$target,el], null));
}
} else {
return null;
}
} else {
if(hipo.interpreter.keyed_children_QMARK_(nch)){
return hipo.interpreter.reconciliate_keyed_children_BANG_(el,och,nch,m);
} else {
return hipo.interpreter.reconciliate_non_keyed_children_BANG_(el,och,nch,m);
}
}
});
hipo.interpreter.reconciliate_vector_BANG_ = (function hipo$interpreter$reconciliate_vector_BANG_(el,oh,nh,p__27239){
var map__27240 = p__27239;
var map__27240__$1 = (((((!((map__27240 == null))))?(((((map__27240.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__27240.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__27240):map__27240);
var m = map__27240__$1;
var interceptors = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27240__$1,cljs.core.cst$kw$interceptors);

if(((hipo.hiccup.literal_QMARK_(oh)) || ((!((hipo.hiccup.tag(nh) === hipo.hiccup.tag(oh))))))){
var nel = hipo.interpreter.create_child(nh,m);
var b__26951__auto__ = ((function (nel,map__27240,map__27240__$1,m,interceptors){
return (function (){

return hipo.dom.replace_BANG_(el,nel);
});})(nel,map__27240,map__27240__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,cljs.core.cst$kw$replace,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,nh], null));
}
} else {
var om = hipo.hiccup.attributes(oh);
var nm = hipo.hiccup.attributes(nh);
var och = hipo.hiccup.children(oh);
var nch = hipo.hiccup.children(nh);
var b__26951__auto___27242 = ((function (om,nm,och,nch,map__27240,map__27240__$1,m,interceptors){
return (function (){
return hipo.interpreter.reconciliate_children_BANG_(el,hipo.hiccup.flatten_children(och),hipo.hiccup.flatten_children(nch),m);
});})(om,nm,och,nch,map__27240,map__27240__$1,m,interceptors))
;
var v__26952__auto___27243 = interceptors;
if(((cljs.core.not(v__26952__auto___27243)) || (cljs.core.empty_QMARK_(v__26952__auto___27243)))){
b__26951__auto___27242();
} else {
hipo.interceptor.call(b__26951__auto___27242,v__26952__auto___27243,cljs.core.cst$kw$reconciliate,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$old_DASH_value,och,cljs.core.cst$kw$new_DASH_value,nch], null));
}

return hipo.interpreter.reconciliate_attributes_BANG_(el,hipo.hiccup.keyns(nh),hipo.hiccup.tag(nh),om,nm,m);
}
});
hipo.interpreter.reconciliate_BANG_ = (function hipo$interpreter$reconciliate_BANG_(el,oh,nh,p__27244){
var map__27245 = p__27244;
var map__27245__$1 = (((((!((map__27245 == null))))?(((((map__27245.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__27245.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__27245):map__27245);
var m = map__27245__$1;
var interceptors = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__27245__$1,cljs.core.cst$kw$interceptors);


var b__26951__auto__ = ((function (map__27245,map__27245__$1,m,interceptors){
return (function (){
if(hipo.hiccup.literal_QMARK_(nh)){
if((!((oh === nh)))){
var b__26951__auto__ = ((function (map__27245,map__27245__$1,m,interceptors){
return (function (){

return hipo.dom.replace_text_BANG_(el,cljs.core.str.cljs$core$IFn$_invoke$arity$1(nh));
});})(map__27245,map__27245__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,cljs.core.cst$kw$replace,new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$value,nh], null));
}
} else {
return null;
}
} else {
return hipo.interpreter.reconciliate_vector_BANG_(el,oh,nh,m);
}
});})(map__27245,map__27245__$1,m,interceptors))
;
var v__26952__auto__ = interceptors;
if(((cljs.core.not(v__26952__auto__)) || (cljs.core.empty_QMARK_(v__26952__auto__)))){
return b__26951__auto__();
} else {
return hipo.interceptor.call(b__26951__auto__,v__26952__auto__,cljs.core.cst$kw$reconciliate,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$target,el,cljs.core.cst$kw$old_DASH_value,oh,cljs.core.cst$kw$new_DASH_value,nh], null));
}
});

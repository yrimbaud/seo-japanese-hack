// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('oops.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.spec.alpha');
goog.require('goog.object');
goog.require('oops.sdefs');
goog.require('oops.state');
goog.require('oops.config');
goog.require('oops.messages');
goog.require('oops.helpers');
goog.require('oops.schema');
oops.core.report_error_dynamically = (function oops$core$report_error_dynamically(msg,data){
if(oops.state.was_error_reported_QMARK_()){
return null;
} else {
oops.state.mark_error_reported_BANG_();

var G__25389 = oops.config.get_error_reporting();
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$throw,G__25389)){
throw oops.state.prepare_error_from_call_site(msg,oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$console,G__25389)){
var G__25391 = (console["error"]);
var G__25392 = msg;
var G__25393 = oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data);
var fexpr__25390 = oops.state.get_console_reporter();
return (fexpr__25390.cljs$core$IFn$_invoke$arity$3 ? fexpr__25390.cljs$core$IFn$_invoke$arity$3(G__25391,G__25392,G__25393) : fexpr__25390.call(null,G__25391,G__25392,G__25393));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(false,G__25389)){
return null;
} else {
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__25389)].join('')));

}
}
}
}
});
oops.core.report_warning_dynamically = (function oops$core$report_warning_dynamically(msg,data){
var G__25394 = oops.config.get_warning_reporting();
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$throw,G__25394)){
throw oops.state.prepare_error_from_call_site(msg,oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$console,G__25394)){
var G__25396 = (console["warn"]);
var G__25397 = msg;
var G__25398 = oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data);
var fexpr__25395 = oops.state.get_console_reporter();
return (fexpr__25395.cljs$core$IFn$_invoke$arity$3 ? fexpr__25395.cljs$core$IFn$_invoke$arity$3(G__25396,G__25397,G__25398) : fexpr__25395.call(null,G__25396,G__25397,G__25398));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(false,G__25394)){
return null;
} else {
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__25394)].join('')));

}
}
}
});
oops.core.report_if_needed_dynamically = (function oops$core$report_if_needed_dynamically(var_args){
var args__4736__auto__ = [];
var len__4730__auto___25405 = arguments.length;
var i__4731__auto___25406 = (0);
while(true){
if((i__4731__auto___25406 < len__4730__auto___25405)){
args__4736__auto__.push((arguments[i__4731__auto___25406]));

var G__25407 = (i__4731__auto___25406 + (1));
i__4731__auto___25406 = G__25407;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic = (function (msg_id,p__25401){
var vec__25402 = p__25401;
var info = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__25402,(0),null);
return null;
});

oops.core.report_if_needed_dynamically.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
oops.core.report_if_needed_dynamically.cljs$lang$applyTo = (function (seq25399){
var G__25400 = cljs.core.first(seq25399);
var seq25399__$1 = cljs.core.next(seq25399);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__25400,seq25399__$1);
});

oops.core.validate_object_access_dynamically = (function oops$core$validate_object_access_dynamically(obj,mode,key,push_QMARK_,check_key_read_QMARK_,check_key_write_QMARK_){
if(((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && ((void 0 === obj))))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"undefined",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"undefined",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && ((obj == null))))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"nil",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"nil",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isBoolean(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"boolean",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"boolean",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isNumber(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"number",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"number",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isString(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"string",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"string",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):((cljs.core.not(goog.isObject(obj)))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"non-object",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"non-object",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isDateLike(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"date-like",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"date-like",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return true;
})()
):(cljs.core.truth_(oops.helpers.cljs_type_QMARK_(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs type",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs type",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return true;
})()
):(cljs.core.truth_(oops.helpers.cljs_instance_QMARK_(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs instance",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs instance",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return true;
})()
):true
)))))))))){
if(cljs.core.truth_(push_QMARK_)){
oops.state.add_key_to_current_path_BANG_(key);

oops.state.set_last_access_modifier_BANG_(mode);
} else {
}

var and__4120__auto__ = (cljs.core.truth_(check_key_read_QMARK_)?((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && (cljs.core.not(goog.object.containsKey(obj,key)))))?(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$missing_DASH_object_DASH_key,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$missing_DASH_object_DASH_key,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null))):true):true);
if(cljs.core.truth_(and__4120__auto__)){
if(cljs.core.truth_(check_key_write_QMARK_)){
var temp__5737__auto__ = oops.helpers.get_property_descriptor(obj,key);
if((temp__5737__auto__ == null)){
if(cljs.core.truth_(oops.helpers.is_object_frozen_QMARK_(obj))){
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$object_DASH_is_DASH_frozen,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$object_DASH_is_DASH_frozen,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));
} else {
if(cljs.core.truth_(oops.helpers.is_object_sealed_QMARK_(obj))){
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$object_DASH_is_DASH_sealed,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$object_DASH_is_DASH_sealed,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));
} else {
return true;

}
}
} else {
var descriptor_25408 = temp__5737__auto__;
var temp__5737__auto____$1 = oops.helpers.determine_property_non_writable_reason(descriptor_25408);
if((temp__5737__auto____$1 == null)){
return true;
} else {
var reason_25409 = temp__5737__auto____$1;
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$object_DASH_key_DASH_not_DASH_writable,new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$frozen_QMARK_,oops.helpers.is_object_frozen_QMARK_(obj),cljs.core.cst$kw$reason,reason_25409,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$object_DASH_key_DASH_not_DASH_writable,new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$frozen_QMARK_,oops.helpers.is_object_frozen_QMARK_(obj),cljs.core.cst$kw$reason,reason_25409,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));
}
}
} else {
return true;
}
} else {
return and__4120__auto__;
}
} else {
return null;
}
});
oops.core.validate_fn_call_dynamically = (function oops$core$validate_fn_call_dynamically(fn,mode){
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1))) && ((fn == null)))){
return true;
} else {
if(cljs.core.truth_(goog.isFunction(fn))){
return true;
} else {
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$expected_DASH_function_DASH_value,new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$soft_QMARK_,cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1)),cljs.core.cst$kw$fn,fn,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$expected_DASH_function_DASH_value,new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$soft_QMARK_,cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1)),cljs.core.cst$kw$fn,fn,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

}
}
});
oops.core.punch_key_dynamically_BANG_ = (function oops$core$punch_key_dynamically_BANG_(obj,key){
var child_factory_25411 = oops.config.get_child_factory();
var child_factory_25411__$1 = (function (){var G__25412 = child_factory_25411;
var G__25412__$1 = (((G__25412 instanceof cljs.core.Keyword))?G__25412.fqn:null);
switch (G__25412__$1) {
case "js-obj":
return ((function (G__25412,G__25412__$1,child_factory_25411){
return (function (){
return ({});
});
;})(G__25412,G__25412__$1,child_factory_25411))

break;
case "js-array":
return ((function (G__25412,G__25412__$1,child_factory_25411){
return (function (){
return [];
});
;})(G__25412,G__25412__$1,child_factory_25411))

break;
default:
return child_factory_25411;

}
})();

var child_obj_25410 = (child_factory_25411__$1.cljs$core$IFn$_invoke$arity$2 ? child_factory_25411__$1.cljs$core$IFn$_invoke$arity$2(obj,key) : child_factory_25411__$1.call(null,obj,key));
(obj[key] = child_obj_25410);

return child_obj_25410;
});
oops.core.build_path_dynamically = (function oops$core$build_path_dynamically(selector){
if(((typeof selector === 'string') || ((selector instanceof cljs.core.Keyword)))){
var selector_path_25416 = [];
oops.schema.prepare_simple_path_BANG_(selector,selector_path_25416);

return selector_path_25416;
} else {
var selector_path_25417 = [];
oops.schema.prepare_path_BANG_(selector,selector_path_25417);

return selector_path_25417;

}
});
oops.core.check_path_dynamically = (function oops$core$check_path_dynamically(path,op){
var temp__5739__auto__ = oops.schema.check_dynamic_path_BANG_(path,op);
if((temp__5739__auto__ == null)){
return null;
} else {
var issue_25418 = temp__5739__auto__;
return cljs.core.apply.cljs$core$IFn$_invoke$arity$2(oops.core.report_if_needed_dynamically,issue_25418);
}
});
oops.core.get_key_dynamically = (function oops$core$get_key_dynamically(obj,key,mode){
return (obj[key]);
});
oops.core.set_key_dynamically = (function oops$core$set_key_dynamically(obj,key,val,mode){
return (obj[key] = val);
});
oops.core.get_selector_dynamically = (function oops$core$get_selector_dynamically(obj,selector){
var path_25420 = (function (){var path_25419 = oops.core.build_path_dynamically(selector);

return path_25419;
})();
var len_25421 = path_25420.length;
var i_25422 = (0);
var obj_25423 = obj;
while(true){
if((i_25422 < len_25421)){
var mode_25424 = (path_25420[i_25422]);
var key_25425 = (path_25420[(i_25422 + (1))]);
var next_obj_25426 = oops.core.get_key_dynamically(obj_25423,key_25425,mode_25424);
var G__25427 = mode_25424;
switch (G__25427) {
case (0):
var G__25429 = (i_25422 + (2));
var G__25430 = next_obj_25426;
i_25422 = G__25429;
obj_25423 = G__25430;
continue;

break;
case (1):
if((!((next_obj_25426 == null)))){
var G__25431 = (i_25422 + (2));
var G__25432 = next_obj_25426;
i_25422 = G__25431;
obj_25423 = G__25432;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_25426 == null)))){
var G__25433 = (i_25422 + (2));
var G__25434 = next_obj_25426;
i_25422 = G__25433;
obj_25423 = G__25434;
continue;
} else {
var G__25435 = (i_25422 + (2));
var G__25436 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_25423,key_25425) : oops.core.punch_key_dynamically_BANG_.call(null,obj_25423,key_25425));
i_25422 = G__25435;
obj_25423 = G__25436;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__25427)].join('')));

}
} else {
return obj_25423;
}
break;
}
});
oops.core.get_selector_call_info_dynamically = (function oops$core$get_selector_call_info_dynamically(obj,selector){
var path_25438 = (function (){var path_25437 = oops.core.build_path_dynamically(selector);

return path_25437;
})();
var len_25439 = path_25438.length;
if((len_25439 < (4))){
return [obj,(function (){var path_25441 = path_25438;
var len_25442 = path_25441.length;
var i_25443 = (0);
var obj_25444 = obj;
while(true){
if((i_25443 < len_25442)){
var mode_25445 = (path_25441[i_25443]);
var key_25446 = (path_25441[(i_25443 + (1))]);
var next_obj_25447 = oops.core.get_key_dynamically(obj_25444,key_25446,mode_25445);
var G__25462 = mode_25445;
switch (G__25462) {
case (0):
var G__25466 = (i_25443 + (2));
var G__25467 = next_obj_25447;
i_25443 = G__25466;
obj_25444 = G__25467;
continue;

break;
case (1):
if((!((next_obj_25447 == null)))){
var G__25468 = (i_25443 + (2));
var G__25469 = next_obj_25447;
i_25443 = G__25468;
obj_25444 = G__25469;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_25447 == null)))){
var G__25470 = (i_25443 + (2));
var G__25471 = next_obj_25447;
i_25443 = G__25470;
obj_25444 = G__25471;
continue;
} else {
var G__25472 = (i_25443 + (2));
var G__25473 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_25444,key_25446) : oops.core.punch_key_dynamically_BANG_.call(null,obj_25444,key_25446));
i_25443 = G__25472;
obj_25444 = G__25473;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__25462)].join('')));

}
} else {
return obj_25444;
}
break;
}
})()];
} else {
var target_obj_25440 = (function (){var path_25448 = path_25438.slice((0),(len_25439 - (2)));
var len_25449 = path_25448.length;
var i_25450 = (0);
var obj_25451 = obj;
while(true){
if((i_25450 < len_25449)){
var mode_25452 = (path_25448[i_25450]);
var key_25453 = (path_25448[(i_25450 + (1))]);
var next_obj_25454 = oops.core.get_key_dynamically(obj_25451,key_25453,mode_25452);
var G__25463 = mode_25452;
switch (G__25463) {
case (0):
var G__25475 = (i_25450 + (2));
var G__25476 = next_obj_25454;
i_25450 = G__25475;
obj_25451 = G__25476;
continue;

break;
case (1):
if((!((next_obj_25454 == null)))){
var G__25477 = (i_25450 + (2));
var G__25478 = next_obj_25454;
i_25450 = G__25477;
obj_25451 = G__25478;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_25454 == null)))){
var G__25479 = (i_25450 + (2));
var G__25480 = next_obj_25454;
i_25450 = G__25479;
obj_25451 = G__25480;
continue;
} else {
var G__25481 = (i_25450 + (2));
var G__25482 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_25451,key_25453) : oops.core.punch_key_dynamically_BANG_.call(null,obj_25451,key_25453));
i_25450 = G__25481;
obj_25451 = G__25482;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__25463)].join('')));

}
} else {
return obj_25451;
}
break;
}
})();
return [target_obj_25440,(function (){var path_25455 = [(path_25438[(len_25439 - (2))]),(path_25438[(len_25439 - (1))])];
var len_25456 = path_25455.length;
var i_25457 = (0);
var obj_25458 = target_obj_25440;
while(true){
if((i_25457 < len_25456)){
var mode_25459 = (path_25455[i_25457]);
var key_25460 = (path_25455[(i_25457 + (1))]);
var next_obj_25461 = oops.core.get_key_dynamically(obj_25458,key_25460,mode_25459);
var G__25464 = mode_25459;
switch (G__25464) {
case (0):
var G__25484 = (i_25457 + (2));
var G__25485 = next_obj_25461;
i_25457 = G__25484;
obj_25458 = G__25485;
continue;

break;
case (1):
if((!((next_obj_25461 == null)))){
var G__25486 = (i_25457 + (2));
var G__25487 = next_obj_25461;
i_25457 = G__25486;
obj_25458 = G__25487;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_25461 == null)))){
var G__25488 = (i_25457 + (2));
var G__25489 = next_obj_25461;
i_25457 = G__25488;
obj_25458 = G__25489;
continue;
} else {
var G__25490 = (i_25457 + (2));
var G__25491 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_25458,key_25460) : oops.core.punch_key_dynamically_BANG_.call(null,obj_25458,key_25460));
i_25457 = G__25490;
obj_25458 = G__25491;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__25464)].join('')));

}
} else {
return obj_25458;
}
break;
}
})()];
}
});
oops.core.set_selector_dynamically = (function oops$core$set_selector_dynamically(obj,selector,val){
var path_25493 = (function (){var path_25492 = oops.core.build_path_dynamically(selector);

return path_25492;
})();
var len_25496 = path_25493.length;
var parent_obj_path_25497 = path_25493.slice((0),(len_25496 - (2)));
var key_25494 = (path_25493[(len_25496 - (1))]);
var mode_25495 = (path_25493[(len_25496 - (2))]);
var parent_obj_25498 = (function (){var path_25499 = parent_obj_path_25497;
var len_25500 = path_25499.length;
var i_25501 = (0);
var obj_25502 = obj;
while(true){
if((i_25501 < len_25500)){
var mode_25503 = (path_25499[i_25501]);
var key_25504 = (path_25499[(i_25501 + (1))]);
var next_obj_25505 = oops.core.get_key_dynamically(obj_25502,key_25504,mode_25503);
var G__25506 = mode_25503;
switch (G__25506) {
case (0):
var G__25508 = (i_25501 + (2));
var G__25509 = next_obj_25505;
i_25501 = G__25508;
obj_25502 = G__25509;
continue;

break;
case (1):
if((!((next_obj_25505 == null)))){
var G__25510 = (i_25501 + (2));
var G__25511 = next_obj_25505;
i_25501 = G__25510;
obj_25502 = G__25511;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_25505 == null)))){
var G__25512 = (i_25501 + (2));
var G__25513 = next_obj_25505;
i_25501 = G__25512;
obj_25502 = G__25513;
continue;
} else {
var G__25514 = (i_25501 + (2));
var G__25515 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_25502,key_25504) : oops.core.punch_key_dynamically_BANG_.call(null,obj_25502,key_25504));
i_25501 = G__25514;
obj_25502 = G__25515;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__25506)].join('')));

}
} else {
return obj_25502;
}
break;
}
})();
return oops.core.set_key_dynamically(parent_obj_25498,key_25494,val,mode_25495);
});

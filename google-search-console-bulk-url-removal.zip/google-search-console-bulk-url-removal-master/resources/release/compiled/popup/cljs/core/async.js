// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('cljs.core.async');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async.impl.channels');
goog.require('cljs.core.async.impl.buffers');
goog.require('cljs.core.async.impl.timers');
goog.require('cljs.core.async.impl.dispatch');
goog.require('cljs.core.async.impl.ioc_helpers');
goog.require('goog.array');
cljs.core.async.fn_handler = (function cljs$core$async$fn_handler(var_args){
var G__22493 = arguments.length;
switch (G__22493) {
case 1:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1 = (function (f){
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(f,true);
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2 = (function (f,blockable){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async22494 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async22494 = (function (f,blockable,meta22495){
this.f = f;
this.blockable = blockable;
this.meta22495 = meta22495;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async22494.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_22496,meta22495__$1){
var self__ = this;
var _22496__$1 = this;
return (new cljs.core.async.t_cljs$core$async22494(self__.f,self__.blockable,meta22495__$1));
});

cljs.core.async.t_cljs$core$async22494.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_22496){
var self__ = this;
var _22496__$1 = this;
return self__.meta22495;
});

cljs.core.async.t_cljs$core$async22494.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async22494.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async22494.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.blockable;
});

cljs.core.async.t_cljs$core$async22494.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.f;
});

cljs.core.async.t_cljs$core$async22494.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$blockable,cljs.core.cst$sym$meta22495], null);
});

cljs.core.async.t_cljs$core$async22494.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async22494.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async22494";

cljs.core.async.t_cljs$core$async22494.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async22494");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async22494.
 */
cljs.core.async.__GT_t_cljs$core$async22494 = (function cljs$core$async$__GT_t_cljs$core$async22494(f__$1,blockable__$1,meta22495){
return (new cljs.core.async.t_cljs$core$async22494(f__$1,blockable__$1,meta22495));
});

}

return (new cljs.core.async.t_cljs$core$async22494(f,blockable,cljs.core.PersistentArrayMap.EMPTY));
});

cljs.core.async.fn_handler.cljs$lang$maxFixedArity = 2;

/**
 * Returns a fixed buffer of size n. When full, puts will block/park.
 */
cljs.core.async.buffer = (function cljs$core$async$buffer(n){
return cljs.core.async.impl.buffers.fixed_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete but
 *   val will be dropped (no transfer).
 */
cljs.core.async.dropping_buffer = (function cljs$core$async$dropping_buffer(n){
return cljs.core.async.impl.buffers.dropping_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete, and be
 *   buffered, but oldest elements in buffer will be dropped (not
 *   transferred).
 */
cljs.core.async.sliding_buffer = (function cljs$core$async$sliding_buffer(n){
return cljs.core.async.impl.buffers.sliding_buffer(n);
});
/**
 * Returns true if a channel created with buff will never block. That is to say,
 * puts into this buffer will never cause the buffer to be full. 
 */
cljs.core.async.unblocking_buffer_QMARK_ = (function cljs$core$async$unblocking_buffer_QMARK_(buff){
if((!((buff == null)))){
if(((false) || ((cljs.core.PROTOCOL_SENTINEL === buff.cljs$core$async$impl$protocols$UnblockingBuffer$)))){
return true;
} else {
if((!buff.cljs$lang$protocol_mask$partition$)){
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
} else {
return false;
}
}
} else {
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
}
});
/**
 * Creates a channel with an optional buffer, an optional transducer (like (map f),
 *   (filter p) etc or a composition thereof), and an optional exception handler.
 *   If buf-or-n is a number, will create and use a fixed buffer of that size. If a
 *   transducer is supplied a buffer must be specified. ex-handler must be a
 *   fn of one argument - if an exception occurs during transformation it will be called
 *   with the thrown value as an argument, and any non-nil return value will be placed
 *   in the channel.
 */
cljs.core.async.chan = (function cljs$core$async$chan(var_args){
var G__22500 = arguments.length;
switch (G__22500) {
case 0:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1 = (function (buf_or_n){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2 = (function (buf_or_n,xform){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,xform,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3 = (function (buf_or_n,xform,ex_handler){
var buf_or_n__$1 = ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(buf_or_n,(0)))?null:buf_or_n);
if(cljs.core.truth_(xform)){
} else {
}

return cljs.core.async.impl.channels.chan.cljs$core$IFn$_invoke$arity$3(((typeof buf_or_n__$1 === 'number')?cljs.core.async.buffer(buf_or_n__$1):buf_or_n__$1),xform,ex_handler);
});

cljs.core.async.chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates a promise channel with an optional transducer, and an optional
 *   exception-handler. A promise channel can take exactly one value that consumers
 *   will receive. Once full, puts complete but val is dropped (no transfer).
 *   Consumers will block until either a value is placed in the channel or the
 *   channel is closed. See chan for the semantics of xform and ex-handler.
 */
cljs.core.async.promise_chan = (function cljs$core$async$promise_chan(var_args){
var G__22503 = arguments.length;
switch (G__22503) {
case 0:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1 = (function (xform){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2(xform,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2 = (function (xform,ex_handler){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(cljs.core.async.impl.buffers.promise_buffer(),xform,ex_handler);
});

cljs.core.async.promise_chan.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel that will close after msecs
 */
cljs.core.async.timeout = (function cljs$core$async$timeout(msecs){
return cljs.core.async.impl.timers.timeout(msecs);
});
/**
 * takes a val from port. Must be called inside a (go ...) block. Will
 *   return nil if closed. Will park if nothing is available.
 *   Returns true unless port is already closed
 */
cljs.core.async._LT__BANG_ = (function cljs$core$async$_LT__BANG_(port){
throw (new Error("<! used not in (go ...) block"));
});
/**
 * Asynchronously takes a val from port, passing to fn1. Will pass nil
 * if closed. If on-caller? (default true) is true, and value is
 * immediately available, will call fn1 on calling thread.
 * Returns nil.
 */
cljs.core.async.take_BANG_ = (function cljs$core$async$take_BANG_(var_args){
var G__22506 = arguments.length;
switch (G__22506) {
case 2:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,fn1){
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3(port,fn1,true);
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,fn1,on_caller_QMARK_){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(ret)){
var val_22508 = cljs.core.deref(ret);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_22508) : fn1.call(null,val_22508));
} else {
cljs.core.async.impl.dispatch.run(((function (val_22508,ret){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_22508) : fn1.call(null,val_22508));
});})(val_22508,ret))
);
}
} else {
}

return null;
});

cljs.core.async.take_BANG_.cljs$lang$maxFixedArity = 3;

cljs.core.async.nop = (function cljs$core$async$nop(_){
return null;
});
cljs.core.async.fhnop = cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(cljs.core.async.nop);
/**
 * puts a val into port. nil values are not allowed. Must be called
 *   inside a (go ...) block. Will park if no buffer space is available.
 *   Returns true unless port is already closed.
 */
cljs.core.async._GT__BANG_ = (function cljs$core$async$_GT__BANG_(port,val){
throw (new Error(">! used not in (go ...) block"));
});
/**
 * Asynchronously puts a val into port, calling fn1 (if supplied) when
 * complete. nil values are not allowed. Will throw if closed. If
 * on-caller? (default true) is true, and the put is immediately
 * accepted, will call fn1 on calling thread.  Returns nil.
 */
cljs.core.async.put_BANG_ = (function cljs$core$async$put_BANG_(var_args){
var G__22510 = arguments.length;
switch (G__22510) {
case 2:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,val){
var temp__5733__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fhnop);
if(cljs.core.truth_(temp__5733__auto__)){
var ret = temp__5733__auto__;
return cljs.core.deref(ret);
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,val,fn1){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4(port,val,fn1,true);
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (port,val,fn1,on_caller_QMARK_){
var temp__5733__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(temp__5733__auto__)){
var retb = temp__5733__auto__;
var ret = cljs.core.deref(retb);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
} else {
cljs.core.async.impl.dispatch.run(((function (ret,retb,temp__5733__auto__){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
});})(ret,retb,temp__5733__auto__))
);
}

return ret;
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$lang$maxFixedArity = 4;

cljs.core.async.close_BANG_ = (function cljs$core$async$close_BANG_(port){
return cljs.core.async.impl.protocols.close_BANG_(port);
});
cljs.core.async.random_array = (function cljs$core$async$random_array(n){
var a = (new Array(n));
var n__4607__auto___22512 = n;
var x_22513 = (0);
while(true){
if((x_22513 < n__4607__auto___22512)){
(a[x_22513] = x_22513);

var G__22514 = (x_22513 + (1));
x_22513 = G__22514;
continue;
} else {
}
break;
}

goog.array.shuffle(a);

return a;
});
cljs.core.async.alt_flag = (function cljs$core$async$alt_flag(){
var flag = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(true);
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async22515 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async22515 = (function (flag,meta22516){
this.flag = flag;
this.meta22516 = meta22516;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async22515.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (flag){
return (function (_22517,meta22516__$1){
var self__ = this;
var _22517__$1 = this;
return (new cljs.core.async.t_cljs$core$async22515(self__.flag,meta22516__$1));
});})(flag))
;

cljs.core.async.t_cljs$core$async22515.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (flag){
return (function (_22517){
var self__ = this;
var _22517__$1 = this;
return self__.meta22516;
});})(flag))
;

cljs.core.async.t_cljs$core$async22515.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async22515.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.deref(self__.flag);
});})(flag))
;

cljs.core.async.t_cljs$core$async22515.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async22515.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.flag,null);

return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async22515.getBasis = ((function (flag){
return (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$meta22516], null);
});})(flag))
;

cljs.core.async.t_cljs$core$async22515.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async22515.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async22515";

cljs.core.async.t_cljs$core$async22515.cljs$lang$ctorPrWriter = ((function (flag){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async22515");
});})(flag))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async22515.
 */
cljs.core.async.__GT_t_cljs$core$async22515 = ((function (flag){
return (function cljs$core$async$alt_flag_$___GT_t_cljs$core$async22515(flag__$1,meta22516){
return (new cljs.core.async.t_cljs$core$async22515(flag__$1,meta22516));
});})(flag))
;

}

return (new cljs.core.async.t_cljs$core$async22515(flag,cljs.core.PersistentArrayMap.EMPTY));
});
cljs.core.async.alt_handler = (function cljs$core$async$alt_handler(flag,cb){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async22518 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async22518 = (function (flag,cb,meta22519){
this.flag = flag;
this.cb = cb;
this.meta22519 = meta22519;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async22518.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_22520,meta22519__$1){
var self__ = this;
var _22520__$1 = this;
return (new cljs.core.async.t_cljs$core$async22518(self__.flag,self__.cb,meta22519__$1));
});

cljs.core.async.t_cljs$core$async22518.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_22520){
var self__ = this;
var _22520__$1 = this;
return self__.meta22519;
});

cljs.core.async.t_cljs$core$async22518.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async22518.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.flag);
});

cljs.core.async.t_cljs$core$async22518.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async22518.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.async.impl.protocols.commit(self__.flag);

return self__.cb;
});

cljs.core.async.t_cljs$core$async22518.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$cb,cljs.core.cst$sym$meta22519], null);
});

cljs.core.async.t_cljs$core$async22518.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async22518.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async22518";

cljs.core.async.t_cljs$core$async22518.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async22518");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async22518.
 */
cljs.core.async.__GT_t_cljs$core$async22518 = (function cljs$core$async$alt_handler_$___GT_t_cljs$core$async22518(flag__$1,cb__$1,meta22519){
return (new cljs.core.async.t_cljs$core$async22518(flag__$1,cb__$1,meta22519));
});

}

return (new cljs.core.async.t_cljs$core$async22518(flag,cb,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * returns derefable [val port] if immediate, nil if enqueued
 */
cljs.core.async.do_alts = (function cljs$core$async$do_alts(fret,ports,opts){

var flag = cljs.core.async.alt_flag();
var n = cljs.core.count(ports);
var idxs = cljs.core.async.random_array(n);
var priority = cljs.core.cst$kw$priority.cljs$core$IFn$_invoke$arity$1(opts);
var ret = (function (){var i = (0);
while(true){
if((i < n)){
var idx = (cljs.core.truth_(priority)?i:(idxs[i]));
var port = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(ports,idx);
var wport = ((cljs.core.vector_QMARK_(port))?(port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((0)) : port.call(null,(0))):null);
var vbox = (cljs.core.truth_(wport)?(function (){var val = (port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((1)) : port.call(null,(1)));
return cljs.core.async.impl.protocols.put_BANG_(wport,val,cljs.core.async.alt_handler(flag,((function (i,val,idx,port,wport,flag,n,idxs,priority){
return (function (p1__22521_SHARP_){
var G__22523 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__22521_SHARP_,wport], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__22523) : fret.call(null,G__22523));
});})(i,val,idx,port,wport,flag,n,idxs,priority))
));
})():cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.alt_handler(flag,((function (i,idx,port,wport,flag,n,idxs,priority){
return (function (p1__22522_SHARP_){
var G__22524 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__22522_SHARP_,port], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__22524) : fret.call(null,G__22524));
});})(i,idx,port,wport,flag,n,idxs,priority))
)));
if(cljs.core.truth_(vbox)){
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.deref(vbox),(function (){var or__4131__auto__ = wport;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return port;
}
})()], null));
} else {
var G__22525 = (i + (1));
i = G__22525;
continue;
}
} else {
return null;
}
break;
}
})();
var or__4131__auto__ = ret;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
if(cljs.core.contains_QMARK_(opts,cljs.core.cst$kw$default)){
var temp__5735__auto__ = (function (){var and__4120__auto__ = flag.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1(null);
if(cljs.core.truth_(and__4120__auto__)){
return flag.cljs$core$async$impl$protocols$Handler$commit$arity$1(null);
} else {
return and__4120__auto__;
}
})();
if(cljs.core.truth_(temp__5735__auto__)){
var got = temp__5735__auto__;
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$default.cljs$core$IFn$_invoke$arity$1(opts),cljs.core.cst$kw$default], null));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Completes at most one of several channel operations. Must be called
 * inside a (go ...) block. ports is a vector of channel endpoints,
 * which can be either a channel to take from or a vector of
 *   [channel-to-put-to val-to-put], in any combination. Takes will be
 *   made as if by <!, and puts will be made as if by >!. Unless
 *   the :priority option is true, if more than one port operation is
 *   ready a non-deterministic choice will be made. If no operation is
 *   ready and a :default value is supplied, [default-val :default] will
 *   be returned, otherwise alts! will park until the first operation to
 *   become ready completes. Returns [val port] of the completed
 *   operation, where val is the value taken for takes, and a
 *   boolean (true unless already closed, as per put!) for puts.
 * 
 *   opts are passed as :key val ... Supported options:
 * 
 *   :default val - the value to use if none of the operations are immediately ready
 *   :priority true - (default nil) when true, the operations will be tried in order.
 * 
 *   Note: there is no guarantee that the port exps or val exprs will be
 *   used, nor in what order should they be, so they should not be
 *   depended upon for side effects.
 */
cljs.core.async.alts_BANG_ = (function cljs$core$async$alts_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___22531 = arguments.length;
var i__4731__auto___22532 = (0);
while(true){
if((i__4731__auto___22532 < len__4730__auto___22531)){
args__4736__auto__.push((arguments[i__4731__auto___22532]));

var G__22533 = (i__4731__auto___22532 + (1));
i__4731__auto___22532 = G__22533;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ports,p__22528){
var map__22529 = p__22528;
var map__22529__$1 = (((((!((map__22529 == null))))?(((((map__22529.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__22529.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__22529):map__22529);
var opts = map__22529__$1;
throw (new Error("alts! used not in (go ...) block"));
});

cljs.core.async.alts_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
cljs.core.async.alts_BANG_.cljs$lang$applyTo = (function (seq22526){
var G__22527 = cljs.core.first(seq22526);
var seq22526__$1 = cljs.core.next(seq22526);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__22527,seq22526__$1);
});

/**
 * Puts a val into port if it's possible to do so immediately.
 *   nil values are not allowed. Never blocks. Returns true if offer succeeds.
 */
cljs.core.async.offer_BANG_ = (function cljs$core$async$offer_BANG_(port,val){
var ret = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes a val from port if it's possible to do so immediately.
 *   Never blocks. Returns value if successful, nil otherwise.
 */
cljs.core.async.poll_BANG_ = (function cljs$core$async$poll_BANG_(port){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes elements from the from channel and supplies them to the to
 * channel. By default, the to channel will be closed when the from
 * channel closes, but can be determined by the close?  parameter. Will
 * stop consuming the from channel if the to channel closes
 */
cljs.core.async.pipe = (function cljs$core$async$pipe(var_args){
var G__22535 = arguments.length;
switch (G__22535) {
case 2:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2 = (function (from,to){
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3(from,to,true);
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3 = (function (from,to,close_QMARK_){
var c__8052__auto___22581 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___22581){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___22581){
return (function (state_22559){
var state_val_22560 = (state_22559[(1)]);
if((state_val_22560 === (7))){
var inst_22555 = (state_22559[(2)]);
var state_22559__$1 = state_22559;
var statearr_22561_22582 = state_22559__$1;
(statearr_22561_22582[(2)] = inst_22555);

(statearr_22561_22582[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22560 === (1))){
var state_22559__$1 = state_22559;
var statearr_22562_22583 = state_22559__$1;
(statearr_22562_22583[(2)] = null);

(statearr_22562_22583[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22560 === (4))){
var inst_22538 = (state_22559[(7)]);
var inst_22538__$1 = (state_22559[(2)]);
var inst_22539 = (inst_22538__$1 == null);
var state_22559__$1 = (function (){var statearr_22563 = state_22559;
(statearr_22563[(7)] = inst_22538__$1);

return statearr_22563;
})();
if(cljs.core.truth_(inst_22539)){
var statearr_22564_22584 = state_22559__$1;
(statearr_22564_22584[(1)] = (5));

} else {
var statearr_22565_22585 = state_22559__$1;
(statearr_22565_22585[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22560 === (13))){
var state_22559__$1 = state_22559;
var statearr_22566_22586 = state_22559__$1;
(statearr_22566_22586[(2)] = null);

(statearr_22566_22586[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22560 === (6))){
var inst_22538 = (state_22559[(7)]);
var state_22559__$1 = state_22559;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_22559__$1,(11),to,inst_22538);
} else {
if((state_val_22560 === (3))){
var inst_22557 = (state_22559[(2)]);
var state_22559__$1 = state_22559;
return cljs.core.async.impl.ioc_helpers.return_chan(state_22559__$1,inst_22557);
} else {
if((state_val_22560 === (12))){
var state_22559__$1 = state_22559;
var statearr_22567_22587 = state_22559__$1;
(statearr_22567_22587[(2)] = null);

(statearr_22567_22587[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22560 === (2))){
var state_22559__$1 = state_22559;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_22559__$1,(4),from);
} else {
if((state_val_22560 === (11))){
var inst_22548 = (state_22559[(2)]);
var state_22559__$1 = state_22559;
if(cljs.core.truth_(inst_22548)){
var statearr_22568_22588 = state_22559__$1;
(statearr_22568_22588[(1)] = (12));

} else {
var statearr_22569_22589 = state_22559__$1;
(statearr_22569_22589[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22560 === (9))){
var state_22559__$1 = state_22559;
var statearr_22570_22590 = state_22559__$1;
(statearr_22570_22590[(2)] = null);

(statearr_22570_22590[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22560 === (5))){
var state_22559__$1 = state_22559;
if(cljs.core.truth_(close_QMARK_)){
var statearr_22571_22591 = state_22559__$1;
(statearr_22571_22591[(1)] = (8));

} else {
var statearr_22572_22592 = state_22559__$1;
(statearr_22572_22592[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22560 === (14))){
var inst_22553 = (state_22559[(2)]);
var state_22559__$1 = state_22559;
var statearr_22573_22593 = state_22559__$1;
(statearr_22573_22593[(2)] = inst_22553);

(statearr_22573_22593[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22560 === (10))){
var inst_22545 = (state_22559[(2)]);
var state_22559__$1 = state_22559;
var statearr_22574_22594 = state_22559__$1;
(statearr_22574_22594[(2)] = inst_22545);

(statearr_22574_22594[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22560 === (8))){
var inst_22542 = cljs.core.async.close_BANG_(to);
var state_22559__$1 = state_22559;
var statearr_22575_22595 = state_22559__$1;
(statearr_22575_22595[(2)] = inst_22542);

(statearr_22575_22595[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___22581))
;
return ((function (switch__7945__auto__,c__8052__auto___22581){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_22576 = [null,null,null,null,null,null,null,null];
(statearr_22576[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_22576[(1)] = (1));

return statearr_22576;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_22559){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_22559);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e22577){if((e22577 instanceof Object)){
var ex__7949__auto__ = e22577;
var statearr_22578_22596 = state_22559;
(statearr_22578_22596[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_22559);

return cljs.core.cst$kw$recur;
} else {
throw e22577;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__22597 = state_22559;
state_22559 = G__22597;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_22559){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_22559);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___22581))
})();
var state__8054__auto__ = (function (){var statearr_22579 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_22579[(6)] = c__8052__auto___22581);

return statearr_22579;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___22581))
);


return to;
});

cljs.core.async.pipe.cljs$lang$maxFixedArity = 3;

cljs.core.async.pipeline_STAR_ = (function cljs$core$async$pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,type){

var jobs = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var results = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var process = ((function (jobs,results){
return (function (p__22598){
var vec__22599 = p__22598;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__22599,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__22599,(1),null);
var job = vec__22599;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((1),xf,ex_handler);
var c__8052__auto___22770 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___22770,res,vec__22599,v,p,job,jobs,results){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___22770,res,vec__22599,v,p,job,jobs,results){
return (function (state_22606){
var state_val_22607 = (state_22606[(1)]);
if((state_val_22607 === (1))){
var state_22606__$1 = state_22606;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_22606__$1,(2),res,v);
} else {
if((state_val_22607 === (2))){
var inst_22603 = (state_22606[(2)]);
var inst_22604 = cljs.core.async.close_BANG_(res);
var state_22606__$1 = (function (){var statearr_22608 = state_22606;
(statearr_22608[(7)] = inst_22603);

return statearr_22608;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_22606__$1,inst_22604);
} else {
return null;
}
}
});})(c__8052__auto___22770,res,vec__22599,v,p,job,jobs,results))
;
return ((function (switch__7945__auto__,c__8052__auto___22770,res,vec__22599,v,p,job,jobs,results){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0 = (function (){
var statearr_22609 = [null,null,null,null,null,null,null,null];
(statearr_22609[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__);

(statearr_22609[(1)] = (1));

return statearr_22609;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1 = (function (state_22606){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_22606);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e22610){if((e22610 instanceof Object)){
var ex__7949__auto__ = e22610;
var statearr_22611_22771 = state_22606;
(statearr_22611_22771[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_22606);

return cljs.core.cst$kw$recur;
} else {
throw e22610;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__22772 = state_22606;
state_22606 = G__22772;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = function(state_22606){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1.call(this,state_22606);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___22770,res,vec__22599,v,p,job,jobs,results))
})();
var state__8054__auto__ = (function (){var statearr_22612 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_22612[(6)] = c__8052__auto___22770);

return statearr_22612;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___22770,res,vec__22599,v,p,job,jobs,results))
);


cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results))
;
var async = ((function (jobs,results,process){
return (function (p__22613){
var vec__22614 = p__22613;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__22614,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__22614,(1),null);
var job = vec__22614;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
(xf.cljs$core$IFn$_invoke$arity$2 ? xf.cljs$core$IFn$_invoke$arity$2(v,res) : xf.call(null,v,res));

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results,process))
;
var n__4607__auto___22773 = n;
var __22774 = (0);
while(true){
if((__22774 < n__4607__auto___22773)){
var G__22617_22775 = type;
var G__22617_22776__$1 = (((G__22617_22775 instanceof cljs.core.Keyword))?G__22617_22775.fqn:null);
switch (G__22617_22776__$1) {
case "compute":
var c__8052__auto___22778 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__22774,c__8052__auto___22778,G__22617_22775,G__22617_22776__$1,n__4607__auto___22773,jobs,results,process,async){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (__22774,c__8052__auto___22778,G__22617_22775,G__22617_22776__$1,n__4607__auto___22773,jobs,results,process,async){
return (function (state_22630){
var state_val_22631 = (state_22630[(1)]);
if((state_val_22631 === (1))){
var state_22630__$1 = state_22630;
var statearr_22632_22779 = state_22630__$1;
(statearr_22632_22779[(2)] = null);

(statearr_22632_22779[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22631 === (2))){
var state_22630__$1 = state_22630;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_22630__$1,(4),jobs);
} else {
if((state_val_22631 === (3))){
var inst_22628 = (state_22630[(2)]);
var state_22630__$1 = state_22630;
return cljs.core.async.impl.ioc_helpers.return_chan(state_22630__$1,inst_22628);
} else {
if((state_val_22631 === (4))){
var inst_22620 = (state_22630[(2)]);
var inst_22621 = process(inst_22620);
var state_22630__$1 = state_22630;
if(cljs.core.truth_(inst_22621)){
var statearr_22633_22780 = state_22630__$1;
(statearr_22633_22780[(1)] = (5));

} else {
var statearr_22634_22781 = state_22630__$1;
(statearr_22634_22781[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22631 === (5))){
var state_22630__$1 = state_22630;
var statearr_22635_22782 = state_22630__$1;
(statearr_22635_22782[(2)] = null);

(statearr_22635_22782[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22631 === (6))){
var state_22630__$1 = state_22630;
var statearr_22636_22783 = state_22630__$1;
(statearr_22636_22783[(2)] = null);

(statearr_22636_22783[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22631 === (7))){
var inst_22626 = (state_22630[(2)]);
var state_22630__$1 = state_22630;
var statearr_22637_22784 = state_22630__$1;
(statearr_22637_22784[(2)] = inst_22626);

(statearr_22637_22784[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__22774,c__8052__auto___22778,G__22617_22775,G__22617_22776__$1,n__4607__auto___22773,jobs,results,process,async))
;
return ((function (__22774,switch__7945__auto__,c__8052__auto___22778,G__22617_22775,G__22617_22776__$1,n__4607__auto___22773,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0 = (function (){
var statearr_22638 = [null,null,null,null,null,null,null];
(statearr_22638[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__);

(statearr_22638[(1)] = (1));

return statearr_22638;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1 = (function (state_22630){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_22630);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e22639){if((e22639 instanceof Object)){
var ex__7949__auto__ = e22639;
var statearr_22640_22785 = state_22630;
(statearr_22640_22785[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_22630);

return cljs.core.cst$kw$recur;
} else {
throw e22639;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__22786 = state_22630;
state_22630 = G__22786;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = function(state_22630){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1.call(this,state_22630);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__;
})()
;})(__22774,switch__7945__auto__,c__8052__auto___22778,G__22617_22775,G__22617_22776__$1,n__4607__auto___22773,jobs,results,process,async))
})();
var state__8054__auto__ = (function (){var statearr_22641 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_22641[(6)] = c__8052__auto___22778);

return statearr_22641;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(__22774,c__8052__auto___22778,G__22617_22775,G__22617_22776__$1,n__4607__auto___22773,jobs,results,process,async))
);


break;
case "async":
var c__8052__auto___22787 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__22774,c__8052__auto___22787,G__22617_22775,G__22617_22776__$1,n__4607__auto___22773,jobs,results,process,async){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (__22774,c__8052__auto___22787,G__22617_22775,G__22617_22776__$1,n__4607__auto___22773,jobs,results,process,async){
return (function (state_22654){
var state_val_22655 = (state_22654[(1)]);
if((state_val_22655 === (1))){
var state_22654__$1 = state_22654;
var statearr_22656_22788 = state_22654__$1;
(statearr_22656_22788[(2)] = null);

(statearr_22656_22788[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22655 === (2))){
var state_22654__$1 = state_22654;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_22654__$1,(4),jobs);
} else {
if((state_val_22655 === (3))){
var inst_22652 = (state_22654[(2)]);
var state_22654__$1 = state_22654;
return cljs.core.async.impl.ioc_helpers.return_chan(state_22654__$1,inst_22652);
} else {
if((state_val_22655 === (4))){
var inst_22644 = (state_22654[(2)]);
var inst_22645 = async(inst_22644);
var state_22654__$1 = state_22654;
if(cljs.core.truth_(inst_22645)){
var statearr_22657_22789 = state_22654__$1;
(statearr_22657_22789[(1)] = (5));

} else {
var statearr_22658_22790 = state_22654__$1;
(statearr_22658_22790[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22655 === (5))){
var state_22654__$1 = state_22654;
var statearr_22659_22791 = state_22654__$1;
(statearr_22659_22791[(2)] = null);

(statearr_22659_22791[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22655 === (6))){
var state_22654__$1 = state_22654;
var statearr_22660_22792 = state_22654__$1;
(statearr_22660_22792[(2)] = null);

(statearr_22660_22792[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22655 === (7))){
var inst_22650 = (state_22654[(2)]);
var state_22654__$1 = state_22654;
var statearr_22661_22793 = state_22654__$1;
(statearr_22661_22793[(2)] = inst_22650);

(statearr_22661_22793[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__22774,c__8052__auto___22787,G__22617_22775,G__22617_22776__$1,n__4607__auto___22773,jobs,results,process,async))
;
return ((function (__22774,switch__7945__auto__,c__8052__auto___22787,G__22617_22775,G__22617_22776__$1,n__4607__auto___22773,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0 = (function (){
var statearr_22662 = [null,null,null,null,null,null,null];
(statearr_22662[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__);

(statearr_22662[(1)] = (1));

return statearr_22662;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1 = (function (state_22654){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_22654);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e22663){if((e22663 instanceof Object)){
var ex__7949__auto__ = e22663;
var statearr_22664_22794 = state_22654;
(statearr_22664_22794[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_22654);

return cljs.core.cst$kw$recur;
} else {
throw e22663;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__22795 = state_22654;
state_22654 = G__22795;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = function(state_22654){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1.call(this,state_22654);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__;
})()
;})(__22774,switch__7945__auto__,c__8052__auto___22787,G__22617_22775,G__22617_22776__$1,n__4607__auto___22773,jobs,results,process,async))
})();
var state__8054__auto__ = (function (){var statearr_22665 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_22665[(6)] = c__8052__auto___22787);

return statearr_22665;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(__22774,c__8052__auto___22787,G__22617_22775,G__22617_22776__$1,n__4607__auto___22773,jobs,results,process,async))
);


break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__22617_22776__$1)].join('')));

}

var G__22796 = (__22774 + (1));
__22774 = G__22796;
continue;
} else {
}
break;
}

var c__8052__auto___22797 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___22797,jobs,results,process,async){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___22797,jobs,results,process,async){
return (function (state_22687){
var state_val_22688 = (state_22687[(1)]);
if((state_val_22688 === (7))){
var inst_22683 = (state_22687[(2)]);
var state_22687__$1 = state_22687;
var statearr_22689_22798 = state_22687__$1;
(statearr_22689_22798[(2)] = inst_22683);

(statearr_22689_22798[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22688 === (1))){
var state_22687__$1 = state_22687;
var statearr_22690_22799 = state_22687__$1;
(statearr_22690_22799[(2)] = null);

(statearr_22690_22799[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22688 === (4))){
var inst_22668 = (state_22687[(7)]);
var inst_22668__$1 = (state_22687[(2)]);
var inst_22669 = (inst_22668__$1 == null);
var state_22687__$1 = (function (){var statearr_22691 = state_22687;
(statearr_22691[(7)] = inst_22668__$1);

return statearr_22691;
})();
if(cljs.core.truth_(inst_22669)){
var statearr_22692_22800 = state_22687__$1;
(statearr_22692_22800[(1)] = (5));

} else {
var statearr_22693_22801 = state_22687__$1;
(statearr_22693_22801[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22688 === (6))){
var inst_22668 = (state_22687[(7)]);
var inst_22673 = (state_22687[(8)]);
var inst_22673__$1 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var inst_22674 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_22675 = [inst_22668,inst_22673__$1];
var inst_22676 = (new cljs.core.PersistentVector(null,2,(5),inst_22674,inst_22675,null));
var state_22687__$1 = (function (){var statearr_22694 = state_22687;
(statearr_22694[(8)] = inst_22673__$1);

return statearr_22694;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_22687__$1,(8),jobs,inst_22676);
} else {
if((state_val_22688 === (3))){
var inst_22685 = (state_22687[(2)]);
var state_22687__$1 = state_22687;
return cljs.core.async.impl.ioc_helpers.return_chan(state_22687__$1,inst_22685);
} else {
if((state_val_22688 === (2))){
var state_22687__$1 = state_22687;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_22687__$1,(4),from);
} else {
if((state_val_22688 === (9))){
var inst_22680 = (state_22687[(2)]);
var state_22687__$1 = (function (){var statearr_22695 = state_22687;
(statearr_22695[(9)] = inst_22680);

return statearr_22695;
})();
var statearr_22696_22802 = state_22687__$1;
(statearr_22696_22802[(2)] = null);

(statearr_22696_22802[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22688 === (5))){
var inst_22671 = cljs.core.async.close_BANG_(jobs);
var state_22687__$1 = state_22687;
var statearr_22697_22803 = state_22687__$1;
(statearr_22697_22803[(2)] = inst_22671);

(statearr_22697_22803[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22688 === (8))){
var inst_22673 = (state_22687[(8)]);
var inst_22678 = (state_22687[(2)]);
var state_22687__$1 = (function (){var statearr_22698 = state_22687;
(statearr_22698[(10)] = inst_22678);

return statearr_22698;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_22687__$1,(9),results,inst_22673);
} else {
return null;
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___22797,jobs,results,process,async))
;
return ((function (switch__7945__auto__,c__8052__auto___22797,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0 = (function (){
var statearr_22699 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_22699[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__);

(statearr_22699[(1)] = (1));

return statearr_22699;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1 = (function (state_22687){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_22687);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e22700){if((e22700 instanceof Object)){
var ex__7949__auto__ = e22700;
var statearr_22701_22804 = state_22687;
(statearr_22701_22804[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_22687);

return cljs.core.cst$kw$recur;
} else {
throw e22700;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__22805 = state_22687;
state_22687 = G__22805;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = function(state_22687){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1.call(this,state_22687);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___22797,jobs,results,process,async))
})();
var state__8054__auto__ = (function (){var statearr_22702 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_22702[(6)] = c__8052__auto___22797);

return statearr_22702;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___22797,jobs,results,process,async))
);


var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__,jobs,results,process,async){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__,jobs,results,process,async){
return (function (state_22740){
var state_val_22741 = (state_22740[(1)]);
if((state_val_22741 === (7))){
var inst_22736 = (state_22740[(2)]);
var state_22740__$1 = state_22740;
var statearr_22742_22806 = state_22740__$1;
(statearr_22742_22806[(2)] = inst_22736);

(statearr_22742_22806[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (20))){
var state_22740__$1 = state_22740;
var statearr_22743_22807 = state_22740__$1;
(statearr_22743_22807[(2)] = null);

(statearr_22743_22807[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (1))){
var state_22740__$1 = state_22740;
var statearr_22744_22808 = state_22740__$1;
(statearr_22744_22808[(2)] = null);

(statearr_22744_22808[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (4))){
var inst_22705 = (state_22740[(7)]);
var inst_22705__$1 = (state_22740[(2)]);
var inst_22706 = (inst_22705__$1 == null);
var state_22740__$1 = (function (){var statearr_22745 = state_22740;
(statearr_22745[(7)] = inst_22705__$1);

return statearr_22745;
})();
if(cljs.core.truth_(inst_22706)){
var statearr_22746_22809 = state_22740__$1;
(statearr_22746_22809[(1)] = (5));

} else {
var statearr_22747_22810 = state_22740__$1;
(statearr_22747_22810[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (15))){
var inst_22718 = (state_22740[(8)]);
var state_22740__$1 = state_22740;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_22740__$1,(18),to,inst_22718);
} else {
if((state_val_22741 === (21))){
var inst_22731 = (state_22740[(2)]);
var state_22740__$1 = state_22740;
var statearr_22748_22811 = state_22740__$1;
(statearr_22748_22811[(2)] = inst_22731);

(statearr_22748_22811[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (13))){
var inst_22733 = (state_22740[(2)]);
var state_22740__$1 = (function (){var statearr_22749 = state_22740;
(statearr_22749[(9)] = inst_22733);

return statearr_22749;
})();
var statearr_22750_22812 = state_22740__$1;
(statearr_22750_22812[(2)] = null);

(statearr_22750_22812[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (6))){
var inst_22705 = (state_22740[(7)]);
var state_22740__$1 = state_22740;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_22740__$1,(11),inst_22705);
} else {
if((state_val_22741 === (17))){
var inst_22726 = (state_22740[(2)]);
var state_22740__$1 = state_22740;
if(cljs.core.truth_(inst_22726)){
var statearr_22751_22813 = state_22740__$1;
(statearr_22751_22813[(1)] = (19));

} else {
var statearr_22752_22814 = state_22740__$1;
(statearr_22752_22814[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (3))){
var inst_22738 = (state_22740[(2)]);
var state_22740__$1 = state_22740;
return cljs.core.async.impl.ioc_helpers.return_chan(state_22740__$1,inst_22738);
} else {
if((state_val_22741 === (12))){
var inst_22715 = (state_22740[(10)]);
var state_22740__$1 = state_22740;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_22740__$1,(14),inst_22715);
} else {
if((state_val_22741 === (2))){
var state_22740__$1 = state_22740;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_22740__$1,(4),results);
} else {
if((state_val_22741 === (19))){
var state_22740__$1 = state_22740;
var statearr_22753_22815 = state_22740__$1;
(statearr_22753_22815[(2)] = null);

(statearr_22753_22815[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (11))){
var inst_22715 = (state_22740[(2)]);
var state_22740__$1 = (function (){var statearr_22754 = state_22740;
(statearr_22754[(10)] = inst_22715);

return statearr_22754;
})();
var statearr_22755_22816 = state_22740__$1;
(statearr_22755_22816[(2)] = null);

(statearr_22755_22816[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (9))){
var state_22740__$1 = state_22740;
var statearr_22756_22817 = state_22740__$1;
(statearr_22756_22817[(2)] = null);

(statearr_22756_22817[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (5))){
var state_22740__$1 = state_22740;
if(cljs.core.truth_(close_QMARK_)){
var statearr_22757_22818 = state_22740__$1;
(statearr_22757_22818[(1)] = (8));

} else {
var statearr_22758_22819 = state_22740__$1;
(statearr_22758_22819[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (14))){
var inst_22718 = (state_22740[(8)]);
var inst_22720 = (state_22740[(11)]);
var inst_22718__$1 = (state_22740[(2)]);
var inst_22719 = (inst_22718__$1 == null);
var inst_22720__$1 = cljs.core.not(inst_22719);
var state_22740__$1 = (function (){var statearr_22759 = state_22740;
(statearr_22759[(8)] = inst_22718__$1);

(statearr_22759[(11)] = inst_22720__$1);

return statearr_22759;
})();
if(inst_22720__$1){
var statearr_22760_22820 = state_22740__$1;
(statearr_22760_22820[(1)] = (15));

} else {
var statearr_22761_22821 = state_22740__$1;
(statearr_22761_22821[(1)] = (16));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (16))){
var inst_22720 = (state_22740[(11)]);
var state_22740__$1 = state_22740;
var statearr_22762_22822 = state_22740__$1;
(statearr_22762_22822[(2)] = inst_22720);

(statearr_22762_22822[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (10))){
var inst_22712 = (state_22740[(2)]);
var state_22740__$1 = state_22740;
var statearr_22763_22823 = state_22740__$1;
(statearr_22763_22823[(2)] = inst_22712);

(statearr_22763_22823[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (18))){
var inst_22723 = (state_22740[(2)]);
var state_22740__$1 = state_22740;
var statearr_22764_22824 = state_22740__$1;
(statearr_22764_22824[(2)] = inst_22723);

(statearr_22764_22824[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22741 === (8))){
var inst_22709 = cljs.core.async.close_BANG_(to);
var state_22740__$1 = state_22740;
var statearr_22765_22825 = state_22740__$1;
(statearr_22765_22825[(2)] = inst_22709);

(statearr_22765_22825[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto__,jobs,results,process,async))
;
return ((function (switch__7945__auto__,c__8052__auto__,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0 = (function (){
var statearr_22766 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_22766[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__);

(statearr_22766[(1)] = (1));

return statearr_22766;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1 = (function (state_22740){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_22740);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e22767){if((e22767 instanceof Object)){
var ex__7949__auto__ = e22767;
var statearr_22768_22826 = state_22740;
(statearr_22768_22826[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_22740);

return cljs.core.cst$kw$recur;
} else {
throw e22767;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__22827 = state_22740;
state_22740 = G__22827;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = function(state_22740){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1.call(this,state_22740);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__,jobs,results,process,async))
})();
var state__8054__auto__ = (function (){var statearr_22769 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_22769[(6)] = c__8052__auto__);

return statearr_22769;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__,jobs,results,process,async))
);

return c__8052__auto__;
});
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the async function af, with parallelism n. af
 *   must be a function of two arguments, the first an input value and
 *   the second a channel on which to place the result(s). af must close!
 *   the channel before returning.  The presumption is that af will
 *   return immediately, having launched some asynchronous operation
 *   whose completion/callback will manipulate the result channel. Outputs
 *   will be returned in order relative to  the inputs. By default, the to
 *   channel will be closed when the from channel closes, but can be
 *   determined by the close?  parameter. Will stop consuming the from
 *   channel if the to channel closes.
 */
cljs.core.async.pipeline_async = (function cljs$core$async$pipeline_async(var_args){
var G__22829 = arguments.length;
switch (G__22829) {
case 4:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4 = (function (n,to,af,from){
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5(n,to,af,from,true);
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5 = (function (n,to,af,from,close_QMARK_){
return cljs.core.async.pipeline_STAR_(n,to,af,from,close_QMARK_,null,cljs.core.cst$kw$async);
});

cljs.core.async.pipeline_async.cljs$lang$maxFixedArity = 5;

/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the transducer xf, with parallelism n. Because
 *   it is parallel, the transducer will be applied independently to each
 *   element, not across elements, and may produce zero or more outputs
 *   per input.  Outputs will be returned in order relative to the
 *   inputs. By default, the to channel will be closed when the from
 *   channel closes, but can be determined by the close?  parameter. Will
 *   stop consuming the from channel if the to channel closes.
 * 
 *   Note this is supplied for API compatibility with the Clojure version.
 *   Values of N > 1 will not result in actual concurrency in a
 *   single-threaded runtime.
 */
cljs.core.async.pipeline = (function cljs$core$async$pipeline(var_args){
var G__22832 = arguments.length;
switch (G__22832) {
case 4:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
case 6:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4 = (function (n,to,xf,from){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5(n,to,xf,from,true);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5 = (function (n,to,xf,from,close_QMARK_){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6(n,to,xf,from,close_QMARK_,null);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6 = (function (n,to,xf,from,close_QMARK_,ex_handler){
return cljs.core.async.pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,cljs.core.cst$kw$compute);
});

cljs.core.async.pipeline.cljs$lang$maxFixedArity = 6;

/**
 * Takes a predicate and a source channel and returns a vector of two
 *   channels, the first of which will contain the values for which the
 *   predicate returned true, the second those for which it returned
 *   false.
 * 
 *   The out channels will be unbuffered by default, or two buf-or-ns can
 *   be supplied. The channels will close after the source channel has
 *   closed.
 */
cljs.core.async.split = (function cljs$core$async$split(var_args){
var G__22835 = arguments.length;
switch (G__22835) {
case 2:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4(p,ch,null,null);
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$4 = (function (p,ch,t_buf_or_n,f_buf_or_n){
var tc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(t_buf_or_n);
var fc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(f_buf_or_n);
var c__8052__auto___22884 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___22884,tc,fc){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___22884,tc,fc){
return (function (state_22861){
var state_val_22862 = (state_22861[(1)]);
if((state_val_22862 === (7))){
var inst_22857 = (state_22861[(2)]);
var state_22861__$1 = state_22861;
var statearr_22863_22885 = state_22861__$1;
(statearr_22863_22885[(2)] = inst_22857);

(statearr_22863_22885[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22862 === (1))){
var state_22861__$1 = state_22861;
var statearr_22864_22886 = state_22861__$1;
(statearr_22864_22886[(2)] = null);

(statearr_22864_22886[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22862 === (4))){
var inst_22838 = (state_22861[(7)]);
var inst_22838__$1 = (state_22861[(2)]);
var inst_22839 = (inst_22838__$1 == null);
var state_22861__$1 = (function (){var statearr_22865 = state_22861;
(statearr_22865[(7)] = inst_22838__$1);

return statearr_22865;
})();
if(cljs.core.truth_(inst_22839)){
var statearr_22866_22887 = state_22861__$1;
(statearr_22866_22887[(1)] = (5));

} else {
var statearr_22867_22888 = state_22861__$1;
(statearr_22867_22888[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22862 === (13))){
var state_22861__$1 = state_22861;
var statearr_22868_22889 = state_22861__$1;
(statearr_22868_22889[(2)] = null);

(statearr_22868_22889[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22862 === (6))){
var inst_22838 = (state_22861[(7)]);
var inst_22844 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_22838) : p.call(null,inst_22838));
var state_22861__$1 = state_22861;
if(cljs.core.truth_(inst_22844)){
var statearr_22869_22890 = state_22861__$1;
(statearr_22869_22890[(1)] = (9));

} else {
var statearr_22870_22891 = state_22861__$1;
(statearr_22870_22891[(1)] = (10));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22862 === (3))){
var inst_22859 = (state_22861[(2)]);
var state_22861__$1 = state_22861;
return cljs.core.async.impl.ioc_helpers.return_chan(state_22861__$1,inst_22859);
} else {
if((state_val_22862 === (12))){
var state_22861__$1 = state_22861;
var statearr_22871_22892 = state_22861__$1;
(statearr_22871_22892[(2)] = null);

(statearr_22871_22892[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22862 === (2))){
var state_22861__$1 = state_22861;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_22861__$1,(4),ch);
} else {
if((state_val_22862 === (11))){
var inst_22838 = (state_22861[(7)]);
var inst_22848 = (state_22861[(2)]);
var state_22861__$1 = state_22861;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_22861__$1,(8),inst_22848,inst_22838);
} else {
if((state_val_22862 === (9))){
var state_22861__$1 = state_22861;
var statearr_22872_22893 = state_22861__$1;
(statearr_22872_22893[(2)] = tc);

(statearr_22872_22893[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22862 === (5))){
var inst_22841 = cljs.core.async.close_BANG_(tc);
var inst_22842 = cljs.core.async.close_BANG_(fc);
var state_22861__$1 = (function (){var statearr_22873 = state_22861;
(statearr_22873[(8)] = inst_22841);

return statearr_22873;
})();
var statearr_22874_22894 = state_22861__$1;
(statearr_22874_22894[(2)] = inst_22842);

(statearr_22874_22894[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22862 === (14))){
var inst_22855 = (state_22861[(2)]);
var state_22861__$1 = state_22861;
var statearr_22875_22895 = state_22861__$1;
(statearr_22875_22895[(2)] = inst_22855);

(statearr_22875_22895[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22862 === (10))){
var state_22861__$1 = state_22861;
var statearr_22876_22896 = state_22861__$1;
(statearr_22876_22896[(2)] = fc);

(statearr_22876_22896[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22862 === (8))){
var inst_22850 = (state_22861[(2)]);
var state_22861__$1 = state_22861;
if(cljs.core.truth_(inst_22850)){
var statearr_22877_22897 = state_22861__$1;
(statearr_22877_22897[(1)] = (12));

} else {
var statearr_22878_22898 = state_22861__$1;
(statearr_22878_22898[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___22884,tc,fc))
;
return ((function (switch__7945__auto__,c__8052__auto___22884,tc,fc){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_22879 = [null,null,null,null,null,null,null,null,null];
(statearr_22879[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_22879[(1)] = (1));

return statearr_22879;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_22861){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_22861);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e22880){if((e22880 instanceof Object)){
var ex__7949__auto__ = e22880;
var statearr_22881_22899 = state_22861;
(statearr_22881_22899[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_22861);

return cljs.core.cst$kw$recur;
} else {
throw e22880;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__22900 = state_22861;
state_22861 = G__22900;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_22861){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_22861);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___22884,tc,fc))
})();
var state__8054__auto__ = (function (){var statearr_22882 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_22882[(6)] = c__8052__auto___22884);

return statearr_22882;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___22884,tc,fc))
);


return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [tc,fc], null);
});

cljs.core.async.split.cljs$lang$maxFixedArity = 4;

/**
 * f should be a function of 2 arguments. Returns a channel containing
 *   the single result of applying f to init and the first item from the
 *   channel, then applying f to that result and the 2nd item, etc. If
 *   the channel closes without yielding items, returns init and f is not
 *   called. ch must close before reduce produces a result.
 */
cljs.core.async.reduce = (function cljs$core$async$reduce(f,init,ch){
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__){
return (function (state_22921){
var state_val_22922 = (state_22921[(1)]);
if((state_val_22922 === (7))){
var inst_22917 = (state_22921[(2)]);
var state_22921__$1 = state_22921;
var statearr_22923_22941 = state_22921__$1;
(statearr_22923_22941[(2)] = inst_22917);

(statearr_22923_22941[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22922 === (1))){
var inst_22901 = init;
var state_22921__$1 = (function (){var statearr_22924 = state_22921;
(statearr_22924[(7)] = inst_22901);

return statearr_22924;
})();
var statearr_22925_22942 = state_22921__$1;
(statearr_22925_22942[(2)] = null);

(statearr_22925_22942[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22922 === (4))){
var inst_22904 = (state_22921[(8)]);
var inst_22904__$1 = (state_22921[(2)]);
var inst_22905 = (inst_22904__$1 == null);
var state_22921__$1 = (function (){var statearr_22926 = state_22921;
(statearr_22926[(8)] = inst_22904__$1);

return statearr_22926;
})();
if(cljs.core.truth_(inst_22905)){
var statearr_22927_22943 = state_22921__$1;
(statearr_22927_22943[(1)] = (5));

} else {
var statearr_22928_22944 = state_22921__$1;
(statearr_22928_22944[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22922 === (6))){
var inst_22901 = (state_22921[(7)]);
var inst_22904 = (state_22921[(8)]);
var inst_22908 = (state_22921[(9)]);
var inst_22908__$1 = (f.cljs$core$IFn$_invoke$arity$2 ? f.cljs$core$IFn$_invoke$arity$2(inst_22901,inst_22904) : f.call(null,inst_22901,inst_22904));
var inst_22909 = cljs.core.reduced_QMARK_(inst_22908__$1);
var state_22921__$1 = (function (){var statearr_22929 = state_22921;
(statearr_22929[(9)] = inst_22908__$1);

return statearr_22929;
})();
if(inst_22909){
var statearr_22930_22945 = state_22921__$1;
(statearr_22930_22945[(1)] = (8));

} else {
var statearr_22931_22946 = state_22921__$1;
(statearr_22931_22946[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22922 === (3))){
var inst_22919 = (state_22921[(2)]);
var state_22921__$1 = state_22921;
return cljs.core.async.impl.ioc_helpers.return_chan(state_22921__$1,inst_22919);
} else {
if((state_val_22922 === (2))){
var state_22921__$1 = state_22921;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_22921__$1,(4),ch);
} else {
if((state_val_22922 === (9))){
var inst_22908 = (state_22921[(9)]);
var inst_22901 = inst_22908;
var state_22921__$1 = (function (){var statearr_22932 = state_22921;
(statearr_22932[(7)] = inst_22901);

return statearr_22932;
})();
var statearr_22933_22947 = state_22921__$1;
(statearr_22933_22947[(2)] = null);

(statearr_22933_22947[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22922 === (5))){
var inst_22901 = (state_22921[(7)]);
var state_22921__$1 = state_22921;
var statearr_22934_22948 = state_22921__$1;
(statearr_22934_22948[(2)] = inst_22901);

(statearr_22934_22948[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22922 === (10))){
var inst_22915 = (state_22921[(2)]);
var state_22921__$1 = state_22921;
var statearr_22935_22949 = state_22921__$1;
(statearr_22935_22949[(2)] = inst_22915);

(statearr_22935_22949[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22922 === (8))){
var inst_22908 = (state_22921[(9)]);
var inst_22911 = cljs.core.deref(inst_22908);
var state_22921__$1 = state_22921;
var statearr_22936_22950 = state_22921__$1;
(statearr_22936_22950[(2)] = inst_22911);

(statearr_22936_22950[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto__))
;
return ((function (switch__7945__auto__,c__8052__auto__){
return (function() {
var cljs$core$async$reduce_$_state_machine__7946__auto__ = null;
var cljs$core$async$reduce_$_state_machine__7946__auto____0 = (function (){
var statearr_22937 = [null,null,null,null,null,null,null,null,null,null];
(statearr_22937[(0)] = cljs$core$async$reduce_$_state_machine__7946__auto__);

(statearr_22937[(1)] = (1));

return statearr_22937;
});
var cljs$core$async$reduce_$_state_machine__7946__auto____1 = (function (state_22921){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_22921);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e22938){if((e22938 instanceof Object)){
var ex__7949__auto__ = e22938;
var statearr_22939_22951 = state_22921;
(statearr_22939_22951[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_22921);

return cljs.core.cst$kw$recur;
} else {
throw e22938;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__22952 = state_22921;
state_22921 = G__22952;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$reduce_$_state_machine__7946__auto__ = function(state_22921){
switch(arguments.length){
case 0:
return cljs$core$async$reduce_$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$reduce_$_state_machine__7946__auto____1.call(this,state_22921);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$reduce_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$reduce_$_state_machine__7946__auto____0;
cljs$core$async$reduce_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$reduce_$_state_machine__7946__auto____1;
return cljs$core$async$reduce_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_22940 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_22940[(6)] = c__8052__auto__);

return statearr_22940;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__))
);

return c__8052__auto__;
});
/**
 * async/reduces a channel with a transformation (xform f).
 *   Returns a channel containing the result.  ch must close before
 *   transduce produces a result.
 */
cljs.core.async.transduce = (function cljs$core$async$transduce(xform,f,init,ch){
var f__$1 = (xform.cljs$core$IFn$_invoke$arity$1 ? xform.cljs$core$IFn$_invoke$arity$1(f) : xform.call(null,f));
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__,f__$1){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__,f__$1){
return (function (state_22958){
var state_val_22959 = (state_22958[(1)]);
if((state_val_22959 === (1))){
var inst_22953 = cljs.core.async.reduce(f__$1,init,ch);
var state_22958__$1 = state_22958;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_22958__$1,(2),inst_22953);
} else {
if((state_val_22959 === (2))){
var inst_22955 = (state_22958[(2)]);
var inst_22956 = (f__$1.cljs$core$IFn$_invoke$arity$1 ? f__$1.cljs$core$IFn$_invoke$arity$1(inst_22955) : f__$1.call(null,inst_22955));
var state_22958__$1 = state_22958;
return cljs.core.async.impl.ioc_helpers.return_chan(state_22958__$1,inst_22956);
} else {
return null;
}
}
});})(c__8052__auto__,f__$1))
;
return ((function (switch__7945__auto__,c__8052__auto__,f__$1){
return (function() {
var cljs$core$async$transduce_$_state_machine__7946__auto__ = null;
var cljs$core$async$transduce_$_state_machine__7946__auto____0 = (function (){
var statearr_22960 = [null,null,null,null,null,null,null];
(statearr_22960[(0)] = cljs$core$async$transduce_$_state_machine__7946__auto__);

(statearr_22960[(1)] = (1));

return statearr_22960;
});
var cljs$core$async$transduce_$_state_machine__7946__auto____1 = (function (state_22958){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_22958);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e22961){if((e22961 instanceof Object)){
var ex__7949__auto__ = e22961;
var statearr_22962_22964 = state_22958;
(statearr_22962_22964[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_22958);

return cljs.core.cst$kw$recur;
} else {
throw e22961;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__22965 = state_22958;
state_22958 = G__22965;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$transduce_$_state_machine__7946__auto__ = function(state_22958){
switch(arguments.length){
case 0:
return cljs$core$async$transduce_$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$transduce_$_state_machine__7946__auto____1.call(this,state_22958);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$transduce_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$transduce_$_state_machine__7946__auto____0;
cljs$core$async$transduce_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$transduce_$_state_machine__7946__auto____1;
return cljs$core$async$transduce_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__,f__$1))
})();
var state__8054__auto__ = (function (){var statearr_22963 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_22963[(6)] = c__8052__auto__);

return statearr_22963;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__,f__$1))
);

return c__8052__auto__;
});
/**
 * Puts the contents of coll into the supplied channel.
 * 
 *   By default the channel will be closed after the items are copied,
 *   but can be determined by the close? parameter.
 * 
 *   Returns a channel which will close after the items are copied.
 */
cljs.core.async.onto_chan = (function cljs$core$async$onto_chan(var_args){
var G__22967 = arguments.length;
switch (G__22967) {
case 2:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2 = (function (ch,coll){
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3(ch,coll,true);
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3 = (function (ch,coll,close_QMARK_){
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__){
return (function (state_22992){
var state_val_22993 = (state_22992[(1)]);
if((state_val_22993 === (7))){
var inst_22974 = (state_22992[(2)]);
var state_22992__$1 = state_22992;
var statearr_22994_23015 = state_22992__$1;
(statearr_22994_23015[(2)] = inst_22974);

(statearr_22994_23015[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22993 === (1))){
var inst_22968 = cljs.core.seq(coll);
var inst_22969 = inst_22968;
var state_22992__$1 = (function (){var statearr_22995 = state_22992;
(statearr_22995[(7)] = inst_22969);

return statearr_22995;
})();
var statearr_22996_23016 = state_22992__$1;
(statearr_22996_23016[(2)] = null);

(statearr_22996_23016[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22993 === (4))){
var inst_22969 = (state_22992[(7)]);
var inst_22972 = cljs.core.first(inst_22969);
var state_22992__$1 = state_22992;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_22992__$1,(7),ch,inst_22972);
} else {
if((state_val_22993 === (13))){
var inst_22986 = (state_22992[(2)]);
var state_22992__$1 = state_22992;
var statearr_22997_23017 = state_22992__$1;
(statearr_22997_23017[(2)] = inst_22986);

(statearr_22997_23017[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22993 === (6))){
var inst_22977 = (state_22992[(2)]);
var state_22992__$1 = state_22992;
if(cljs.core.truth_(inst_22977)){
var statearr_22998_23018 = state_22992__$1;
(statearr_22998_23018[(1)] = (8));

} else {
var statearr_22999_23019 = state_22992__$1;
(statearr_22999_23019[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22993 === (3))){
var inst_22990 = (state_22992[(2)]);
var state_22992__$1 = state_22992;
return cljs.core.async.impl.ioc_helpers.return_chan(state_22992__$1,inst_22990);
} else {
if((state_val_22993 === (12))){
var state_22992__$1 = state_22992;
var statearr_23000_23020 = state_22992__$1;
(statearr_23000_23020[(2)] = null);

(statearr_23000_23020[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22993 === (2))){
var inst_22969 = (state_22992[(7)]);
var state_22992__$1 = state_22992;
if(cljs.core.truth_(inst_22969)){
var statearr_23001_23021 = state_22992__$1;
(statearr_23001_23021[(1)] = (4));

} else {
var statearr_23002_23022 = state_22992__$1;
(statearr_23002_23022[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22993 === (11))){
var inst_22983 = cljs.core.async.close_BANG_(ch);
var state_22992__$1 = state_22992;
var statearr_23003_23023 = state_22992__$1;
(statearr_23003_23023[(2)] = inst_22983);

(statearr_23003_23023[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22993 === (9))){
var state_22992__$1 = state_22992;
if(cljs.core.truth_(close_QMARK_)){
var statearr_23004_23024 = state_22992__$1;
(statearr_23004_23024[(1)] = (11));

} else {
var statearr_23005_23025 = state_22992__$1;
(statearr_23005_23025[(1)] = (12));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_22993 === (5))){
var inst_22969 = (state_22992[(7)]);
var state_22992__$1 = state_22992;
var statearr_23006_23026 = state_22992__$1;
(statearr_23006_23026[(2)] = inst_22969);

(statearr_23006_23026[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22993 === (10))){
var inst_22988 = (state_22992[(2)]);
var state_22992__$1 = state_22992;
var statearr_23007_23027 = state_22992__$1;
(statearr_23007_23027[(2)] = inst_22988);

(statearr_23007_23027[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_22993 === (8))){
var inst_22969 = (state_22992[(7)]);
var inst_22979 = cljs.core.next(inst_22969);
var inst_22969__$1 = inst_22979;
var state_22992__$1 = (function (){var statearr_23008 = state_22992;
(statearr_23008[(7)] = inst_22969__$1);

return statearr_23008;
})();
var statearr_23009_23028 = state_22992__$1;
(statearr_23009_23028[(2)] = null);

(statearr_23009_23028[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto__))
;
return ((function (switch__7945__auto__,c__8052__auto__){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_23010 = [null,null,null,null,null,null,null,null];
(statearr_23010[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_23010[(1)] = (1));

return statearr_23010;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_22992){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_22992);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e23011){if((e23011 instanceof Object)){
var ex__7949__auto__ = e23011;
var statearr_23012_23029 = state_22992;
(statearr_23012_23029[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_22992);

return cljs.core.cst$kw$recur;
} else {
throw e23011;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__23030 = state_22992;
state_22992 = G__23030;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_22992){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_22992);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_23013 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_23013[(6)] = c__8052__auto__);

return statearr_23013;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__))
);

return c__8052__auto__;
});

cljs.core.async.onto_chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates and returns a channel which contains the contents of coll,
 *   closing when exhausted.
 */
cljs.core.async.to_chan = (function cljs$core$async$to_chan(coll){
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(cljs.core.bounded_count((100),coll));
cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2(ch,coll);

return ch;
});

/**
 * @interface
 */
cljs.core.async.Mux = function(){};

cljs.core.async.muxch_STAR_ = (function cljs$core$async$muxch_STAR_(_){
if((((!((_ == null)))) && ((!((_.cljs$core$async$Mux$muxch_STAR_$arity$1 == null)))))){
return _.cljs$core$async$Mux$muxch_STAR_$arity$1(_);
} else {
var x__4433__auto__ = (((_ == null))?null:_);
var m__4434__auto__ = (cljs.core.async.muxch_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(_) : m__4434__auto__.call(null,_));
} else {
var m__4431__auto__ = (cljs.core.async.muxch_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(_) : m__4431__auto__.call(null,_));
} else {
throw cljs.core.missing_protocol("Mux.muxch*",_);
}
}
}
});


/**
 * @interface
 */
cljs.core.async.Mult = function(){};

cljs.core.async.tap_STAR_ = (function cljs$core$async$tap_STAR_(m,ch,close_QMARK_){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$tap_STAR_$arity$3 == null)))))){
return m.cljs$core$async$Mult$tap_STAR_$arity$3(m,ch,close_QMARK_);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.tap_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4434__auto__.call(null,m,ch,close_QMARK_));
} else {
var m__4431__auto__ = (cljs.core.async.tap_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4431__auto__.call(null,m,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Mult.tap*",m);
}
}
}
});

cljs.core.async.untap_STAR_ = (function cljs$core$async$untap_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mult$untap_STAR_$arity$2(m,ch);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.untap_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4434__auto__.call(null,m,ch));
} else {
var m__4431__auto__ = (cljs.core.async.untap_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4431__auto__.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mult.untap*",m);
}
}
}
});

cljs.core.async.untap_all_STAR_ = (function cljs$core$async$untap_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mult$untap_all_STAR_$arity$1(m);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.untap_all_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4434__auto__.call(null,m));
} else {
var m__4431__auto__ = (cljs.core.async.untap_all_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4431__auto__.call(null,m));
} else {
throw cljs.core.missing_protocol("Mult.untap-all*",m);
}
}
}
});

/**
 * Creates and returns a mult(iple) of the supplied channel. Channels
 *   containing copies of the channel can be created with 'tap', and
 *   detached with 'untap'.
 * 
 *   Each item is distributed to all taps in parallel and synchronously,
 *   i.e. each tap must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow taps from holding up the mult.
 * 
 *   Items received when there are no taps get dropped.
 * 
 *   If a tap puts to a closed channel, it will be removed from the mult.
 */
cljs.core.async.mult = (function cljs$core$async$mult(ch){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async23031 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Mult}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async23031 = (function (ch,cs,meta23032){
this.ch = ch;
this.cs = cs;
this.meta23032 = meta23032;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async23031.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs){
return (function (_23033,meta23032__$1){
var self__ = this;
var _23033__$1 = this;
return (new cljs.core.async.t_cljs$core$async23031(self__.ch,self__.cs,meta23032__$1));
});})(cs))
;

cljs.core.async.t_cljs$core$async23031.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs){
return (function (_23033){
var self__ = this;
var _23033__$1 = this;
return self__.meta23032;
});})(cs))
;

cljs.core.async.t_cljs$core$async23031.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23031.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(cs))
;

cljs.core.async.t_cljs$core$async23031.prototype.cljs$core$async$Mult$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23031.prototype.cljs$core$async$Mult$tap_STAR_$arity$3 = ((function (cs){
return (function (_,ch__$1,close_QMARK_){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch__$1,close_QMARK_);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async23031.prototype.cljs$core$async$Mult$untap_STAR_$arity$2 = ((function (cs){
return (function (_,ch__$1){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch__$1);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async23031.prototype.cljs$core$async$Mult$untap_all_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async23031.getBasis = ((function (cs){
return (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$cs,cljs.core.cst$sym$meta23032], null);
});})(cs))
;

cljs.core.async.t_cljs$core$async23031.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async23031.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async23031";

cljs.core.async.t_cljs$core$async23031.cljs$lang$ctorPrWriter = ((function (cs){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async23031");
});})(cs))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async23031.
 */
cljs.core.async.__GT_t_cljs$core$async23031 = ((function (cs){
return (function cljs$core$async$mult_$___GT_t_cljs$core$async23031(ch__$1,cs__$1,meta23032){
return (new cljs.core.async.t_cljs$core$async23031(ch__$1,cs__$1,meta23032));
});})(cs))
;

}

return (new cljs.core.async.t_cljs$core$async23031(ch,cs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = ((function (cs,m,dchan,dctr){
return (function (_){
if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,true);
} else {
return null;
}
});})(cs,m,dchan,dctr))
;
var c__8052__auto___23253 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___23253,cs,m,dchan,dctr,done){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___23253,cs,m,dchan,dctr,done){
return (function (state_23168){
var state_val_23169 = (state_23168[(1)]);
if((state_val_23169 === (7))){
var inst_23164 = (state_23168[(2)]);
var state_23168__$1 = state_23168;
var statearr_23170_23254 = state_23168__$1;
(statearr_23170_23254[(2)] = inst_23164);

(statearr_23170_23254[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (20))){
var inst_23067 = (state_23168[(7)]);
var inst_23079 = cljs.core.first(inst_23067);
var inst_23080 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_23079,(0),null);
var inst_23081 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_23079,(1),null);
var state_23168__$1 = (function (){var statearr_23171 = state_23168;
(statearr_23171[(8)] = inst_23080);

return statearr_23171;
})();
if(cljs.core.truth_(inst_23081)){
var statearr_23172_23255 = state_23168__$1;
(statearr_23172_23255[(1)] = (22));

} else {
var statearr_23173_23256 = state_23168__$1;
(statearr_23173_23256[(1)] = (23));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (27))){
var inst_23111 = (state_23168[(9)]);
var inst_23109 = (state_23168[(10)]);
var inst_23036 = (state_23168[(11)]);
var inst_23116 = (state_23168[(12)]);
var inst_23116__$1 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_23109,inst_23111);
var inst_23117 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_23116__$1,inst_23036,done);
var state_23168__$1 = (function (){var statearr_23174 = state_23168;
(statearr_23174[(12)] = inst_23116__$1);

return statearr_23174;
})();
if(cljs.core.truth_(inst_23117)){
var statearr_23175_23257 = state_23168__$1;
(statearr_23175_23257[(1)] = (30));

} else {
var statearr_23176_23258 = state_23168__$1;
(statearr_23176_23258[(1)] = (31));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (1))){
var state_23168__$1 = state_23168;
var statearr_23177_23259 = state_23168__$1;
(statearr_23177_23259[(2)] = null);

(statearr_23177_23259[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (24))){
var inst_23067 = (state_23168[(7)]);
var inst_23086 = (state_23168[(2)]);
var inst_23087 = cljs.core.next(inst_23067);
var inst_23045 = inst_23087;
var inst_23046 = null;
var inst_23047 = (0);
var inst_23048 = (0);
var state_23168__$1 = (function (){var statearr_23178 = state_23168;
(statearr_23178[(13)] = inst_23086);

(statearr_23178[(14)] = inst_23045);

(statearr_23178[(15)] = inst_23047);

(statearr_23178[(16)] = inst_23048);

(statearr_23178[(17)] = inst_23046);

return statearr_23178;
})();
var statearr_23179_23260 = state_23168__$1;
(statearr_23179_23260[(2)] = null);

(statearr_23179_23260[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (39))){
var state_23168__$1 = state_23168;
var statearr_23183_23261 = state_23168__$1;
(statearr_23183_23261[(2)] = null);

(statearr_23183_23261[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (4))){
var inst_23036 = (state_23168[(11)]);
var inst_23036__$1 = (state_23168[(2)]);
var inst_23037 = (inst_23036__$1 == null);
var state_23168__$1 = (function (){var statearr_23184 = state_23168;
(statearr_23184[(11)] = inst_23036__$1);

return statearr_23184;
})();
if(cljs.core.truth_(inst_23037)){
var statearr_23185_23262 = state_23168__$1;
(statearr_23185_23262[(1)] = (5));

} else {
var statearr_23186_23263 = state_23168__$1;
(statearr_23186_23263[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (15))){
var inst_23045 = (state_23168[(14)]);
var inst_23047 = (state_23168[(15)]);
var inst_23048 = (state_23168[(16)]);
var inst_23046 = (state_23168[(17)]);
var inst_23063 = (state_23168[(2)]);
var inst_23064 = (inst_23048 + (1));
var tmp23180 = inst_23045;
var tmp23181 = inst_23047;
var tmp23182 = inst_23046;
var inst_23045__$1 = tmp23180;
var inst_23046__$1 = tmp23182;
var inst_23047__$1 = tmp23181;
var inst_23048__$1 = inst_23064;
var state_23168__$1 = (function (){var statearr_23187 = state_23168;
(statearr_23187[(14)] = inst_23045__$1);

(statearr_23187[(15)] = inst_23047__$1);

(statearr_23187[(18)] = inst_23063);

(statearr_23187[(16)] = inst_23048__$1);

(statearr_23187[(17)] = inst_23046__$1);

return statearr_23187;
})();
var statearr_23188_23264 = state_23168__$1;
(statearr_23188_23264[(2)] = null);

(statearr_23188_23264[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (21))){
var inst_23090 = (state_23168[(2)]);
var state_23168__$1 = state_23168;
var statearr_23192_23265 = state_23168__$1;
(statearr_23192_23265[(2)] = inst_23090);

(statearr_23192_23265[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (31))){
var inst_23116 = (state_23168[(12)]);
var inst_23120 = done(null);
var inst_23121 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_23116);
var state_23168__$1 = (function (){var statearr_23193 = state_23168;
(statearr_23193[(19)] = inst_23120);

return statearr_23193;
})();
var statearr_23194_23266 = state_23168__$1;
(statearr_23194_23266[(2)] = inst_23121);

(statearr_23194_23266[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (32))){
var inst_23110 = (state_23168[(20)]);
var inst_23108 = (state_23168[(21)]);
var inst_23111 = (state_23168[(9)]);
var inst_23109 = (state_23168[(10)]);
var inst_23123 = (state_23168[(2)]);
var inst_23124 = (inst_23111 + (1));
var tmp23189 = inst_23110;
var tmp23190 = inst_23108;
var tmp23191 = inst_23109;
var inst_23108__$1 = tmp23190;
var inst_23109__$1 = tmp23191;
var inst_23110__$1 = tmp23189;
var inst_23111__$1 = inst_23124;
var state_23168__$1 = (function (){var statearr_23195 = state_23168;
(statearr_23195[(20)] = inst_23110__$1);

(statearr_23195[(21)] = inst_23108__$1);

(statearr_23195[(9)] = inst_23111__$1);

(statearr_23195[(10)] = inst_23109__$1);

(statearr_23195[(22)] = inst_23123);

return statearr_23195;
})();
var statearr_23196_23267 = state_23168__$1;
(statearr_23196_23267[(2)] = null);

(statearr_23196_23267[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (40))){
var inst_23136 = (state_23168[(23)]);
var inst_23140 = done(null);
var inst_23141 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_23136);
var state_23168__$1 = (function (){var statearr_23197 = state_23168;
(statearr_23197[(24)] = inst_23140);

return statearr_23197;
})();
var statearr_23198_23268 = state_23168__$1;
(statearr_23198_23268[(2)] = inst_23141);

(statearr_23198_23268[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (33))){
var inst_23127 = (state_23168[(25)]);
var inst_23129 = cljs.core.chunked_seq_QMARK_(inst_23127);
var state_23168__$1 = state_23168;
if(inst_23129){
var statearr_23199_23269 = state_23168__$1;
(statearr_23199_23269[(1)] = (36));

} else {
var statearr_23200_23270 = state_23168__$1;
(statearr_23200_23270[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (13))){
var inst_23057 = (state_23168[(26)]);
var inst_23060 = cljs.core.async.close_BANG_(inst_23057);
var state_23168__$1 = state_23168;
var statearr_23201_23271 = state_23168__$1;
(statearr_23201_23271[(2)] = inst_23060);

(statearr_23201_23271[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (22))){
var inst_23080 = (state_23168[(8)]);
var inst_23083 = cljs.core.async.close_BANG_(inst_23080);
var state_23168__$1 = state_23168;
var statearr_23202_23272 = state_23168__$1;
(statearr_23202_23272[(2)] = inst_23083);

(statearr_23202_23272[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (36))){
var inst_23127 = (state_23168[(25)]);
var inst_23131 = cljs.core.chunk_first(inst_23127);
var inst_23132 = cljs.core.chunk_rest(inst_23127);
var inst_23133 = cljs.core.count(inst_23131);
var inst_23108 = inst_23132;
var inst_23109 = inst_23131;
var inst_23110 = inst_23133;
var inst_23111 = (0);
var state_23168__$1 = (function (){var statearr_23203 = state_23168;
(statearr_23203[(20)] = inst_23110);

(statearr_23203[(21)] = inst_23108);

(statearr_23203[(9)] = inst_23111);

(statearr_23203[(10)] = inst_23109);

return statearr_23203;
})();
var statearr_23204_23273 = state_23168__$1;
(statearr_23204_23273[(2)] = null);

(statearr_23204_23273[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (41))){
var inst_23127 = (state_23168[(25)]);
var inst_23143 = (state_23168[(2)]);
var inst_23144 = cljs.core.next(inst_23127);
var inst_23108 = inst_23144;
var inst_23109 = null;
var inst_23110 = (0);
var inst_23111 = (0);
var state_23168__$1 = (function (){var statearr_23205 = state_23168;
(statearr_23205[(20)] = inst_23110);

(statearr_23205[(21)] = inst_23108);

(statearr_23205[(9)] = inst_23111);

(statearr_23205[(10)] = inst_23109);

(statearr_23205[(27)] = inst_23143);

return statearr_23205;
})();
var statearr_23206_23274 = state_23168__$1;
(statearr_23206_23274[(2)] = null);

(statearr_23206_23274[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (43))){
var state_23168__$1 = state_23168;
var statearr_23207_23275 = state_23168__$1;
(statearr_23207_23275[(2)] = null);

(statearr_23207_23275[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (29))){
var inst_23152 = (state_23168[(2)]);
var state_23168__$1 = state_23168;
var statearr_23208_23276 = state_23168__$1;
(statearr_23208_23276[(2)] = inst_23152);

(statearr_23208_23276[(1)] = (26));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (44))){
var inst_23161 = (state_23168[(2)]);
var state_23168__$1 = (function (){var statearr_23209 = state_23168;
(statearr_23209[(28)] = inst_23161);

return statearr_23209;
})();
var statearr_23210_23277 = state_23168__$1;
(statearr_23210_23277[(2)] = null);

(statearr_23210_23277[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (6))){
var inst_23100 = (state_23168[(29)]);
var inst_23099 = cljs.core.deref(cs);
var inst_23100__$1 = cljs.core.keys(inst_23099);
var inst_23101 = cljs.core.count(inst_23100__$1);
var inst_23102 = cljs.core.reset_BANG_(dctr,inst_23101);
var inst_23107 = cljs.core.seq(inst_23100__$1);
var inst_23108 = inst_23107;
var inst_23109 = null;
var inst_23110 = (0);
var inst_23111 = (0);
var state_23168__$1 = (function (){var statearr_23211 = state_23168;
(statearr_23211[(20)] = inst_23110);

(statearr_23211[(30)] = inst_23102);

(statearr_23211[(21)] = inst_23108);

(statearr_23211[(9)] = inst_23111);

(statearr_23211[(10)] = inst_23109);

(statearr_23211[(29)] = inst_23100__$1);

return statearr_23211;
})();
var statearr_23212_23278 = state_23168__$1;
(statearr_23212_23278[(2)] = null);

(statearr_23212_23278[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (28))){
var inst_23108 = (state_23168[(21)]);
var inst_23127 = (state_23168[(25)]);
var inst_23127__$1 = cljs.core.seq(inst_23108);
var state_23168__$1 = (function (){var statearr_23213 = state_23168;
(statearr_23213[(25)] = inst_23127__$1);

return statearr_23213;
})();
if(inst_23127__$1){
var statearr_23214_23279 = state_23168__$1;
(statearr_23214_23279[(1)] = (33));

} else {
var statearr_23215_23280 = state_23168__$1;
(statearr_23215_23280[(1)] = (34));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (25))){
var inst_23110 = (state_23168[(20)]);
var inst_23111 = (state_23168[(9)]);
var inst_23113 = (inst_23111 < inst_23110);
var inst_23114 = inst_23113;
var state_23168__$1 = state_23168;
if(cljs.core.truth_(inst_23114)){
var statearr_23216_23281 = state_23168__$1;
(statearr_23216_23281[(1)] = (27));

} else {
var statearr_23217_23282 = state_23168__$1;
(statearr_23217_23282[(1)] = (28));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (34))){
var state_23168__$1 = state_23168;
var statearr_23218_23283 = state_23168__$1;
(statearr_23218_23283[(2)] = null);

(statearr_23218_23283[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (17))){
var state_23168__$1 = state_23168;
var statearr_23219_23284 = state_23168__$1;
(statearr_23219_23284[(2)] = null);

(statearr_23219_23284[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (3))){
var inst_23166 = (state_23168[(2)]);
var state_23168__$1 = state_23168;
return cljs.core.async.impl.ioc_helpers.return_chan(state_23168__$1,inst_23166);
} else {
if((state_val_23169 === (12))){
var inst_23095 = (state_23168[(2)]);
var state_23168__$1 = state_23168;
var statearr_23220_23285 = state_23168__$1;
(statearr_23220_23285[(2)] = inst_23095);

(statearr_23220_23285[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (2))){
var state_23168__$1 = state_23168;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_23168__$1,(4),ch);
} else {
if((state_val_23169 === (23))){
var state_23168__$1 = state_23168;
var statearr_23221_23286 = state_23168__$1;
(statearr_23221_23286[(2)] = null);

(statearr_23221_23286[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (35))){
var inst_23150 = (state_23168[(2)]);
var state_23168__$1 = state_23168;
var statearr_23222_23287 = state_23168__$1;
(statearr_23222_23287[(2)] = inst_23150);

(statearr_23222_23287[(1)] = (29));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (19))){
var inst_23067 = (state_23168[(7)]);
var inst_23071 = cljs.core.chunk_first(inst_23067);
var inst_23072 = cljs.core.chunk_rest(inst_23067);
var inst_23073 = cljs.core.count(inst_23071);
var inst_23045 = inst_23072;
var inst_23046 = inst_23071;
var inst_23047 = inst_23073;
var inst_23048 = (0);
var state_23168__$1 = (function (){var statearr_23223 = state_23168;
(statearr_23223[(14)] = inst_23045);

(statearr_23223[(15)] = inst_23047);

(statearr_23223[(16)] = inst_23048);

(statearr_23223[(17)] = inst_23046);

return statearr_23223;
})();
var statearr_23224_23288 = state_23168__$1;
(statearr_23224_23288[(2)] = null);

(statearr_23224_23288[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (11))){
var inst_23045 = (state_23168[(14)]);
var inst_23067 = (state_23168[(7)]);
var inst_23067__$1 = cljs.core.seq(inst_23045);
var state_23168__$1 = (function (){var statearr_23225 = state_23168;
(statearr_23225[(7)] = inst_23067__$1);

return statearr_23225;
})();
if(inst_23067__$1){
var statearr_23226_23289 = state_23168__$1;
(statearr_23226_23289[(1)] = (16));

} else {
var statearr_23227_23290 = state_23168__$1;
(statearr_23227_23290[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (9))){
var inst_23097 = (state_23168[(2)]);
var state_23168__$1 = state_23168;
var statearr_23228_23291 = state_23168__$1;
(statearr_23228_23291[(2)] = inst_23097);

(statearr_23228_23291[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (5))){
var inst_23043 = cljs.core.deref(cs);
var inst_23044 = cljs.core.seq(inst_23043);
var inst_23045 = inst_23044;
var inst_23046 = null;
var inst_23047 = (0);
var inst_23048 = (0);
var state_23168__$1 = (function (){var statearr_23229 = state_23168;
(statearr_23229[(14)] = inst_23045);

(statearr_23229[(15)] = inst_23047);

(statearr_23229[(16)] = inst_23048);

(statearr_23229[(17)] = inst_23046);

return statearr_23229;
})();
var statearr_23230_23292 = state_23168__$1;
(statearr_23230_23292[(2)] = null);

(statearr_23230_23292[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (14))){
var state_23168__$1 = state_23168;
var statearr_23231_23293 = state_23168__$1;
(statearr_23231_23293[(2)] = null);

(statearr_23231_23293[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (45))){
var inst_23158 = (state_23168[(2)]);
var state_23168__$1 = state_23168;
var statearr_23232_23294 = state_23168__$1;
(statearr_23232_23294[(2)] = inst_23158);

(statearr_23232_23294[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (26))){
var inst_23100 = (state_23168[(29)]);
var inst_23154 = (state_23168[(2)]);
var inst_23155 = cljs.core.seq(inst_23100);
var state_23168__$1 = (function (){var statearr_23233 = state_23168;
(statearr_23233[(31)] = inst_23154);

return statearr_23233;
})();
if(inst_23155){
var statearr_23234_23295 = state_23168__$1;
(statearr_23234_23295[(1)] = (42));

} else {
var statearr_23235_23296 = state_23168__$1;
(statearr_23235_23296[(1)] = (43));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (16))){
var inst_23067 = (state_23168[(7)]);
var inst_23069 = cljs.core.chunked_seq_QMARK_(inst_23067);
var state_23168__$1 = state_23168;
if(inst_23069){
var statearr_23236_23297 = state_23168__$1;
(statearr_23236_23297[(1)] = (19));

} else {
var statearr_23237_23298 = state_23168__$1;
(statearr_23237_23298[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (38))){
var inst_23147 = (state_23168[(2)]);
var state_23168__$1 = state_23168;
var statearr_23238_23299 = state_23168__$1;
(statearr_23238_23299[(2)] = inst_23147);

(statearr_23238_23299[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (30))){
var state_23168__$1 = state_23168;
var statearr_23239_23300 = state_23168__$1;
(statearr_23239_23300[(2)] = null);

(statearr_23239_23300[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (10))){
var inst_23048 = (state_23168[(16)]);
var inst_23046 = (state_23168[(17)]);
var inst_23056 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_23046,inst_23048);
var inst_23057 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_23056,(0),null);
var inst_23058 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_23056,(1),null);
var state_23168__$1 = (function (){var statearr_23240 = state_23168;
(statearr_23240[(26)] = inst_23057);

return statearr_23240;
})();
if(cljs.core.truth_(inst_23058)){
var statearr_23241_23301 = state_23168__$1;
(statearr_23241_23301[(1)] = (13));

} else {
var statearr_23242_23302 = state_23168__$1;
(statearr_23242_23302[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (18))){
var inst_23093 = (state_23168[(2)]);
var state_23168__$1 = state_23168;
var statearr_23243_23303 = state_23168__$1;
(statearr_23243_23303[(2)] = inst_23093);

(statearr_23243_23303[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (42))){
var state_23168__$1 = state_23168;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_23168__$1,(45),dchan);
} else {
if((state_val_23169 === (37))){
var inst_23136 = (state_23168[(23)]);
var inst_23036 = (state_23168[(11)]);
var inst_23127 = (state_23168[(25)]);
var inst_23136__$1 = cljs.core.first(inst_23127);
var inst_23137 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_23136__$1,inst_23036,done);
var state_23168__$1 = (function (){var statearr_23244 = state_23168;
(statearr_23244[(23)] = inst_23136__$1);

return statearr_23244;
})();
if(cljs.core.truth_(inst_23137)){
var statearr_23245_23304 = state_23168__$1;
(statearr_23245_23304[(1)] = (39));

} else {
var statearr_23246_23305 = state_23168__$1;
(statearr_23246_23305[(1)] = (40));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23169 === (8))){
var inst_23047 = (state_23168[(15)]);
var inst_23048 = (state_23168[(16)]);
var inst_23050 = (inst_23048 < inst_23047);
var inst_23051 = inst_23050;
var state_23168__$1 = state_23168;
if(cljs.core.truth_(inst_23051)){
var statearr_23247_23306 = state_23168__$1;
(statearr_23247_23306[(1)] = (10));

} else {
var statearr_23248_23307 = state_23168__$1;
(statearr_23248_23307[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___23253,cs,m,dchan,dctr,done))
;
return ((function (switch__7945__auto__,c__8052__auto___23253,cs,m,dchan,dctr,done){
return (function() {
var cljs$core$async$mult_$_state_machine__7946__auto__ = null;
var cljs$core$async$mult_$_state_machine__7946__auto____0 = (function (){
var statearr_23249 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_23249[(0)] = cljs$core$async$mult_$_state_machine__7946__auto__);

(statearr_23249[(1)] = (1));

return statearr_23249;
});
var cljs$core$async$mult_$_state_machine__7946__auto____1 = (function (state_23168){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_23168);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e23250){if((e23250 instanceof Object)){
var ex__7949__auto__ = e23250;
var statearr_23251_23308 = state_23168;
(statearr_23251_23308[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_23168);

return cljs.core.cst$kw$recur;
} else {
throw e23250;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__23309 = state_23168;
state_23168 = G__23309;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$mult_$_state_machine__7946__auto__ = function(state_23168){
switch(arguments.length){
case 0:
return cljs$core$async$mult_$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$mult_$_state_machine__7946__auto____1.call(this,state_23168);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mult_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mult_$_state_machine__7946__auto____0;
cljs$core$async$mult_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mult_$_state_machine__7946__auto____1;
return cljs$core$async$mult_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___23253,cs,m,dchan,dctr,done))
})();
var state__8054__auto__ = (function (){var statearr_23252 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_23252[(6)] = c__8052__auto___23253);

return statearr_23252;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___23253,cs,m,dchan,dctr,done))
);


return m;
});
/**
 * Copies the mult source onto the supplied channel.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.tap = (function cljs$core$async$tap(var_args){
var G__23311 = arguments.length;
switch (G__23311) {
case 2:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2 = (function (mult,ch){
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(mult,ch,true);
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3 = (function (mult,ch,close_QMARK_){
cljs.core.async.tap_STAR_(mult,ch,close_QMARK_);

return ch;
});

cljs.core.async.tap.cljs$lang$maxFixedArity = 3;

/**
 * Disconnects a target channel from a mult
 */
cljs.core.async.untap = (function cljs$core$async$untap(mult,ch){
return cljs.core.async.untap_STAR_(mult,ch);
});
/**
 * Disconnects all target channels from a mult
 */
cljs.core.async.untap_all = (function cljs$core$async$untap_all(mult){
return cljs.core.async.untap_all_STAR_(mult);
});

/**
 * @interface
 */
cljs.core.async.Mix = function(){};

cljs.core.async.admix_STAR_ = (function cljs$core$async$admix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$admix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$admix_STAR_$arity$2(m,ch);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.admix_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4434__auto__.call(null,m,ch));
} else {
var m__4431__auto__ = (cljs.core.async.admix_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4431__auto__.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.admix*",m);
}
}
}
});

cljs.core.async.unmix_STAR_ = (function cljs$core$async$unmix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$unmix_STAR_$arity$2(m,ch);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.unmix_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4434__auto__.call(null,m,ch));
} else {
var m__4431__auto__ = (cljs.core.async.unmix_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4431__auto__.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.unmix*",m);
}
}
}
});

cljs.core.async.unmix_all_STAR_ = (function cljs$core$async$unmix_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mix$unmix_all_STAR_$arity$1(m);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.unmix_all_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4434__auto__.call(null,m));
} else {
var m__4431__auto__ = (cljs.core.async.unmix_all_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4431__auto__.call(null,m));
} else {
throw cljs.core.missing_protocol("Mix.unmix-all*",m);
}
}
}
});

cljs.core.async.toggle_STAR_ = (function cljs$core$async$toggle_STAR_(m,state_map){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$toggle_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$toggle_STAR_$arity$2(m,state_map);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.toggle_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4434__auto__.call(null,m,state_map));
} else {
var m__4431__auto__ = (cljs.core.async.toggle_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4431__auto__.call(null,m,state_map));
} else {
throw cljs.core.missing_protocol("Mix.toggle*",m);
}
}
}
});

cljs.core.async.solo_mode_STAR_ = (function cljs$core$async$solo_mode_STAR_(m,mode){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$solo_mode_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$solo_mode_STAR_$arity$2(m,mode);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.solo_mode_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4434__auto__.call(null,m,mode));
} else {
var m__4431__auto__ = (cljs.core.async.solo_mode_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4431__auto__.call(null,m,mode));
} else {
throw cljs.core.missing_protocol("Mix.solo-mode*",m);
}
}
}
});

cljs.core.async.ioc_alts_BANG_ = (function cljs$core$async$ioc_alts_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___23323 = arguments.length;
var i__4731__auto___23324 = (0);
while(true){
if((i__4731__auto___23324 < len__4730__auto___23323)){
args__4736__auto__.push((arguments[i__4731__auto___23324]));

var G__23325 = (i__4731__auto___23324 + (1));
i__4731__auto___23324 = G__23325;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((3) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((3)),(0),null)):null);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__4737__auto__);
});

cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (state,cont_block,ports,p__23317){
var map__23318 = p__23317;
var map__23318__$1 = (((((!((map__23318 == null))))?(((((map__23318.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__23318.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__23318):map__23318);
var opts = map__23318__$1;
var statearr_23320_23326 = state;
(statearr_23320_23326[(1)] = cont_block);


var temp__5735__auto__ = cljs.core.async.do_alts(((function (map__23318,map__23318__$1,opts){
return (function (val){
var statearr_23321_23327 = state;
(statearr_23321_23327[(2)] = val);


return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state);
});})(map__23318,map__23318__$1,opts))
,ports,opts);
if(cljs.core.truth_(temp__5735__auto__)){
var cb = temp__5735__auto__;
var statearr_23322_23328 = state;
(statearr_23322_23328[(2)] = cljs.core.deref(cb));


return cljs.core.cst$kw$recur;
} else {
return null;
}
});

cljs.core.async.ioc_alts_BANG_.cljs$lang$maxFixedArity = (3);

/** @this {Function} */
cljs.core.async.ioc_alts_BANG_.cljs$lang$applyTo = (function (seq23313){
var G__23314 = cljs.core.first(seq23313);
var seq23313__$1 = cljs.core.next(seq23313);
var G__23315 = cljs.core.first(seq23313__$1);
var seq23313__$2 = cljs.core.next(seq23313__$1);
var G__23316 = cljs.core.first(seq23313__$2);
var seq23313__$3 = cljs.core.next(seq23313__$2);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__23314,G__23315,G__23316,seq23313__$3);
});

/**
 * Creates and returns a mix of one or more input channels which will
 *   be put on the supplied out channel. Input sources can be added to
 *   the mix with 'admix', and removed with 'unmix'. A mix supports
 *   soloing, muting and pausing multiple inputs atomically using
 *   'toggle', and can solo using either muting or pausing as determined
 *   by 'solo-mode'.
 * 
 *   Each channel can have zero or more boolean modes set via 'toggle':
 * 
 *   :solo - when true, only this (ond other soloed) channel(s) will appear
 *        in the mix output channel. :mute and :pause states of soloed
 *        channels are ignored. If solo-mode is :mute, non-soloed
 *        channels are muted, if :pause, non-soloed channels are
 *        paused.
 * 
 *   :mute - muted channels will have their contents consumed but not included in the mix
 *   :pause - paused channels will not have their contents consumed (and thus also not included in the mix)
 */
cljs.core.async.mix = (function cljs$core$async$mix(out){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var solo_modes = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$pause,null,cljs.core.cst$kw$mute,null], null), null);
var attrs = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(solo_modes,cljs.core.cst$kw$solo);
var solo_mode = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.cst$kw$mute);
var change = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var changed = ((function (cs,solo_modes,attrs,solo_mode,change){
return (function (){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(change,true);
});})(cs,solo_modes,attrs,solo_mode,change))
;
var pick = ((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (attr,chs){
return cljs.core.reduce_kv(((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (ret,c,v){
if(cljs.core.truth_((attr.cljs$core$IFn$_invoke$arity$1 ? attr.cljs$core$IFn$_invoke$arity$1(v) : attr.call(null,v)))){
return cljs.core.conj.cljs$core$IFn$_invoke$arity$2(ret,c);
} else {
return ret;
}
});})(cs,solo_modes,attrs,solo_mode,change,changed))
,cljs.core.PersistentHashSet.EMPTY,chs);
});})(cs,solo_modes,attrs,solo_mode,change,changed))
;
var calc_state = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick){
return (function (){
var chs = cljs.core.deref(cs);
var mode = cljs.core.deref(solo_mode);
var solos = pick(cljs.core.cst$kw$solo,chs);
var pauses = pick(cljs.core.cst$kw$pause,chs);
return new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$solos,solos,cljs.core.cst$kw$mutes,pick(cljs.core.cst$kw$mute,chs),cljs.core.cst$kw$reads,cljs.core.conj.cljs$core$IFn$_invoke$arity$2(((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,cljs.core.cst$kw$pause)) && ((!(cljs.core.empty_QMARK_(solos))))))?cljs.core.vec(solos):cljs.core.vec(cljs.core.remove.cljs$core$IFn$_invoke$arity$2(pauses,cljs.core.keys(chs)))),change)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick))
;
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async23329 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mix}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async23329 = (function (change,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,meta23330){
this.change = change;
this.solo_mode = solo_mode;
this.pick = pick;
this.cs = cs;
this.calc_state = calc_state;
this.out = out;
this.changed = changed;
this.solo_modes = solo_modes;
this.attrs = attrs;
this.meta23330 = meta23330;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async23329.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_23331,meta23330__$1){
var self__ = this;
var _23331__$1 = this;
return (new cljs.core.async.t_cljs$core$async23329(self__.change,self__.solo_mode,self__.pick,self__.cs,self__.calc_state,self__.out,self__.changed,self__.solo_modes,self__.attrs,meta23330__$1));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async23329.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_23331){
var self__ = this;
var _23331__$1 = this;
return self__.meta23330;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async23329.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23329.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.out;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async23329.prototype.cljs$core$async$Mix$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23329.prototype.cljs$core$async$Mix$admix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async23329.prototype.cljs$core$async$Mix$unmix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async23329.prototype.cljs$core$async$Mix$unmix_all_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async23329.prototype.cljs$core$async$Mix$toggle_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,state_map){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.partial.cljs$core$IFn$_invoke$arity$2(cljs.core.merge_with,cljs.core.merge),state_map);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async23329.prototype.cljs$core$async$Mix$solo_mode_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,mode){
var self__ = this;
var ___$1 = this;

cljs.core.reset_BANG_(self__.solo_mode,mode);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async23329.getBasis = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (){
return new cljs.core.PersistentVector(null, 10, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$change,cljs.core.cst$sym$solo_DASH_mode,cljs.core.cst$sym$pick,cljs.core.cst$sym$cs,cljs.core.cst$sym$calc_DASH_state,cljs.core.cst$sym$out,cljs.core.cst$sym$changed,cljs.core.cst$sym$solo_DASH_modes,cljs.core.cst$sym$attrs,cljs.core.cst$sym$meta23330], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async23329.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async23329.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async23329";

cljs.core.async.t_cljs$core$async23329.cljs$lang$ctorPrWriter = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async23329");
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async23329.
 */
cljs.core.async.__GT_t_cljs$core$async23329 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function cljs$core$async$mix_$___GT_t_cljs$core$async23329(change__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta23330){
return (new cljs.core.async.t_cljs$core$async23329(change__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta23330));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

}

return (new cljs.core.async.t_cljs$core$async23329(change,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__8052__auto___23493 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___23493,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___23493,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (state_23433){
var state_val_23434 = (state_23433[(1)]);
if((state_val_23434 === (7))){
var inst_23348 = (state_23433[(2)]);
var state_23433__$1 = state_23433;
var statearr_23435_23494 = state_23433__$1;
(statearr_23435_23494[(2)] = inst_23348);

(statearr_23435_23494[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (20))){
var inst_23360 = (state_23433[(7)]);
var state_23433__$1 = state_23433;
var statearr_23436_23495 = state_23433__$1;
(statearr_23436_23495[(2)] = inst_23360);

(statearr_23436_23495[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (27))){
var state_23433__$1 = state_23433;
var statearr_23437_23496 = state_23433__$1;
(statearr_23437_23496[(2)] = null);

(statearr_23437_23496[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (1))){
var inst_23335 = (state_23433[(8)]);
var inst_23335__$1 = calc_state();
var inst_23337 = (inst_23335__$1 == null);
var inst_23338 = cljs.core.not(inst_23337);
var state_23433__$1 = (function (){var statearr_23438 = state_23433;
(statearr_23438[(8)] = inst_23335__$1);

return statearr_23438;
})();
if(inst_23338){
var statearr_23439_23497 = state_23433__$1;
(statearr_23439_23497[(1)] = (2));

} else {
var statearr_23440_23498 = state_23433__$1;
(statearr_23440_23498[(1)] = (3));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (24))){
var inst_23393 = (state_23433[(9)]);
var inst_23407 = (state_23433[(10)]);
var inst_23384 = (state_23433[(11)]);
var inst_23407__$1 = (inst_23384.cljs$core$IFn$_invoke$arity$1 ? inst_23384.cljs$core$IFn$_invoke$arity$1(inst_23393) : inst_23384.call(null,inst_23393));
var state_23433__$1 = (function (){var statearr_23441 = state_23433;
(statearr_23441[(10)] = inst_23407__$1);

return statearr_23441;
})();
if(cljs.core.truth_(inst_23407__$1)){
var statearr_23442_23499 = state_23433__$1;
(statearr_23442_23499[(1)] = (29));

} else {
var statearr_23443_23500 = state_23433__$1;
(statearr_23443_23500[(1)] = (30));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (4))){
var inst_23351 = (state_23433[(2)]);
var state_23433__$1 = state_23433;
if(cljs.core.truth_(inst_23351)){
var statearr_23444_23501 = state_23433__$1;
(statearr_23444_23501[(1)] = (8));

} else {
var statearr_23445_23502 = state_23433__$1;
(statearr_23445_23502[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (15))){
var inst_23378 = (state_23433[(2)]);
var state_23433__$1 = state_23433;
if(cljs.core.truth_(inst_23378)){
var statearr_23446_23503 = state_23433__$1;
(statearr_23446_23503[(1)] = (19));

} else {
var statearr_23447_23504 = state_23433__$1;
(statearr_23447_23504[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (21))){
var inst_23383 = (state_23433[(12)]);
var inst_23383__$1 = (state_23433[(2)]);
var inst_23384 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_23383__$1,cljs.core.cst$kw$solos);
var inst_23385 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_23383__$1,cljs.core.cst$kw$mutes);
var inst_23386 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_23383__$1,cljs.core.cst$kw$reads);
var state_23433__$1 = (function (){var statearr_23448 = state_23433;
(statearr_23448[(11)] = inst_23384);

(statearr_23448[(12)] = inst_23383__$1);

(statearr_23448[(13)] = inst_23385);

return statearr_23448;
})();
return cljs.core.async.ioc_alts_BANG_(state_23433__$1,(22),inst_23386);
} else {
if((state_val_23434 === (31))){
var inst_23415 = (state_23433[(2)]);
var state_23433__$1 = state_23433;
if(cljs.core.truth_(inst_23415)){
var statearr_23449_23505 = state_23433__$1;
(statearr_23449_23505[(1)] = (32));

} else {
var statearr_23450_23506 = state_23433__$1;
(statearr_23450_23506[(1)] = (33));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (32))){
var inst_23392 = (state_23433[(14)]);
var state_23433__$1 = state_23433;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_23433__$1,(35),out,inst_23392);
} else {
if((state_val_23434 === (33))){
var inst_23383 = (state_23433[(12)]);
var inst_23360 = inst_23383;
var state_23433__$1 = (function (){var statearr_23451 = state_23433;
(statearr_23451[(7)] = inst_23360);

return statearr_23451;
})();
var statearr_23452_23507 = state_23433__$1;
(statearr_23452_23507[(2)] = null);

(statearr_23452_23507[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (13))){
var inst_23360 = (state_23433[(7)]);
var inst_23367 = inst_23360.cljs$lang$protocol_mask$partition0$;
var inst_23368 = (inst_23367 & (64));
var inst_23369 = inst_23360.cljs$core$ISeq$;
var inst_23370 = (cljs.core.PROTOCOL_SENTINEL === inst_23369);
var inst_23371 = ((inst_23368) || (inst_23370));
var state_23433__$1 = state_23433;
if(cljs.core.truth_(inst_23371)){
var statearr_23453_23508 = state_23433__$1;
(statearr_23453_23508[(1)] = (16));

} else {
var statearr_23454_23509 = state_23433__$1;
(statearr_23454_23509[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (22))){
var inst_23393 = (state_23433[(9)]);
var inst_23392 = (state_23433[(14)]);
var inst_23391 = (state_23433[(2)]);
var inst_23392__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_23391,(0),null);
var inst_23393__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_23391,(1),null);
var inst_23394 = (inst_23392__$1 == null);
var inst_23395 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_23393__$1,change);
var inst_23396 = ((inst_23394) || (inst_23395));
var state_23433__$1 = (function (){var statearr_23455 = state_23433;
(statearr_23455[(9)] = inst_23393__$1);

(statearr_23455[(14)] = inst_23392__$1);

return statearr_23455;
})();
if(cljs.core.truth_(inst_23396)){
var statearr_23456_23510 = state_23433__$1;
(statearr_23456_23510[(1)] = (23));

} else {
var statearr_23457_23511 = state_23433__$1;
(statearr_23457_23511[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (36))){
var inst_23383 = (state_23433[(12)]);
var inst_23360 = inst_23383;
var state_23433__$1 = (function (){var statearr_23458 = state_23433;
(statearr_23458[(7)] = inst_23360);

return statearr_23458;
})();
var statearr_23459_23512 = state_23433__$1;
(statearr_23459_23512[(2)] = null);

(statearr_23459_23512[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (29))){
var inst_23407 = (state_23433[(10)]);
var state_23433__$1 = state_23433;
var statearr_23460_23513 = state_23433__$1;
(statearr_23460_23513[(2)] = inst_23407);

(statearr_23460_23513[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (6))){
var state_23433__$1 = state_23433;
var statearr_23461_23514 = state_23433__$1;
(statearr_23461_23514[(2)] = false);

(statearr_23461_23514[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (28))){
var inst_23403 = (state_23433[(2)]);
var inst_23404 = calc_state();
var inst_23360 = inst_23404;
var state_23433__$1 = (function (){var statearr_23462 = state_23433;
(statearr_23462[(15)] = inst_23403);

(statearr_23462[(7)] = inst_23360);

return statearr_23462;
})();
var statearr_23463_23515 = state_23433__$1;
(statearr_23463_23515[(2)] = null);

(statearr_23463_23515[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (25))){
var inst_23429 = (state_23433[(2)]);
var state_23433__$1 = state_23433;
var statearr_23464_23516 = state_23433__$1;
(statearr_23464_23516[(2)] = inst_23429);

(statearr_23464_23516[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (34))){
var inst_23427 = (state_23433[(2)]);
var state_23433__$1 = state_23433;
var statearr_23465_23517 = state_23433__$1;
(statearr_23465_23517[(2)] = inst_23427);

(statearr_23465_23517[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (17))){
var state_23433__$1 = state_23433;
var statearr_23466_23518 = state_23433__$1;
(statearr_23466_23518[(2)] = false);

(statearr_23466_23518[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (3))){
var state_23433__$1 = state_23433;
var statearr_23467_23519 = state_23433__$1;
(statearr_23467_23519[(2)] = false);

(statearr_23467_23519[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (12))){
var inst_23431 = (state_23433[(2)]);
var state_23433__$1 = state_23433;
return cljs.core.async.impl.ioc_helpers.return_chan(state_23433__$1,inst_23431);
} else {
if((state_val_23434 === (2))){
var inst_23335 = (state_23433[(8)]);
var inst_23340 = inst_23335.cljs$lang$protocol_mask$partition0$;
var inst_23341 = (inst_23340 & (64));
var inst_23342 = inst_23335.cljs$core$ISeq$;
var inst_23343 = (cljs.core.PROTOCOL_SENTINEL === inst_23342);
var inst_23344 = ((inst_23341) || (inst_23343));
var state_23433__$1 = state_23433;
if(cljs.core.truth_(inst_23344)){
var statearr_23468_23520 = state_23433__$1;
(statearr_23468_23520[(1)] = (5));

} else {
var statearr_23469_23521 = state_23433__$1;
(statearr_23469_23521[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (23))){
var inst_23392 = (state_23433[(14)]);
var inst_23398 = (inst_23392 == null);
var state_23433__$1 = state_23433;
if(cljs.core.truth_(inst_23398)){
var statearr_23470_23522 = state_23433__$1;
(statearr_23470_23522[(1)] = (26));

} else {
var statearr_23471_23523 = state_23433__$1;
(statearr_23471_23523[(1)] = (27));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (35))){
var inst_23418 = (state_23433[(2)]);
var state_23433__$1 = state_23433;
if(cljs.core.truth_(inst_23418)){
var statearr_23472_23524 = state_23433__$1;
(statearr_23472_23524[(1)] = (36));

} else {
var statearr_23473_23525 = state_23433__$1;
(statearr_23473_23525[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (19))){
var inst_23360 = (state_23433[(7)]);
var inst_23380 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_23360);
var state_23433__$1 = state_23433;
var statearr_23474_23526 = state_23433__$1;
(statearr_23474_23526[(2)] = inst_23380);

(statearr_23474_23526[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (11))){
var inst_23360 = (state_23433[(7)]);
var inst_23364 = (inst_23360 == null);
var inst_23365 = cljs.core.not(inst_23364);
var state_23433__$1 = state_23433;
if(inst_23365){
var statearr_23475_23527 = state_23433__$1;
(statearr_23475_23527[(1)] = (13));

} else {
var statearr_23476_23528 = state_23433__$1;
(statearr_23476_23528[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (9))){
var inst_23335 = (state_23433[(8)]);
var state_23433__$1 = state_23433;
var statearr_23477_23529 = state_23433__$1;
(statearr_23477_23529[(2)] = inst_23335);

(statearr_23477_23529[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (5))){
var state_23433__$1 = state_23433;
var statearr_23478_23530 = state_23433__$1;
(statearr_23478_23530[(2)] = true);

(statearr_23478_23530[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (14))){
var state_23433__$1 = state_23433;
var statearr_23479_23531 = state_23433__$1;
(statearr_23479_23531[(2)] = false);

(statearr_23479_23531[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (26))){
var inst_23393 = (state_23433[(9)]);
var inst_23400 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(cs,cljs.core.dissoc,inst_23393);
var state_23433__$1 = state_23433;
var statearr_23480_23532 = state_23433__$1;
(statearr_23480_23532[(2)] = inst_23400);

(statearr_23480_23532[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (16))){
var state_23433__$1 = state_23433;
var statearr_23481_23533 = state_23433__$1;
(statearr_23481_23533[(2)] = true);

(statearr_23481_23533[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (38))){
var inst_23423 = (state_23433[(2)]);
var state_23433__$1 = state_23433;
var statearr_23482_23534 = state_23433__$1;
(statearr_23482_23534[(2)] = inst_23423);

(statearr_23482_23534[(1)] = (34));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (30))){
var inst_23393 = (state_23433[(9)]);
var inst_23384 = (state_23433[(11)]);
var inst_23385 = (state_23433[(13)]);
var inst_23410 = cljs.core.empty_QMARK_(inst_23384);
var inst_23411 = (inst_23385.cljs$core$IFn$_invoke$arity$1 ? inst_23385.cljs$core$IFn$_invoke$arity$1(inst_23393) : inst_23385.call(null,inst_23393));
var inst_23412 = cljs.core.not(inst_23411);
var inst_23413 = ((inst_23410) && (inst_23412));
var state_23433__$1 = state_23433;
var statearr_23483_23535 = state_23433__$1;
(statearr_23483_23535[(2)] = inst_23413);

(statearr_23483_23535[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (10))){
var inst_23335 = (state_23433[(8)]);
var inst_23356 = (state_23433[(2)]);
var inst_23357 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_23356,cljs.core.cst$kw$solos);
var inst_23358 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_23356,cljs.core.cst$kw$mutes);
var inst_23359 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_23356,cljs.core.cst$kw$reads);
var inst_23360 = inst_23335;
var state_23433__$1 = (function (){var statearr_23484 = state_23433;
(statearr_23484[(16)] = inst_23357);

(statearr_23484[(17)] = inst_23359);

(statearr_23484[(18)] = inst_23358);

(statearr_23484[(7)] = inst_23360);

return statearr_23484;
})();
var statearr_23485_23536 = state_23433__$1;
(statearr_23485_23536[(2)] = null);

(statearr_23485_23536[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (18))){
var inst_23375 = (state_23433[(2)]);
var state_23433__$1 = state_23433;
var statearr_23486_23537 = state_23433__$1;
(statearr_23486_23537[(2)] = inst_23375);

(statearr_23486_23537[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (37))){
var state_23433__$1 = state_23433;
var statearr_23487_23538 = state_23433__$1;
(statearr_23487_23538[(2)] = null);

(statearr_23487_23538[(1)] = (38));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23434 === (8))){
var inst_23335 = (state_23433[(8)]);
var inst_23353 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_23335);
var state_23433__$1 = state_23433;
var statearr_23488_23539 = state_23433__$1;
(statearr_23488_23539[(2)] = inst_23353);

(statearr_23488_23539[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___23493,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
;
return ((function (switch__7945__auto__,c__8052__auto___23493,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function() {
var cljs$core$async$mix_$_state_machine__7946__auto__ = null;
var cljs$core$async$mix_$_state_machine__7946__auto____0 = (function (){
var statearr_23489 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_23489[(0)] = cljs$core$async$mix_$_state_machine__7946__auto__);

(statearr_23489[(1)] = (1));

return statearr_23489;
});
var cljs$core$async$mix_$_state_machine__7946__auto____1 = (function (state_23433){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_23433);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e23490){if((e23490 instanceof Object)){
var ex__7949__auto__ = e23490;
var statearr_23491_23540 = state_23433;
(statearr_23491_23540[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_23433);

return cljs.core.cst$kw$recur;
} else {
throw e23490;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__23541 = state_23433;
state_23433 = G__23541;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$mix_$_state_machine__7946__auto__ = function(state_23433){
switch(arguments.length){
case 0:
return cljs$core$async$mix_$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$mix_$_state_machine__7946__auto____1.call(this,state_23433);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mix_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mix_$_state_machine__7946__auto____0;
cljs$core$async$mix_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mix_$_state_machine__7946__auto____1;
return cljs$core$async$mix_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___23493,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
})();
var state__8054__auto__ = (function (){var statearr_23492 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_23492[(6)] = c__8052__auto___23493);

return statearr_23492;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___23493,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
);


return m;
});
/**
 * Adds ch as an input to the mix
 */
cljs.core.async.admix = (function cljs$core$async$admix(mix,ch){
return cljs.core.async.admix_STAR_(mix,ch);
});
/**
 * Removes ch as an input to the mix
 */
cljs.core.async.unmix = (function cljs$core$async$unmix(mix,ch){
return cljs.core.async.unmix_STAR_(mix,ch);
});
/**
 * removes all inputs from the mix
 */
cljs.core.async.unmix_all = (function cljs$core$async$unmix_all(mix){
return cljs.core.async.unmix_all_STAR_(mix);
});
/**
 * Atomically sets the state(s) of one or more channels in a mix. The
 *   state map is a map of channels -> channel-state-map. A
 *   channel-state-map is a map of attrs -> boolean, where attr is one or
 *   more of :mute, :pause or :solo. Any states supplied are merged with
 *   the current state.
 * 
 *   Note that channels can be added to a mix via toggle, which can be
 *   used to add channels in a particular (e.g. paused) state.
 */
cljs.core.async.toggle = (function cljs$core$async$toggle(mix,state_map){
return cljs.core.async.toggle_STAR_(mix,state_map);
});
/**
 * Sets the solo mode of the mix. mode must be one of :mute or :pause
 */
cljs.core.async.solo_mode = (function cljs$core$async$solo_mode(mix,mode){
return cljs.core.async.solo_mode_STAR_(mix,mode);
});

/**
 * @interface
 */
cljs.core.async.Pub = function(){};

cljs.core.async.sub_STAR_ = (function cljs$core$async$sub_STAR_(p,v,ch,close_QMARK_){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$sub_STAR_$arity$4 == null)))))){
return p.cljs$core$async$Pub$sub_STAR_$arity$4(p,v,ch,close_QMARK_);
} else {
var x__4433__auto__ = (((p == null))?null:p);
var m__4434__auto__ = (cljs.core.async.sub_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$4 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4434__auto__.call(null,p,v,ch,close_QMARK_));
} else {
var m__4431__auto__ = (cljs.core.async.sub_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$4 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4431__auto__.call(null,p,v,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Pub.sub*",p);
}
}
}
});

cljs.core.async.unsub_STAR_ = (function cljs$core$async$unsub_STAR_(p,v,ch){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_STAR_$arity$3 == null)))))){
return p.cljs$core$async$Pub$unsub_STAR_$arity$3(p,v,ch);
} else {
var x__4433__auto__ = (((p == null))?null:p);
var m__4434__auto__ = (cljs.core.async.unsub_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4434__auto__.call(null,p,v,ch));
} else {
var m__4431__auto__ = (cljs.core.async.unsub_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4431__auto__.call(null,p,v,ch));
} else {
throw cljs.core.missing_protocol("Pub.unsub*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_ = (function cljs$core$async$unsub_all_STAR_(var_args){
var G__23543 = arguments.length;
switch (G__23543) {
case 1:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1 = (function (p){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$1 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$1(p);
} else {
var x__4433__auto__ = (((p == null))?null:p);
var m__4434__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(p) : m__4434__auto__.call(null,p));
} else {
var m__4431__auto__ = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(p) : m__4431__auto__.call(null,p));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (p,v){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$2 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$2(p,v);
} else {
var x__4433__auto__ = (((p == null))?null:p);
var m__4434__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(p,v) : m__4434__auto__.call(null,p,v));
} else {
var m__4431__auto__ = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(p,v) : m__4431__auto__.call(null,p,v));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$lang$maxFixedArity = 2;


/**
 * Creates and returns a pub(lication) of the supplied channel,
 *   partitioned into topics by the topic-fn. topic-fn will be applied to
 *   each value on the channel and the result will determine the 'topic'
 *   on which that value will be put. Channels can be subscribed to
 *   receive copies of topics using 'sub', and unsubscribed using
 *   'unsub'. Each topic will be handled by an internal mult on a
 *   dedicated channel. By default these internal channels are
 *   unbuffered, but a buf-fn can be supplied which, given a topic,
 *   creates a buffer with desired properties.
 * 
 *   Each item is distributed to all subs in parallel and synchronously,
 *   i.e. each sub must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow subs from holding up the pub.
 * 
 *   Items received when there are no matching subs get dropped.
 * 
 *   Note that if buf-fns are used then each topic is handled
 *   asynchronously, i.e. if a channel is subscribed to more than one
 *   topic it should not expect them to be interleaved identically with
 *   the source.
 */
cljs.core.async.pub = (function cljs$core$async$pub(var_args){
var G__23547 = arguments.length;
switch (G__23547) {
case 2:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2 = (function (ch,topic_fn){
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3(ch,topic_fn,cljs.core.constantly(null));
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3 = (function (ch,topic_fn,buf_fn){
var mults = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var ensure_mult = ((function (mults){
return (function (topic){
var or__4131__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(mults),topic);
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(mults,((function (or__4131__auto__,mults){
return (function (p1__23545_SHARP_){
if(cljs.core.truth_((p1__23545_SHARP_.cljs$core$IFn$_invoke$arity$1 ? p1__23545_SHARP_.cljs$core$IFn$_invoke$arity$1(topic) : p1__23545_SHARP_.call(null,topic)))){
return p1__23545_SHARP_;
} else {
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__23545_SHARP_,topic,cljs.core.async.mult(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((buf_fn.cljs$core$IFn$_invoke$arity$1 ? buf_fn.cljs$core$IFn$_invoke$arity$1(topic) : buf_fn.call(null,topic)))));
}
});})(or__4131__auto__,mults))
),topic);
}
});})(mults))
;
var p = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async23548 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Pub}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async23548 = (function (ch,topic_fn,buf_fn,mults,ensure_mult,meta23549){
this.ch = ch;
this.topic_fn = topic_fn;
this.buf_fn = buf_fn;
this.mults = mults;
this.ensure_mult = ensure_mult;
this.meta23549 = meta23549;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async23548.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (mults,ensure_mult){
return (function (_23550,meta23549__$1){
var self__ = this;
var _23550__$1 = this;
return (new cljs.core.async.t_cljs$core$async23548(self__.ch,self__.topic_fn,self__.buf_fn,self__.mults,self__.ensure_mult,meta23549__$1));
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async23548.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (mults,ensure_mult){
return (function (_23550){
var self__ = this;
var _23550__$1 = this;
return self__.meta23549;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async23548.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23548.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async23548.prototype.cljs$core$async$Pub$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23548.prototype.cljs$core$async$Pub$sub_STAR_$arity$4 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1,close_QMARK_){
var self__ = this;
var p__$1 = this;
var m = (self__.ensure_mult.cljs$core$IFn$_invoke$arity$1 ? self__.ensure_mult.cljs$core$IFn$_invoke$arity$1(topic) : self__.ensure_mult.call(null,topic));
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(m,ch__$1,close_QMARK_);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async23548.prototype.cljs$core$async$Pub$unsub_STAR_$arity$3 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1){
var self__ = this;
var p__$1 = this;
var temp__5735__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(self__.mults),topic);
if(cljs.core.truth_(temp__5735__auto__)){
var m = temp__5735__auto__;
return cljs.core.async.untap(m,ch__$1);
} else {
return null;
}
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async23548.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.reset_BANG_(self__.mults,cljs.core.PersistentArrayMap.EMPTY);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async23548.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$2 = ((function (mults,ensure_mult){
return (function (_,topic){
var self__ = this;
var ___$1 = this;
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.mults,cljs.core.dissoc,topic);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async23548.getBasis = ((function (mults,ensure_mult){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$topic_DASH_fn,cljs.core.cst$sym$buf_DASH_fn,cljs.core.cst$sym$mults,cljs.core.cst$sym$ensure_DASH_mult,cljs.core.cst$sym$meta23549], null);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async23548.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async23548.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async23548";

cljs.core.async.t_cljs$core$async23548.cljs$lang$ctorPrWriter = ((function (mults,ensure_mult){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async23548");
});})(mults,ensure_mult))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async23548.
 */
cljs.core.async.__GT_t_cljs$core$async23548 = ((function (mults,ensure_mult){
return (function cljs$core$async$__GT_t_cljs$core$async23548(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta23549){
return (new cljs.core.async.t_cljs$core$async23548(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta23549));
});})(mults,ensure_mult))
;

}

return (new cljs.core.async.t_cljs$core$async23548(ch,topic_fn,buf_fn,mults,ensure_mult,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__8052__auto___23668 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___23668,mults,ensure_mult,p){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___23668,mults,ensure_mult,p){
return (function (state_23622){
var state_val_23623 = (state_23622[(1)]);
if((state_val_23623 === (7))){
var inst_23618 = (state_23622[(2)]);
var state_23622__$1 = state_23622;
var statearr_23624_23669 = state_23622__$1;
(statearr_23624_23669[(2)] = inst_23618);

(statearr_23624_23669[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (20))){
var state_23622__$1 = state_23622;
var statearr_23625_23670 = state_23622__$1;
(statearr_23625_23670[(2)] = null);

(statearr_23625_23670[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (1))){
var state_23622__$1 = state_23622;
var statearr_23626_23671 = state_23622__$1;
(statearr_23626_23671[(2)] = null);

(statearr_23626_23671[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (24))){
var inst_23601 = (state_23622[(7)]);
var inst_23610 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(mults,cljs.core.dissoc,inst_23601);
var state_23622__$1 = state_23622;
var statearr_23627_23672 = state_23622__$1;
(statearr_23627_23672[(2)] = inst_23610);

(statearr_23627_23672[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (4))){
var inst_23553 = (state_23622[(8)]);
var inst_23553__$1 = (state_23622[(2)]);
var inst_23554 = (inst_23553__$1 == null);
var state_23622__$1 = (function (){var statearr_23628 = state_23622;
(statearr_23628[(8)] = inst_23553__$1);

return statearr_23628;
})();
if(cljs.core.truth_(inst_23554)){
var statearr_23629_23673 = state_23622__$1;
(statearr_23629_23673[(1)] = (5));

} else {
var statearr_23630_23674 = state_23622__$1;
(statearr_23630_23674[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (15))){
var inst_23595 = (state_23622[(2)]);
var state_23622__$1 = state_23622;
var statearr_23631_23675 = state_23622__$1;
(statearr_23631_23675[(2)] = inst_23595);

(statearr_23631_23675[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (21))){
var inst_23615 = (state_23622[(2)]);
var state_23622__$1 = (function (){var statearr_23632 = state_23622;
(statearr_23632[(9)] = inst_23615);

return statearr_23632;
})();
var statearr_23633_23676 = state_23622__$1;
(statearr_23633_23676[(2)] = null);

(statearr_23633_23676[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (13))){
var inst_23577 = (state_23622[(10)]);
var inst_23579 = cljs.core.chunked_seq_QMARK_(inst_23577);
var state_23622__$1 = state_23622;
if(inst_23579){
var statearr_23634_23677 = state_23622__$1;
(statearr_23634_23677[(1)] = (16));

} else {
var statearr_23635_23678 = state_23622__$1;
(statearr_23635_23678[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (22))){
var inst_23607 = (state_23622[(2)]);
var state_23622__$1 = state_23622;
if(cljs.core.truth_(inst_23607)){
var statearr_23636_23679 = state_23622__$1;
(statearr_23636_23679[(1)] = (23));

} else {
var statearr_23637_23680 = state_23622__$1;
(statearr_23637_23680[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (6))){
var inst_23553 = (state_23622[(8)]);
var inst_23601 = (state_23622[(7)]);
var inst_23603 = (state_23622[(11)]);
var inst_23601__$1 = (topic_fn.cljs$core$IFn$_invoke$arity$1 ? topic_fn.cljs$core$IFn$_invoke$arity$1(inst_23553) : topic_fn.call(null,inst_23553));
var inst_23602 = cljs.core.deref(mults);
var inst_23603__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_23602,inst_23601__$1);
var state_23622__$1 = (function (){var statearr_23638 = state_23622;
(statearr_23638[(7)] = inst_23601__$1);

(statearr_23638[(11)] = inst_23603__$1);

return statearr_23638;
})();
if(cljs.core.truth_(inst_23603__$1)){
var statearr_23639_23681 = state_23622__$1;
(statearr_23639_23681[(1)] = (19));

} else {
var statearr_23640_23682 = state_23622__$1;
(statearr_23640_23682[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (25))){
var inst_23612 = (state_23622[(2)]);
var state_23622__$1 = state_23622;
var statearr_23641_23683 = state_23622__$1;
(statearr_23641_23683[(2)] = inst_23612);

(statearr_23641_23683[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (17))){
var inst_23577 = (state_23622[(10)]);
var inst_23586 = cljs.core.first(inst_23577);
var inst_23587 = cljs.core.async.muxch_STAR_(inst_23586);
var inst_23588 = cljs.core.async.close_BANG_(inst_23587);
var inst_23589 = cljs.core.next(inst_23577);
var inst_23563 = inst_23589;
var inst_23564 = null;
var inst_23565 = (0);
var inst_23566 = (0);
var state_23622__$1 = (function (){var statearr_23642 = state_23622;
(statearr_23642[(12)] = inst_23566);

(statearr_23642[(13)] = inst_23563);

(statearr_23642[(14)] = inst_23588);

(statearr_23642[(15)] = inst_23564);

(statearr_23642[(16)] = inst_23565);

return statearr_23642;
})();
var statearr_23643_23684 = state_23622__$1;
(statearr_23643_23684[(2)] = null);

(statearr_23643_23684[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (3))){
var inst_23620 = (state_23622[(2)]);
var state_23622__$1 = state_23622;
return cljs.core.async.impl.ioc_helpers.return_chan(state_23622__$1,inst_23620);
} else {
if((state_val_23623 === (12))){
var inst_23597 = (state_23622[(2)]);
var state_23622__$1 = state_23622;
var statearr_23644_23685 = state_23622__$1;
(statearr_23644_23685[(2)] = inst_23597);

(statearr_23644_23685[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (2))){
var state_23622__$1 = state_23622;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_23622__$1,(4),ch);
} else {
if((state_val_23623 === (23))){
var state_23622__$1 = state_23622;
var statearr_23645_23686 = state_23622__$1;
(statearr_23645_23686[(2)] = null);

(statearr_23645_23686[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (19))){
var inst_23553 = (state_23622[(8)]);
var inst_23603 = (state_23622[(11)]);
var inst_23605 = cljs.core.async.muxch_STAR_(inst_23603);
var state_23622__$1 = state_23622;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_23622__$1,(22),inst_23605,inst_23553);
} else {
if((state_val_23623 === (11))){
var inst_23563 = (state_23622[(13)]);
var inst_23577 = (state_23622[(10)]);
var inst_23577__$1 = cljs.core.seq(inst_23563);
var state_23622__$1 = (function (){var statearr_23646 = state_23622;
(statearr_23646[(10)] = inst_23577__$1);

return statearr_23646;
})();
if(inst_23577__$1){
var statearr_23647_23687 = state_23622__$1;
(statearr_23647_23687[(1)] = (13));

} else {
var statearr_23648_23688 = state_23622__$1;
(statearr_23648_23688[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (9))){
var inst_23599 = (state_23622[(2)]);
var state_23622__$1 = state_23622;
var statearr_23649_23689 = state_23622__$1;
(statearr_23649_23689[(2)] = inst_23599);

(statearr_23649_23689[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (5))){
var inst_23560 = cljs.core.deref(mults);
var inst_23561 = cljs.core.vals(inst_23560);
var inst_23562 = cljs.core.seq(inst_23561);
var inst_23563 = inst_23562;
var inst_23564 = null;
var inst_23565 = (0);
var inst_23566 = (0);
var state_23622__$1 = (function (){var statearr_23650 = state_23622;
(statearr_23650[(12)] = inst_23566);

(statearr_23650[(13)] = inst_23563);

(statearr_23650[(15)] = inst_23564);

(statearr_23650[(16)] = inst_23565);

return statearr_23650;
})();
var statearr_23651_23690 = state_23622__$1;
(statearr_23651_23690[(2)] = null);

(statearr_23651_23690[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (14))){
var state_23622__$1 = state_23622;
var statearr_23655_23691 = state_23622__$1;
(statearr_23655_23691[(2)] = null);

(statearr_23655_23691[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (16))){
var inst_23577 = (state_23622[(10)]);
var inst_23581 = cljs.core.chunk_first(inst_23577);
var inst_23582 = cljs.core.chunk_rest(inst_23577);
var inst_23583 = cljs.core.count(inst_23581);
var inst_23563 = inst_23582;
var inst_23564 = inst_23581;
var inst_23565 = inst_23583;
var inst_23566 = (0);
var state_23622__$1 = (function (){var statearr_23656 = state_23622;
(statearr_23656[(12)] = inst_23566);

(statearr_23656[(13)] = inst_23563);

(statearr_23656[(15)] = inst_23564);

(statearr_23656[(16)] = inst_23565);

return statearr_23656;
})();
var statearr_23657_23692 = state_23622__$1;
(statearr_23657_23692[(2)] = null);

(statearr_23657_23692[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (10))){
var inst_23566 = (state_23622[(12)]);
var inst_23563 = (state_23622[(13)]);
var inst_23564 = (state_23622[(15)]);
var inst_23565 = (state_23622[(16)]);
var inst_23571 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_23564,inst_23566);
var inst_23572 = cljs.core.async.muxch_STAR_(inst_23571);
var inst_23573 = cljs.core.async.close_BANG_(inst_23572);
var inst_23574 = (inst_23566 + (1));
var tmp23652 = inst_23563;
var tmp23653 = inst_23564;
var tmp23654 = inst_23565;
var inst_23563__$1 = tmp23652;
var inst_23564__$1 = tmp23653;
var inst_23565__$1 = tmp23654;
var inst_23566__$1 = inst_23574;
var state_23622__$1 = (function (){var statearr_23658 = state_23622;
(statearr_23658[(12)] = inst_23566__$1);

(statearr_23658[(13)] = inst_23563__$1);

(statearr_23658[(17)] = inst_23573);

(statearr_23658[(15)] = inst_23564__$1);

(statearr_23658[(16)] = inst_23565__$1);

return statearr_23658;
})();
var statearr_23659_23693 = state_23622__$1;
(statearr_23659_23693[(2)] = null);

(statearr_23659_23693[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (18))){
var inst_23592 = (state_23622[(2)]);
var state_23622__$1 = state_23622;
var statearr_23660_23694 = state_23622__$1;
(statearr_23660_23694[(2)] = inst_23592);

(statearr_23660_23694[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23623 === (8))){
var inst_23566 = (state_23622[(12)]);
var inst_23565 = (state_23622[(16)]);
var inst_23568 = (inst_23566 < inst_23565);
var inst_23569 = inst_23568;
var state_23622__$1 = state_23622;
if(cljs.core.truth_(inst_23569)){
var statearr_23661_23695 = state_23622__$1;
(statearr_23661_23695[(1)] = (10));

} else {
var statearr_23662_23696 = state_23622__$1;
(statearr_23662_23696[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___23668,mults,ensure_mult,p))
;
return ((function (switch__7945__auto__,c__8052__auto___23668,mults,ensure_mult,p){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_23663 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_23663[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_23663[(1)] = (1));

return statearr_23663;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_23622){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_23622);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e23664){if((e23664 instanceof Object)){
var ex__7949__auto__ = e23664;
var statearr_23665_23697 = state_23622;
(statearr_23665_23697[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_23622);

return cljs.core.cst$kw$recur;
} else {
throw e23664;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__23698 = state_23622;
state_23622 = G__23698;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_23622){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_23622);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___23668,mults,ensure_mult,p))
})();
var state__8054__auto__ = (function (){var statearr_23666 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_23666[(6)] = c__8052__auto___23668);

return statearr_23666;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___23668,mults,ensure_mult,p))
);


return p;
});

cljs.core.async.pub.cljs$lang$maxFixedArity = 3;

/**
 * Subscribes a channel to a topic of a pub.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.sub = (function cljs$core$async$sub(var_args){
var G__23700 = arguments.length;
switch (G__23700) {
case 3:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3 = (function (p,topic,ch){
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4(p,topic,ch,true);
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4 = (function (p,topic,ch,close_QMARK_){
return cljs.core.async.sub_STAR_(p,topic,ch,close_QMARK_);
});

cljs.core.async.sub.cljs$lang$maxFixedArity = 4;

/**
 * Unsubscribes a channel from a topic of a pub
 */
cljs.core.async.unsub = (function cljs$core$async$unsub(p,topic,ch){
return cljs.core.async.unsub_STAR_(p,topic,ch);
});
/**
 * Unsubscribes all channels from a pub, or a topic of a pub
 */
cljs.core.async.unsub_all = (function cljs$core$async$unsub_all(var_args){
var G__23703 = arguments.length;
switch (G__23703) {
case 1:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1 = (function (p){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1(p);
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2 = (function (p,topic){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2(p,topic);
});

cljs.core.async.unsub_all.cljs$lang$maxFixedArity = 2;

/**
 * Takes a function and a collection of source channels, and returns a
 *   channel which contains the values produced by applying f to the set
 *   of first items taken from each source channel, followed by applying
 *   f to the set of second items from each channel, until any one of the
 *   channels is closed, at which point the output channel will be
 *   closed. The returned channel will be unbuffered by default, or a
 *   buf-or-n can be supplied
 */
cljs.core.async.map = (function cljs$core$async$map(var_args){
var G__23706 = arguments.length;
switch (G__23706) {
case 2:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$2 = (function (f,chs){
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3(f,chs,null);
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$3 = (function (f,chs,buf_or_n){
var chs__$1 = cljs.core.vec(chs);
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var cnt = cljs.core.count(chs__$1);
var rets = cljs.core.object_array.cljs$core$IFn$_invoke$arity$1(cnt);
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = cljs.core.mapv.cljs$core$IFn$_invoke$arity$2(((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (i){
return ((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (ret){
(rets[i] = ret);

if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,rets.slice((0)));
} else {
return null;
}
});
;})(chs__$1,out,cnt,rets,dchan,dctr))
});})(chs__$1,out,cnt,rets,dchan,dctr))
,cljs.core.range.cljs$core$IFn$_invoke$arity$1(cnt));
var c__8052__auto___23773 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___23773,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___23773,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (state_23745){
var state_val_23746 = (state_23745[(1)]);
if((state_val_23746 === (7))){
var state_23745__$1 = state_23745;
var statearr_23747_23774 = state_23745__$1;
(statearr_23747_23774[(2)] = null);

(statearr_23747_23774[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23746 === (1))){
var state_23745__$1 = state_23745;
var statearr_23748_23775 = state_23745__$1;
(statearr_23748_23775[(2)] = null);

(statearr_23748_23775[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23746 === (4))){
var inst_23709 = (state_23745[(7)]);
var inst_23711 = (inst_23709 < cnt);
var state_23745__$1 = state_23745;
if(cljs.core.truth_(inst_23711)){
var statearr_23749_23776 = state_23745__$1;
(statearr_23749_23776[(1)] = (6));

} else {
var statearr_23750_23777 = state_23745__$1;
(statearr_23750_23777[(1)] = (7));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23746 === (15))){
var inst_23741 = (state_23745[(2)]);
var state_23745__$1 = state_23745;
var statearr_23751_23778 = state_23745__$1;
(statearr_23751_23778[(2)] = inst_23741);

(statearr_23751_23778[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23746 === (13))){
var inst_23734 = cljs.core.async.close_BANG_(out);
var state_23745__$1 = state_23745;
var statearr_23752_23779 = state_23745__$1;
(statearr_23752_23779[(2)] = inst_23734);

(statearr_23752_23779[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23746 === (6))){
var state_23745__$1 = state_23745;
var statearr_23753_23780 = state_23745__$1;
(statearr_23753_23780[(2)] = null);

(statearr_23753_23780[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23746 === (3))){
var inst_23743 = (state_23745[(2)]);
var state_23745__$1 = state_23745;
return cljs.core.async.impl.ioc_helpers.return_chan(state_23745__$1,inst_23743);
} else {
if((state_val_23746 === (12))){
var inst_23731 = (state_23745[(8)]);
var inst_23731__$1 = (state_23745[(2)]);
var inst_23732 = cljs.core.some(cljs.core.nil_QMARK_,inst_23731__$1);
var state_23745__$1 = (function (){var statearr_23754 = state_23745;
(statearr_23754[(8)] = inst_23731__$1);

return statearr_23754;
})();
if(cljs.core.truth_(inst_23732)){
var statearr_23755_23781 = state_23745__$1;
(statearr_23755_23781[(1)] = (13));

} else {
var statearr_23756_23782 = state_23745__$1;
(statearr_23756_23782[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23746 === (2))){
var inst_23708 = cljs.core.reset_BANG_(dctr,cnt);
var inst_23709 = (0);
var state_23745__$1 = (function (){var statearr_23757 = state_23745;
(statearr_23757[(9)] = inst_23708);

(statearr_23757[(7)] = inst_23709);

return statearr_23757;
})();
var statearr_23758_23783 = state_23745__$1;
(statearr_23758_23783[(2)] = null);

(statearr_23758_23783[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23746 === (11))){
var inst_23709 = (state_23745[(7)]);
var _ = cljs.core.async.impl.ioc_helpers.add_exception_frame(state_23745,(10),Object,null,(9));
var inst_23718 = (chs__$1.cljs$core$IFn$_invoke$arity$1 ? chs__$1.cljs$core$IFn$_invoke$arity$1(inst_23709) : chs__$1.call(null,inst_23709));
var inst_23719 = (done.cljs$core$IFn$_invoke$arity$1 ? done.cljs$core$IFn$_invoke$arity$1(inst_23709) : done.call(null,inst_23709));
var inst_23720 = cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2(inst_23718,inst_23719);
var state_23745__$1 = state_23745;
var statearr_23759_23784 = state_23745__$1;
(statearr_23759_23784[(2)] = inst_23720);


cljs.core.async.impl.ioc_helpers.process_exception(state_23745__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_23746 === (9))){
var inst_23709 = (state_23745[(7)]);
var inst_23722 = (state_23745[(2)]);
var inst_23723 = (inst_23709 + (1));
var inst_23709__$1 = inst_23723;
var state_23745__$1 = (function (){var statearr_23760 = state_23745;
(statearr_23760[(10)] = inst_23722);

(statearr_23760[(7)] = inst_23709__$1);

return statearr_23760;
})();
var statearr_23761_23785 = state_23745__$1;
(statearr_23761_23785[(2)] = null);

(statearr_23761_23785[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23746 === (5))){
var inst_23729 = (state_23745[(2)]);
var state_23745__$1 = (function (){var statearr_23762 = state_23745;
(statearr_23762[(11)] = inst_23729);

return statearr_23762;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_23745__$1,(12),dchan);
} else {
if((state_val_23746 === (14))){
var inst_23731 = (state_23745[(8)]);
var inst_23736 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(f,inst_23731);
var state_23745__$1 = state_23745;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_23745__$1,(16),out,inst_23736);
} else {
if((state_val_23746 === (16))){
var inst_23738 = (state_23745[(2)]);
var state_23745__$1 = (function (){var statearr_23763 = state_23745;
(statearr_23763[(12)] = inst_23738);

return statearr_23763;
})();
var statearr_23764_23786 = state_23745__$1;
(statearr_23764_23786[(2)] = null);

(statearr_23764_23786[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23746 === (10))){
var inst_23713 = (state_23745[(2)]);
var inst_23714 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec);
var state_23745__$1 = (function (){var statearr_23765 = state_23745;
(statearr_23765[(13)] = inst_23713);

return statearr_23765;
})();
var statearr_23766_23787 = state_23745__$1;
(statearr_23766_23787[(2)] = inst_23714);


cljs.core.async.impl.ioc_helpers.process_exception(state_23745__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_23746 === (8))){
var inst_23727 = (state_23745[(2)]);
var state_23745__$1 = state_23745;
var statearr_23767_23788 = state_23745__$1;
(statearr_23767_23788[(2)] = inst_23727);

(statearr_23767_23788[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___23773,chs__$1,out,cnt,rets,dchan,dctr,done))
;
return ((function (switch__7945__auto__,c__8052__auto___23773,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_23768 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_23768[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_23768[(1)] = (1));

return statearr_23768;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_23745){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_23745);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e23769){if((e23769 instanceof Object)){
var ex__7949__auto__ = e23769;
var statearr_23770_23789 = state_23745;
(statearr_23770_23789[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_23745);

return cljs.core.cst$kw$recur;
} else {
throw e23769;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__23790 = state_23745;
state_23745 = G__23790;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_23745){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_23745);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___23773,chs__$1,out,cnt,rets,dchan,dctr,done))
})();
var state__8054__auto__ = (function (){var statearr_23771 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_23771[(6)] = c__8052__auto___23773);

return statearr_23771;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___23773,chs__$1,out,cnt,rets,dchan,dctr,done))
);


return out;
});

cljs.core.async.map.cljs$lang$maxFixedArity = 3;

/**
 * Takes a collection of source channels and returns a channel which
 *   contains all values taken from them. The returned channel will be
 *   unbuffered by default, or a buf-or-n can be supplied. The channel
 *   will close after all the source channels have closed.
 */
cljs.core.async.merge = (function cljs$core$async$merge(var_args){
var G__23793 = arguments.length;
switch (G__23793) {
case 1:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1 = (function (chs){
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2(chs,null);
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2 = (function (chs,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__8052__auto___23847 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___23847,out){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___23847,out){
return (function (state_23825){
var state_val_23826 = (state_23825[(1)]);
if((state_val_23826 === (7))){
var inst_23805 = (state_23825[(7)]);
var inst_23804 = (state_23825[(8)]);
var inst_23804__$1 = (state_23825[(2)]);
var inst_23805__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_23804__$1,(0),null);
var inst_23806 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_23804__$1,(1),null);
var inst_23807 = (inst_23805__$1 == null);
var state_23825__$1 = (function (){var statearr_23827 = state_23825;
(statearr_23827[(9)] = inst_23806);

(statearr_23827[(7)] = inst_23805__$1);

(statearr_23827[(8)] = inst_23804__$1);

return statearr_23827;
})();
if(cljs.core.truth_(inst_23807)){
var statearr_23828_23848 = state_23825__$1;
(statearr_23828_23848[(1)] = (8));

} else {
var statearr_23829_23849 = state_23825__$1;
(statearr_23829_23849[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23826 === (1))){
var inst_23794 = cljs.core.vec(chs);
var inst_23795 = inst_23794;
var state_23825__$1 = (function (){var statearr_23830 = state_23825;
(statearr_23830[(10)] = inst_23795);

return statearr_23830;
})();
var statearr_23831_23850 = state_23825__$1;
(statearr_23831_23850[(2)] = null);

(statearr_23831_23850[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23826 === (4))){
var inst_23795 = (state_23825[(10)]);
var state_23825__$1 = state_23825;
return cljs.core.async.ioc_alts_BANG_(state_23825__$1,(7),inst_23795);
} else {
if((state_val_23826 === (6))){
var inst_23821 = (state_23825[(2)]);
var state_23825__$1 = state_23825;
var statearr_23832_23851 = state_23825__$1;
(statearr_23832_23851[(2)] = inst_23821);

(statearr_23832_23851[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23826 === (3))){
var inst_23823 = (state_23825[(2)]);
var state_23825__$1 = state_23825;
return cljs.core.async.impl.ioc_helpers.return_chan(state_23825__$1,inst_23823);
} else {
if((state_val_23826 === (2))){
var inst_23795 = (state_23825[(10)]);
var inst_23797 = cljs.core.count(inst_23795);
var inst_23798 = (inst_23797 > (0));
var state_23825__$1 = state_23825;
if(cljs.core.truth_(inst_23798)){
var statearr_23834_23852 = state_23825__$1;
(statearr_23834_23852[(1)] = (4));

} else {
var statearr_23835_23853 = state_23825__$1;
(statearr_23835_23853[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23826 === (11))){
var inst_23795 = (state_23825[(10)]);
var inst_23814 = (state_23825[(2)]);
var tmp23833 = inst_23795;
var inst_23795__$1 = tmp23833;
var state_23825__$1 = (function (){var statearr_23836 = state_23825;
(statearr_23836[(10)] = inst_23795__$1);

(statearr_23836[(11)] = inst_23814);

return statearr_23836;
})();
var statearr_23837_23854 = state_23825__$1;
(statearr_23837_23854[(2)] = null);

(statearr_23837_23854[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23826 === (9))){
var inst_23805 = (state_23825[(7)]);
var state_23825__$1 = state_23825;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_23825__$1,(11),out,inst_23805);
} else {
if((state_val_23826 === (5))){
var inst_23819 = cljs.core.async.close_BANG_(out);
var state_23825__$1 = state_23825;
var statearr_23838_23855 = state_23825__$1;
(statearr_23838_23855[(2)] = inst_23819);

(statearr_23838_23855[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23826 === (10))){
var inst_23817 = (state_23825[(2)]);
var state_23825__$1 = state_23825;
var statearr_23839_23856 = state_23825__$1;
(statearr_23839_23856[(2)] = inst_23817);

(statearr_23839_23856[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23826 === (8))){
var inst_23795 = (state_23825[(10)]);
var inst_23806 = (state_23825[(9)]);
var inst_23805 = (state_23825[(7)]);
var inst_23804 = (state_23825[(8)]);
var inst_23809 = (function (){var cs = inst_23795;
var vec__23800 = inst_23804;
var v = inst_23805;
var c = inst_23806;
return ((function (cs,vec__23800,v,c,inst_23795,inst_23806,inst_23805,inst_23804,state_val_23826,c__8052__auto___23847,out){
return (function (p1__23791_SHARP_){
return cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(c,p1__23791_SHARP_);
});
;})(cs,vec__23800,v,c,inst_23795,inst_23806,inst_23805,inst_23804,state_val_23826,c__8052__auto___23847,out))
})();
var inst_23810 = cljs.core.filterv(inst_23809,inst_23795);
var inst_23795__$1 = inst_23810;
var state_23825__$1 = (function (){var statearr_23840 = state_23825;
(statearr_23840[(10)] = inst_23795__$1);

return statearr_23840;
})();
var statearr_23841_23857 = state_23825__$1;
(statearr_23841_23857[(2)] = null);

(statearr_23841_23857[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___23847,out))
;
return ((function (switch__7945__auto__,c__8052__auto___23847,out){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_23842 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_23842[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_23842[(1)] = (1));

return statearr_23842;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_23825){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_23825);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e23843){if((e23843 instanceof Object)){
var ex__7949__auto__ = e23843;
var statearr_23844_23858 = state_23825;
(statearr_23844_23858[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_23825);

return cljs.core.cst$kw$recur;
} else {
throw e23843;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__23859 = state_23825;
state_23825 = G__23859;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_23825){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_23825);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___23847,out))
})();
var state__8054__auto__ = (function (){var statearr_23845 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_23845[(6)] = c__8052__auto___23847);

return statearr_23845;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___23847,out))
);


return out;
});

cljs.core.async.merge.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel containing the single (collection) result of the
 *   items taken from the channel conjoined to the supplied
 *   collection. ch must close before into produces a result.
 */
cljs.core.async.into = (function cljs$core$async$into(coll,ch){
return cljs.core.async.reduce(cljs.core.conj,coll,ch);
});
/**
 * Returns a channel that will return, at most, n items from ch. After n items
 * have been returned, or ch has been closed, the return chanel will close.
 * 
 *   The output channel is unbuffered by default, unless buf-or-n is given.
 */
cljs.core.async.take = (function cljs$core$async$take(var_args){
var G__23861 = arguments.length;
switch (G__23861) {
case 2:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__8052__auto___23906 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___23906,out){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___23906,out){
return (function (state_23885){
var state_val_23886 = (state_23885[(1)]);
if((state_val_23886 === (7))){
var inst_23867 = (state_23885[(7)]);
var inst_23867__$1 = (state_23885[(2)]);
var inst_23868 = (inst_23867__$1 == null);
var inst_23869 = cljs.core.not(inst_23868);
var state_23885__$1 = (function (){var statearr_23887 = state_23885;
(statearr_23887[(7)] = inst_23867__$1);

return statearr_23887;
})();
if(inst_23869){
var statearr_23888_23907 = state_23885__$1;
(statearr_23888_23907[(1)] = (8));

} else {
var statearr_23889_23908 = state_23885__$1;
(statearr_23889_23908[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23886 === (1))){
var inst_23862 = (0);
var state_23885__$1 = (function (){var statearr_23890 = state_23885;
(statearr_23890[(8)] = inst_23862);

return statearr_23890;
})();
var statearr_23891_23909 = state_23885__$1;
(statearr_23891_23909[(2)] = null);

(statearr_23891_23909[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23886 === (4))){
var state_23885__$1 = state_23885;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_23885__$1,(7),ch);
} else {
if((state_val_23886 === (6))){
var inst_23880 = (state_23885[(2)]);
var state_23885__$1 = state_23885;
var statearr_23892_23910 = state_23885__$1;
(statearr_23892_23910[(2)] = inst_23880);

(statearr_23892_23910[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23886 === (3))){
var inst_23882 = (state_23885[(2)]);
var inst_23883 = cljs.core.async.close_BANG_(out);
var state_23885__$1 = (function (){var statearr_23893 = state_23885;
(statearr_23893[(9)] = inst_23882);

return statearr_23893;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_23885__$1,inst_23883);
} else {
if((state_val_23886 === (2))){
var inst_23862 = (state_23885[(8)]);
var inst_23864 = (inst_23862 < n);
var state_23885__$1 = state_23885;
if(cljs.core.truth_(inst_23864)){
var statearr_23894_23911 = state_23885__$1;
(statearr_23894_23911[(1)] = (4));

} else {
var statearr_23895_23912 = state_23885__$1;
(statearr_23895_23912[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23886 === (11))){
var inst_23862 = (state_23885[(8)]);
var inst_23872 = (state_23885[(2)]);
var inst_23873 = (inst_23862 + (1));
var inst_23862__$1 = inst_23873;
var state_23885__$1 = (function (){var statearr_23896 = state_23885;
(statearr_23896[(8)] = inst_23862__$1);

(statearr_23896[(10)] = inst_23872);

return statearr_23896;
})();
var statearr_23897_23913 = state_23885__$1;
(statearr_23897_23913[(2)] = null);

(statearr_23897_23913[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23886 === (9))){
var state_23885__$1 = state_23885;
var statearr_23898_23914 = state_23885__$1;
(statearr_23898_23914[(2)] = null);

(statearr_23898_23914[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23886 === (5))){
var state_23885__$1 = state_23885;
var statearr_23899_23915 = state_23885__$1;
(statearr_23899_23915[(2)] = null);

(statearr_23899_23915[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23886 === (10))){
var inst_23877 = (state_23885[(2)]);
var state_23885__$1 = state_23885;
var statearr_23900_23916 = state_23885__$1;
(statearr_23900_23916[(2)] = inst_23877);

(statearr_23900_23916[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23886 === (8))){
var inst_23867 = (state_23885[(7)]);
var state_23885__$1 = state_23885;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_23885__$1,(11),out,inst_23867);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___23906,out))
;
return ((function (switch__7945__auto__,c__8052__auto___23906,out){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_23901 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_23901[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_23901[(1)] = (1));

return statearr_23901;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_23885){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_23885);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e23902){if((e23902 instanceof Object)){
var ex__7949__auto__ = e23902;
var statearr_23903_23917 = state_23885;
(statearr_23903_23917[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_23885);

return cljs.core.cst$kw$recur;
} else {
throw e23902;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__23918 = state_23885;
state_23885 = G__23918;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_23885){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_23885);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___23906,out))
})();
var state__8054__auto__ = (function (){var statearr_23904 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_23904[(6)] = c__8052__auto___23906);

return statearr_23904;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___23906,out))
);


return out;
});

cljs.core.async.take.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_LT_ = (function cljs$core$async$map_LT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async23920 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async23920 = (function (f,ch,meta23921){
this.f = f;
this.ch = ch;
this.meta23921 = meta23921;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async23920.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_23922,meta23921__$1){
var self__ = this;
var _23922__$1 = this;
return (new cljs.core.async.t_cljs$core$async23920(self__.f,self__.ch,meta23921__$1));
});

cljs.core.async.t_cljs$core$async23920.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_23922){
var self__ = this;
var _23922__$1 = this;
return self__.meta23921;
});

cljs.core.async.t_cljs$core$async23920.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23920.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async23920.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async23920.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23920.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
var ret = cljs.core.async.impl.protocols.take_BANG_(self__.ch,(function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async23923 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async23923 = (function (f,ch,meta23921,_,fn1,meta23924){
this.f = f;
this.ch = ch;
this.meta23921 = meta23921;
this._ = _;
this.fn1 = fn1;
this.meta23924 = meta23924;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async23923.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (___$1){
return (function (_23925,meta23924__$1){
var self__ = this;
var _23925__$1 = this;
return (new cljs.core.async.t_cljs$core$async23923(self__.f,self__.ch,self__.meta23921,self__._,self__.fn1,meta23924__$1));
});})(___$1))
;

cljs.core.async.t_cljs$core$async23923.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (___$1){
return (function (_23925){
var self__ = this;
var _23925__$1 = this;
return self__.meta23924;
});})(___$1))
;

cljs.core.async.t_cljs$core$async23923.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23923.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.fn1);
});})(___$1))
;

cljs.core.async.t_cljs$core$async23923.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return true;
});})(___$1))
;

cljs.core.async.t_cljs$core$async23923.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
var f1 = cljs.core.async.impl.protocols.commit(self__.fn1);
return ((function (f1,___$2,___$1){
return (function (p1__23919_SHARP_){
var G__23926 = (((p1__23919_SHARP_ == null))?null:(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(p1__23919_SHARP_) : self__.f.call(null,p1__23919_SHARP_)));
return (f1.cljs$core$IFn$_invoke$arity$1 ? f1.cljs$core$IFn$_invoke$arity$1(G__23926) : f1.call(null,G__23926));
});
;})(f1,___$2,___$1))
});})(___$1))
;

cljs.core.async.t_cljs$core$async23923.getBasis = ((function (___$1){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta23921,cljs.core.with_meta(cljs.core.cst$sym$_,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$tag,cljs.core.cst$sym$cljs$core$async_SLASH_t_cljs$core$async23920], null)),cljs.core.cst$sym$fn1,cljs.core.cst$sym$meta23924], null);
});})(___$1))
;

cljs.core.async.t_cljs$core$async23923.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async23923.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async23923";

cljs.core.async.t_cljs$core$async23923.cljs$lang$ctorPrWriter = ((function (___$1){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async23923");
});})(___$1))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async23923.
 */
cljs.core.async.__GT_t_cljs$core$async23923 = ((function (___$1){
return (function cljs$core$async$map_LT__$___GT_t_cljs$core$async23923(f__$1,ch__$1,meta23921__$1,___$2,fn1__$1,meta23924){
return (new cljs.core.async.t_cljs$core$async23923(f__$1,ch__$1,meta23921__$1,___$2,fn1__$1,meta23924));
});})(___$1))
;

}

return (new cljs.core.async.t_cljs$core$async23923(self__.f,self__.ch,self__.meta23921,___$1,fn1,cljs.core.PersistentArrayMap.EMPTY));
})()
);
if(cljs.core.truth_((function (){var and__4120__auto__ = ret;
if(cljs.core.truth_(and__4120__auto__)){
return (!((cljs.core.deref(ret) == null)));
} else {
return and__4120__auto__;
}
})())){
return cljs.core.async.impl.channels.box((function (){var G__23927 = cljs.core.deref(ret);
return (self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(G__23927) : self__.f.call(null,G__23927));
})());
} else {
return ret;
}
});

cljs.core.async.t_cljs$core$async23920.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23920.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
});

cljs.core.async.t_cljs$core$async23920.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta23921], null);
});

cljs.core.async.t_cljs$core$async23920.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async23920.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async23920";

cljs.core.async.t_cljs$core$async23920.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async23920");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async23920.
 */
cljs.core.async.__GT_t_cljs$core$async23920 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async23920(f__$1,ch__$1,meta23921){
return (new cljs.core.async.t_cljs$core$async23920(f__$1,ch__$1,meta23921));
});

}

return (new cljs.core.async.t_cljs$core$async23920(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_GT_ = (function cljs$core$async$map_GT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async23928 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async23928 = (function (f,ch,meta23929){
this.f = f;
this.ch = ch;
this.meta23929 = meta23929;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async23928.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_23930,meta23929__$1){
var self__ = this;
var _23930__$1 = this;
return (new cljs.core.async.t_cljs$core$async23928(self__.f,self__.ch,meta23929__$1));
});

cljs.core.async.t_cljs$core$async23928.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_23930){
var self__ = this;
var _23930__$1 = this;
return self__.meta23929;
});

cljs.core.async.t_cljs$core$async23928.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23928.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async23928.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23928.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async23928.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23928.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(val) : self__.f.call(null,val)),fn1);
});

cljs.core.async.t_cljs$core$async23928.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta23929], null);
});

cljs.core.async.t_cljs$core$async23928.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async23928.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async23928";

cljs.core.async.t_cljs$core$async23928.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async23928");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async23928.
 */
cljs.core.async.__GT_t_cljs$core$async23928 = (function cljs$core$async$map_GT__$___GT_t_cljs$core$async23928(f__$1,ch__$1,meta23929){
return (new cljs.core.async.t_cljs$core$async23928(f__$1,ch__$1,meta23929));
});

}

return (new cljs.core.async.t_cljs$core$async23928(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_GT_ = (function cljs$core$async$filter_GT_(p,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async23931 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async23931 = (function (p,ch,meta23932){
this.p = p;
this.ch = ch;
this.meta23932 = meta23932;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async23931.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_23933,meta23932__$1){
var self__ = this;
var _23933__$1 = this;
return (new cljs.core.async.t_cljs$core$async23931(self__.p,self__.ch,meta23932__$1));
});

cljs.core.async.t_cljs$core$async23931.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_23933){
var self__ = this;
var _23933__$1 = this;
return self__.meta23932;
});

cljs.core.async.t_cljs$core$async23931.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23931.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async23931.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async23931.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23931.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async23931.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async23931.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_((self__.p.cljs$core$IFn$_invoke$arity$1 ? self__.p.cljs$core$IFn$_invoke$arity$1(val) : self__.p.call(null,val)))){
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
} else {
return cljs.core.async.impl.channels.box(cljs.core.not(cljs.core.async.impl.protocols.closed_QMARK_(self__.ch)));
}
});

cljs.core.async.t_cljs$core$async23931.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$p,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta23932], null);
});

cljs.core.async.t_cljs$core$async23931.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async23931.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async23931";

cljs.core.async.t_cljs$core$async23931.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async23931");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async23931.
 */
cljs.core.async.__GT_t_cljs$core$async23931 = (function cljs$core$async$filter_GT__$___GT_t_cljs$core$async23931(p__$1,ch__$1,meta23932){
return (new cljs.core.async.t_cljs$core$async23931(p__$1,ch__$1,meta23932));
});

}

return (new cljs.core.async.t_cljs$core$async23931(p,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_GT_ = (function cljs$core$async$remove_GT_(p,ch){
return cljs.core.async.filter_GT_(cljs.core.complement(p),ch);
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_LT_ = (function cljs$core$async$filter_LT_(var_args){
var G__23935 = arguments.length;
switch (G__23935) {
case 2:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__8052__auto___23975 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___23975,out){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___23975,out){
return (function (state_23956){
var state_val_23957 = (state_23956[(1)]);
if((state_val_23957 === (7))){
var inst_23952 = (state_23956[(2)]);
var state_23956__$1 = state_23956;
var statearr_23958_23976 = state_23956__$1;
(statearr_23958_23976[(2)] = inst_23952);

(statearr_23958_23976[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23957 === (1))){
var state_23956__$1 = state_23956;
var statearr_23959_23977 = state_23956__$1;
(statearr_23959_23977[(2)] = null);

(statearr_23959_23977[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23957 === (4))){
var inst_23938 = (state_23956[(7)]);
var inst_23938__$1 = (state_23956[(2)]);
var inst_23939 = (inst_23938__$1 == null);
var state_23956__$1 = (function (){var statearr_23960 = state_23956;
(statearr_23960[(7)] = inst_23938__$1);

return statearr_23960;
})();
if(cljs.core.truth_(inst_23939)){
var statearr_23961_23978 = state_23956__$1;
(statearr_23961_23978[(1)] = (5));

} else {
var statearr_23962_23979 = state_23956__$1;
(statearr_23962_23979[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23957 === (6))){
var inst_23938 = (state_23956[(7)]);
var inst_23943 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_23938) : p.call(null,inst_23938));
var state_23956__$1 = state_23956;
if(cljs.core.truth_(inst_23943)){
var statearr_23963_23980 = state_23956__$1;
(statearr_23963_23980[(1)] = (8));

} else {
var statearr_23964_23981 = state_23956__$1;
(statearr_23964_23981[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_23957 === (3))){
var inst_23954 = (state_23956[(2)]);
var state_23956__$1 = state_23956;
return cljs.core.async.impl.ioc_helpers.return_chan(state_23956__$1,inst_23954);
} else {
if((state_val_23957 === (2))){
var state_23956__$1 = state_23956;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_23956__$1,(4),ch);
} else {
if((state_val_23957 === (11))){
var inst_23946 = (state_23956[(2)]);
var state_23956__$1 = state_23956;
var statearr_23965_23982 = state_23956__$1;
(statearr_23965_23982[(2)] = inst_23946);

(statearr_23965_23982[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23957 === (9))){
var state_23956__$1 = state_23956;
var statearr_23966_23983 = state_23956__$1;
(statearr_23966_23983[(2)] = null);

(statearr_23966_23983[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23957 === (5))){
var inst_23941 = cljs.core.async.close_BANG_(out);
var state_23956__$1 = state_23956;
var statearr_23967_23984 = state_23956__$1;
(statearr_23967_23984[(2)] = inst_23941);

(statearr_23967_23984[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23957 === (10))){
var inst_23949 = (state_23956[(2)]);
var state_23956__$1 = (function (){var statearr_23968 = state_23956;
(statearr_23968[(8)] = inst_23949);

return statearr_23968;
})();
var statearr_23969_23985 = state_23956__$1;
(statearr_23969_23985[(2)] = null);

(statearr_23969_23985[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_23957 === (8))){
var inst_23938 = (state_23956[(7)]);
var state_23956__$1 = state_23956;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_23956__$1,(11),out,inst_23938);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___23975,out))
;
return ((function (switch__7945__auto__,c__8052__auto___23975,out){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_23970 = [null,null,null,null,null,null,null,null,null];
(statearr_23970[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_23970[(1)] = (1));

return statearr_23970;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_23956){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_23956);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e23971){if((e23971 instanceof Object)){
var ex__7949__auto__ = e23971;
var statearr_23972_23986 = state_23956;
(statearr_23972_23986[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_23956);

return cljs.core.cst$kw$recur;
} else {
throw e23971;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__23987 = state_23956;
state_23956 = G__23987;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_23956){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_23956);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___23975,out))
})();
var state__8054__auto__ = (function (){var statearr_23973 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_23973[(6)] = c__8052__auto___23975);

return statearr_23973;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___23975,out))
);


return out;
});

cljs.core.async.filter_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_LT_ = (function cljs$core$async$remove_LT_(var_args){
var G__23989 = arguments.length;
switch (G__23989) {
case 2:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(cljs.core.complement(p),ch,buf_or_n);
});

cljs.core.async.remove_LT_.cljs$lang$maxFixedArity = 3;

cljs.core.async.mapcat_STAR_ = (function cljs$core$async$mapcat_STAR_(f,in$,out){
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__){
return (function (state_24052){
var state_val_24053 = (state_24052[(1)]);
if((state_val_24053 === (7))){
var inst_24048 = (state_24052[(2)]);
var state_24052__$1 = state_24052;
var statearr_24054_24092 = state_24052__$1;
(statearr_24054_24092[(2)] = inst_24048);

(statearr_24054_24092[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (20))){
var inst_24018 = (state_24052[(7)]);
var inst_24029 = (state_24052[(2)]);
var inst_24030 = cljs.core.next(inst_24018);
var inst_24004 = inst_24030;
var inst_24005 = null;
var inst_24006 = (0);
var inst_24007 = (0);
var state_24052__$1 = (function (){var statearr_24055 = state_24052;
(statearr_24055[(8)] = inst_24029);

(statearr_24055[(9)] = inst_24006);

(statearr_24055[(10)] = inst_24005);

(statearr_24055[(11)] = inst_24007);

(statearr_24055[(12)] = inst_24004);

return statearr_24055;
})();
var statearr_24056_24093 = state_24052__$1;
(statearr_24056_24093[(2)] = null);

(statearr_24056_24093[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (1))){
var state_24052__$1 = state_24052;
var statearr_24057_24094 = state_24052__$1;
(statearr_24057_24094[(2)] = null);

(statearr_24057_24094[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (4))){
var inst_23993 = (state_24052[(13)]);
var inst_23993__$1 = (state_24052[(2)]);
var inst_23994 = (inst_23993__$1 == null);
var state_24052__$1 = (function (){var statearr_24058 = state_24052;
(statearr_24058[(13)] = inst_23993__$1);

return statearr_24058;
})();
if(cljs.core.truth_(inst_23994)){
var statearr_24059_24095 = state_24052__$1;
(statearr_24059_24095[(1)] = (5));

} else {
var statearr_24060_24096 = state_24052__$1;
(statearr_24060_24096[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (15))){
var state_24052__$1 = state_24052;
var statearr_24064_24097 = state_24052__$1;
(statearr_24064_24097[(2)] = null);

(statearr_24064_24097[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (21))){
var state_24052__$1 = state_24052;
var statearr_24065_24098 = state_24052__$1;
(statearr_24065_24098[(2)] = null);

(statearr_24065_24098[(1)] = (23));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (13))){
var inst_24006 = (state_24052[(9)]);
var inst_24005 = (state_24052[(10)]);
var inst_24007 = (state_24052[(11)]);
var inst_24004 = (state_24052[(12)]);
var inst_24014 = (state_24052[(2)]);
var inst_24015 = (inst_24007 + (1));
var tmp24061 = inst_24006;
var tmp24062 = inst_24005;
var tmp24063 = inst_24004;
var inst_24004__$1 = tmp24063;
var inst_24005__$1 = tmp24062;
var inst_24006__$1 = tmp24061;
var inst_24007__$1 = inst_24015;
var state_24052__$1 = (function (){var statearr_24066 = state_24052;
(statearr_24066[(14)] = inst_24014);

(statearr_24066[(9)] = inst_24006__$1);

(statearr_24066[(10)] = inst_24005__$1);

(statearr_24066[(11)] = inst_24007__$1);

(statearr_24066[(12)] = inst_24004__$1);

return statearr_24066;
})();
var statearr_24067_24099 = state_24052__$1;
(statearr_24067_24099[(2)] = null);

(statearr_24067_24099[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (22))){
var state_24052__$1 = state_24052;
var statearr_24068_24100 = state_24052__$1;
(statearr_24068_24100[(2)] = null);

(statearr_24068_24100[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (6))){
var inst_23993 = (state_24052[(13)]);
var inst_24002 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_23993) : f.call(null,inst_23993));
var inst_24003 = cljs.core.seq(inst_24002);
var inst_24004 = inst_24003;
var inst_24005 = null;
var inst_24006 = (0);
var inst_24007 = (0);
var state_24052__$1 = (function (){var statearr_24069 = state_24052;
(statearr_24069[(9)] = inst_24006);

(statearr_24069[(10)] = inst_24005);

(statearr_24069[(11)] = inst_24007);

(statearr_24069[(12)] = inst_24004);

return statearr_24069;
})();
var statearr_24070_24101 = state_24052__$1;
(statearr_24070_24101[(2)] = null);

(statearr_24070_24101[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (17))){
var inst_24018 = (state_24052[(7)]);
var inst_24022 = cljs.core.chunk_first(inst_24018);
var inst_24023 = cljs.core.chunk_rest(inst_24018);
var inst_24024 = cljs.core.count(inst_24022);
var inst_24004 = inst_24023;
var inst_24005 = inst_24022;
var inst_24006 = inst_24024;
var inst_24007 = (0);
var state_24052__$1 = (function (){var statearr_24071 = state_24052;
(statearr_24071[(9)] = inst_24006);

(statearr_24071[(10)] = inst_24005);

(statearr_24071[(11)] = inst_24007);

(statearr_24071[(12)] = inst_24004);

return statearr_24071;
})();
var statearr_24072_24102 = state_24052__$1;
(statearr_24072_24102[(2)] = null);

(statearr_24072_24102[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (3))){
var inst_24050 = (state_24052[(2)]);
var state_24052__$1 = state_24052;
return cljs.core.async.impl.ioc_helpers.return_chan(state_24052__$1,inst_24050);
} else {
if((state_val_24053 === (12))){
var inst_24038 = (state_24052[(2)]);
var state_24052__$1 = state_24052;
var statearr_24073_24103 = state_24052__$1;
(statearr_24073_24103[(2)] = inst_24038);

(statearr_24073_24103[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (2))){
var state_24052__$1 = state_24052;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_24052__$1,(4),in$);
} else {
if((state_val_24053 === (23))){
var inst_24046 = (state_24052[(2)]);
var state_24052__$1 = state_24052;
var statearr_24074_24104 = state_24052__$1;
(statearr_24074_24104[(2)] = inst_24046);

(statearr_24074_24104[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (19))){
var inst_24033 = (state_24052[(2)]);
var state_24052__$1 = state_24052;
var statearr_24075_24105 = state_24052__$1;
(statearr_24075_24105[(2)] = inst_24033);

(statearr_24075_24105[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (11))){
var inst_24018 = (state_24052[(7)]);
var inst_24004 = (state_24052[(12)]);
var inst_24018__$1 = cljs.core.seq(inst_24004);
var state_24052__$1 = (function (){var statearr_24076 = state_24052;
(statearr_24076[(7)] = inst_24018__$1);

return statearr_24076;
})();
if(inst_24018__$1){
var statearr_24077_24106 = state_24052__$1;
(statearr_24077_24106[(1)] = (14));

} else {
var statearr_24078_24107 = state_24052__$1;
(statearr_24078_24107[(1)] = (15));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (9))){
var inst_24040 = (state_24052[(2)]);
var inst_24041 = cljs.core.async.impl.protocols.closed_QMARK_(out);
var state_24052__$1 = (function (){var statearr_24079 = state_24052;
(statearr_24079[(15)] = inst_24040);

return statearr_24079;
})();
if(cljs.core.truth_(inst_24041)){
var statearr_24080_24108 = state_24052__$1;
(statearr_24080_24108[(1)] = (21));

} else {
var statearr_24081_24109 = state_24052__$1;
(statearr_24081_24109[(1)] = (22));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (5))){
var inst_23996 = cljs.core.async.close_BANG_(out);
var state_24052__$1 = state_24052;
var statearr_24082_24110 = state_24052__$1;
(statearr_24082_24110[(2)] = inst_23996);

(statearr_24082_24110[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (14))){
var inst_24018 = (state_24052[(7)]);
var inst_24020 = cljs.core.chunked_seq_QMARK_(inst_24018);
var state_24052__$1 = state_24052;
if(inst_24020){
var statearr_24083_24111 = state_24052__$1;
(statearr_24083_24111[(1)] = (17));

} else {
var statearr_24084_24112 = state_24052__$1;
(statearr_24084_24112[(1)] = (18));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (16))){
var inst_24036 = (state_24052[(2)]);
var state_24052__$1 = state_24052;
var statearr_24085_24113 = state_24052__$1;
(statearr_24085_24113[(2)] = inst_24036);

(statearr_24085_24113[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24053 === (10))){
var inst_24005 = (state_24052[(10)]);
var inst_24007 = (state_24052[(11)]);
var inst_24012 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_24005,inst_24007);
var state_24052__$1 = state_24052;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_24052__$1,(13),out,inst_24012);
} else {
if((state_val_24053 === (18))){
var inst_24018 = (state_24052[(7)]);
var inst_24027 = cljs.core.first(inst_24018);
var state_24052__$1 = state_24052;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_24052__$1,(20),out,inst_24027);
} else {
if((state_val_24053 === (8))){
var inst_24006 = (state_24052[(9)]);
var inst_24007 = (state_24052[(11)]);
var inst_24009 = (inst_24007 < inst_24006);
var inst_24010 = inst_24009;
var state_24052__$1 = state_24052;
if(cljs.core.truth_(inst_24010)){
var statearr_24086_24114 = state_24052__$1;
(statearr_24086_24114[(1)] = (10));

} else {
var statearr_24087_24115 = state_24052__$1;
(statearr_24087_24115[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto__))
;
return ((function (switch__7945__auto__,c__8052__auto__){
return (function() {
var cljs$core$async$mapcat_STAR__$_state_machine__7946__auto__ = null;
var cljs$core$async$mapcat_STAR__$_state_machine__7946__auto____0 = (function (){
var statearr_24088 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_24088[(0)] = cljs$core$async$mapcat_STAR__$_state_machine__7946__auto__);

(statearr_24088[(1)] = (1));

return statearr_24088;
});
var cljs$core$async$mapcat_STAR__$_state_machine__7946__auto____1 = (function (state_24052){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_24052);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e24089){if((e24089 instanceof Object)){
var ex__7949__auto__ = e24089;
var statearr_24090_24116 = state_24052;
(statearr_24090_24116[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_24052);

return cljs.core.cst$kw$recur;
} else {
throw e24089;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__24117 = state_24052;
state_24052 = G__24117;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$mapcat_STAR__$_state_machine__7946__auto__ = function(state_24052){
switch(arguments.length){
case 0:
return cljs$core$async$mapcat_STAR__$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$mapcat_STAR__$_state_machine__7946__auto____1.call(this,state_24052);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mapcat_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mapcat_STAR__$_state_machine__7946__auto____0;
cljs$core$async$mapcat_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mapcat_STAR__$_state_machine__7946__auto____1;
return cljs$core$async$mapcat_STAR__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_24091 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_24091[(6)] = c__8052__auto__);

return statearr_24091;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__))
);

return c__8052__auto__;
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_LT_ = (function cljs$core$async$mapcat_LT_(var_args){
var G__24119 = arguments.length;
switch (G__24119) {
case 2:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2 = (function (f,in$){
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3(f,in$,null);
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3 = (function (f,in$,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return out;
});

cljs.core.async.mapcat_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_GT_ = (function cljs$core$async$mapcat_GT_(var_args){
var G__24122 = arguments.length;
switch (G__24122) {
case 2:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2 = (function (f,out){
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3(f,out,null);
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3 = (function (f,out,buf_or_n){
var in$ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return in$;
});

cljs.core.async.mapcat_GT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.unique = (function cljs$core$async$unique(var_args){
var G__24125 = arguments.length;
switch (G__24125) {
case 1:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1 = (function (ch){
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2(ch,null);
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2 = (function (ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__8052__auto___24172 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___24172,out){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___24172,out){
return (function (state_24149){
var state_val_24150 = (state_24149[(1)]);
if((state_val_24150 === (7))){
var inst_24144 = (state_24149[(2)]);
var state_24149__$1 = state_24149;
var statearr_24151_24173 = state_24149__$1;
(statearr_24151_24173[(2)] = inst_24144);

(statearr_24151_24173[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24150 === (1))){
var inst_24126 = null;
var state_24149__$1 = (function (){var statearr_24152 = state_24149;
(statearr_24152[(7)] = inst_24126);

return statearr_24152;
})();
var statearr_24153_24174 = state_24149__$1;
(statearr_24153_24174[(2)] = null);

(statearr_24153_24174[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24150 === (4))){
var inst_24129 = (state_24149[(8)]);
var inst_24129__$1 = (state_24149[(2)]);
var inst_24130 = (inst_24129__$1 == null);
var inst_24131 = cljs.core.not(inst_24130);
var state_24149__$1 = (function (){var statearr_24154 = state_24149;
(statearr_24154[(8)] = inst_24129__$1);

return statearr_24154;
})();
if(inst_24131){
var statearr_24155_24175 = state_24149__$1;
(statearr_24155_24175[(1)] = (5));

} else {
var statearr_24156_24176 = state_24149__$1;
(statearr_24156_24176[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_24150 === (6))){
var state_24149__$1 = state_24149;
var statearr_24157_24177 = state_24149__$1;
(statearr_24157_24177[(2)] = null);

(statearr_24157_24177[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24150 === (3))){
var inst_24146 = (state_24149[(2)]);
var inst_24147 = cljs.core.async.close_BANG_(out);
var state_24149__$1 = (function (){var statearr_24158 = state_24149;
(statearr_24158[(9)] = inst_24146);

return statearr_24158;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_24149__$1,inst_24147);
} else {
if((state_val_24150 === (2))){
var state_24149__$1 = state_24149;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_24149__$1,(4),ch);
} else {
if((state_val_24150 === (11))){
var inst_24129 = (state_24149[(8)]);
var inst_24138 = (state_24149[(2)]);
var inst_24126 = inst_24129;
var state_24149__$1 = (function (){var statearr_24159 = state_24149;
(statearr_24159[(10)] = inst_24138);

(statearr_24159[(7)] = inst_24126);

return statearr_24159;
})();
var statearr_24160_24178 = state_24149__$1;
(statearr_24160_24178[(2)] = null);

(statearr_24160_24178[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24150 === (9))){
var inst_24129 = (state_24149[(8)]);
var state_24149__$1 = state_24149;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_24149__$1,(11),out,inst_24129);
} else {
if((state_val_24150 === (5))){
var inst_24129 = (state_24149[(8)]);
var inst_24126 = (state_24149[(7)]);
var inst_24133 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_24129,inst_24126);
var state_24149__$1 = state_24149;
if(inst_24133){
var statearr_24162_24179 = state_24149__$1;
(statearr_24162_24179[(1)] = (8));

} else {
var statearr_24163_24180 = state_24149__$1;
(statearr_24163_24180[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_24150 === (10))){
var inst_24141 = (state_24149[(2)]);
var state_24149__$1 = state_24149;
var statearr_24164_24181 = state_24149__$1;
(statearr_24164_24181[(2)] = inst_24141);

(statearr_24164_24181[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24150 === (8))){
var inst_24126 = (state_24149[(7)]);
var tmp24161 = inst_24126;
var inst_24126__$1 = tmp24161;
var state_24149__$1 = (function (){var statearr_24165 = state_24149;
(statearr_24165[(7)] = inst_24126__$1);

return statearr_24165;
})();
var statearr_24166_24182 = state_24149__$1;
(statearr_24166_24182[(2)] = null);

(statearr_24166_24182[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___24172,out))
;
return ((function (switch__7945__auto__,c__8052__auto___24172,out){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_24167 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_24167[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_24167[(1)] = (1));

return statearr_24167;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_24149){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_24149);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e24168){if((e24168 instanceof Object)){
var ex__7949__auto__ = e24168;
var statearr_24169_24183 = state_24149;
(statearr_24169_24183[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_24149);

return cljs.core.cst$kw$recur;
} else {
throw e24168;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__24184 = state_24149;
state_24149 = G__24184;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_24149){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_24149);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___24172,out))
})();
var state__8054__auto__ = (function (){var statearr_24170 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_24170[(6)] = c__8052__auto___24172);

return statearr_24170;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___24172,out))
);


return out;
});

cljs.core.async.unique.cljs$lang$maxFixedArity = 2;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition = (function cljs$core$async$partition(var_args){
var G__24186 = arguments.length;
switch (G__24186) {
case 2:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__8052__auto___24252 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___24252,out){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___24252,out){
return (function (state_24224){
var state_val_24225 = (state_24224[(1)]);
if((state_val_24225 === (7))){
var inst_24220 = (state_24224[(2)]);
var state_24224__$1 = state_24224;
var statearr_24226_24253 = state_24224__$1;
(statearr_24226_24253[(2)] = inst_24220);

(statearr_24226_24253[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24225 === (1))){
var inst_24187 = (new Array(n));
var inst_24188 = inst_24187;
var inst_24189 = (0);
var state_24224__$1 = (function (){var statearr_24227 = state_24224;
(statearr_24227[(7)] = inst_24189);

(statearr_24227[(8)] = inst_24188);

return statearr_24227;
})();
var statearr_24228_24254 = state_24224__$1;
(statearr_24228_24254[(2)] = null);

(statearr_24228_24254[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24225 === (4))){
var inst_24192 = (state_24224[(9)]);
var inst_24192__$1 = (state_24224[(2)]);
var inst_24193 = (inst_24192__$1 == null);
var inst_24194 = cljs.core.not(inst_24193);
var state_24224__$1 = (function (){var statearr_24229 = state_24224;
(statearr_24229[(9)] = inst_24192__$1);

return statearr_24229;
})();
if(inst_24194){
var statearr_24230_24255 = state_24224__$1;
(statearr_24230_24255[(1)] = (5));

} else {
var statearr_24231_24256 = state_24224__$1;
(statearr_24231_24256[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_24225 === (15))){
var inst_24214 = (state_24224[(2)]);
var state_24224__$1 = state_24224;
var statearr_24232_24257 = state_24224__$1;
(statearr_24232_24257[(2)] = inst_24214);

(statearr_24232_24257[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24225 === (13))){
var state_24224__$1 = state_24224;
var statearr_24233_24258 = state_24224__$1;
(statearr_24233_24258[(2)] = null);

(statearr_24233_24258[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24225 === (6))){
var inst_24189 = (state_24224[(7)]);
var inst_24210 = (inst_24189 > (0));
var state_24224__$1 = state_24224;
if(cljs.core.truth_(inst_24210)){
var statearr_24234_24259 = state_24224__$1;
(statearr_24234_24259[(1)] = (12));

} else {
var statearr_24235_24260 = state_24224__$1;
(statearr_24235_24260[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_24225 === (3))){
var inst_24222 = (state_24224[(2)]);
var state_24224__$1 = state_24224;
return cljs.core.async.impl.ioc_helpers.return_chan(state_24224__$1,inst_24222);
} else {
if((state_val_24225 === (12))){
var inst_24188 = (state_24224[(8)]);
var inst_24212 = cljs.core.vec(inst_24188);
var state_24224__$1 = state_24224;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_24224__$1,(15),out,inst_24212);
} else {
if((state_val_24225 === (2))){
var state_24224__$1 = state_24224;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_24224__$1,(4),ch);
} else {
if((state_val_24225 === (11))){
var inst_24204 = (state_24224[(2)]);
var inst_24205 = (new Array(n));
var inst_24188 = inst_24205;
var inst_24189 = (0);
var state_24224__$1 = (function (){var statearr_24236 = state_24224;
(statearr_24236[(7)] = inst_24189);

(statearr_24236[(10)] = inst_24204);

(statearr_24236[(8)] = inst_24188);

return statearr_24236;
})();
var statearr_24237_24261 = state_24224__$1;
(statearr_24237_24261[(2)] = null);

(statearr_24237_24261[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24225 === (9))){
var inst_24188 = (state_24224[(8)]);
var inst_24202 = cljs.core.vec(inst_24188);
var state_24224__$1 = state_24224;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_24224__$1,(11),out,inst_24202);
} else {
if((state_val_24225 === (5))){
var inst_24189 = (state_24224[(7)]);
var inst_24188 = (state_24224[(8)]);
var inst_24197 = (state_24224[(11)]);
var inst_24192 = (state_24224[(9)]);
var inst_24196 = (inst_24188[inst_24189] = inst_24192);
var inst_24197__$1 = (inst_24189 + (1));
var inst_24198 = (inst_24197__$1 < n);
var state_24224__$1 = (function (){var statearr_24238 = state_24224;
(statearr_24238[(12)] = inst_24196);

(statearr_24238[(11)] = inst_24197__$1);

return statearr_24238;
})();
if(cljs.core.truth_(inst_24198)){
var statearr_24239_24262 = state_24224__$1;
(statearr_24239_24262[(1)] = (8));

} else {
var statearr_24240_24263 = state_24224__$1;
(statearr_24240_24263[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_24225 === (14))){
var inst_24217 = (state_24224[(2)]);
var inst_24218 = cljs.core.async.close_BANG_(out);
var state_24224__$1 = (function (){var statearr_24242 = state_24224;
(statearr_24242[(13)] = inst_24217);

return statearr_24242;
})();
var statearr_24243_24264 = state_24224__$1;
(statearr_24243_24264[(2)] = inst_24218);

(statearr_24243_24264[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24225 === (10))){
var inst_24208 = (state_24224[(2)]);
var state_24224__$1 = state_24224;
var statearr_24244_24265 = state_24224__$1;
(statearr_24244_24265[(2)] = inst_24208);

(statearr_24244_24265[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24225 === (8))){
var inst_24188 = (state_24224[(8)]);
var inst_24197 = (state_24224[(11)]);
var tmp24241 = inst_24188;
var inst_24188__$1 = tmp24241;
var inst_24189 = inst_24197;
var state_24224__$1 = (function (){var statearr_24245 = state_24224;
(statearr_24245[(7)] = inst_24189);

(statearr_24245[(8)] = inst_24188__$1);

return statearr_24245;
})();
var statearr_24246_24266 = state_24224__$1;
(statearr_24246_24266[(2)] = null);

(statearr_24246_24266[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___24252,out))
;
return ((function (switch__7945__auto__,c__8052__auto___24252,out){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_24247 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_24247[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_24247[(1)] = (1));

return statearr_24247;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_24224){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_24224);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e24248){if((e24248 instanceof Object)){
var ex__7949__auto__ = e24248;
var statearr_24249_24267 = state_24224;
(statearr_24249_24267[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_24224);

return cljs.core.cst$kw$recur;
} else {
throw e24248;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__24268 = state_24224;
state_24224 = G__24268;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_24224){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_24224);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___24252,out))
})();
var state__8054__auto__ = (function (){var statearr_24250 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_24250[(6)] = c__8052__auto___24252);

return statearr_24250;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___24252,out))
);


return out;
});

cljs.core.async.partition.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition_by = (function cljs$core$async$partition_by(var_args){
var G__24270 = arguments.length;
switch (G__24270) {
case 2:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2 = (function (f,ch){
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3(f,ch,null);
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3 = (function (f,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__8052__auto___24340 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___24340,out){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___24340,out){
return (function (state_24312){
var state_val_24313 = (state_24312[(1)]);
if((state_val_24313 === (7))){
var inst_24308 = (state_24312[(2)]);
var state_24312__$1 = state_24312;
var statearr_24314_24341 = state_24312__$1;
(statearr_24314_24341[(2)] = inst_24308);

(statearr_24314_24341[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24313 === (1))){
var inst_24271 = [];
var inst_24272 = inst_24271;
var inst_24273 = cljs.core.cst$kw$cljs$core$async_SLASH_nothing;
var state_24312__$1 = (function (){var statearr_24315 = state_24312;
(statearr_24315[(7)] = inst_24272);

(statearr_24315[(8)] = inst_24273);

return statearr_24315;
})();
var statearr_24316_24342 = state_24312__$1;
(statearr_24316_24342[(2)] = null);

(statearr_24316_24342[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24313 === (4))){
var inst_24276 = (state_24312[(9)]);
var inst_24276__$1 = (state_24312[(2)]);
var inst_24277 = (inst_24276__$1 == null);
var inst_24278 = cljs.core.not(inst_24277);
var state_24312__$1 = (function (){var statearr_24317 = state_24312;
(statearr_24317[(9)] = inst_24276__$1);

return statearr_24317;
})();
if(inst_24278){
var statearr_24318_24343 = state_24312__$1;
(statearr_24318_24343[(1)] = (5));

} else {
var statearr_24319_24344 = state_24312__$1;
(statearr_24319_24344[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_24313 === (15))){
var inst_24302 = (state_24312[(2)]);
var state_24312__$1 = state_24312;
var statearr_24320_24345 = state_24312__$1;
(statearr_24320_24345[(2)] = inst_24302);

(statearr_24320_24345[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24313 === (13))){
var state_24312__$1 = state_24312;
var statearr_24321_24346 = state_24312__$1;
(statearr_24321_24346[(2)] = null);

(statearr_24321_24346[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24313 === (6))){
var inst_24272 = (state_24312[(7)]);
var inst_24297 = inst_24272.length;
var inst_24298 = (inst_24297 > (0));
var state_24312__$1 = state_24312;
if(cljs.core.truth_(inst_24298)){
var statearr_24322_24347 = state_24312__$1;
(statearr_24322_24347[(1)] = (12));

} else {
var statearr_24323_24348 = state_24312__$1;
(statearr_24323_24348[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_24313 === (3))){
var inst_24310 = (state_24312[(2)]);
var state_24312__$1 = state_24312;
return cljs.core.async.impl.ioc_helpers.return_chan(state_24312__$1,inst_24310);
} else {
if((state_val_24313 === (12))){
var inst_24272 = (state_24312[(7)]);
var inst_24300 = cljs.core.vec(inst_24272);
var state_24312__$1 = state_24312;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_24312__$1,(15),out,inst_24300);
} else {
if((state_val_24313 === (2))){
var state_24312__$1 = state_24312;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_24312__$1,(4),ch);
} else {
if((state_val_24313 === (11))){
var inst_24276 = (state_24312[(9)]);
var inst_24280 = (state_24312[(10)]);
var inst_24290 = (state_24312[(2)]);
var inst_24291 = [];
var inst_24292 = inst_24291.push(inst_24276);
var inst_24272 = inst_24291;
var inst_24273 = inst_24280;
var state_24312__$1 = (function (){var statearr_24324 = state_24312;
(statearr_24324[(11)] = inst_24290);

(statearr_24324[(7)] = inst_24272);

(statearr_24324[(8)] = inst_24273);

(statearr_24324[(12)] = inst_24292);

return statearr_24324;
})();
var statearr_24325_24349 = state_24312__$1;
(statearr_24325_24349[(2)] = null);

(statearr_24325_24349[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24313 === (9))){
var inst_24272 = (state_24312[(7)]);
var inst_24288 = cljs.core.vec(inst_24272);
var state_24312__$1 = state_24312;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_24312__$1,(11),out,inst_24288);
} else {
if((state_val_24313 === (5))){
var inst_24276 = (state_24312[(9)]);
var inst_24280 = (state_24312[(10)]);
var inst_24273 = (state_24312[(8)]);
var inst_24280__$1 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_24276) : f.call(null,inst_24276));
var inst_24281 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_24280__$1,inst_24273);
var inst_24282 = cljs.core.keyword_identical_QMARK_(inst_24273,cljs.core.cst$kw$cljs$core$async_SLASH_nothing);
var inst_24283 = ((inst_24281) || (inst_24282));
var state_24312__$1 = (function (){var statearr_24326 = state_24312;
(statearr_24326[(10)] = inst_24280__$1);

return statearr_24326;
})();
if(cljs.core.truth_(inst_24283)){
var statearr_24327_24350 = state_24312__$1;
(statearr_24327_24350[(1)] = (8));

} else {
var statearr_24328_24351 = state_24312__$1;
(statearr_24328_24351[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_24313 === (14))){
var inst_24305 = (state_24312[(2)]);
var inst_24306 = cljs.core.async.close_BANG_(out);
var state_24312__$1 = (function (){var statearr_24330 = state_24312;
(statearr_24330[(13)] = inst_24305);

return statearr_24330;
})();
var statearr_24331_24352 = state_24312__$1;
(statearr_24331_24352[(2)] = inst_24306);

(statearr_24331_24352[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24313 === (10))){
var inst_24295 = (state_24312[(2)]);
var state_24312__$1 = state_24312;
var statearr_24332_24353 = state_24312__$1;
(statearr_24332_24353[(2)] = inst_24295);

(statearr_24332_24353[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_24313 === (8))){
var inst_24276 = (state_24312[(9)]);
var inst_24280 = (state_24312[(10)]);
var inst_24272 = (state_24312[(7)]);
var inst_24285 = inst_24272.push(inst_24276);
var tmp24329 = inst_24272;
var inst_24272__$1 = tmp24329;
var inst_24273 = inst_24280;
var state_24312__$1 = (function (){var statearr_24333 = state_24312;
(statearr_24333[(14)] = inst_24285);

(statearr_24333[(7)] = inst_24272__$1);

(statearr_24333[(8)] = inst_24273);

return statearr_24333;
})();
var statearr_24334_24354 = state_24312__$1;
(statearr_24334_24354[(2)] = null);

(statearr_24334_24354[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___24340,out))
;
return ((function (switch__7945__auto__,c__8052__auto___24340,out){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_24335 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_24335[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_24335[(1)] = (1));

return statearr_24335;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_24312){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_24312);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e24336){if((e24336 instanceof Object)){
var ex__7949__auto__ = e24336;
var statearr_24337_24355 = state_24312;
(statearr_24337_24355[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_24312);

return cljs.core.cst$kw$recur;
} else {
throw e24336;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__24356 = state_24312;
state_24312 = G__24356;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_24312){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_24312);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___24340,out))
})();
var state__8054__auto__ = (function (){var statearr_24338 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_24338[(6)] = c__8052__auto___24340);

return statearr_24338;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___24340,out))
);


return out;
});

cljs.core.async.partition_by.cljs$lang$maxFixedArity = 3;


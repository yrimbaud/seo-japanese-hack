// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('google_webmaster_tools_bulk_url_removal.content_script.common');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async');
goog.require('chromex.logging');
goog.require('cognitect.transit');
goog.require('cemerick.url');
google_webmaster_tools_bulk_url_removal.content_script.common.run_message_loop_BANG_ = (function google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG_(message_channel,message_handler_BANG_){
console.log("CONTENT SCRIPT: starting message loop...");


var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__){
return (function (state_32175){
var state_val_32176 = (state_32175[(1)]);
if((state_val_32176 === (1))){
var state_32175__$1 = state_32175;
var statearr_32177_32190 = state_32175__$1;
(statearr_32177_32190[(2)] = null);

(statearr_32177_32190[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_32176 === (2))){
var state_32175__$1 = state_32175;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_32175__$1,(4),message_channel);
} else {
if((state_val_32176 === (3))){
var inst_32173 = (state_32175[(2)]);
var state_32175__$1 = state_32175;
return cljs.core.async.impl.ioc_helpers.return_chan(state_32175__$1,inst_32173);
} else {
if((state_val_32176 === (4))){
var inst_32163 = (state_32175[(7)]);
var inst_32163__$1 = (state_32175[(2)]);
var inst_32164 = (inst_32163__$1 == null);
var state_32175__$1 = (function (){var statearr_32178 = state_32175;
(statearr_32178[(7)] = inst_32163__$1);

return statearr_32178;
})();
if(cljs.core.truth_(inst_32164)){
var statearr_32179_32191 = state_32175__$1;
(statearr_32179_32191[(1)] = (5));

} else {
var statearr_32180_32192 = state_32175__$1;
(statearr_32180_32192[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_32176 === (5))){
var state_32175__$1 = state_32175;
var statearr_32181_32193 = state_32175__$1;
(statearr_32181_32193[(2)] = null);

(statearr_32181_32193[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_32176 === (6))){
var inst_32163 = (state_32175[(7)]);
var inst_32167 = (message_handler_BANG_.cljs$core$IFn$_invoke$arity$2 ? message_handler_BANG_.cljs$core$IFn$_invoke$arity$2(message_channel,inst_32163) : message_handler_BANG_.call(null,message_channel,inst_32163));
var state_32175__$1 = (function (){var statearr_32182 = state_32175;
(statearr_32182[(8)] = inst_32167);

return statearr_32182;
})();
var statearr_32183_32194 = state_32175__$1;
(statearr_32183_32194[(2)] = null);

(statearr_32183_32194[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_32176 === (7))){
var inst_32170 = (state_32175[(2)]);
var inst_32171 = console.log("CONTENT SCRIPT: leaving message loop");
var state_32175__$1 = (function (){var statearr_32184 = state_32175;
(statearr_32184[(9)] = inst_32170);

(statearr_32184[(10)] = inst_32171);

return statearr_32184;
})();
var statearr_32185_32195 = state_32175__$1;
(statearr_32185_32195[(2)] = null);

(statearr_32185_32195[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(c__8052__auto__))
;
return ((function (switch__7945__auto__,c__8052__auto__){
return (function() {
var google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto____0 = (function (){
var statearr_32186 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_32186[(0)] = google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto__);

(statearr_32186[(1)] = (1));

return statearr_32186;
});
var google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto____1 = (function (state_32175){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_32175);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e32187){if((e32187 instanceof Object)){
var ex__7949__auto__ = e32187;
var statearr_32188_32196 = state_32175;
(statearr_32188_32196[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_32175);

return cljs.core.cst$kw$recur;
} else {
throw e32187;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__32197 = state_32175;
state_32175 = G__32197;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto__ = function(state_32175){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto____1.call(this,state_32175);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_32189 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_32189[(6)] = c__8052__auto__);

return statearr_32189;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__))
);

return c__8052__auto__;
});
google_webmaster_tools_bulk_url_removal.content_script.common.connect_to_background_page_BANG_ = (function google_webmaster_tools_bulk_url_removal$content_script$common$connect_to_background_page_BANG_(background_port,message_handler_BANG_){
return google_webmaster_tools_bulk_url_removal.content_script.common.run_message_loop_BANG_(background_port,message_handler_BANG_);
});
google_webmaster_tools_bulk_url_removal.content_script.common.marshall = (function google_webmaster_tools_bulk_url_removal$content_script$common$marshall(edn_msg){
var w = cognitect.transit.writer.cljs$core$IFn$_invoke$arity$1(cljs.core.cst$kw$json);
return cognitect.transit.write(w,edn_msg);
});
google_webmaster_tools_bulk_url_removal.content_script.common.unmarshall = (function google_webmaster_tools_bulk_url_removal$content_script$common$unmarshall(msg_str){
var r = cognitect.transit.reader.cljs$core$IFn$_invoke$arity$1(cljs.core.cst$kw$json);
return cognitect.transit.read(r,msg_str);
});
google_webmaster_tools_bulk_url_removal.content_script.common.normalize_url_encoding = (function google_webmaster_tools_bulk_url_removal$content_script$common$normalize_url_encoding(fq_url){
var url_parts = cemerick.url.url.cljs$core$IFn$_invoke$arity$1(fq_url);
var normalized_path = cemerick.url.url_encode(cemerick.url.url_decode(cljs.core.subs.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$path.cljs$core$IFn$_invoke$arity$1(url_parts),(1))));
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(url_parts,cljs.core.cst$kw$path,["/",cljs.core.str.cljs$core$IFn$_invoke$arity$1(normalized_path)].join(''));
});
google_webmaster_tools_bulk_url_removal.content_script.common.fq_victim_url = (function google_webmaster_tools_bulk_url_removal$content_script$common$fq_victim_url(victim_url){
var domain_name = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(cemerick.url.url.cljs$core$IFn$_invoke$arity$1(window.location.href),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$query,"siteUrl"], null));
return google_webmaster_tools_bulk_url_removal.content_script.common.normalize_url_encoding(((clojure.string.starts_with_QMARK_(victim_url,"http"))?victim_url:((clojure.string.ends_with_QMARK_(victim_url,"/"))?[cljs.core.str.cljs$core$IFn$_invoke$arity$1(cemerick.url.url.cljs$core$IFn$_invoke$arity$variadic(domain_name,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([victim_url], 0))),"/"].join(''):cljs.core.str.cljs$core$IFn$_invoke$arity$1(cemerick.url.url.cljs$core$IFn$_invoke$arity$variadic(domain_name,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([victim_url], 0)))
)));
});

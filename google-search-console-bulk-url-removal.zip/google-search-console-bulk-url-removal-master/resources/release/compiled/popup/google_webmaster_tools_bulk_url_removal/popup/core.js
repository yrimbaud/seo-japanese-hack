// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('google_webmaster_tools_bulk_url_removal.popup.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async');
goog.require('hipo.core');
goog.require('dommy.core');
goog.require('domina');
goog.require('domina.xpath');
goog.require('chromex.logging');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.ext.runtime');
goog.require('chromex.ext.downloads');
goog.require('chromex.ext.browser_action');
goog.require('cemerick.url');
goog.require('re_com.core');
goog.require('testdouble.cljs.csv');
goog.require('google_webmaster_tools_bulk_url_removal.content_script.common');
goog.require('reagent.core');
goog.require('google_webmaster_tools_bulk_url_removal.background.storage');
google_webmaster_tools_bulk_url_removal.popup.core.my_status = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.cst$kw$done);
google_webmaster_tools_bulk_url_removal.popup.core.upload_chan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((1),cljs.core.map.cljs$core$IFn$_invoke$arity$1((function (e){
var target = e.currentTarget;
var file = (target.files[(0)]);
target.value = "";

return file;
})));
google_webmaster_tools_bulk_url_removal.popup.core.read_chan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((1),cljs.core.map.cljs$core$IFn$_invoke$arity$1((function (p1__32326_SHARP_){
return cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(p1__32326_SHARP_.target.result);
})));
google_webmaster_tools_bulk_url_removal.popup.core.cached_bad_victims_atom = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
google_webmaster_tools_bulk_url_removal.popup.core.process_message_BANG_ = (function google_webmaster_tools_bulk_url_removal$popup$core$process_message_BANG_(channel,message){
var map__32327 = google_webmaster_tools_bulk_url_removal.content_script.common.unmarshall(message);
var map__32327__$1 = (((((!((map__32327 == null))))?(((((map__32327.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__32327.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__32327):map__32327);
var whole_edn = map__32327__$1;
var type = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__32327__$1,cljs.core.cst$kw$type);
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(type,cljs.core.cst$kw$init_DASH_errors)){
cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["init-errors: ",whole_edn], 0));

return cljs.core.reset_BANG_(google_webmaster_tools_bulk_url_removal.popup.core.cached_bad_victims_atom,cljs.core.vec(cljs.core.cst$kw$bad_DASH_victims.cljs$core$IFn$_invoke$arity$1(whole_edn)));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(type,cljs.core.cst$kw$new_DASH_error)){
cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["new-error: ",whole_edn], 0));

return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(google_webmaster_tools_bulk_url_removal.popup.core.cached_bad_victims_atom,cljs.core.conj,cljs.core.first(cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentVector.EMPTY,cljs.core.cst$kw$error.cljs$core$IFn$_invoke$arity$1(whole_edn))));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(type,cljs.core.cst$kw$done)){
cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["done: ",whole_edn], 0));

return cljs.core.reset_BANG_(google_webmaster_tools_bulk_url_removal.popup.core.my_status,cljs.core.cst$kw$done);
} else {
return null;
}
}
}
});
google_webmaster_tools_bulk_url_removal.popup.core.run_message_loop_BANG_ = (function google_webmaster_tools_bulk_url_removal$popup$core$run_message_loop_BANG_(message_channel){
console.log("POPUP: starting message loop...");


var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__){
return (function (state_32343){
var state_val_32344 = (state_32343[(1)]);
if((state_val_32344 === (1))){
var state_32343__$1 = state_32343;
var statearr_32345_32358 = state_32343__$1;
(statearr_32345_32358[(2)] = null);

(statearr_32345_32358[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_32344 === (2))){
var state_32343__$1 = state_32343;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_32343__$1,(4),message_channel);
} else {
if((state_val_32344 === (3))){
var inst_32341 = (state_32343[(2)]);
var state_32343__$1 = state_32343;
return cljs.core.async.impl.ioc_helpers.return_chan(state_32343__$1,inst_32341);
} else {
if((state_val_32344 === (4))){
var inst_32331 = (state_32343[(7)]);
var inst_32331__$1 = (state_32343[(2)]);
var inst_32332 = (inst_32331__$1 == null);
var state_32343__$1 = (function (){var statearr_32346 = state_32343;
(statearr_32346[(7)] = inst_32331__$1);

return statearr_32346;
})();
if(cljs.core.truth_(inst_32332)){
var statearr_32347_32359 = state_32343__$1;
(statearr_32347_32359[(1)] = (5));

} else {
var statearr_32348_32360 = state_32343__$1;
(statearr_32348_32360[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_32344 === (5))){
var state_32343__$1 = state_32343;
var statearr_32349_32361 = state_32343__$1;
(statearr_32349_32361[(2)] = null);

(statearr_32349_32361[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_32344 === (6))){
var inst_32331 = (state_32343[(7)]);
var inst_32335 = google_webmaster_tools_bulk_url_removal.popup.core.process_message_BANG_(message_channel,inst_32331);
var state_32343__$1 = (function (){var statearr_32350 = state_32343;
(statearr_32350[(8)] = inst_32335);

return statearr_32350;
})();
var statearr_32351_32362 = state_32343__$1;
(statearr_32351_32362[(2)] = null);

(statearr_32351_32362[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_32344 === (7))){
var inst_32338 = (state_32343[(2)]);
var inst_32339 = console.log("POPUP: leaving message loop");
var state_32343__$1 = (function (){var statearr_32352 = state_32343;
(statearr_32352[(9)] = inst_32338);

(statearr_32352[(10)] = inst_32339);

return statearr_32352;
})();
var statearr_32353_32363 = state_32343__$1;
(statearr_32353_32363[(2)] = null);

(statearr_32353_32363[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(c__8052__auto__))
;
return ((function (switch__7945__auto__,c__8052__auto__){
return (function() {
var google_webmaster_tools_bulk_url_removal$popup$core$run_message_loop_BANG__$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$popup$core$run_message_loop_BANG__$_state_machine__7946__auto____0 = (function (){
var statearr_32354 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_32354[(0)] = google_webmaster_tools_bulk_url_removal$popup$core$run_message_loop_BANG__$_state_machine__7946__auto__);

(statearr_32354[(1)] = (1));

return statearr_32354;
});
var google_webmaster_tools_bulk_url_removal$popup$core$run_message_loop_BANG__$_state_machine__7946__auto____1 = (function (state_32343){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_32343);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e32355){if((e32355 instanceof Object)){
var ex__7949__auto__ = e32355;
var statearr_32356_32364 = state_32343;
(statearr_32356_32364[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_32343);

return cljs.core.cst$kw$recur;
} else {
throw e32355;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__32365 = state_32343;
state_32343 = G__32365;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$popup$core$run_message_loop_BANG__$_state_machine__7946__auto__ = function(state_32343){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$popup$core$run_message_loop_BANG__$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$popup$core$run_message_loop_BANG__$_state_machine__7946__auto____1.call(this,state_32343);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$popup$core$run_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$popup$core$run_message_loop_BANG__$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$popup$core$run_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$popup$core$run_message_loop_BANG__$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$popup$core$run_message_loop_BANG__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_32357 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_32357[(6)] = c__8052__auto__);

return statearr_32357;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__))
);

return c__8052__auto__;
});
google_webmaster_tools_bulk_url_removal.popup.core.connect_to_background_page_BANG_ = (function google_webmaster_tools_bulk_url_removal$popup$core$connect_to_background_page_BANG_(background_port){
chromex.protocols.chrome_port.post_message_BANG_(background_port,google_webmaster_tools_bulk_url_removal.content_script.common.marshall(new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$type,cljs.core.cst$kw$fetch_DASH_initial_DASH_errors], null)));

return google_webmaster_tools_bulk_url_removal.popup.core.run_message_loop_BANG_(background_port);
});
google_webmaster_tools_bulk_url_removal.popup.core.csv_content = (function google_webmaster_tools_bulk_url_removal$popup$core$csv_content(input){
return cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p__32366){
var vec__32367 = p__32366;
var url = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32367,(0),null);
var map__32370 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32367,(1),null);
var map__32370__$1 = (((((!((map__32370 == null))))?(((((map__32370.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__32370.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__32370):map__32370);
var v = map__32370__$1;
var error_reason = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__32370__$1,cljs.core.cst$kw$error_DASH_reason);
var removal_method = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__32370__$1,cljs.core.cst$kw$removal_DASH_method);
var url_type = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__32370__$1,cljs.core.cst$kw$url_DASH_type);
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [url,error_reason,removal_method,url_type], null);
}),clojure.walk.keywordize_keys(input));
});
google_webmaster_tools_bulk_url_removal.popup.core.current_page = (function google_webmaster_tools_bulk_url_removal$popup$core$current_page(){
var disable_error_download_ratom_QMARK_ = reagent.ratom.make_reaction((function (){
return ((cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$done,cljs.core.deref(google_webmaster_tools_bulk_url_removal.popup.core.my_status))) || ((cljs.core.count(cljs.core.deref(google_webmaster_tools_bulk_url_removal.popup.core.cached_bad_victims_atom)) === (0))));
}));
var download_fn = ((function (disable_error_download_ratom_QMARK_){
return (function (){
var content = testdouble.cljs.csv.write_csv(google_webmaster_tools_bulk_url_removal.popup.core.csv_content(cljs.core.deref(google_webmaster_tools_bulk_url_removal.popup.core.cached_bad_victims_atom)));
var data_blob = (new Blob(cljs.core.clj__GT_js(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [content], null)),cljs.core.clj__GT_js(new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$type,"text/csv"], null))));
var url = URL.createObjectURL(data_blob);
return chromex.ext.downloads.download_STAR_(chromex.config.get_active_config(),cljs.core.clj__GT_js(new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$url,url,cljs.core.cst$kw$filename,"error.csv",cljs.core.cst$kw$saveAs,true,cljs.core.cst$kw$conflictAction,"overwrite"], null)));
});})(disable_error_download_ratom_QMARK_))
;
return ((function (disable_error_download_ratom_QMARK_,download_fn){
return (function (){
var cnt_ratom = reagent.ratom.make_reaction(((function (disable_error_download_ratom_QMARK_,download_fn){
return (function (){
return cljs.core.count(cljs.core.deref(google_webmaster_tools_bulk_url_removal.popup.core.cached_bad_victims_atom));
});})(disable_error_download_ratom_QMARK_,download_fn))
);
return new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$width,"380px",cljs.core.cst$kw$align,cljs.core.cst$kw$center,cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$div,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$style,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$display,"none"], null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$input,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$id,"bulkCsvFileInput",cljs.core.cst$kw$type,"file",cljs.core.cst$kw$on_DASH_change,((function (cnt_ratom,disable_error_download_ratom_QMARK_,download_fn){
return (function (e){
cljs.core.reset_BANG_(google_webmaster_tools_bulk_url_removal.popup.core.my_status,cljs.core.cst$kw$running);

cljs.core.reset_BANG_(google_webmaster_tools_bulk_url_removal.popup.core.cached_bad_victims_atom,null);

return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(google_webmaster_tools_bulk_url_removal.popup.core.upload_chan,e);
});})(cnt_ratom,disable_error_download_ratom_QMARK_,download_fn))
], null)], null)], null),new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$align,cljs.core.cst$kw$start,cljs.core.cst$kw$style,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$padding,"10px"], null),cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 8, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.title,cljs.core.cst$kw$label,"Instructions:",cljs.core.cst$kw$level,cljs.core.cst$kw$level1], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.label,cljs.core.cst$kw$label,"- Go to Google Search Console."], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.label,cljs.core.cst$kw$label,"- Select the proper domain from the dropdown on the left."], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.label,cljs.core.cst$kw$label,"- Select Removals on the left."], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.label,cljs.core.cst$kw$label,"- Upload your csv file by clicking on the 'Submit CSV File' button. Check out the example csv below."], null),new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.hyperlink_href,cljs.core.cst$kw$label,"CSV Format Documentation",cljs.core.cst$kw$href,"https://github.com/noitcudni/google-search-console-bulk-url-removal/#csv-format",cljs.core.cst$kw$target,"_blank"], null),new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.hyperlink_href,cljs.core.cst$kw$label,"example 1",cljs.core.cst$kw$href,"examples/most-common.csv"], null),new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.hyperlink_href,cljs.core.cst$kw$label,"example 2",cljs.core.cst$kw$href,"examples/optional-columns.csv"], null)], null)], null),new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$gap,"10px",cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 9, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.button,cljs.core.cst$kw$label,"Submit CSV File",cljs.core.cst$kw$tooltip,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.label,cljs.core.cst$kw$label,"Make sure that you are on "], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.label,cljs.core.cst$kw$label,"Google Search Console's Removals page."], null)], null)], null),cljs.core.cst$kw$style,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$width,"200px",cljs.core.cst$kw$background_DASH_color,"#007bff",cljs.core.cst$kw$color,"white"], null),cljs.core.cst$kw$on_DASH_click,((function (cnt_ratom,disable_error_download_ratom_QMARK_,download_fn){
return (function (e){
return domina.single_node(domina.xpath.xpath.cljs$core$IFn$_invoke$arity$1("//input[@id='bulkCsvFileInput']")).click();
});})(cnt_ratom,disable_error_download_ratom_QMARK_,download_fn))
], null),new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.button,cljs.core.cst$kw$label,"Clear cache",cljs.core.cst$kw$style,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$width,"200px"], null),cljs.core.cst$kw$on_DASH_click,((function (cnt_ratom,disable_error_download_ratom_QMARK_,download_fn){
return (function (_){
google_webmaster_tools_bulk_url_removal.background.storage.clear_victims_BANG_();

chromex.ext.browser_action.set_badge_text_STAR_(chromex.config.get_active_config(),({"text": ""}));

return cljs.core.reset_BANG_(google_webmaster_tools_bulk_url_removal.popup.core.cached_bad_victims_atom,null);
});})(cnt_ratom,disable_error_download_ratom_QMARK_,download_fn))
], null),new cljs.core.PersistentVector(null, 9, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.button,cljs.core.cst$kw$label,"View cache",cljs.core.cst$kw$tooltip,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.label,cljs.core.cst$kw$label,"Go to the chrome developer console"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.label,cljs.core.cst$kw$label,"Press me to see debugging information"], null)], null)], null),cljs.core.cst$kw$style,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$width,"200px"], null),cljs.core.cst$kw$on_DASH_click,((function (cnt_ratom,disable_error_download_ratom_QMARK_,download_fn){
return (function (_){
google_webmaster_tools_bulk_url_removal.background.storage.print_victims();

var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__,cnt_ratom,disable_error_download_ratom_QMARK_,download_fn){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__,cnt_ratom,disable_error_download_ratom_QMARK_,download_fn){
return (function (state_32377){
var state_val_32378 = (state_32377[(1)]);
if((state_val_32378 === (1))){
var inst_32372 = google_webmaster_tools_bulk_url_removal.background.storage.get_bad_victims();
var state_32377__$1 = state_32377;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_32377__$1,(2),inst_32372);
} else {
if((state_val_32378 === (2))){
var inst_32374 = (state_32377[(2)]);
var inst_32375 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["bad-victims: ",inst_32374], 0));
var state_32377__$1 = state_32377;
return cljs.core.async.impl.ioc_helpers.return_chan(state_32377__$1,inst_32375);
} else {
return null;
}
}
});})(c__8052__auto__,cnt_ratom,disable_error_download_ratom_QMARK_,download_fn))
;
return ((function (switch__7945__auto__,c__8052__auto__,cnt_ratom,disable_error_download_ratom_QMARK_,download_fn){
return (function() {
var google_webmaster_tools_bulk_url_removal$popup$core$current_page_$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$popup$core$current_page_$_state_machine__7946__auto____0 = (function (){
var statearr_32379 = [null,null,null,null,null,null,null];
(statearr_32379[(0)] = google_webmaster_tools_bulk_url_removal$popup$core$current_page_$_state_machine__7946__auto__);

(statearr_32379[(1)] = (1));

return statearr_32379;
});
var google_webmaster_tools_bulk_url_removal$popup$core$current_page_$_state_machine__7946__auto____1 = (function (state_32377){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_32377);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e32380){if((e32380 instanceof Object)){
var ex__7949__auto__ = e32380;
var statearr_32381_32383 = state_32377;
(statearr_32381_32383[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_32377);

return cljs.core.cst$kw$recur;
} else {
throw e32380;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__32384 = state_32377;
state_32377 = G__32384;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$popup$core$current_page_$_state_machine__7946__auto__ = function(state_32377){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$popup$core$current_page_$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$popup$core$current_page_$_state_machine__7946__auto____1.call(this,state_32377);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$popup$core$current_page_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$popup$core$current_page_$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$popup$core$current_page_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$popup$core$current_page_$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$popup$core$current_page_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__,cnt_ratom,disable_error_download_ratom_QMARK_,download_fn))
})();
var state__8054__auto__ = (function (){var statearr_32382 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_32382[(6)] = c__8052__auto__);

return statearr_32382;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__,cnt_ratom,disable_error_download_ratom_QMARK_,download_fn))
);

return c__8052__auto__;
});})(cnt_ratom,disable_error_download_ratom_QMARK_,download_fn))
], null)], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.h_box,cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.title,cljs.core.cst$kw$label,"Error Count: ",cljs.core.cst$kw$level,cljs.core.cst$kw$level2], null),new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.title,cljs.core.cst$kw$label,cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.deref(cnt_ratom)),cljs.core.cst$kw$level,cljs.core.cst$kw$level2], null)], null)], null),new cljs.core.PersistentVector(null, 11, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.button,cljs.core.cst$kw$label,"Download Error CSV",cljs.core.cst$kw$disabled_QMARK_,cljs.core.deref(disable_error_download_ratom_QMARK_),cljs.core.cst$kw$tooltip,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.v_box,cljs.core.cst$kw$children,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.label,cljs.core.cst$kw$label,"Click here to download "], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.label,cljs.core.cst$kw$label,"the list of URLs that errored out."], null)], null)], null),cljs.core.cst$kw$style,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$color,"white",cljs.core.cst$kw$background_DASH_color,"#d9534f",cljs.core.cst$kw$padding,"10px 16px"], null),cljs.core.cst$kw$on_DASH_click,download_fn], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [re_com.core.gap,cljs.core.cst$kw$size,"30px"], null)], null)], null);
});
;})(disable_error_download_ratom_QMARK_,download_fn))
});
google_webmaster_tools_bulk_url_removal.popup.core.mount_root = (function google_webmaster_tools_bulk_url_removal$popup$core$mount_root(){
return reagent.core.render.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [google_webmaster_tools_bulk_url_removal.popup.core.current_page], null),document.getElementById("app"));
});
google_webmaster_tools_bulk_url_removal.popup.core.init_BANG_ = (function google_webmaster_tools_bulk_url_removal$popup$core$init_BANG_(){
var _ = (function (){
console.log("POPUP: init");

return null;
})()
;
var background_port = chromex.ext.runtime.connect_STAR_(chromex.config.get_active_config(),cljs.core.cst$kw$omit,cljs.core.cst$kw$omit);
var c__8052__auto___32446 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___32446,_,background_port){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___32446,_,background_port){
return (function (state_32397){
var state_val_32398 = (state_32397[(1)]);
if((state_val_32398 === (1))){
var state_32397__$1 = state_32397;
var statearr_32399_32447 = state_32397__$1;
(statearr_32399_32447[(2)] = null);

(statearr_32399_32447[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_32398 === (2))){
var inst_32387 = (new FileReader());
var state_32397__$1 = (function (){var statearr_32400 = state_32397;
(statearr_32400[(7)] = inst_32387);

return statearr_32400;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_32397__$1,(4),google_webmaster_tools_bulk_url_removal.popup.core.upload_chan);
} else {
if((state_val_32398 === (3))){
var inst_32395 = (state_32397[(2)]);
var state_32397__$1 = state_32397;
return cljs.core.async.impl.ioc_helpers.return_chan(state_32397__$1,inst_32395);
} else {
if((state_val_32398 === (4))){
var inst_32387 = (state_32397[(7)]);
var inst_32389 = (state_32397[(2)]);
var inst_32390 = (function (){var reader = inst_32387;
var file = inst_32389;
return ((function (reader,file,inst_32387,inst_32389,state_val_32398,c__8052__auto___32446,_,background_port){
return (function (p1__32385_SHARP_){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(google_webmaster_tools_bulk_url_removal.popup.core.read_chan,p1__32385_SHARP_);
});
;})(reader,file,inst_32387,inst_32389,state_val_32398,c__8052__auto___32446,_,background_port))
})();
var inst_32391 = inst_32387.onload = inst_32390;
var inst_32392 = inst_32387.readAsText(inst_32389);
var state_32397__$1 = (function (){var statearr_32401 = state_32397;
(statearr_32401[(8)] = inst_32391);

(statearr_32401[(9)] = inst_32392);

return statearr_32401;
})();
var statearr_32402_32448 = state_32397__$1;
(statearr_32402_32448[(2)] = null);

(statearr_32402_32448[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
});})(c__8052__auto___32446,_,background_port))
;
return ((function (switch__7945__auto__,c__8052__auto___32446,_,background_port){
return (function() {
var google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto____0 = (function (){
var statearr_32403 = [null,null,null,null,null,null,null,null,null,null];
(statearr_32403[(0)] = google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto__);

(statearr_32403[(1)] = (1));

return statearr_32403;
});
var google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto____1 = (function (state_32397){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_32397);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e32404){if((e32404 instanceof Object)){
var ex__7949__auto__ = e32404;
var statearr_32405_32449 = state_32397;
(statearr_32405_32449[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_32397);

return cljs.core.cst$kw$recur;
} else {
throw e32404;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__32450 = state_32397;
state_32397 = G__32450;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto__ = function(state_32397){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto____1.call(this,state_32397);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___32446,_,background_port))
})();
var state__8054__auto__ = (function (){var statearr_32406 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_32406[(6)] = c__8052__auto___32446);

return statearr_32406;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___32446,_,background_port))
);


var c__8052__auto___32451 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___32451,_,background_port){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___32451,_,background_port){
return (function (state_32434){
var state_val_32435 = (state_32434[(1)]);
if((state_val_32435 === (1))){
var state_32434__$1 = state_32434;
var statearr_32436_32452 = state_32434__$1;
(statearr_32436_32452[(2)] = null);

(statearr_32436_32452[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_32435 === (2))){
var state_32434__$1 = state_32434;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_32434__$1,(4),google_webmaster_tools_bulk_url_removal.popup.core.read_chan);
} else {
if((state_val_32435 === (3))){
var inst_32432 = (state_32434[(2)]);
var state_32434__$1 = state_32434;
return cljs.core.async.impl.ioc_helpers.return_chan(state_32434__$1,inst_32432);
} else {
if((state_val_32435 === (4))){
var inst_32409 = (state_32434[(2)]);
var inst_32410 = clojure.string.trim(inst_32409);
var inst_32411 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["file-content: ",inst_32410], 0));
var inst_32412 = (function (){var file_content = inst_32409;
var ___$1 = inst_32411;
return ((function (file_content,___$1,inst_32409,inst_32410,inst_32411,state_val_32435,c__8052__auto___32451,_,background_port){
return (function (x){
return (cljs.core.count(x) === (0));
});
;})(file_content,___$1,inst_32409,inst_32410,inst_32411,state_val_32435,c__8052__auto___32451,_,background_port))
})();
var inst_32413 = clojure.string.split.cljs$core$IFn$_invoke$arity$2(inst_32409,/\r/);
var inst_32414 = cljs.core.map.cljs$core$IFn$_invoke$arity$2(clojure.string.trim,inst_32413);
var inst_32415 = cljs.core.remove.cljs$core$IFn$_invoke$arity$2(inst_32412,inst_32414);
var inst_32416 = clojure.string.join.cljs$core$IFn$_invoke$arity$2("\n",inst_32415);
var inst_32417 = clojure.string.trim(inst_32416);
var inst_32418 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["sanitized file-content: ",inst_32417], 0));
var inst_32420 = (function (){var file_content = inst_32416;
var ___$1 = inst_32418;
return ((function (file_content,___$1,inst_32409,inst_32410,inst_32411,inst_32412,inst_32413,inst_32414,inst_32415,inst_32416,inst_32417,inst_32418,state_val_32435,c__8052__auto___32451,_,background_port){
return (function (p__32419){
var vec__32437 = p__32419;
var url = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32437,(0),null);
var method = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32437,(1),null);
var url_type = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32437,(2),null);
return cljs.core.filter.cljs$core$IFn$_invoke$arity$2(cljs.core.complement(cljs.core.nil_QMARK_),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [clojure.string.trim(url),(cljs.core.truth_(method)?clojure.string.trim(method):null),(cljs.core.truth_(url_type)?clojure.string.trim(url_type):null)], null));
});
;})(file_content,___$1,inst_32409,inst_32410,inst_32411,inst_32412,inst_32413,inst_32414,inst_32415,inst_32416,inst_32417,inst_32418,state_val_32435,c__8052__auto___32451,_,background_port))
})();
var inst_32421 = clojure.string.trim(inst_32416);
var inst_32422 = testdouble.cljs.csv.read_csv(inst_32421);
var inst_32423 = cljs.core.map.cljs$core$IFn$_invoke$arity$2(inst_32420,inst_32422);
var inst_32424 = console.log("about to call :init-victims");
var inst_32425 = [cljs.core.cst$kw$type,cljs.core.cst$kw$data];
var inst_32426 = [cljs.core.cst$kw$init_DASH_victims,inst_32423];
var inst_32427 = cljs.core.PersistentHashMap.fromArrays(inst_32425,inst_32426);
var inst_32428 = google_webmaster_tools_bulk_url_removal.content_script.common.marshall(inst_32427);
var inst_32429 = chromex.protocols.chrome_port.post_message_BANG_(background_port,inst_32428);
var state_32434__$1 = (function (){var statearr_32440 = state_32434;
(statearr_32440[(7)] = inst_32424);

(statearr_32440[(8)] = inst_32429);

return statearr_32440;
})();
var statearr_32441_32453 = state_32434__$1;
(statearr_32441_32453[(2)] = null);

(statearr_32441_32453[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
});})(c__8052__auto___32451,_,background_port))
;
return ((function (switch__7945__auto__,c__8052__auto___32451,_,background_port){
return (function() {
var google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto____0 = (function (){
var statearr_32442 = [null,null,null,null,null,null,null,null,null];
(statearr_32442[(0)] = google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto__);

(statearr_32442[(1)] = (1));

return statearr_32442;
});
var google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto____1 = (function (state_32434){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_32434);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e32443){if((e32443 instanceof Object)){
var ex__7949__auto__ = e32443;
var statearr_32444_32454 = state_32434;
(statearr_32444_32454[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_32434);

return cljs.core.cst$kw$recur;
} else {
throw e32443;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__32455 = state_32434;
state_32434 = G__32455;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto__ = function(state_32434){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto____1.call(this,state_32434);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$popup$core$init_BANG__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___32451,_,background_port))
})();
var state__8054__auto__ = (function (){var statearr_32445 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_32445[(6)] = c__8052__auto___32451);

return statearr_32445;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___32451,_,background_port))
);


google_webmaster_tools_bulk_url_removal.popup.core.connect_to_background_page_BANG_(background_port);

return google_webmaster_tools_bulk_url_removal.popup.core.mount_root();
});

// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('google_webmaster_tools_bulk_url_removal.background.storage');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async');
goog.require('cljs_time.core');
goog.require('cljs_time.coerce');
goog.require('cljs_time.format');
goog.require('chromex.logging');
goog.require('chromex.protocols.chrome_storage_area');
goog.require('chromex.ext.storage');
google_webmaster_tools_bulk_url_removal.background.storage._STAR_DONE_FLAG_STAR_ = "**D0N3-FL@G**";
/**
 * status: pending, removed, removing, error
 *   CSV format : url, removal-method, url-type
 * 
 *   removal-method: 'remove-url' vs 'clear-cached'
 *   url-type: 'url-only' vs 'prefix'
 *   
 */
google_webmaster_tools_bulk_url_removal.background.storage.store_victims_BANG_ = (function google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG_(p__29518){
var map__29519 = p__29518;
var map__29519__$1 = (((((!((map__29519 == null))))?(((((map__29519.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__29519.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__29519):map__29519);
var data = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__29519__$1,cljs.core.cst$kw$data);
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
var data__$1 = cljs.core.concat.cljs$core$IFn$_invoke$arity$2(data,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, ["poison-pill",google_webmaster_tools_bulk_url_removal.background.storage._STAR_DONE_FLAG_STAR_], null)], null));
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__,local_storage,data__$1,map__29519,map__29519__$1,data){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__,local_storage,data__$1,map__29519,map__29519__$1,data){
return (function (state_29614){
var state_val_29615 = (state_29614[(1)]);
if((state_val_29615 === (7))){
var inst_29559 = (state_29614[(7)]);
var state_29614__$1 = state_29614;
var statearr_29616_29656 = state_29614__$1;
(statearr_29616_29656[(2)] = inst_29559);

(statearr_29616_29656[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (20))){
var inst_29552 = (state_29614[(8)]);
var inst_29588 = (state_29614[(9)]);
var inst_29590 = ["fetching ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(inst_29552),":"].join('');
var inst_29591 = (inst_29588.cljs$core$IFn$_invoke$arity$2 ? inst_29588.cljs$core$IFn$_invoke$arity$2(inst_29590,inst_29588) : inst_29588.call(null,inst_29590,inst_29588));
var state_29614__$1 = state_29614;
var statearr_29617_29657 = state_29614__$1;
(statearr_29617_29657[(2)] = inst_29591);

(statearr_29617_29657[(1)] = (22));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (1))){
var inst_29534 = cljs.core.seq(data__$1);
var inst_29535 = cljs.core.first(inst_29534);
var inst_29536 = cljs.core.next(inst_29534);
var inst_29537 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29535,(0),null);
var inst_29538 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29535,(1),null);
var inst_29539 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29535,(2),null);
var inst_29540 = data__$1;
var inst_29541 = (0);
var state_29614__$1 = (function (){var statearr_29618 = state_29614;
(statearr_29618[(10)] = inst_29538);

(statearr_29618[(11)] = inst_29539);

(statearr_29618[(12)] = inst_29537);

(statearr_29618[(13)] = inst_29536);

(statearr_29618[(14)] = inst_29540);

(statearr_29618[(15)] = inst_29541);

return statearr_29618;
})();
var statearr_29619_29658 = state_29614__$1;
(statearr_29619_29658[(2)] = null);

(statearr_29619_29658[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (4))){
var state_29614__$1 = state_29614;
var statearr_29620_29659 = state_29614__$1;
(statearr_29620_29659[(2)] = null);

(statearr_29620_29659[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (15))){
var inst_29550 = (state_29614[(16)]);
var inst_29572 = (state_29614[(2)]);
var inst_29573 = (inst_29550 == null);
var state_29614__$1 = (function (){var statearr_29621 = state_29614;
(statearr_29621[(17)] = inst_29572);

return statearr_29621;
})();
if(cljs.core.truth_(inst_29573)){
var statearr_29622_29660 = state_29614__$1;
(statearr_29622_29660[(1)] = (16));

} else {
var statearr_29623_29661 = state_29614__$1;
(statearr_29623_29661[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (21))){
var inst_29552 = (state_29614[(8)]);
var inst_29572 = (state_29614[(17)]);
var inst_29563 = (state_29614[(18)]);
var inst_29541 = (state_29614[(15)]);
var inst_29593 = console.log("setting url: ",inst_29552," | method: ",inst_29563);
var inst_29594 = console.log("setting url: ",inst_29552," | url-type ",inst_29572);
var inst_29595 = [inst_29552];
var inst_29596 = ["submit-ts","remove-ts","removal-method","url-type","status","idx"];
var inst_29597 = cljs_time.core.now();
var inst_29598 = cljs_time.coerce.to_long(inst_29597);
var inst_29599 = [inst_29598,null,inst_29563,inst_29572,"pending",inst_29541];
var inst_29600 = cljs.core.PersistentHashMap.fromArrays(inst_29596,inst_29599);
var inst_29601 = [inst_29600];
var inst_29602 = cljs.core.PersistentHashMap.fromArrays(inst_29595,inst_29601);
var inst_29603 = cljs.core.clj__GT_js(inst_29602);
var inst_29604 = chromex.protocols.chrome_storage_area.set(local_storage,inst_29603);
var state_29614__$1 = (function (){var statearr_29624 = state_29614;
(statearr_29624[(19)] = inst_29593);

(statearr_29624[(20)] = inst_29594);

return statearr_29624;
})();
var statearr_29625_29662 = state_29614__$1;
(statearr_29625_29662[(2)] = inst_29604);

(statearr_29625_29662[(1)] = (22));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (13))){
var inst_29568 = (state_29614[(21)]);
var state_29614__$1 = state_29614;
var statearr_29626_29663 = state_29614__$1;
(statearr_29626_29663[(2)] = inst_29568);

(statearr_29626_29663[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (22))){
var inst_29551 = (state_29614[(22)]);
var inst_29541 = (state_29614[(15)]);
var inst_29606 = (state_29614[(2)]);
var inst_29607 = (inst_29541 + (1));
var inst_29540 = inst_29551;
var inst_29541__$1 = inst_29607;
var state_29614__$1 = (function (){var statearr_29627 = state_29614;
(statearr_29627[(23)] = inst_29606);

(statearr_29627[(14)] = inst_29540);

(statearr_29627[(15)] = inst_29541__$1);

return statearr_29627;
})();
var statearr_29628_29664 = state_29614__$1;
(statearr_29628_29664[(2)] = null);

(statearr_29628_29664[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (6))){
var inst_29559 = (state_29614[(7)]);
var inst_29559__$1 = (state_29614[(2)]);
var state_29614__$1 = (function (){var statearr_29629 = state_29614;
(statearr_29629[(7)] = inst_29559__$1);

return statearr_29629;
})();
if(cljs.core.truth_(inst_29559__$1)){
var statearr_29630_29665 = state_29614__$1;
(statearr_29630_29665[(1)] = (7));

} else {
var statearr_29631_29666 = state_29614__$1;
(statearr_29631_29666[(1)] = (8));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (17))){
var inst_29552 = (state_29614[(8)]);
var inst_29583 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$2(local_storage,inst_29552);
var state_29614__$1 = state_29614;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29614__$1,(19),inst_29583);
} else {
if((state_val_29615 === (3))){
var inst_29612 = (state_29614[(2)]);
var state_29614__$1 = state_29614;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29614__$1,inst_29612);
} else {
if((state_val_29615 === (12))){
var inst_29568 = (state_29614[(21)]);
var inst_29568__$1 = (state_29614[(2)]);
var state_29614__$1 = (function (){var statearr_29632 = state_29614;
(statearr_29632[(21)] = inst_29568__$1);

return statearr_29632;
})();
if(cljs.core.truth_(inst_29568__$1)){
var statearr_29633_29667 = state_29614__$1;
(statearr_29633_29667[(1)] = (13));

} else {
var statearr_29634_29668 = state_29614__$1;
(statearr_29634_29668[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (2))){
var inst_29550 = (state_29614[(16)]);
var inst_29540 = (state_29614[(14)]);
var inst_29553 = (state_29614[(24)]);
var inst_29549 = cljs.core.seq(inst_29540);
var inst_29550__$1 = cljs.core.first(inst_29549);
var inst_29551 = cljs.core.next(inst_29549);
var inst_29552 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29550__$1,(0),null);
var inst_29553__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29550__$1,(1),null);
var inst_29554 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29550__$1,(2),null);
var inst_29555 = cljs.core.empty_QMARK_(inst_29553__$1);
var state_29614__$1 = (function (){var statearr_29635 = state_29614;
(statearr_29635[(16)] = inst_29550__$1);

(statearr_29635[(8)] = inst_29552);

(statearr_29635[(25)] = inst_29554);

(statearr_29635[(22)] = inst_29551);

(statearr_29635[(24)] = inst_29553__$1);

return statearr_29635;
})();
if(inst_29555){
var statearr_29636_29669 = state_29614__$1;
(statearr_29636_29669[(1)] = (4));

} else {
var statearr_29637_29670 = state_29614__$1;
(statearr_29637_29670[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (19))){
var inst_29588 = (state_29614[(9)]);
var inst_29585 = (state_29614[(2)]);
var inst_29586 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29585,(0),null);
var inst_29587 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29586,(0),null);
var inst_29588__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29585,(1),null);
var state_29614__$1 = (function (){var statearr_29638 = state_29614;
(statearr_29638[(26)] = inst_29587);

(statearr_29638[(9)] = inst_29588__$1);

return statearr_29638;
})();
if(cljs.core.truth_(inst_29588__$1)){
var statearr_29639_29671 = state_29614__$1;
(statearr_29639_29671[(1)] = (20));

} else {
var statearr_29640_29672 = state_29614__$1;
(statearr_29640_29672[(1)] = (21));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (11))){
var inst_29554 = (state_29614[(25)]);
var state_29614__$1 = state_29614;
var statearr_29641_29673 = state_29614__$1;
(statearr_29641_29673[(2)] = inst_29554);

(statearr_29641_29673[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (9))){
var inst_29554 = (state_29614[(25)]);
var inst_29563 = (state_29614[(2)]);
var inst_29564 = cljs.core.empty_QMARK_(inst_29554);
var state_29614__$1 = (function (){var statearr_29642 = state_29614;
(statearr_29642[(18)] = inst_29563);

return statearr_29642;
})();
if(inst_29564){
var statearr_29643_29674 = state_29614__$1;
(statearr_29643_29674[(1)] = (10));

} else {
var statearr_29644_29675 = state_29614__$1;
(statearr_29644_29675[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (5))){
var inst_29553 = (state_29614[(24)]);
var state_29614__$1 = state_29614;
var statearr_29645_29676 = state_29614__$1;
(statearr_29645_29676[(2)] = inst_29553);

(statearr_29645_29676[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (14))){
var state_29614__$1 = state_29614;
var statearr_29646_29677 = state_29614__$1;
(statearr_29646_29677[(2)] = "url-only");

(statearr_29646_29677[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (16))){
var inst_29575 = console.log("DONE storing victims");
var state_29614__$1 = (function (){var statearr_29647 = state_29614;
(statearr_29647[(27)] = inst_29575);

return statearr_29647;
})();
var statearr_29648_29678 = state_29614__$1;
(statearr_29648_29678[(2)] = null);

(statearr_29648_29678[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (10))){
var state_29614__$1 = state_29614;
var statearr_29649_29679 = state_29614__$1;
(statearr_29649_29679[(2)] = null);

(statearr_29649_29679[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (18))){
var inst_29610 = (state_29614[(2)]);
var state_29614__$1 = state_29614;
var statearr_29650_29680 = state_29614__$1;
(statearr_29650_29680[(2)] = inst_29610);

(statearr_29650_29680[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29615 === (8))){
var state_29614__$1 = state_29614;
var statearr_29651_29681 = state_29614__$1;
(statearr_29651_29681[(2)] = "remove-url");

(statearr_29651_29681[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto__,local_storage,data__$1,map__29519,map__29519__$1,data))
;
return ((function (switch__7945__auto__,c__8052__auto__,local_storage,data__$1,map__29519,map__29519__$1,data){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto____0 = (function (){
var statearr_29652 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_29652[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto__);

(statearr_29652[(1)] = (1));

return statearr_29652;
});
var google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto____1 = (function (state_29614){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_29614);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e29653){if((e29653 instanceof Object)){
var ex__7949__auto__ = e29653;
var statearr_29654_29682 = state_29614;
(statearr_29654_29682[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29614);

return cljs.core.cst$kw$recur;
} else {
throw e29653;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__29683 = state_29614;
state_29614 = G__29683;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto__ = function(state_29614){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto____1.call(this,state_29614);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__,local_storage,data__$1,map__29519,map__29519__$1,data))
})();
var state__8054__auto__ = (function (){var statearr_29655 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_29655[(6)] = c__8052__auto__);

return statearr_29655;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__,local_storage,data__$1,map__29519,map__29519__$1,data))
);

return c__8052__auto__;
});
google_webmaster_tools_bulk_url_removal.background.storage.update_storage = (function google_webmaster_tools_bulk_url_removal$background$storage$update_storage(var_args){
var args__4736__auto__ = [];
var len__4730__auto___29733 = arguments.length;
var i__4731__auto___29734 = (0);
while(true){
if((i__4731__auto___29734 < len__4730__auto___29733)){
args__4736__auto__.push((arguments[i__4731__auto___29734]));

var G__29735 = (i__4731__auto___29734 + (1));
i__4731__auto___29734 = G__29735;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return google_webmaster_tools_bulk_url_removal.background.storage.update_storage.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

google_webmaster_tools_bulk_url_removal.background.storage.update_storage.cljs$core$IFn$_invoke$arity$variadic = (function (url,args){

var kv_pairs = cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),args);
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var c__8052__auto___29736 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___29736,kv_pairs,local_storage,ch){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___29736,kv_pairs,local_storage,ch){
return (function (state_29718){
var state_val_29719 = (state_29718[(1)]);
if((state_val_29719 === (1))){
var inst_29692 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$2(local_storage,url);
var state_29718__$1 = state_29718;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29718__$1,(2),inst_29692);
} else {
if((state_val_29719 === (2))){
var inst_29694 = (state_29718[(7)]);
var inst_29697 = (state_29718[(8)]);
var inst_29695 = (state_29718[(9)]);
var inst_29694__$1 = (state_29718[(2)]);
var inst_29695__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29694__$1,(0),null);
var inst_29696 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29695__$1,(0),null);
var inst_29697__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29694__$1,(1),null);
var state_29718__$1 = (function (){var statearr_29720 = state_29718;
(statearr_29720[(7)] = inst_29694__$1);

(statearr_29720[(10)] = inst_29696);

(statearr_29720[(8)] = inst_29697__$1);

(statearr_29720[(9)] = inst_29695__$1);

return statearr_29720;
})();
if(cljs.core.truth_(inst_29697__$1)){
var statearr_29721_29737 = state_29718__$1;
(statearr_29721_29737[(1)] = (3));

} else {
var statearr_29722_29738 = state_29718__$1;
(statearr_29722_29738[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29719 === (3))){
var inst_29697 = (state_29718[(8)]);
var inst_29699 = ["fetching ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(url),":"].join('');
var inst_29700 = (inst_29697.cljs$core$IFn$_invoke$arity$2 ? inst_29697.cljs$core$IFn$_invoke$arity$2(inst_29699,inst_29697) : inst_29697.call(null,inst_29699,inst_29697));
var state_29718__$1 = state_29718;
var statearr_29723_29739 = state_29718__$1;
(statearr_29723_29739[(2)] = inst_29700);

(statearr_29723_29739[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29719 === (4))){
var inst_29694 = (state_29718[(7)]);
var inst_29696 = (state_29718[(10)]);
var inst_29697 = (state_29718[(8)]);
var inst_29695 = (state_29718[(9)]);
var inst_29702 = cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(inst_29696);
var inst_29703 = cljs.core.vals(inst_29702);
var inst_29704 = cljs.core.first(inst_29703);
var inst_29705 = [url];
var inst_29707 = (function (){var vec__29686 = inst_29694;
var vec__29689 = inst_29695;
var items = inst_29696;
var error = inst_29697;
var entry = inst_29704;
return ((function (vec__29686,vec__29689,items,error,entry,inst_29694,inst_29696,inst_29697,inst_29695,inst_29702,inst_29703,inst_29704,inst_29705,state_val_29719,c__8052__auto___29736,kv_pairs,local_storage,ch){
return (function (accum,p__29706){
var vec__29724 = p__29706;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29724,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29724,(1),null);
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(accum,k,v);
});
;})(vec__29686,vec__29689,items,error,entry,inst_29694,inst_29696,inst_29697,inst_29695,inst_29702,inst_29703,inst_29704,inst_29705,state_val_29719,c__8052__auto___29736,kv_pairs,local_storage,ch))
})();
var inst_29708 = cljs.core.reduce.cljs$core$IFn$_invoke$arity$3(inst_29707,inst_29704,kv_pairs);
var inst_29709 = [inst_29708];
var inst_29710 = cljs.core.PersistentHashMap.fromArrays(inst_29705,inst_29709);
var inst_29711 = cljs.core.clj__GT_js(inst_29710);
var inst_29712 = chromex.protocols.chrome_storage_area.set(local_storage,inst_29711);
var state_29718__$1 = (function (){var statearr_29727 = state_29718;
(statearr_29727[(11)] = inst_29712);

return statearr_29727;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29718__$1,(6),ch,inst_29710);
} else {
if((state_val_29719 === (5))){
var inst_29716 = (state_29718[(2)]);
var state_29718__$1 = state_29718;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29718__$1,inst_29716);
} else {
if((state_val_29719 === (6))){
var inst_29714 = (state_29718[(2)]);
var state_29718__$1 = state_29718;
var statearr_29728_29740 = state_29718__$1;
(statearr_29728_29740[(2)] = inst_29714);

(statearr_29728_29740[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
});})(c__8052__auto___29736,kv_pairs,local_storage,ch))
;
return ((function (switch__7945__auto__,c__8052__auto___29736,kv_pairs,local_storage,ch){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto____0 = (function (){
var statearr_29729 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_29729[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto__);

(statearr_29729[(1)] = (1));

return statearr_29729;
});
var google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto____1 = (function (state_29718){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_29718);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e29730){if((e29730 instanceof Object)){
var ex__7949__auto__ = e29730;
var statearr_29731_29741 = state_29718;
(statearr_29731_29741[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29718);

return cljs.core.cst$kw$recur;
} else {
throw e29730;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__29742 = state_29718;
state_29718 = G__29742;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto__ = function(state_29718){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto____1.call(this,state_29718);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___29736,kv_pairs,local_storage,ch))
})();
var state__8054__auto__ = (function (){var statearr_29732 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_29732[(6)] = c__8052__auto___29736);

return statearr_29732;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___29736,kv_pairs,local_storage,ch))
);


return ch;
});

google_webmaster_tools_bulk_url_removal.background.storage.update_storage.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
google_webmaster_tools_bulk_url_removal.background.storage.update_storage.cljs$lang$applyTo = (function (seq29684){
var G__29685 = cljs.core.first(seq29684);
var seq29684__$1 = cljs.core.next(seq29684);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__29685,seq29684__$1);
});

/**
 * NOTE: There should only be one item that's undergoing removal.
 *   Return nil if not found.
 *   Return URL if found.
 *   
 */
google_webmaster_tools_bulk_url_removal.background.storage.current_removal_attempt = (function google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt(){
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__,local_storage){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__,local_storage){
return (function (state_29761){
var state_val_29762 = (state_29761[(1)]);
if((state_val_29762 === (1))){
var inst_29749 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$1(local_storage);
var state_29761__$1 = state_29761;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29761__$1,(2),inst_29749);
} else {
if((state_val_29762 === (2))){
var inst_29751 = (state_29761[(2)]);
var inst_29752 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29751,(0),null);
var inst_29753 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29752,(0),null);
var inst_29754 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29751,(1),null);
var inst_29756 = (function (){var vec__29743 = inst_29751;
var vec__29746 = inst_29752;
var items = inst_29753;
var error = inst_29754;
return ((function (vec__29743,vec__29746,items,error,inst_29751,inst_29752,inst_29753,inst_29754,state_val_29762,c__8052__auto__,local_storage){
return (function (p__29755){
var vec__29763 = p__29755;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29763,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29763,(1),null);
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2("removing",cljs.core.get.cljs$core$IFn$_invoke$arity$2(v,"status"));
});
;})(vec__29743,vec__29746,items,error,inst_29751,inst_29752,inst_29753,inst_29754,state_val_29762,c__8052__auto__,local_storage))
})();
var inst_29757 = cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(inst_29753);
var inst_29758 = cljs.core.filter.cljs$core$IFn$_invoke$arity$2(inst_29756,inst_29757);
var inst_29759 = cljs.core.first(inst_29758);
var state_29761__$1 = state_29761;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29761__$1,inst_29759);
} else {
return null;
}
}
});})(c__8052__auto__,local_storage))
;
return ((function (switch__7945__auto__,c__8052__auto__,local_storage){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto____0 = (function (){
var statearr_29766 = [null,null,null,null,null,null,null];
(statearr_29766[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto__);

(statearr_29766[(1)] = (1));

return statearr_29766;
});
var google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto____1 = (function (state_29761){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_29761);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e29767){if((e29767 instanceof Object)){
var ex__7949__auto__ = e29767;
var statearr_29768_29770 = state_29761;
(statearr_29768_29770[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29761);

return cljs.core.cst$kw$recur;
} else {
throw e29767;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__29771 = state_29761;
state_29761 = G__29771;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto__ = function(state_29761){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto____1.call(this,state_29761);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__,local_storage))
})();
var state__8054__auto__ = (function (){var statearr_29769 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_29769[(6)] = c__8052__auto__);

return statearr_29769;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__,local_storage))
);

return c__8052__auto__;
});
google_webmaster_tools_bulk_url_removal.background.storage.fresh_new_victim = (function google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim(){
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var c__8052__auto___29850 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___29850,local_storage,ch){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___29850,local_storage,ch){
return (function (state_29822){
var state_val_29823 = (state_29822[(1)]);
if((state_val_29823 === (7))){
var inst_29800 = (state_29822[(7)]);
var inst_29805 = google_webmaster_tools_bulk_url_removal.background.storage.update_storage.cljs$core$IFn$_invoke$arity$variadic(inst_29800,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["status","removing"], 0));
var state_29822__$1 = state_29822;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29822__$1,(9),inst_29805);
} else {
if((state_val_29823 === (1))){
var inst_29781 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$1(local_storage);
var state_29822__$1 = state_29822;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29822__$1,(2),inst_29781);
} else {
if((state_val_29823 === (4))){
var inst_29793 = cljs.core.List.EMPTY;
var state_29822__$1 = state_29822;
var statearr_29824_29851 = state_29822__$1;
(statearr_29824_29851[(2)] = inst_29793);

(statearr_29824_29851[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29823 === (13))){
var inst_29820 = (state_29822[(2)]);
var state_29822__$1 = state_29822;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29822__$1,inst_29820);
} else {
if((state_val_29823 === (6))){
var state_29822__$1 = state_29822;
var statearr_29825_29852 = state_29822__$1;
(statearr_29825_29852[(2)] = null);

(statearr_29825_29852[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29823 === (3))){
var inst_29785 = (state_29822[(8)]);
var state_29822__$1 = state_29822;
var statearr_29826_29853 = state_29822__$1;
(statearr_29826_29853[(2)] = inst_29785);

(statearr_29826_29853[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29823 === (12))){
var inst_29812 = (state_29822[(9)]);
var state_29822__$1 = state_29822;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29822__$1,(14),ch,inst_29812);
} else {
if((state_val_29823 === (2))){
var inst_29785 = (state_29822[(8)]);
var inst_29783 = (state_29822[(2)]);
var inst_29784 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29783,(0),null);
var inst_29785__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29784,(0),null);
var inst_29786 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29783,(1),null);
var inst_29788 = (function (){var vec__29772 = inst_29783;
var vec__29775 = inst_29784;
var items = inst_29785__$1;
var error = inst_29786;
return ((function (vec__29772,vec__29775,items,error,inst_29785,inst_29783,inst_29784,inst_29785__$1,inst_29786,state_val_29823,c__8052__auto___29850,local_storage,ch){
return (function (p__29787){
var vec__29827 = p__29787;
var _ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29827,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29827,(1),null);
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(v,"idx");
});
;})(vec__29772,vec__29775,items,error,inst_29785,inst_29783,inst_29784,inst_29785__$1,inst_29786,state_val_29823,c__8052__auto___29850,local_storage,ch))
})();
var inst_29790 = (function (){var vec__29772 = inst_29783;
var vec__29775 = inst_29784;
var items = inst_29785__$1;
var error = inst_29786;
return ((function (vec__29772,vec__29775,items,error,inst_29785,inst_29783,inst_29784,inst_29785__$1,inst_29786,inst_29788,state_val_29823,c__8052__auto___29850,local_storage,ch){
return (function (p__29789){
var vec__29830 = p__29789;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29830,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29830,(1),null);
var status = cljs.core.get.cljs$core$IFn$_invoke$arity$2(v,"status");
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2("pending",status);
});
;})(vec__29772,vec__29775,items,error,inst_29785,inst_29783,inst_29784,inst_29785__$1,inst_29786,inst_29788,state_val_29823,c__8052__auto___29850,local_storage,ch))
})();
var state_29822__$1 = (function (){var statearr_29833 = state_29822;
(statearr_29833[(10)] = inst_29790);

(statearr_29833[(11)] = inst_29788);

(statearr_29833[(8)] = inst_29785__$1);

return statearr_29833;
})();
if(cljs.core.truth_(inst_29785__$1)){
var statearr_29834_29854 = state_29822__$1;
(statearr_29834_29854[(1)] = (3));

} else {
var statearr_29835_29855 = state_29822__$1;
(statearr_29835_29855[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29823 === (11))){
var inst_29815 = cljs.core.async.close_BANG_(ch);
var state_29822__$1 = state_29822;
var statearr_29836_29856 = state_29822__$1;
(statearr_29836_29856[(2)] = inst_29815);

(statearr_29836_29856[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29823 === (9))){
var inst_29807 = (state_29822[(2)]);
var state_29822__$1 = state_29822;
var statearr_29837_29857 = state_29822__$1;
(statearr_29837_29857[(2)] = inst_29807);

(statearr_29837_29857[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29823 === (5))){
var inst_29790 = (state_29822[(10)]);
var inst_29788 = (state_29822[(11)]);
var inst_29795 = (state_29822[(2)]);
var inst_29796 = cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(inst_29795);
var inst_29797 = cljs.core.filter.cljs$core$IFn$_invoke$arity$2(inst_29790,inst_29796);
var inst_29798 = cljs.core.sort_by.cljs$core$IFn$_invoke$arity$2(inst_29788,inst_29797);
var inst_29799 = cljs.core.first(inst_29798);
var inst_29800 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29799,(0),null);
var inst_29801 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29799,(1),null);
var inst_29802 = (inst_29801 == null);
var state_29822__$1 = (function (){var statearr_29838 = state_29822;
(statearr_29838[(7)] = inst_29800);

return statearr_29838;
})();
if(cljs.core.truth_(inst_29802)){
var statearr_29839_29858 = state_29822__$1;
(statearr_29839_29858[(1)] = (6));

} else {
var statearr_29840_29859 = state_29822__$1;
(statearr_29840_29859[(1)] = (7));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29823 === (14))){
var inst_29818 = (state_29822[(2)]);
var state_29822__$1 = state_29822;
var statearr_29841_29860 = state_29822__$1;
(statearr_29841_29860[(2)] = inst_29818);

(statearr_29841_29860[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29823 === (10))){
var inst_29812 = (state_29822[(9)]);
var inst_29812__$1 = (state_29822[(2)]);
var inst_29813 = (inst_29812__$1 == null);
var state_29822__$1 = (function (){var statearr_29842 = state_29822;
(statearr_29842[(9)] = inst_29812__$1);

return statearr_29842;
})();
if(cljs.core.truth_(inst_29813)){
var statearr_29843_29861 = state_29822__$1;
(statearr_29843_29861[(1)] = (11));

} else {
var statearr_29844_29862 = state_29822__$1;
(statearr_29844_29862[(1)] = (12));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29823 === (8))){
var inst_29809 = (state_29822[(2)]);
var inst_29810 = google_webmaster_tools_bulk_url_removal.background.storage.current_removal_attempt();
var state_29822__$1 = (function (){var statearr_29845 = state_29822;
(statearr_29845[(12)] = inst_29809);

return statearr_29845;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29822__$1,(10),inst_29810);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___29850,local_storage,ch))
;
return ((function (switch__7945__auto__,c__8052__auto___29850,local_storage,ch){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto____0 = (function (){
var statearr_29846 = [null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_29846[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto__);

(statearr_29846[(1)] = (1));

return statearr_29846;
});
var google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto____1 = (function (state_29822){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_29822);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e29847){if((e29847 instanceof Object)){
var ex__7949__auto__ = e29847;
var statearr_29848_29863 = state_29822;
(statearr_29848_29863[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29822);

return cljs.core.cst$kw$recur;
} else {
throw e29847;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__29864 = state_29822;
state_29822 = G__29864;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto__ = function(state_29822){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto____1.call(this,state_29822);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___29850,local_storage,ch))
})();
var state__8054__auto__ = (function (){var statearr_29849 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_29849[(6)] = c__8052__auto___29850);

return statearr_29849;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___29850,local_storage,ch))
);


return ch;
});
google_webmaster_tools_bulk_url_removal.background.storage.next_victim = (function google_webmaster_tools_bulk_url_removal$background$storage$next_victim(){
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var c__8052__auto___29901 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___29901,ch){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___29901,ch){
return (function (state_29885){
var state_val_29886 = (state_29885[(1)]);
if((state_val_29886 === (7))){
var inst_29878 = cljs.core.async.close_BANG_(ch);
var state_29885__$1 = state_29885;
var statearr_29887_29902 = state_29885__$1;
(statearr_29887_29902[(2)] = inst_29878);

(statearr_29887_29902[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (1))){
var inst_29865 = google_webmaster_tools_bulk_url_removal.background.storage.current_removal_attempt();
var state_29885__$1 = state_29885;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29885__$1,(2),inst_29865);
} else {
if((state_val_29886 === (4))){
var inst_29867 = (state_29885[(7)]);
var state_29885__$1 = state_29885;
var statearr_29888_29903 = state_29885__$1;
(statearr_29888_29903[(2)] = inst_29867);

(statearr_29888_29903[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (6))){
var inst_29872 = (state_29885[(2)]);
var state_29885__$1 = state_29885;
var statearr_29889_29904 = state_29885__$1;
(statearr_29889_29904[(2)] = inst_29872);

(statearr_29889_29904[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (3))){
var inst_29870 = google_webmaster_tools_bulk_url_removal.background.storage.fresh_new_victim();
var state_29885__$1 = state_29885;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29885__$1,(6),inst_29870);
} else {
if((state_val_29886 === (2))){
var inst_29867 = (state_29885[(7)]);
var inst_29867__$1 = (state_29885[(2)]);
var inst_29868 = cljs.core.empty_QMARK_(inst_29867__$1);
var state_29885__$1 = (function (){var statearr_29890 = state_29885;
(statearr_29890[(7)] = inst_29867__$1);

return statearr_29890;
})();
if(inst_29868){
var statearr_29891_29905 = state_29885__$1;
(statearr_29891_29905[(1)] = (3));

} else {
var statearr_29892_29906 = state_29885__$1;
(statearr_29892_29906[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (9))){
var inst_29883 = (state_29885[(2)]);
var state_29885__$1 = state_29885;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29885__$1,inst_29883);
} else {
if((state_val_29886 === (5))){
var inst_29875 = (state_29885[(8)]);
var inst_29875__$1 = (state_29885[(2)]);
var inst_29876 = (inst_29875__$1 == null);
var state_29885__$1 = (function (){var statearr_29893 = state_29885;
(statearr_29893[(8)] = inst_29875__$1);

return statearr_29893;
})();
if(cljs.core.truth_(inst_29876)){
var statearr_29894_29907 = state_29885__$1;
(statearr_29894_29907[(1)] = (7));

} else {
var statearr_29895_29908 = state_29885__$1;
(statearr_29895_29908[(1)] = (8));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (10))){
var inst_29881 = (state_29885[(2)]);
var state_29885__$1 = state_29885;
var statearr_29896_29909 = state_29885__$1;
(statearr_29896_29909[(2)] = inst_29881);

(statearr_29896_29909[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29886 === (8))){
var inst_29875 = (state_29885[(8)]);
var state_29885__$1 = state_29885;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29885__$1,(10),ch,inst_29875);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___29901,ch))
;
return ((function (switch__7945__auto__,c__8052__auto___29901,ch){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto____0 = (function (){
var statearr_29897 = [null,null,null,null,null,null,null,null,null];
(statearr_29897[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto__);

(statearr_29897[(1)] = (1));

return statearr_29897;
});
var google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto____1 = (function (state_29885){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_29885);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e29898){if((e29898 instanceof Object)){
var ex__7949__auto__ = e29898;
var statearr_29899_29910 = state_29885;
(statearr_29899_29910[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29885);

return cljs.core.cst$kw$recur;
} else {
throw e29898;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__29911 = state_29885;
state_29885 = G__29911;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto__ = function(state_29885){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto____1.call(this,state_29885);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___29901,ch))
})();
var state__8054__auto__ = (function (){var statearr_29900 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_29900[(6)] = c__8052__auto___29901);

return statearr_29900;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___29901,ch))
);


return ch;
});
google_webmaster_tools_bulk_url_removal.background.storage.clear_victims_BANG_ = (function google_webmaster_tools_bulk_url_removal$background$storage$clear_victims_BANG_(){
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
return chromex.protocols.chrome_storage_area.clear(local_storage);
});
google_webmaster_tools_bulk_url_removal.background.storage.print_victims = (function google_webmaster_tools_bulk_url_removal$background$storage$print_victims(){
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__,local_storage){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__,local_storage){
return (function (state_29927){
var state_val_29928 = (state_29927[(1)]);
if((state_val_29928 === (1))){
var inst_29918 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$1(local_storage);
var state_29927__$1 = state_29927;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29927__$1,(2),inst_29918);
} else {
if((state_val_29928 === (2))){
var inst_29920 = (state_29927[(2)]);
var inst_29921 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29920,(0),null);
var inst_29922 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29921,(0),null);
var inst_29923 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29920,(1),null);
var inst_29924 = cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(inst_29922);
var inst_29925 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([inst_29924], 0));
var state_29927__$1 = (function (){var statearr_29929 = state_29927;
(statearr_29929[(7)] = inst_29923);

return statearr_29929;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_29927__$1,inst_29925);
} else {
return null;
}
}
});})(c__8052__auto__,local_storage))
;
return ((function (switch__7945__auto__,c__8052__auto__,local_storage){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto____0 = (function (){
var statearr_29930 = [null,null,null,null,null,null,null,null];
(statearr_29930[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto__);

(statearr_29930[(1)] = (1));

return statearr_29930;
});
var google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto____1 = (function (state_29927){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_29927);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e29931){if((e29931 instanceof Object)){
var ex__7949__auto__ = e29931;
var statearr_29932_29934 = state_29927;
(statearr_29932_29934[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29927);

return cljs.core.cst$kw$recur;
} else {
throw e29931;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__29935 = state_29927;
state_29927 = G__29935;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto__ = function(state_29927){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto____1.call(this,state_29927);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__,local_storage))
})();
var state__8054__auto__ = (function (){var statearr_29933 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_29933[(6)] = c__8052__auto__);

return statearr_29933;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__,local_storage))
);

return c__8052__auto__;
});
google_webmaster_tools_bulk_url_removal.background.storage.get_bad_victims = (function google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims(){
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var c__8052__auto___29980 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___29980,local_storage,ch){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___29980,local_storage,ch){
return (function (state_29963){
var state_val_29964 = (state_29963[(1)]);
if((state_val_29964 === (1))){
var inst_29942 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$1(local_storage);
var state_29963__$1 = state_29963;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_29963__$1,(2),inst_29942);
} else {
if((state_val_29964 === (2))){
var inst_29946 = (state_29963[(7)]);
var inst_29944 = (state_29963[(2)]);
var inst_29945 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29944,(0),null);
var inst_29946__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29945,(0),null);
var inst_29947 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_29944,(1),null);
var inst_29949 = (function (){var vec__29936 = inst_29944;
var vec__29939 = inst_29945;
var items = inst_29946__$1;
var error = inst_29947;
return ((function (vec__29936,vec__29939,items,error,inst_29946,inst_29944,inst_29945,inst_29946__$1,inst_29947,state_val_29964,c__8052__auto___29980,local_storage,ch){
return (function (p__29948){
var vec__29965 = p__29948;
var _ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29965,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29965,(1),null);
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(v,"idx");
});
;})(vec__29936,vec__29939,items,error,inst_29946,inst_29944,inst_29945,inst_29946__$1,inst_29947,state_val_29964,c__8052__auto___29980,local_storage,ch))
})();
var inst_29951 = (function (){var vec__29936 = inst_29944;
var vec__29939 = inst_29945;
var items = inst_29946__$1;
var error = inst_29947;
return ((function (vec__29936,vec__29939,items,error,inst_29946,inst_29944,inst_29945,inst_29946__$1,inst_29947,inst_29949,state_val_29964,c__8052__auto___29980,local_storage,ch){
return (function (p__29950){
var vec__29968 = p__29950;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29968,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__29968,(1),null);
var status = cljs.core.get.cljs$core$IFn$_invoke$arity$2(v,"status");
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2("error",status);
});
;})(vec__29936,vec__29939,items,error,inst_29946,inst_29944,inst_29945,inst_29946__$1,inst_29947,inst_29949,state_val_29964,c__8052__auto___29980,local_storage,ch))
})();
var state_29963__$1 = (function (){var statearr_29971 = state_29963;
(statearr_29971[(7)] = inst_29946__$1);

(statearr_29971[(8)] = inst_29951);

(statearr_29971[(9)] = inst_29949);

return statearr_29971;
})();
if(cljs.core.truth_(inst_29946__$1)){
var statearr_29972_29981 = state_29963__$1;
(statearr_29972_29981[(1)] = (4));

} else {
var statearr_29973_29982 = state_29963__$1;
(statearr_29973_29982[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_29964 === (3))){
var inst_29961 = (state_29963[(2)]);
var state_29963__$1 = state_29963;
return cljs.core.async.impl.ioc_helpers.return_chan(state_29963__$1,inst_29961);
} else {
if((state_val_29964 === (4))){
var inst_29946 = (state_29963[(7)]);
var state_29963__$1 = state_29963;
var statearr_29974_29983 = state_29963__$1;
(statearr_29974_29983[(2)] = inst_29946);

(statearr_29974_29983[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29964 === (5))){
var inst_29954 = cljs.core.List.EMPTY;
var state_29963__$1 = state_29963;
var statearr_29975_29984 = state_29963__$1;
(statearr_29975_29984[(2)] = inst_29954);

(statearr_29975_29984[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_29964 === (6))){
var inst_29951 = (state_29963[(8)]);
var inst_29949 = (state_29963[(9)]);
var inst_29956 = (state_29963[(2)]);
var inst_29957 = cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(inst_29956);
var inst_29958 = cljs.core.filter.cljs$core$IFn$_invoke$arity$2(inst_29951,inst_29957);
var inst_29959 = cljs.core.sort_by.cljs$core$IFn$_invoke$arity$2(inst_29949,inst_29958);
var state_29963__$1 = state_29963;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_29963__$1,(3),ch,inst_29959);
} else {
return null;
}
}
}
}
}
}
});})(c__8052__auto___29980,local_storage,ch))
;
return ((function (switch__7945__auto__,c__8052__auto___29980,local_storage,ch){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto____0 = (function (){
var statearr_29976 = [null,null,null,null,null,null,null,null,null,null];
(statearr_29976[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto__);

(statearr_29976[(1)] = (1));

return statearr_29976;
});
var google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto____1 = (function (state_29963){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_29963);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e29977){if((e29977 instanceof Object)){
var ex__7949__auto__ = e29977;
var statearr_29978_29985 = state_29963;
(statearr_29978_29985[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_29963);

return cljs.core.cst$kw$recur;
} else {
throw e29977;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__29986 = state_29963;
state_29963 = G__29986;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto__ = function(state_29963){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto____1.call(this,state_29963);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___29980,local_storage,ch))
})();
var state__8054__auto__ = (function (){var statearr_29979 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_29979[(6)] = c__8052__auto___29980);

return statearr_29979;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___29980,local_storage,ch))
);


return ch;
});

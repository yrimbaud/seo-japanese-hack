// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.defaults');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.error');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.protocols.chrome_port_state');
goog.require('chromex.support');
goog.require('cljs.core.async');
goog.require('goog.object');
goog.require('oops.core');
chromex.defaults.log_prefix = "[chromex]";
chromex.defaults.console_log = (function chromex$defaults$console_log(var_args){
var args__4736__auto__ = [];
var len__4730__auto___25598 = arguments.length;
var i__4731__auto___25599 = (0);
while(true){
if((i__4731__auto___25599 < len__4730__auto___25598)){
args__4736__auto__.push((arguments[i__4731__auto___25599]));

var G__25600 = (i__4731__auto___25599 + (1));
i__4731__auto___25599 = G__25600;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return console.log.apply(console,cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(args));
});

chromex.defaults.console_log.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
chromex.defaults.console_log.cljs$lang$applyTo = (function (seq25597){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq25597));
});

chromex.defaults.console_error = (function chromex$defaults$console_error(var_args){
var args__4736__auto__ = [];
var len__4730__auto___25602 = arguments.length;
var i__4731__auto___25603 = (0);
while(true){
if((i__4731__auto___25603 < len__4730__auto___25602)){
args__4736__auto__.push((arguments[i__4731__auto___25603]));

var G__25604 = (i__4731__auto___25603 + (1));
i__4731__auto___25603 = G__25604;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return console.error.apply(console,cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(args));
});

chromex.defaults.console_error.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
chromex.defaults.console_error.cljs$lang$applyTo = (function (seq25601){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq25601));
});

chromex.defaults.default_logger = (function chromex$defaults$default_logger(var_args){
var args__4736__auto__ = [];
var len__4730__auto___25606 = arguments.length;
var i__4731__auto___25607 = (0);
while(true){
if((i__4731__auto___25607 < len__4730__auto___25606)){
args__4736__auto__.push((arguments[i__4731__auto___25607]));

var G__25608 = (i__4731__auto___25607 + (1));
i__4731__auto___25607 = G__25608;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return cljs.core.apply.cljs$core$IFn$_invoke$arity$3(chromex.defaults.console_log,chromex.defaults.log_prefix,args);
});

chromex.defaults.default_logger.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
chromex.defaults.default_logger.cljs$lang$applyTo = (function (seq25605){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq25605));
});

chromex.defaults.default_callback_error_reporter = (function chromex$defaults$default_callback_error_reporter(descriptor,error){
var function$ = (function (){var or__4131__auto__ = [cljs.core.namespace(cljs.core.cst$kw$id.cljs$core$IFn$_invoke$arity$1(descriptor)),"/",cljs.core.name(cljs.core.cst$kw$id.cljs$core$IFn$_invoke$arity$1(descriptor))].join('');
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return "an unknown function";
}
})();
var explanation = (function (){var target_obj_25609 = error;
var next_obj_25610 = (target_obj_25609["message"]);
return next_obj_25610;
})();
var message = ["an error occurred during the call to ",function$,(cljs.core.truth_(explanation)?[": ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(explanation)].join(''):null)].join('');
return chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([chromex.defaults.log_prefix,message,"Details:",error], 0));
});
chromex.defaults.report_error_if_needed_BANG_ = (function chromex$defaults$report_error_if_needed_BANG_(config,descriptor,error){
var temp__5735__auto__ = cljs.core.cst$kw$callback_DASH_error_DASH_reporter.cljs$core$IFn$_invoke$arity$1(config);
if(cljs.core.truth_(temp__5735__auto__)){
var error_reporter = temp__5735__auto__;

return (error_reporter.cljs$core$IFn$_invoke$arity$2 ? error_reporter.cljs$core$IFn$_invoke$arity$2(descriptor,error) : error_reporter.call(null,descriptor,error));
} else {
return null;
}
});
chromex.defaults.normalize_args = (function chromex$defaults$normalize_args(args){
return cljs.core.vec(args);
});
chromex.defaults.default_callback_fn_factory = (function chromex$defaults$default_callback_fn_factory(config,descriptor,chan){
return (function() { 
var G__25615__delegate = function (args){
var normalized_args = chromex.defaults.normalize_args(args);
var temp__5737__auto__ = (function (){var target_obj_25611 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25612 = (target_obj_25611["chrome"]);
var next_obj_25613 = (next_obj_25612["runtime"]);
var next_obj_25614 = (next_obj_25613["lastError"]);
if((!((next_obj_25614 == null)))){
return next_obj_25614;
} else {
return null;
}
})();
if((temp__5737__auto__ == null)){
chromex.error.set_last_error_BANG_(null);

chromex.error.set_last_error_args_BANG_(null);

return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,normalized_args);
} else {
var error = temp__5737__auto__;
chromex.error.set_last_error_BANG_(error);

chromex.error.set_last_error_args_BANG_(normalized_args);

chromex.defaults.report_error_if_needed_BANG_(config,descriptor,error);

return cljs.core.async.close_BANG_(chan);
}
};
var G__25615 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__25616__i = 0, G__25616__a = new Array(arguments.length -  0);
while (G__25616__i < G__25616__a.length) {G__25616__a[G__25616__i] = arguments[G__25616__i + 0]; ++G__25616__i;}
  args = new cljs.core.IndexedSeq(G__25616__a,0,null);
} 
return G__25615__delegate.call(this,args);};
G__25615.cljs$lang$maxFixedArity = 0;
G__25615.cljs$lang$applyTo = (function (arglist__25617){
var args = cljs.core.seq(arglist__25617);
return G__25615__delegate(args);
});
G__25615.cljs$core$IFn$_invoke$arity$variadic = G__25615__delegate;
return G__25615;
})()
;
});
chromex.defaults.default_callback_channel_factory = (function chromex$defaults$default_callback_channel_factory(_config){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_event_listener_factory = (function chromex$defaults$default_event_listener_factory(_config,event_id,chan){
return (function() { 
var G__25618__delegate = function (args){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [event_id,cljs.core.vec(args)], null));
};
var G__25618 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__25619__i = 0, G__25619__a = new Array(arguments.length -  0);
while (G__25619__i < G__25619__a.length) {G__25619__a[G__25619__i] = arguments[G__25619__i + 0]; ++G__25619__i;}
  args = new cljs.core.IndexedSeq(G__25619__a,0,null);
} 
return G__25618__delegate.call(this,args);};
G__25618.cljs$lang$maxFixedArity = 0;
G__25618.cljs$lang$applyTo = (function (arglist__25620){
var args = cljs.core.seq(arglist__25620);
return G__25618__delegate(args);
});
G__25618.cljs$core$IFn$_invoke$arity$variadic = G__25618__delegate;
return G__25618;
})()
;
});
chromex.defaults.default_missing_api_check = (function chromex$defaults$default_missing_api_check(api,obj,key){
if(cljs.core.truth_(goog.object.containsKey(obj,key))){
return null;
} else {
console.error((new Error(["Chromex library tried to access a missing Chrome API object '",cljs.core.str.cljs$core$IFn$_invoke$arity$1(api),"'.\n","Your Chrome version might be too old or too recent for running this extension.\n","This is a failure which probably requires a software update."].join(''))));

return true;
}
});
chromex.defaults.default_chrome_content_setting_callback_fn_factory = (function chromex$defaults$default_chrome_content_setting_callback_fn_factory(config,chan){
return (function() { 
var G__25625__delegate = function (args){
var last_error = (function (){var target_obj_25621 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25622 = (target_obj_25621["chrome"]);
var next_obj_25623 = (next_obj_25622["runtime"]);
var next_obj_25624 = (next_obj_25623["lastError"]);
if((!((next_obj_25624 == null)))){
return next_obj_25624;
} else {
return null;
}
})();
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.vec(args),last_error], null));
};
var G__25625 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__25626__i = 0, G__25626__a = new Array(arguments.length -  0);
while (G__25626__i < G__25626__a.length) {G__25626__a[G__25626__i] = arguments[G__25626__i + 0]; ++G__25626__i;}
  args = new cljs.core.IndexedSeq(G__25626__a,0,null);
} 
return G__25625__delegate.call(this,args);};
G__25625.cljs$lang$maxFixedArity = 0;
G__25625.cljs$lang$applyTo = (function (arglist__25627){
var args = cljs.core.seq(arglist__25627);
return G__25625__delegate(args);
});
G__25625.cljs$core$IFn$_invoke$arity$variadic = G__25625__delegate;
return G__25625;
})()
;
});
chromex.defaults.default_chrome_content_setting_callback_channel_factory = (function chromex$defaults$default_chrome_content_setting_callback_channel_factory(_config){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_chrome_storage_area_callback_fn_factory = (function chromex$defaults$default_chrome_storage_area_callback_fn_factory(config,chan){
return (function() { 
var G__25632__delegate = function (args){
var last_error = (function (){var target_obj_25628 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25629 = (target_obj_25628["chrome"]);
var next_obj_25630 = (next_obj_25629["runtime"]);
var next_obj_25631 = (next_obj_25630["lastError"]);
if((!((next_obj_25631 == null)))){
return next_obj_25631;
} else {
return null;
}
})();
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.vec(args),last_error], null));
};
var G__25632 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__25633__i = 0, G__25633__a = new Array(arguments.length -  0);
while (G__25633__i < G__25633__a.length) {G__25633__a[G__25633__i] = arguments[G__25633__i + 0]; ++G__25633__i;}
  args = new cljs.core.IndexedSeq(G__25633__a,0,null);
} 
return G__25632__delegate.call(this,args);};
G__25632.cljs$lang$maxFixedArity = 0;
G__25632.cljs$lang$applyTo = (function (arglist__25634){
var args = cljs.core.seq(arglist__25634);
return G__25632__delegate(args);
});
G__25632.cljs$core$IFn$_invoke$arity$variadic = G__25632__delegate;
return G__25632;
})()
;
});
chromex.defaults.default_chrome_storage_area_callback_channel_factory = (function chromex$defaults$default_chrome_storage_area_callback_channel_factory(_config){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_chrome_port_channel_factory = (function chromex$defaults$default_chrome_port_channel_factory(_config){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_chrome_port_on_message_fn_factory = (function chromex$defaults$default_chrome_port_on_message_fn_factory(config,chrome_port){
return (function (message){
if((message == null)){
var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_received_DASH_nil_DASH_message;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$2(config__6203__auto__,chrome_port) : handler__6205__auto__.call(null,config__6203__auto__,chrome_port));
} else {
chromex.protocols.chrome_port_state.put_message_BANG_(chrome_port,message);

return null;
}
});
});
chromex.defaults.default_chrome_port_on_disconnect_fn_factory = (function chromex$defaults$default_chrome_port_on_disconnect_fn_factory(_config,chrome_port){
return (function (){
chromex.protocols.chrome_port_state.close_resources_BANG_(chrome_port);

chromex.protocols.chrome_port_state.set_connected_BANG_(chrome_port,false);

return null;
});
});
chromex.defaults.default_chrome_port_disconnect_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_disconnect_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_post_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_post_message_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_on_disconnect_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_on_disconnect_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_on_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_on_message_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_post_message_called_with_nil = (function chromex$defaults$default_chrome_port_post_message_called_with_nil(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_received_nil_message = (function chromex$defaults$default_chrome_port_received_nil_message(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_put_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_put_message_called_on_disconnected_port(_config,_chrome_port,message){
return null;
});
chromex.defaults.default_config = cljs.core.PersistentHashMap.fromArrays([cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_put_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_channel_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_with_DASH_nil,cljs.core.cst$kw$chrome_DASH_port_DASH_channel_DASH_factory,cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn,cljs.core.cst$kw$chrome_DASH_port_DASH_received_DASH_nil_DASH_message,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_fn_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_channel_DASH_factory,cljs.core.cst$kw$root,cljs.core.cst$kw$event_DASH_listener_DASH_factory,cljs.core.cst$kw$callback_DASH_fn_DASH_factory,cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_fn_DASH_factory,cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_fn_DASH_factory,cljs.core.cst$kw$callback_DASH_error_DASH_reporter,cljs.core.cst$kw$callback_DASH_channel_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_fn_DASH_factory],[chromex.defaults.default_chrome_port_post_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_put_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_on_disconnect_called_on_disconnected_port,chromex.defaults.default_chrome_storage_area_callback_channel_factory,chromex.defaults.default_chrome_port_post_message_called_with_nil,chromex.defaults.default_chrome_port_channel_factory,chromex.defaults.default_missing_api_check,chromex.defaults.default_chrome_port_received_nil_message,chromex.defaults.default_chrome_port_on_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_on_message_fn_factory,chromex.defaults.default_chrome_port_disconnect_called_on_disconnected_port,chromex.defaults.default_chrome_content_setting_callback_channel_factory,goog.global,chromex.defaults.default_event_listener_factory,chromex.defaults.default_callback_fn_factory,chromex.defaults.default_chrome_content_setting_callback_fn_factory,chromex.defaults.default_chrome_storage_area_callback_fn_factory,chromex.defaults.default_callback_error_reporter,chromex.defaults.default_callback_channel_factory,chromex.defaults.default_chrome_port_on_disconnect_fn_factory]);

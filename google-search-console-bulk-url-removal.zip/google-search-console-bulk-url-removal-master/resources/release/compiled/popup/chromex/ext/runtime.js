// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.runtime');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.runtime.last_error_STAR_ = (function chromex$ext$runtime$last_error_STAR_(config){
var result_25722 = (function (){var final_args_array_25723 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.lastError");
var ns_25724 = (function (){var target_obj_25727 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25728 = (target_obj_25727["chrome"]);
var next_obj_25729 = (next_obj_25728["runtime"]);
return next_obj_25729;
})();
var missing_api_25725 = null;
if(missing_api_25725 === true){
return null;
} else {

var target_25726 = (function (){var target_obj_25730 = ns_25724;
var next_obj_25731 = (target_obj_25730["lastError"]);
if((!((next_obj_25731 == null)))){
return next_obj_25731;
} else {
return null;
}
})();
return target_25726;
}
})();
return result_25722;
});
chromex.ext.runtime.id_STAR_ = (function chromex$ext$runtime$id_STAR_(config){
var result_25732 = (function (){var final_args_array_25733 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.id");
var ns_25734 = (function (){var target_obj_25737 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25738 = (target_obj_25737["chrome"]);
var next_obj_25739 = (next_obj_25738["runtime"]);
return next_obj_25739;
})();
var missing_api_25735 = null;
if(missing_api_25735 === true){
return null;
} else {

var target_25736 = (function (){var target_obj_25740 = ns_25734;
var next_obj_25741 = (target_obj_25740["id"]);
if((!((next_obj_25741 == null)))){
return next_obj_25741;
} else {
return null;
}
})();
return target_25736;
}
})();
return result_25732;
});
chromex.ext.runtime.get_background_page_STAR_ = (function chromex$ext$runtime$get_background_page_STAR_(config){
var callback_chan_25742 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_callback_25744_25762 = ((function (callback_chan_25742){
return (function (cb_background_page_25749){
var fexpr__25753 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__25754 = config__6203__auto__;
var G__25755 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_background_DASH_page,cljs.core.cst$kw$name,"getBackgroundPage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"background-page",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__25756 = callback_chan_25742;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__25754,G__25755,G__25756) : handler__6205__auto__.call(null,G__25754,G__25755,G__25756));
})();
return (fexpr__25753.cljs$core$IFn$_invoke$arity$1 ? fexpr__25753.cljs$core$IFn$_invoke$arity$1(cb_background_page_25749) : fexpr__25753.call(null,cb_background_page_25749));
});})(callback_chan_25742))
;
var result_25743_25763 = (function (){var final_args_array_25745 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_25744_25762,"callback",null], null)], null),"chrome.runtime.getBackgroundPage");
var ns_25746 = (function (){var target_obj_25757 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25758 = (target_obj_25757["chrome"]);
var next_obj_25759 = (next_obj_25758["runtime"]);
return next_obj_25759;
})();
var missing_api_25747 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getBackgroundPage",ns_25746,"getBackgroundPage") : api_check_fn__6242__auto__.call(null,"chrome.runtime.getBackgroundPage",ns_25746,"getBackgroundPage"));
})();
if(missing_api_25747 === true){
return null;
} else {

var target_25748 = (function (){var target_obj_25760 = ns_25746;
var next_obj_25761 = (target_obj_25760["getBackgroundPage"]);
if((!((next_obj_25761 == null)))){
return next_obj_25761;
} else {
return null;
}
})();
return target_25748.apply(ns_25746,final_args_array_25745);
}
})();

return callback_chan_25742;
});
chromex.ext.runtime.open_options_page_STAR_ = (function chromex$ext$runtime$open_options_page_STAR_(config){
var callback_chan_25764 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_callback_25766_25779 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__25771 = config__6203__auto__;
var G__25772 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_open_DASH_options_DASH_page,cljs.core.cst$kw$name,"openOptionsPage",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__25773 = callback_chan_25764;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__25771,G__25772,G__25773) : handler__6205__auto__.call(null,G__25771,G__25772,G__25773));
})();
var result_25765_25780 = (function (){var final_args_array_25767 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_25766_25779,"callback",true], null)], null),"chrome.runtime.openOptionsPage");
var ns_25768 = (function (){var target_obj_25774 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25775 = (target_obj_25774["chrome"]);
var next_obj_25776 = (next_obj_25775["runtime"]);
return next_obj_25776;
})();
var missing_api_25769 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.openOptionsPage",ns_25768,"openOptionsPage") : api_check_fn__6242__auto__.call(null,"chrome.runtime.openOptionsPage",ns_25768,"openOptionsPage"));
})();
if(missing_api_25769 === true){
return null;
} else {

var target_25770 = (function (){var target_obj_25777 = ns_25768;
var next_obj_25778 = (target_obj_25777["openOptionsPage"]);
if((!((next_obj_25778 == null)))){
return next_obj_25778;
} else {
return null;
}
})();
return target_25770.apply(ns_25768,final_args_array_25767);
}
})();

return callback_chan_25764;
});
chromex.ext.runtime.get_manifest_STAR_ = (function chromex$ext$runtime$get_manifest_STAR_(config){
var result_25781 = (function (){var final_args_array_25782 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.getManifest");
var ns_25783 = (function (){var target_obj_25786 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25787 = (target_obj_25786["chrome"]);
var next_obj_25788 = (next_obj_25787["runtime"]);
return next_obj_25788;
})();
var missing_api_25784 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getManifest",ns_25783,"getManifest") : api_check_fn__6242__auto__.call(null,"chrome.runtime.getManifest",ns_25783,"getManifest"));
})();
if(missing_api_25784 === true){
return null;
} else {

var target_25785 = (function (){var target_obj_25789 = ns_25783;
var next_obj_25790 = (target_obj_25789["getManifest"]);
if((!((next_obj_25790 == null)))){
return next_obj_25790;
} else {
return null;
}
})();
return target_25785.apply(ns_25783,final_args_array_25782);
}
})();
return result_25781;
});
chromex.ext.runtime.get_url_STAR_ = (function chromex$ext$runtime$get_url_STAR_(config,path){
var marshalled_path_25792 = (function (){var omit_test_25797 = path;
if(cljs.core.keyword_identical_QMARK_(omit_test_25797,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_25797;
}
})();
var result_25791 = (function (){var final_args_array_25793 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_path_25792,"path",null], null)], null),"chrome.runtime.getURL");
var ns_25794 = (function (){var target_obj_25798 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25799 = (target_obj_25798["chrome"]);
var next_obj_25800 = (next_obj_25799["runtime"]);
return next_obj_25800;
})();
var missing_api_25795 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getURL",ns_25794,"getURL") : api_check_fn__6242__auto__.call(null,"chrome.runtime.getURL",ns_25794,"getURL"));
})();
if(missing_api_25795 === true){
return null;
} else {

var target_25796 = (function (){var target_obj_25801 = ns_25794;
var next_obj_25802 = (target_obj_25801["getURL"]);
if((!((next_obj_25802 == null)))){
return next_obj_25802;
} else {
return null;
}
})();
return target_25796.apply(ns_25794,final_args_array_25793);
}
})();
return result_25791;
});
chromex.ext.runtime.set_uninstall_url_STAR_ = (function chromex$ext$runtime$set_uninstall_url_STAR_(config,url){
var callback_chan_25803 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_url_25805_25820 = (function (){var omit_test_25811 = url;
if(cljs.core.keyword_identical_QMARK_(omit_test_25811,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_25811;
}
})();
var marshalled_callback_25806_25821 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__25812 = config__6203__auto__;
var G__25813 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_set_DASH_uninstall_DASH_url,cljs.core.cst$kw$name,"setUninstallURL",cljs.core.cst$kw$since,"41",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"url",cljs.core.cst$kw$since,"34",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__25814 = callback_chan_25803;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__25812,G__25813,G__25814) : handler__6205__auto__.call(null,G__25812,G__25813,G__25814));
})();
var result_25804_25822 = (function (){var final_args_array_25807 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_url_25805_25820,"url",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_25806_25821,"callback",true], null)], null),"chrome.runtime.setUninstallURL");
var ns_25808 = (function (){var target_obj_25815 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25816 = (target_obj_25815["chrome"]);
var next_obj_25817 = (next_obj_25816["runtime"]);
return next_obj_25817;
})();
var missing_api_25809 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.setUninstallURL",ns_25808,"setUninstallURL") : api_check_fn__6242__auto__.call(null,"chrome.runtime.setUninstallURL",ns_25808,"setUninstallURL"));
})();
if(missing_api_25809 === true){
return null;
} else {

var target_25810 = (function (){var target_obj_25818 = ns_25808;
var next_obj_25819 = (target_obj_25818["setUninstallURL"]);
if((!((next_obj_25819 == null)))){
return next_obj_25819;
} else {
return null;
}
})();
return target_25810.apply(ns_25808,final_args_array_25807);
}
})();

return callback_chan_25803;
});
chromex.ext.runtime.reload_STAR_ = (function chromex$ext$runtime$reload_STAR_(config){
var result_25823 = (function (){var final_args_array_25824 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.reload");
var ns_25825 = (function (){var target_obj_25828 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25829 = (target_obj_25828["chrome"]);
var next_obj_25830 = (next_obj_25829["runtime"]);
return next_obj_25830;
})();
var missing_api_25826 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.reload",ns_25825,"reload") : api_check_fn__6242__auto__.call(null,"chrome.runtime.reload",ns_25825,"reload"));
})();
if(missing_api_25826 === true){
return null;
} else {

var target_25827 = (function (){var target_obj_25831 = ns_25825;
var next_obj_25832 = (target_obj_25831["reload"]);
if((!((next_obj_25832 == null)))){
return next_obj_25832;
} else {
return null;
}
})();
return target_25827.apply(ns_25825,final_args_array_25824);
}
})();
return result_25823;
});
chromex.ext.runtime.request_update_check_STAR_ = (function chromex$ext$runtime$request_update_check_STAR_(config){
var callback_chan_25833 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_callback_25835_25854 = ((function (callback_chan_25833){
return (function (cb_status_25840,cb_details_25841){
var fexpr__25845 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__25846 = config__6203__auto__;
var G__25847 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_request_DASH_update_DASH_check,cljs.core.cst$kw$name,"requestUpdateCheck",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"status",cljs.core.cst$kw$type,"runtime.RequestUpdateCheckStatus"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__25848 = callback_chan_25833;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__25846,G__25847,G__25848) : handler__6205__auto__.call(null,G__25846,G__25847,G__25848));
})();
return (fexpr__25845.cljs$core$IFn$_invoke$arity$2 ? fexpr__25845.cljs$core$IFn$_invoke$arity$2(cb_status_25840,cb_details_25841) : fexpr__25845.call(null,cb_status_25840,cb_details_25841));
});})(callback_chan_25833))
;
var result_25834_25855 = (function (){var final_args_array_25836 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_25835_25854,"callback",null], null)], null),"chrome.runtime.requestUpdateCheck");
var ns_25837 = (function (){var target_obj_25849 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25850 = (target_obj_25849["chrome"]);
var next_obj_25851 = (next_obj_25850["runtime"]);
return next_obj_25851;
})();
var missing_api_25838 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.requestUpdateCheck",ns_25837,"requestUpdateCheck") : api_check_fn__6242__auto__.call(null,"chrome.runtime.requestUpdateCheck",ns_25837,"requestUpdateCheck"));
})();
if(missing_api_25838 === true){
return null;
} else {

var target_25839 = (function (){var target_obj_25852 = ns_25837;
var next_obj_25853 = (target_obj_25852["requestUpdateCheck"]);
if((!((next_obj_25853 == null)))){
return next_obj_25853;
} else {
return null;
}
})();
return target_25839.apply(ns_25837,final_args_array_25836);
}
})();

return callback_chan_25833;
});
chromex.ext.runtime.restart_STAR_ = (function chromex$ext$runtime$restart_STAR_(config){
var result_25856 = (function (){var final_args_array_25857 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.restart");
var ns_25858 = (function (){var target_obj_25861 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25862 = (target_obj_25861["chrome"]);
var next_obj_25863 = (next_obj_25862["runtime"]);
return next_obj_25863;
})();
var missing_api_25859 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restart",ns_25858,"restart") : api_check_fn__6242__auto__.call(null,"chrome.runtime.restart",ns_25858,"restart"));
})();
if(missing_api_25859 === true){
return null;
} else {

var target_25860 = (function (){var target_obj_25864 = ns_25858;
var next_obj_25865 = (target_obj_25864["restart"]);
if((!((next_obj_25865 == null)))){
return next_obj_25865;
} else {
return null;
}
})();
return target_25860.apply(ns_25858,final_args_array_25857);
}
})();
return result_25856;
});
chromex.ext.runtime.restart_after_delay_STAR_ = (function chromex$ext$runtime$restart_after_delay_STAR_(config,seconds){
var callback_chan_25866 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_seconds_25868_25883 = (function (){var omit_test_25874 = seconds;
if(cljs.core.keyword_identical_QMARK_(omit_test_25874,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_25874;
}
})();
var marshalled_callback_25869_25884 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__25875 = config__6203__auto__;
var G__25876 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_restart_DASH_after_DASH_delay,cljs.core.cst$kw$name,"restartAfterDelay",cljs.core.cst$kw$since,"53",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"seconds",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__25877 = callback_chan_25866;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__25875,G__25876,G__25877) : handler__6205__auto__.call(null,G__25875,G__25876,G__25877));
})();
var result_25867_25885 = (function (){var final_args_array_25870 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_seconds_25868_25883,"seconds",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_25869_25884,"callback",true], null)], null),"chrome.runtime.restartAfterDelay");
var ns_25871 = (function (){var target_obj_25878 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25879 = (target_obj_25878["chrome"]);
var next_obj_25880 = (next_obj_25879["runtime"]);
return next_obj_25880;
})();
var missing_api_25872 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restartAfterDelay",ns_25871,"restartAfterDelay") : api_check_fn__6242__auto__.call(null,"chrome.runtime.restartAfterDelay",ns_25871,"restartAfterDelay"));
})();
if(missing_api_25872 === true){
return null;
} else {

var target_25873 = (function (){var target_obj_25881 = ns_25871;
var next_obj_25882 = (target_obj_25881["restartAfterDelay"]);
if((!((next_obj_25882 == null)))){
return next_obj_25882;
} else {
return null;
}
})();
return target_25873.apply(ns_25871,final_args_array_25870);
}
})();

return callback_chan_25866;
});
chromex.ext.runtime.connect_STAR_ = (function chromex$ext$runtime$connect_STAR_(config,extension_id,connect_info){
var marshalled_extension_id_25887 = (function (){var omit_test_25893 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_25893,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_25893;
}
})();
var marshalled_connect_info_25888 = (function (){var omit_test_25894 = connect_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_25894,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_25894;
}
})();
var result_25886 = (function (){var final_args_array_25889 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_25887,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_25888,"connect-info",true], null)], null),"chrome.runtime.connect");
var ns_25890 = (function (){var target_obj_25895 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25896 = (target_obj_25895["chrome"]);
var next_obj_25897 = (next_obj_25896["runtime"]);
return next_obj_25897;
})();
var missing_api_25891 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connect",ns_25890,"connect") : api_check_fn__6242__auto__.call(null,"chrome.runtime.connect",ns_25890,"connect"));
})();
if(missing_api_25891 === true){
return null;
} else {

var target_25892 = (function (){var target_obj_25898 = ns_25890;
var next_obj_25899 = (target_obj_25898["connect"]);
if((!((next_obj_25899 == null)))){
return next_obj_25899;
} else {
return null;
}
})();
return target_25892.apply(ns_25890,final_args_array_25889);
}
})();
return chromex.marshalling.from_native_chrome_port(config,result_25886);
});
chromex.ext.runtime.connect_native_STAR_ = (function chromex$ext$runtime$connect_native_STAR_(config,application){
var marshalled_application_25901 = (function (){var omit_test_25906 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_25906,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_25906;
}
})();
var result_25900 = (function (){var final_args_array_25902 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_25901,"application",null], null)], null),"chrome.runtime.connectNative");
var ns_25903 = (function (){var target_obj_25907 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25908 = (target_obj_25907["chrome"]);
var next_obj_25909 = (next_obj_25908["runtime"]);
return next_obj_25909;
})();
var missing_api_25904 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connectNative",ns_25903,"connectNative") : api_check_fn__6242__auto__.call(null,"chrome.runtime.connectNative",ns_25903,"connectNative"));
})();
if(missing_api_25904 === true){
return null;
} else {

var target_25905 = (function (){var target_obj_25910 = ns_25903;
var next_obj_25911 = (target_obj_25910["connectNative"]);
if((!((next_obj_25911 == null)))){
return next_obj_25911;
} else {
return null;
}
})();
return target_25905.apply(ns_25903,final_args_array_25902);
}
})();
return chromex.marshalling.from_native_chrome_port(config,result_25900);
});
chromex.ext.runtime.send_message_STAR_ = (function chromex$ext$runtime$send_message_STAR_(config,extension_id,message,options){
var callback_chan_25912 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_extension_id_25914_25938 = (function (){var omit_test_25922 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_25922,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_25922;
}
})();
var marshalled_message_25915_25939 = (function (){var omit_test_25923 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_25923,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_25923;
}
})();
var marshalled_options_25916_25940 = (function (){var omit_test_25924 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_25924,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_25924;
}
})();
var marshalled_response_callback_25917_25941 = ((function (marshalled_extension_id_25914_25938,marshalled_message_25915_25939,marshalled_options_25916_25940,callback_chan_25912){
return (function (cb_response_25925){
var fexpr__25929 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__25930 = config__6203__auto__;
var G__25931 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_message,cljs.core.cst$kw$name,"sendMessage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"extension-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$since,"32",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__25932 = callback_chan_25912;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__25930,G__25931,G__25932) : handler__6205__auto__.call(null,G__25930,G__25931,G__25932));
})();
return (fexpr__25929.cljs$core$IFn$_invoke$arity$1 ? fexpr__25929.cljs$core$IFn$_invoke$arity$1(cb_response_25925) : fexpr__25929.call(null,cb_response_25925));
});})(marshalled_extension_id_25914_25938,marshalled_message_25915_25939,marshalled_options_25916_25940,callback_chan_25912))
;
var result_25913_25942 = (function (){var final_args_array_25918 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_25914_25938,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_25915_25939,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_25916_25940,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_25917_25941,"response-callback",true], null)], null),"chrome.runtime.sendMessage");
var ns_25919 = (function (){var target_obj_25933 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25934 = (target_obj_25933["chrome"]);
var next_obj_25935 = (next_obj_25934["runtime"]);
return next_obj_25935;
})();
var missing_api_25920 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendMessage",ns_25919,"sendMessage") : api_check_fn__6242__auto__.call(null,"chrome.runtime.sendMessage",ns_25919,"sendMessage"));
})();
if(missing_api_25920 === true){
return null;
} else {

var target_25921 = (function (){var target_obj_25936 = ns_25919;
var next_obj_25937 = (target_obj_25936["sendMessage"]);
if((!((next_obj_25937 == null)))){
return next_obj_25937;
} else {
return null;
}
})();
return target_25921.apply(ns_25919,final_args_array_25918);
}
})();

return callback_chan_25912;
});
chromex.ext.runtime.send_native_message_STAR_ = (function chromex$ext$runtime$send_native_message_STAR_(config,application,message){
var callback_chan_25943 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_application_25945_25967 = (function (){var omit_test_25952 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_25952,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_25952;
}
})();
var marshalled_message_25946_25968 = (function (){var omit_test_25953 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_25953,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_25953;
}
})();
var marshalled_response_callback_25947_25969 = ((function (marshalled_application_25945_25967,marshalled_message_25946_25968,callback_chan_25943){
return (function (cb_response_25954){
var fexpr__25958 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__25959 = config__6203__auto__;
var G__25960 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_native_DASH_message,cljs.core.cst$kw$name,"sendNativeMessage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"application",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__25961 = callback_chan_25943;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__25959,G__25960,G__25961) : handler__6205__auto__.call(null,G__25959,G__25960,G__25961));
})();
return (fexpr__25958.cljs$core$IFn$_invoke$arity$1 ? fexpr__25958.cljs$core$IFn$_invoke$arity$1(cb_response_25954) : fexpr__25958.call(null,cb_response_25954));
});})(marshalled_application_25945_25967,marshalled_message_25946_25968,callback_chan_25943))
;
var result_25944_25970 = (function (){var final_args_array_25948 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_25945_25967,"application",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_25946_25968,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_25947_25969,"response-callback",true], null)], null),"chrome.runtime.sendNativeMessage");
var ns_25949 = (function (){var target_obj_25962 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25963 = (target_obj_25962["chrome"]);
var next_obj_25964 = (next_obj_25963["runtime"]);
return next_obj_25964;
})();
var missing_api_25950 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendNativeMessage",ns_25949,"sendNativeMessage") : api_check_fn__6242__auto__.call(null,"chrome.runtime.sendNativeMessage",ns_25949,"sendNativeMessage"));
})();
if(missing_api_25950 === true){
return null;
} else {

var target_25951 = (function (){var target_obj_25965 = ns_25949;
var next_obj_25966 = (target_obj_25965["sendNativeMessage"]);
if((!((next_obj_25966 == null)))){
return next_obj_25966;
} else {
return null;
}
})();
return target_25951.apply(ns_25949,final_args_array_25948);
}
})();

return callback_chan_25943;
});
chromex.ext.runtime.get_platform_info_STAR_ = (function chromex$ext$runtime$get_platform_info_STAR_(config){
var callback_chan_25971 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_callback_25973_25991 = ((function (callback_chan_25971){
return (function (cb_platform_info_25978){
var fexpr__25982 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__25983 = config__6203__auto__;
var G__25984 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_platform_DASH_info,cljs.core.cst$kw$name,"getPlatformInfo",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"platform-info",cljs.core.cst$kw$type,"runtime.PlatformInfo"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__25985 = callback_chan_25971;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__25983,G__25984,G__25985) : handler__6205__auto__.call(null,G__25983,G__25984,G__25985));
})();
return (fexpr__25982.cljs$core$IFn$_invoke$arity$1 ? fexpr__25982.cljs$core$IFn$_invoke$arity$1(cb_platform_info_25978) : fexpr__25982.call(null,cb_platform_info_25978));
});})(callback_chan_25971))
;
var result_25972_25992 = (function (){var final_args_array_25974 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_25973_25991,"callback",null], null)], null),"chrome.runtime.getPlatformInfo");
var ns_25975 = (function (){var target_obj_25986 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_25987 = (target_obj_25986["chrome"]);
var next_obj_25988 = (next_obj_25987["runtime"]);
return next_obj_25988;
})();
var missing_api_25976 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPlatformInfo",ns_25975,"getPlatformInfo") : api_check_fn__6242__auto__.call(null,"chrome.runtime.getPlatformInfo",ns_25975,"getPlatformInfo"));
})();
if(missing_api_25976 === true){
return null;
} else {

var target_25977 = (function (){var target_obj_25989 = ns_25975;
var next_obj_25990 = (target_obj_25989["getPlatformInfo"]);
if((!((next_obj_25990 == null)))){
return next_obj_25990;
} else {
return null;
}
})();
return target_25977.apply(ns_25975,final_args_array_25974);
}
})();

return callback_chan_25971;
});
chromex.ext.runtime.get_package_directory_entry_STAR_ = (function chromex$ext$runtime$get_package_directory_entry_STAR_(config){
var callback_chan_25993 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_callback_25995_26013 = ((function (callback_chan_25993){
return (function (cb_directory_entry_26000){
var fexpr__26004 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__26005 = config__6203__auto__;
var G__26006 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_package_DASH_directory_DASH_entry,cljs.core.cst$kw$name,"getPackageDirectoryEntry",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"directory-entry",cljs.core.cst$kw$type,"DirectoryEntry"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__26007 = callback_chan_25993;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__26005,G__26006,G__26007) : handler__6205__auto__.call(null,G__26005,G__26006,G__26007));
})();
return (fexpr__26004.cljs$core$IFn$_invoke$arity$1 ? fexpr__26004.cljs$core$IFn$_invoke$arity$1(cb_directory_entry_26000) : fexpr__26004.call(null,cb_directory_entry_26000));
});})(callback_chan_25993))
;
var result_25994_26014 = (function (){var final_args_array_25996 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_25995_26013,"callback",null], null)], null),"chrome.runtime.getPackageDirectoryEntry");
var ns_25997 = (function (){var target_obj_26008 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_26009 = (target_obj_26008["chrome"]);
var next_obj_26010 = (next_obj_26009["runtime"]);
return next_obj_26010;
})();
var missing_api_25998 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPackageDirectoryEntry",ns_25997,"getPackageDirectoryEntry") : api_check_fn__6242__auto__.call(null,"chrome.runtime.getPackageDirectoryEntry",ns_25997,"getPackageDirectoryEntry"));
})();
if(missing_api_25998 === true){
return null;
} else {

var target_25999 = (function (){var target_obj_26011 = ns_25997;
var next_obj_26012 = (target_obj_26011["getPackageDirectoryEntry"]);
if((!((next_obj_26012 == null)))){
return next_obj_26012;
} else {
return null;
}
})();
return target_25999.apply(ns_25997,final_args_array_25996);
}
})();

return callback_chan_25993;
});
chromex.ext.runtime.on_startup_STAR_ = (function chromex$ext$runtime$on_startup_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___26033 = arguments.length;
var i__4731__auto___26034 = (0);
while(true){
if((i__4731__auto___26034 < len__4730__auto___26033)){
args__4736__auto__.push((arguments[i__4731__auto___26034]));

var G__26035 = (i__4731__auto___26034 + (1));
i__4731__auto___26034 = G__26035;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_26018 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__26025 = config__6203__auto__;
var G__26026 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_startup;
var G__26027 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__26025,G__26026,G__26027) : handler__6205__auto__.call(null,G__26025,G__26026,G__26027));
})();
var handler_fn_26019 = event_fn_26018;
var logging_fn_26020 = ((function (event_fn_26018,handler_fn_26019){
return (function (){

return (handler_fn_26019.cljs$core$IFn$_invoke$arity$0 ? handler_fn_26019.cljs$core$IFn$_invoke$arity$0() : handler_fn_26019.call(null));
});})(event_fn_26018,handler_fn_26019))
;
var ns_obj_26023 = (function (){var target_obj_26028 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_26029 = (target_obj_26028["chrome"]);
var next_obj_26030 = (next_obj_26029["runtime"]);
return next_obj_26030;
})();
var missing_api_26024 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onStartup",ns_obj_26023,"onStartup") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onStartup",ns_obj_26023,"onStartup"));
})();
if(missing_api_26024 === true){
return null;
} else {
var event_obj_26021 = (function (){var target_obj_26031 = ns_obj_26023;
var next_obj_26032 = (target_obj_26031["onStartup"]);
return next_obj_26032;
})();
var result_26022 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_26021,logging_fn_26020,channel);
result_26022.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_26022;
}
});

chromex.ext.runtime.on_startup_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_startup_STAR_.cljs$lang$applyTo = (function (seq26015){
var G__26016 = cljs.core.first(seq26015);
var seq26015__$1 = cljs.core.next(seq26015);
var G__26017 = cljs.core.first(seq26015__$1);
var seq26015__$2 = cljs.core.next(seq26015__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__26016,G__26017,seq26015__$2);
});

chromex.ext.runtime.on_installed_STAR_ = (function chromex$ext$runtime$on_installed_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___26056 = arguments.length;
var i__4731__auto___26057 = (0);
while(true){
if((i__4731__auto___26057 < len__4730__auto___26056)){
args__4736__auto__.push((arguments[i__4731__auto___26057]));

var G__26058 = (i__4731__auto___26057 + (1));
i__4731__auto___26057 = G__26058;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_26039 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__26048 = config__6203__auto__;
var G__26049 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_installed;
var G__26050 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__26048,G__26049,G__26050) : handler__6205__auto__.call(null,G__26048,G__26049,G__26050));
})();
var handler_fn_26040 = ((function (event_fn_26039){
return (function (cb_details_26046){
return (event_fn_26039.cljs$core$IFn$_invoke$arity$1 ? event_fn_26039.cljs$core$IFn$_invoke$arity$1(cb_details_26046) : event_fn_26039.call(null,cb_details_26046));
});})(event_fn_26039))
;
var logging_fn_26041 = ((function (event_fn_26039,handler_fn_26040){
return (function (cb_param_details_26047){

return handler_fn_26040(cb_param_details_26047);
});})(event_fn_26039,handler_fn_26040))
;
var ns_obj_26044 = (function (){var target_obj_26051 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_26052 = (target_obj_26051["chrome"]);
var next_obj_26053 = (next_obj_26052["runtime"]);
return next_obj_26053;
})();
var missing_api_26045 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onInstalled",ns_obj_26044,"onInstalled") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onInstalled",ns_obj_26044,"onInstalled"));
})();
if(missing_api_26045 === true){
return null;
} else {
var event_obj_26042 = (function (){var target_obj_26054 = ns_obj_26044;
var next_obj_26055 = (target_obj_26054["onInstalled"]);
return next_obj_26055;
})();
var result_26043 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_26042,logging_fn_26041,channel);
result_26043.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_26043;
}
});

chromex.ext.runtime.on_installed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_installed_STAR_.cljs$lang$applyTo = (function (seq26036){
var G__26037 = cljs.core.first(seq26036);
var seq26036__$1 = cljs.core.next(seq26036);
var G__26038 = cljs.core.first(seq26036__$1);
var seq26036__$2 = cljs.core.next(seq26036__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__26037,G__26038,seq26036__$2);
});

chromex.ext.runtime.on_suspend_STAR_ = (function chromex$ext$runtime$on_suspend_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___26077 = arguments.length;
var i__4731__auto___26078 = (0);
while(true){
if((i__4731__auto___26078 < len__4730__auto___26077)){
args__4736__auto__.push((arguments[i__4731__auto___26078]));

var G__26079 = (i__4731__auto___26078 + (1));
i__4731__auto___26078 = G__26079;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_26062 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__26069 = config__6203__auto__;
var G__26070 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend;
var G__26071 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__26069,G__26070,G__26071) : handler__6205__auto__.call(null,G__26069,G__26070,G__26071));
})();
var handler_fn_26063 = event_fn_26062;
var logging_fn_26064 = ((function (event_fn_26062,handler_fn_26063){
return (function (){

return (handler_fn_26063.cljs$core$IFn$_invoke$arity$0 ? handler_fn_26063.cljs$core$IFn$_invoke$arity$0() : handler_fn_26063.call(null));
});})(event_fn_26062,handler_fn_26063))
;
var ns_obj_26067 = (function (){var target_obj_26072 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_26073 = (target_obj_26072["chrome"]);
var next_obj_26074 = (next_obj_26073["runtime"]);
return next_obj_26074;
})();
var missing_api_26068 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspend",ns_obj_26067,"onSuspend") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onSuspend",ns_obj_26067,"onSuspend"));
})();
if(missing_api_26068 === true){
return null;
} else {
var event_obj_26065 = (function (){var target_obj_26075 = ns_obj_26067;
var next_obj_26076 = (target_obj_26075["onSuspend"]);
return next_obj_26076;
})();
var result_26066 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_26065,logging_fn_26064,channel);
result_26066.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_26066;
}
});

chromex.ext.runtime.on_suspend_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_suspend_STAR_.cljs$lang$applyTo = (function (seq26059){
var G__26060 = cljs.core.first(seq26059);
var seq26059__$1 = cljs.core.next(seq26059);
var G__26061 = cljs.core.first(seq26059__$1);
var seq26059__$2 = cljs.core.next(seq26059__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__26060,G__26061,seq26059__$2);
});

chromex.ext.runtime.on_suspend_canceled_STAR_ = (function chromex$ext$runtime$on_suspend_canceled_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___26098 = arguments.length;
var i__4731__auto___26099 = (0);
while(true){
if((i__4731__auto___26099 < len__4730__auto___26098)){
args__4736__auto__.push((arguments[i__4731__auto___26099]));

var G__26100 = (i__4731__auto___26099 + (1));
i__4731__auto___26099 = G__26100;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_26083 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__26090 = config__6203__auto__;
var G__26091 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend_DASH_canceled;
var G__26092 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__26090,G__26091,G__26092) : handler__6205__auto__.call(null,G__26090,G__26091,G__26092));
})();
var handler_fn_26084 = event_fn_26083;
var logging_fn_26085 = ((function (event_fn_26083,handler_fn_26084){
return (function (){

return (handler_fn_26084.cljs$core$IFn$_invoke$arity$0 ? handler_fn_26084.cljs$core$IFn$_invoke$arity$0() : handler_fn_26084.call(null));
});})(event_fn_26083,handler_fn_26084))
;
var ns_obj_26088 = (function (){var target_obj_26093 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_26094 = (target_obj_26093["chrome"]);
var next_obj_26095 = (next_obj_26094["runtime"]);
return next_obj_26095;
})();
var missing_api_26089 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspendCanceled",ns_obj_26088,"onSuspendCanceled") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onSuspendCanceled",ns_obj_26088,"onSuspendCanceled"));
})();
if(missing_api_26089 === true){
return null;
} else {
var event_obj_26086 = (function (){var target_obj_26096 = ns_obj_26088;
var next_obj_26097 = (target_obj_26096["onSuspendCanceled"]);
return next_obj_26097;
})();
var result_26087 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_26086,logging_fn_26085,channel);
result_26087.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_26087;
}
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$applyTo = (function (seq26080){
var G__26081 = cljs.core.first(seq26080);
var seq26080__$1 = cljs.core.next(seq26080);
var G__26082 = cljs.core.first(seq26080__$1);
var seq26080__$2 = cljs.core.next(seq26080__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__26081,G__26082,seq26080__$2);
});

chromex.ext.runtime.on_update_available_STAR_ = (function chromex$ext$runtime$on_update_available_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___26121 = arguments.length;
var i__4731__auto___26122 = (0);
while(true){
if((i__4731__auto___26122 < len__4730__auto___26121)){
args__4736__auto__.push((arguments[i__4731__auto___26122]));

var G__26123 = (i__4731__auto___26122 + (1));
i__4731__auto___26122 = G__26123;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_26104 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__26113 = config__6203__auto__;
var G__26114 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_update_DASH_available;
var G__26115 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__26113,G__26114,G__26115) : handler__6205__auto__.call(null,G__26113,G__26114,G__26115));
})();
var handler_fn_26105 = ((function (event_fn_26104){
return (function (cb_details_26111){
return (event_fn_26104.cljs$core$IFn$_invoke$arity$1 ? event_fn_26104.cljs$core$IFn$_invoke$arity$1(cb_details_26111) : event_fn_26104.call(null,cb_details_26111));
});})(event_fn_26104))
;
var logging_fn_26106 = ((function (event_fn_26104,handler_fn_26105){
return (function (cb_param_details_26112){

return handler_fn_26105(cb_param_details_26112);
});})(event_fn_26104,handler_fn_26105))
;
var ns_obj_26109 = (function (){var target_obj_26116 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_26117 = (target_obj_26116["chrome"]);
var next_obj_26118 = (next_obj_26117["runtime"]);
return next_obj_26118;
})();
var missing_api_26110 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onUpdateAvailable",ns_obj_26109,"onUpdateAvailable") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onUpdateAvailable",ns_obj_26109,"onUpdateAvailable"));
})();
if(missing_api_26110 === true){
return null;
} else {
var event_obj_26107 = (function (){var target_obj_26119 = ns_obj_26109;
var next_obj_26120 = (target_obj_26119["onUpdateAvailable"]);
return next_obj_26120;
})();
var result_26108 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_26107,logging_fn_26106,channel);
result_26108.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_26108;
}
});

chromex.ext.runtime.on_update_available_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_update_available_STAR_.cljs$lang$applyTo = (function (seq26101){
var G__26102 = cljs.core.first(seq26101);
var seq26101__$1 = cljs.core.next(seq26101);
var G__26103 = cljs.core.first(seq26101__$1);
var seq26101__$2 = cljs.core.next(seq26101__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__26102,G__26103,seq26101__$2);
});

chromex.ext.runtime.on_browser_update_available_STAR_ = (function chromex$ext$runtime$on_browser_update_available_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___26142 = arguments.length;
var i__4731__auto___26143 = (0);
while(true){
if((i__4731__auto___26143 < len__4730__auto___26142)){
args__4736__auto__.push((arguments[i__4731__auto___26143]));

var G__26144 = (i__4731__auto___26143 + (1));
i__4731__auto___26143 = G__26144;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_26127 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__26134 = config__6203__auto__;
var G__26135 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_browser_DASH_update_DASH_available;
var G__26136 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__26134,G__26135,G__26136) : handler__6205__auto__.call(null,G__26134,G__26135,G__26136));
})();
var handler_fn_26128 = event_fn_26127;
var logging_fn_26129 = ((function (event_fn_26127,handler_fn_26128){
return (function (){

return (handler_fn_26128.cljs$core$IFn$_invoke$arity$0 ? handler_fn_26128.cljs$core$IFn$_invoke$arity$0() : handler_fn_26128.call(null));
});})(event_fn_26127,handler_fn_26128))
;
var ns_obj_26132 = (function (){var target_obj_26137 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_26138 = (target_obj_26137["chrome"]);
var next_obj_26139 = (next_obj_26138["runtime"]);
return next_obj_26139;
})();
var missing_api_26133 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onBrowserUpdateAvailable",ns_obj_26132,"onBrowserUpdateAvailable") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onBrowserUpdateAvailable",ns_obj_26132,"onBrowserUpdateAvailable"));
})();
if(missing_api_26133 === true){
return null;
} else {
var event_obj_26130 = (function (){var target_obj_26140 = ns_obj_26132;
var next_obj_26141 = (target_obj_26140["onBrowserUpdateAvailable"]);
return next_obj_26141;
})();
var result_26131 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_26130,logging_fn_26129,channel);
result_26131.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_26131;
}
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$applyTo = (function (seq26124){
var G__26125 = cljs.core.first(seq26124);
var seq26124__$1 = cljs.core.next(seq26124);
var G__26126 = cljs.core.first(seq26124__$1);
var seq26124__$2 = cljs.core.next(seq26124__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__26125,G__26126,seq26124__$2);
});

chromex.ext.runtime.on_connect_STAR_ = (function chromex$ext$runtime$on_connect_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___26166 = arguments.length;
var i__4731__auto___26167 = (0);
while(true){
if((i__4731__auto___26167 < len__4730__auto___26166)){
args__4736__auto__.push((arguments[i__4731__auto___26167]));

var G__26168 = (i__4731__auto___26167 + (1));
i__4731__auto___26167 = G__26168;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_26148 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__26157 = config__6203__auto__;
var G__26158 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect;
var G__26159 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__26157,G__26158,G__26159) : handler__6205__auto__.call(null,G__26157,G__26158,G__26159));
})();
var handler_fn_26149 = ((function (event_fn_26148){
return (function (cb_port_26155){
var G__26160 = chromex.marshalling.from_native_chrome_port(config,cb_port_26155);
return (event_fn_26148.cljs$core$IFn$_invoke$arity$1 ? event_fn_26148.cljs$core$IFn$_invoke$arity$1(G__26160) : event_fn_26148.call(null,G__26160));
});})(event_fn_26148))
;
var logging_fn_26150 = ((function (event_fn_26148,handler_fn_26149){
return (function (cb_param_port_26156){

return handler_fn_26149(cb_param_port_26156);
});})(event_fn_26148,handler_fn_26149))
;
var ns_obj_26153 = (function (){var target_obj_26161 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_26162 = (target_obj_26161["chrome"]);
var next_obj_26163 = (next_obj_26162["runtime"]);
return next_obj_26163;
})();
var missing_api_26154 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnect",ns_obj_26153,"onConnect") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onConnect",ns_obj_26153,"onConnect"));
})();
if(missing_api_26154 === true){
return null;
} else {
var event_obj_26151 = (function (){var target_obj_26164 = ns_obj_26153;
var next_obj_26165 = (target_obj_26164["onConnect"]);
return next_obj_26165;
})();
var result_26152 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_26151,logging_fn_26150,channel);
result_26152.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_26152;
}
});

chromex.ext.runtime.on_connect_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_connect_STAR_.cljs$lang$applyTo = (function (seq26145){
var G__26146 = cljs.core.first(seq26145);
var seq26145__$1 = cljs.core.next(seq26145);
var G__26147 = cljs.core.first(seq26145__$1);
var seq26145__$2 = cljs.core.next(seq26145__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__26146,G__26147,seq26145__$2);
});

chromex.ext.runtime.on_connect_external_STAR_ = (function chromex$ext$runtime$on_connect_external_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___26190 = arguments.length;
var i__4731__auto___26191 = (0);
while(true){
if((i__4731__auto___26191 < len__4730__auto___26190)){
args__4736__auto__.push((arguments[i__4731__auto___26191]));

var G__26192 = (i__4731__auto___26191 + (1));
i__4731__auto___26191 = G__26192;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_26172 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__26181 = config__6203__auto__;
var G__26182 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect_DASH_external;
var G__26183 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__26181,G__26182,G__26183) : handler__6205__auto__.call(null,G__26181,G__26182,G__26183));
})();
var handler_fn_26173 = ((function (event_fn_26172){
return (function (cb_port_26179){
var G__26184 = chromex.marshalling.from_native_chrome_port(config,cb_port_26179);
return (event_fn_26172.cljs$core$IFn$_invoke$arity$1 ? event_fn_26172.cljs$core$IFn$_invoke$arity$1(G__26184) : event_fn_26172.call(null,G__26184));
});})(event_fn_26172))
;
var logging_fn_26174 = ((function (event_fn_26172,handler_fn_26173){
return (function (cb_param_port_26180){

return handler_fn_26173(cb_param_port_26180);
});})(event_fn_26172,handler_fn_26173))
;
var ns_obj_26177 = (function (){var target_obj_26185 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_26186 = (target_obj_26185["chrome"]);
var next_obj_26187 = (next_obj_26186["runtime"]);
return next_obj_26187;
})();
var missing_api_26178 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnectExternal",ns_obj_26177,"onConnectExternal") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onConnectExternal",ns_obj_26177,"onConnectExternal"));
})();
if(missing_api_26178 === true){
return null;
} else {
var event_obj_26175 = (function (){var target_obj_26188 = ns_obj_26177;
var next_obj_26189 = (target_obj_26188["onConnectExternal"]);
return next_obj_26189;
})();
var result_26176 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_26175,logging_fn_26174,channel);
result_26176.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_26176;
}
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$applyTo = (function (seq26169){
var G__26170 = cljs.core.first(seq26169);
var seq26169__$1 = cljs.core.next(seq26169);
var G__26171 = cljs.core.first(seq26169__$1);
var seq26169__$2 = cljs.core.next(seq26169__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__26170,G__26171,seq26169__$2);
});

chromex.ext.runtime.on_connect_native_STAR_ = (function chromex$ext$runtime$on_connect_native_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___26214 = arguments.length;
var i__4731__auto___26215 = (0);
while(true){
if((i__4731__auto___26215 < len__4730__auto___26214)){
args__4736__auto__.push((arguments[i__4731__auto___26215]));

var G__26216 = (i__4731__auto___26215 + (1));
i__4731__auto___26215 = G__26216;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_native_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_connect_native_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_26196 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__26205 = config__6203__auto__;
var G__26206 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect_DASH_native;
var G__26207 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__26205,G__26206,G__26207) : handler__6205__auto__.call(null,G__26205,G__26206,G__26207));
})();
var handler_fn_26197 = ((function (event_fn_26196){
return (function (cb_port_26203){
var G__26208 = chromex.marshalling.from_native_chrome_port(config,cb_port_26203);
return (event_fn_26196.cljs$core$IFn$_invoke$arity$1 ? event_fn_26196.cljs$core$IFn$_invoke$arity$1(G__26208) : event_fn_26196.call(null,G__26208));
});})(event_fn_26196))
;
var logging_fn_26198 = ((function (event_fn_26196,handler_fn_26197){
return (function (cb_param_port_26204){

return handler_fn_26197(cb_param_port_26204);
});})(event_fn_26196,handler_fn_26197))
;
var ns_obj_26201 = (function (){var target_obj_26209 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_26210 = (target_obj_26209["chrome"]);
var next_obj_26211 = (next_obj_26210["runtime"]);
return next_obj_26211;
})();
var missing_api_26202 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnectNative",ns_obj_26201,"onConnectNative") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onConnectNative",ns_obj_26201,"onConnectNative"));
})();
if(missing_api_26202 === true){
return null;
} else {
var event_obj_26199 = (function (){var target_obj_26212 = ns_obj_26201;
var next_obj_26213 = (target_obj_26212["onConnectNative"]);
return next_obj_26213;
})();
var result_26200 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_26199,logging_fn_26198,channel);
result_26200.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_26200;
}
});

chromex.ext.runtime.on_connect_native_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_connect_native_STAR_.cljs$lang$applyTo = (function (seq26193){
var G__26194 = cljs.core.first(seq26193);
var seq26193__$1 = cljs.core.next(seq26193);
var G__26195 = cljs.core.first(seq26193__$1);
var seq26193__$2 = cljs.core.next(seq26193__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__26194,G__26195,seq26193__$2);
});

chromex.ext.runtime.on_message_STAR_ = (function chromex$ext$runtime$on_message_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___26241 = arguments.length;
var i__4731__auto___26242 = (0);
while(true){
if((i__4731__auto___26242 < len__4730__auto___26241)){
args__4736__auto__.push((arguments[i__4731__auto___26242]));

var G__26243 = (i__4731__auto___26242 + (1));
i__4731__auto___26242 = G__26243;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_26220 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__26233 = config__6203__auto__;
var G__26234 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message;
var G__26235 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__26233,G__26234,G__26235) : handler__6205__auto__.call(null,G__26233,G__26234,G__26235));
})();
var handler_fn_26221 = ((function (event_fn_26220){
return (function (cb_message_26227,cb_sender_26228,cb_send_response_26229){
return (event_fn_26220.cljs$core$IFn$_invoke$arity$3 ? event_fn_26220.cljs$core$IFn$_invoke$arity$3(cb_message_26227,cb_sender_26228,cb_send_response_26229) : event_fn_26220.call(null,cb_message_26227,cb_sender_26228,cb_send_response_26229));
});})(event_fn_26220))
;
var logging_fn_26222 = ((function (event_fn_26220,handler_fn_26221){
return (function (cb_param_message_26230,cb_param_sender_26231,cb_param_send_response_26232){

return handler_fn_26221(cb_param_message_26230,cb_param_sender_26231,cb_param_send_response_26232);
});})(event_fn_26220,handler_fn_26221))
;
var ns_obj_26225 = (function (){var target_obj_26236 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_26237 = (target_obj_26236["chrome"]);
var next_obj_26238 = (next_obj_26237["runtime"]);
return next_obj_26238;
})();
var missing_api_26226 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessage",ns_obj_26225,"onMessage") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onMessage",ns_obj_26225,"onMessage"));
})();
if(missing_api_26226 === true){
return null;
} else {
var event_obj_26223 = (function (){var target_obj_26239 = ns_obj_26225;
var next_obj_26240 = (target_obj_26239["onMessage"]);
return next_obj_26240;
})();
var result_26224 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_26223,logging_fn_26222,channel);
result_26224.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_26224;
}
});

chromex.ext.runtime.on_message_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_message_STAR_.cljs$lang$applyTo = (function (seq26217){
var G__26218 = cljs.core.first(seq26217);
var seq26217__$1 = cljs.core.next(seq26217);
var G__26219 = cljs.core.first(seq26217__$1);
var seq26217__$2 = cljs.core.next(seq26217__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__26218,G__26219,seq26217__$2);
});

chromex.ext.runtime.on_message_external_STAR_ = (function chromex$ext$runtime$on_message_external_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___26268 = arguments.length;
var i__4731__auto___26269 = (0);
while(true){
if((i__4731__auto___26269 < len__4730__auto___26268)){
args__4736__auto__.push((arguments[i__4731__auto___26269]));

var G__26270 = (i__4731__auto___26269 + (1));
i__4731__auto___26269 = G__26270;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_26247 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__26260 = config__6203__auto__;
var G__26261 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message_DASH_external;
var G__26262 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__26260,G__26261,G__26262) : handler__6205__auto__.call(null,G__26260,G__26261,G__26262));
})();
var handler_fn_26248 = ((function (event_fn_26247){
return (function (cb_message_26254,cb_sender_26255,cb_send_response_26256){
return (event_fn_26247.cljs$core$IFn$_invoke$arity$3 ? event_fn_26247.cljs$core$IFn$_invoke$arity$3(cb_message_26254,cb_sender_26255,cb_send_response_26256) : event_fn_26247.call(null,cb_message_26254,cb_sender_26255,cb_send_response_26256));
});})(event_fn_26247))
;
var logging_fn_26249 = ((function (event_fn_26247,handler_fn_26248){
return (function (cb_param_message_26257,cb_param_sender_26258,cb_param_send_response_26259){

return handler_fn_26248(cb_param_message_26257,cb_param_sender_26258,cb_param_send_response_26259);
});})(event_fn_26247,handler_fn_26248))
;
var ns_obj_26252 = (function (){var target_obj_26263 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_26264 = (target_obj_26263["chrome"]);
var next_obj_26265 = (next_obj_26264["runtime"]);
return next_obj_26265;
})();
var missing_api_26253 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessageExternal",ns_obj_26252,"onMessageExternal") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onMessageExternal",ns_obj_26252,"onMessageExternal"));
})();
if(missing_api_26253 === true){
return null;
} else {
var event_obj_26250 = (function (){var target_obj_26266 = ns_obj_26252;
var next_obj_26267 = (target_obj_26266["onMessageExternal"]);
return next_obj_26267;
})();
var result_26251 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_26250,logging_fn_26249,channel);
result_26251.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_26251;
}
});

chromex.ext.runtime.on_message_external_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_message_external_STAR_.cljs$lang$applyTo = (function (seq26244){
var G__26245 = cljs.core.first(seq26244);
var seq26244__$1 = cljs.core.next(seq26244);
var G__26246 = cljs.core.first(seq26244__$1);
var seq26244__$2 = cljs.core.next(seq26244__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__26245,G__26246,seq26244__$2);
});

chromex.ext.runtime.on_restart_required_STAR_ = (function chromex$ext$runtime$on_restart_required_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___26291 = arguments.length;
var i__4731__auto___26292 = (0);
while(true){
if((i__4731__auto___26292 < len__4730__auto___26291)){
args__4736__auto__.push((arguments[i__4731__auto___26292]));

var G__26293 = (i__4731__auto___26292 + (1));
i__4731__auto___26292 = G__26293;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_26274 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__26283 = config__6203__auto__;
var G__26284 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_restart_DASH_required;
var G__26285 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__26283,G__26284,G__26285) : handler__6205__auto__.call(null,G__26283,G__26284,G__26285));
})();
var handler_fn_26275 = ((function (event_fn_26274){
return (function (cb_reason_26281){
return (event_fn_26274.cljs$core$IFn$_invoke$arity$1 ? event_fn_26274.cljs$core$IFn$_invoke$arity$1(cb_reason_26281) : event_fn_26274.call(null,cb_reason_26281));
});})(event_fn_26274))
;
var logging_fn_26276 = ((function (event_fn_26274,handler_fn_26275){
return (function (cb_param_reason_26282){

return handler_fn_26275(cb_param_reason_26282);
});})(event_fn_26274,handler_fn_26275))
;
var ns_obj_26279 = (function (){var target_obj_26286 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_26287 = (target_obj_26286["chrome"]);
var next_obj_26288 = (next_obj_26287["runtime"]);
return next_obj_26288;
})();
var missing_api_26280 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onRestartRequired",ns_obj_26279,"onRestartRequired") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onRestartRequired",ns_obj_26279,"onRestartRequired"));
})();
if(missing_api_26280 === true){
return null;
} else {
var event_obj_26277 = (function (){var target_obj_26289 = ns_obj_26279;
var next_obj_26290 = (target_obj_26289["onRestartRequired"]);
return next_obj_26290;
})();
var result_26278 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_26277,logging_fn_26276,channel);
result_26278.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_26278;
}
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$applyTo = (function (seq26271){
var G__26272 = cljs.core.first(seq26271);
var seq26271__$1 = cljs.core.next(seq26271);
var G__26273 = cljs.core.first(seq26271__$1);
var seq26271__$2 = cljs.core.next(seq26271__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__26272,G__26273,seq26271__$2);
});


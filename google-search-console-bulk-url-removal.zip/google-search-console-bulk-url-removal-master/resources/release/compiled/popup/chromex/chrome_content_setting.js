// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_content_setting');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.protocols.chrome_content_setting');
goog.require('chromex.support');
goog.require('oops.core');

/**
* @constructor
 * @implements {chromex.protocols.chrome_content_setting.IChromeContentSetting}
*/
chromex.chrome_content_setting.ChromeContentSetting = (function (native_chrome_content_setting,channel_factory,callback_factory){
this.native_chrome_content_setting = native_chrome_content_setting;
this.channel_factory = channel_factory;
this.callback_factory = callback_factory;
});
chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_native_content_setting$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_content_setting;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_25649_25665 = self__.native_chrome_content_setting;
var call_info_25651_25666 = [target_obj_25649_25665,(function (){var next_obj_25652 = (target_obj_25649_25665["get"]);
return next_obj_25652;
})()];
var fn_25650_25667 = (call_info_25651_25666[(1)]);
if((!((fn_25650_25667 == null)))){
fn_25650_25667.call((call_info_25651_25666[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$set$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_25653_25668 = self__.native_chrome_content_setting;
var call_info_25655_25669 = [target_obj_25653_25668,(function (){var next_obj_25656 = (target_obj_25653_25668["set"]);
return next_obj_25656;
})()];
var fn_25654_25670 = (call_info_25655_25669[(1)]);
if((!((fn_25654_25670 == null)))){
fn_25654_25670.call((call_info_25655_25669[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$clear$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_25657_25671 = self__.native_chrome_content_setting;
var call_info_25659_25672 = [target_obj_25657_25671,(function (){var next_obj_25660 = (target_obj_25657_25671["clear"]);
return next_obj_25660;
})()];
var fn_25658_25673 = (call_info_25659_25672[(1)]);
if((!((fn_25658_25673 == null)))){
fn_25658_25673.call((call_info_25659_25672[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_resource_identifiers$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_25661_25674 = self__.native_chrome_content_setting;
var call_info_25663_25675 = [target_obj_25661_25674,(function (){var next_obj_25664 = (target_obj_25661_25674["getResourceIdentifiers"]);
return next_obj_25664;
})()];
var fn_25662_25676 = (call_info_25663_25675[(1)]);
if((!((fn_25662_25676 == null)))){
fn_25662_25676.call((call_info_25663_25675[(0)]),(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$native_DASH_chrome_DASH_content_DASH_setting,cljs.core.cst$sym$channel_DASH_factory,cljs.core.cst$sym$callback_DASH_factory], null);
});

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$type = true;

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorStr = "chromex.chrome-content-setting/ChromeContentSetting";

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"chromex.chrome-content-setting/ChromeContentSetting");
});

/**
 * Positional factory function for chromex.chrome-content-setting/ChromeContentSetting.
 */
chromex.chrome_content_setting.__GT_ChromeContentSetting = (function chromex$chrome_content_setting$__GT_ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory){
return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory));
});

chromex.chrome_content_setting.make_chrome_content_setting = (function chromex$chrome_content_setting$make_chrome_content_setting(config,native_chrome_content_setting){

return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,(function (){var config__6212__auto__ = config;
var handler_key__6213__auto__ = cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_channel_DASH_factory;
var handler__6214__auto__ = handler_key__6213__auto__.cljs$core$IFn$_invoke$arity$1(config__6212__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6214__auto__,config__6212__auto__);
})(),(function (){var config__6212__auto__ = config;
var handler_key__6213__auto__ = cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_fn_DASH_factory;
var handler__6214__auto__ = handler_key__6213__auto__.cljs$core$IFn$_invoke$arity$1(config__6212__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6214__auto__,config__6212__auto__);
})()));
});

// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_event_subscription');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.protocols.chrome_event_channel');
goog.require('chromex.protocols.chrome_event_subscription');
goog.require('oops.core');

/**
* @constructor
 * @implements {chromex.protocols.chrome_event_subscription.IChromeEventSubscription}
*/
chromex.chrome_event_subscription.ChromeEventSubscription = (function (chrome_event,listener,chan,subscribed_count){
this.chrome_event = chrome_event;
this.listener = listener;
this.chan = chan;
this.subscribed_count = subscribed_count;
});
chromex.chrome_event_subscription.ChromeEventSubscription.prototype.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_event_subscription.ChromeEventSubscription.prototype.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return this$__$1.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,null);
});

chromex.chrome_event_subscription.ChromeEventSubscription.prototype.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2 = (function (this$,extra_args){
var self__ = this;
var this$__$1 = this;
new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$pre,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [(((extra_args == null)) || (cljs.core.seq_QMARK_(extra_args)))], null)], null);

if((!(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(self__.subscribed_count,(0))))){
return (chromex.chrome_event_subscription._STAR_subscribe_called_while_subscribed_STAR_.cljs$core$IFn$_invoke$arity$1 ? chromex.chrome_event_subscription._STAR_subscribe_called_while_subscribed_STAR_.cljs$core$IFn$_invoke$arity$1(this$__$1) : chromex.chrome_event_subscription._STAR_subscribe_called_while_subscribed_STAR_.call(null,this$__$1));
} else {
if((((!((self__.chan == null))))?((((false) || ((cljs.core.PROTOCOL_SENTINEL === self__.chan.chromex$protocols$chrome_event_channel$IChromeEventChannel$))))?true:(((!self__.chan.cljs$lang$protocol_mask$partition$))?cljs.core.native_satisfies_QMARK_(chromex.protocols.chrome_event_channel.IChromeEventChannel,self__.chan):false)):cljs.core.native_satisfies_QMARK_(chromex.protocols.chrome_event_channel.IChromeEventChannel,self__.chan))){
chromex.protocols.chrome_event_channel.register_BANG_(self__.chan,this$__$1);
} else {
}

self__.subscribed_count = (self__.subscribed_count + (1));

var target_obj_25581 = self__.chrome_event;
var call_info_25583 = [target_obj_25581,(function (){var next_obj_25584 = (target_obj_25581["addListener"]);
return next_obj_25584;
})()];
var fn_25582 = (call_info_25583[(1)]);
if((!((fn_25582 == null)))){
return fn_25582.apply((call_info_25583[(0)]),oops.helpers.to_native_array(cljs.core.cons(self__.listener,extra_args)));
} else {
return null;
}
}
});

chromex.chrome_event_subscription.ChromeEventSubscription.prototype.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$unsubscribe_BANG_$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
if((!(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(self__.subscribed_count,(1))))){
return (chromex.chrome_event_subscription._STAR_unsubscribe_called_while_not_subscribed_STAR_.cljs$core$IFn$_invoke$arity$1 ? chromex.chrome_event_subscription._STAR_unsubscribe_called_while_not_subscribed_STAR_.cljs$core$IFn$_invoke$arity$1(this$__$1) : chromex.chrome_event_subscription._STAR_unsubscribe_called_while_not_subscribed_STAR_.call(null,this$__$1));
} else {
self__.subscribed_count = (self__.subscribed_count - (1));

var target_obj_25585_25590 = self__.chrome_event;
var call_info_25587_25591 = [target_obj_25585_25590,(function (){var next_obj_25588 = (target_obj_25585_25590["removeListener"]);
return next_obj_25588;
})()];
var fn_25586_25592 = (call_info_25587_25591[(1)]);
if((!((fn_25586_25592 == null)))){
fn_25586_25592.call((call_info_25587_25591[(0)]),self__.listener);
} else {
}

if((((!((self__.chan == null))))?((((false) || ((cljs.core.PROTOCOL_SENTINEL === self__.chan.chromex$protocols$chrome_event_channel$IChromeEventChannel$))))?true:(((!self__.chan.cljs$lang$protocol_mask$partition$))?cljs.core.native_satisfies_QMARK_(chromex.protocols.chrome_event_channel.IChromeEventChannel,self__.chan):false)):cljs.core.native_satisfies_QMARK_(chromex.protocols.chrome_event_channel.IChromeEventChannel,self__.chan))){
return chromex.protocols.chrome_event_channel.unregister_BANG_(self__.chan,this$__$1);
} else {
return null;
}
}
});

chromex.chrome_event_subscription.ChromeEventSubscription.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$chrome_DASH_event,cljs.core.cst$sym$listener,cljs.core.cst$sym$chan,cljs.core.with_meta(cljs.core.cst$sym$subscribed_DASH_count,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$mutable,true], null))], null);
});

chromex.chrome_event_subscription.ChromeEventSubscription.cljs$lang$type = true;

chromex.chrome_event_subscription.ChromeEventSubscription.cljs$lang$ctorStr = "chromex.chrome-event-subscription/ChromeEventSubscription";

chromex.chrome_event_subscription.ChromeEventSubscription.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"chromex.chrome-event-subscription/ChromeEventSubscription");
});

/**
 * Positional factory function for chromex.chrome-event-subscription/ChromeEventSubscription.
 */
chromex.chrome_event_subscription.__GT_ChromeEventSubscription = (function chromex$chrome_event_subscription$__GT_ChromeEventSubscription(chrome_event,listener,chan,subscribed_count){
return (new chromex.chrome_event_subscription.ChromeEventSubscription(chrome_event,listener,chan,subscribed_count));
});

chromex.chrome_event_subscription.make_chrome_event_subscription = (function chromex$chrome_event_subscription$make_chrome_event_subscription(chrome_event,listener,chan){



return (new chromex.chrome_event_subscription.ChromeEventSubscription(chrome_event,listener,chan,(0)));
});
chromex.chrome_event_subscription._STAR_subscribe_called_while_subscribed_STAR_ = (function chromex$chrome_event_subscription$_STAR_subscribe_called_while_subscribed_STAR_(_chrome_event_subscription){
return null;
});
chromex.chrome_event_subscription._STAR_unsubscribe_called_while_not_subscribed_STAR_ = (function chromex$chrome_event_subscription$_STAR_unsubscribe_called_while_not_subscribed_STAR_(_chrome_event_subscription){
return null;
});

// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('dommy.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('clojure.string');
goog.require('dommy.utils');
/**
 * Returns a selector in string format.
 * Accepts string, keyword, or collection.
 */
dommy.core.selector = (function dommy$core$selector(data){
if(cljs.core.coll_QMARK_(data)){
return clojure.string.join.cljs$core$IFn$_invoke$arity$2(" ",cljs.core.map.cljs$core$IFn$_invoke$arity$2(dommy.core.selector,data));
} else {
if(((typeof data === 'string') || ((data instanceof cljs.core.Keyword)))){
return cljs.core.name(data);
} else {
return null;
}
}
});
dommy.core.text = (function dommy$core$text(elem){
var or__4131__auto__ = elem.textContent;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return elem.innerText;
}
});
dommy.core.html = (function dommy$core$html(elem){
return elem.innerHTML;
});
dommy.core.value = (function dommy$core$value(elem){
return elem.value;
});
dommy.core.class$ = (function dommy$core$class(elem){
return elem.className;
});
dommy.core.attr = (function dommy$core$attr(elem,k){
if(cljs.core.truth_(k)){
return elem.getAttribute(dommy.utils.as_str(k));
} else {
return null;
}
});
/**
 * The computed style of `elem`, optionally specifying the key of
 * a particular style to return
 */
dommy.core.style = (function dommy$core$style(var_args){
var G__31301 = arguments.length;
switch (G__31301) {
case 1:
return dommy.core.style.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return dommy.core.style.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.style.cljs$core$IFn$_invoke$arity$1 = (function (elem){
return cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(window.getComputedStyle(elem));
});

dommy.core.style.cljs$core$IFn$_invoke$arity$2 = (function (elem,k){
return (window.getComputedStyle(elem)[dommy.utils.as_str(k)]);
});

dommy.core.style.cljs$lang$maxFixedArity = 2;

dommy.core.px = (function dommy$core$px(elem,k){

var pixels = dommy.core.style.cljs$core$IFn$_invoke$arity$2(elem,k);
if(cljs.core.seq(pixels)){
return parseInt(pixels);
} else {
return null;
}
});
/**
 * Does `elem` contain `c` in its class list
 */
dommy.core.has_class_QMARK_ = (function dommy$core$has_class_QMARK_(elem,c){
var c__$1 = dommy.utils.as_str(c);
var temp__5733__auto__ = elem.classList;
if(cljs.core.truth_(temp__5733__auto__)){
var class_list = temp__5733__auto__;
return class_list.contains(c__$1);
} else {
var temp__5735__auto__ = dommy.core.class$(elem);
if(cljs.core.truth_(temp__5735__auto__)){
var class_name = temp__5735__auto__;
var temp__5735__auto____$1 = dommy.utils.class_index(class_name,c__$1);
if(cljs.core.truth_(temp__5735__auto____$1)){
var i = temp__5735__auto____$1;
return (i >= (0));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Is `elem` hidden (as associated with hide!/show!/toggle!, using display: none)
 */
dommy.core.hidden_QMARK_ = (function dommy$core$hidden_QMARK_(elem){
return (dommy.core.style.cljs$core$IFn$_invoke$arity$2(elem,cljs.core.cst$kw$display) === "none");
});
/**
 * Returns a map of the bounding client rect of `elem`
 * as a map with [:top :left :right :bottom :width :height]
 */
dommy.core.bounding_client_rect = (function dommy$core$bounding_client_rect(elem){
var r = elem.getBoundingClientRect();
return new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$top,r.top,cljs.core.cst$kw$bottom,r.bottom,cljs.core.cst$kw$left,r.left,cljs.core.cst$kw$right,r.right,cljs.core.cst$kw$width,r.width,cljs.core.cst$kw$height,r.height], null);
});
dommy.core.parent = (function dommy$core$parent(elem){
return elem.parentNode;
});
dommy.core.children = (function dommy$core$children(elem){
return elem.children;
});
/**
 * Lazy seq of the ancestors of `elem`
 */
dommy.core.ancestors = (function dommy$core$ancestors(elem){
return cljs.core.take_while.cljs$core$IFn$_invoke$arity$2(cljs.core.identity,cljs.core.iterate(dommy.core.parent,elem));
});
dommy.core.ancestor_nodes = dommy.core.ancestors;
/**
 * Returns a predicate on nodes that match `selector` at the
 * time of this `matches-pred` call (may return outdated results
 * if you fuck with the DOM)
 */
dommy.core.matches_pred = (function dommy$core$matches_pred(var_args){
var G__31304 = arguments.length;
switch (G__31304) {
case 2:
return dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 1:
return dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$2 = (function (base,selector){
var matches = dommy.utils.__GT_Array(base.querySelectorAll(dommy.core.selector(selector)));
return ((function (matches){
return (function (elem){
return (matches.indexOf(elem) >= (0));
});
;})(matches))
});

dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$1 = (function (selector){
return dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$2(document,selector);
});

dommy.core.matches_pred.cljs$lang$maxFixedArity = 2;

/**
 * Closest ancestor of `elem` (up to `base`, if provided)
 * that matches `selector`
 */
dommy.core.closest = (function dommy$core$closest(var_args){
var G__31308 = arguments.length;
switch (G__31308) {
case 3:
return dommy.core.closest.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 2:
return dommy.core.closest.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.closest.cljs$core$IFn$_invoke$arity$3 = (function (base,elem,selector){
return cljs.core.first(cljs.core.filter.cljs$core$IFn$_invoke$arity$2(dommy.core.matches_pred.cljs$core$IFn$_invoke$arity$2(base,selector),cljs.core.take_while.cljs$core$IFn$_invoke$arity$2((function (p1__31306_SHARP_){
return (!((p1__31306_SHARP_ === base)));
}),dommy.core.ancestors(elem))));
});

dommy.core.closest.cljs$core$IFn$_invoke$arity$2 = (function (elem,selector){
return dommy.core.closest.cljs$core$IFn$_invoke$arity$3(document.body,elem,selector);
});

dommy.core.closest.cljs$lang$maxFixedArity = 3;

/**
 * Is `descendant` a descendant of `ancestor`?
 * (http://goo.gl/T8pgCX)
 */
dommy.core.descendant_QMARK_ = (function dommy$core$descendant_QMARK_(descendant,ancestor){
if(cljs.core.truth_(ancestor.contains)){
return ancestor.contains(descendant);
} else {
if(cljs.core.truth_(ancestor.compareDocumentPosition)){
return ((ancestor.compareDocumentPosition(descendant) & (1 << (4))) != 0);
} else {
return null;
}
}
});
/**
 * Set the textContent of `elem` to `text`, fall back to innerText
 */
dommy.core.set_text_BANG_ = (function dommy$core$set_text_BANG_(elem,text){
if((!((void 0 === elem.textContent)))){
elem.textContent = text;
} else {
elem.innerText = text;
}

return elem;
});
/**
 * Set the innerHTML of `elem` to `html`
 */
dommy.core.set_html_BANG_ = (function dommy$core$set_html_BANG_(elem,html){
elem.innerHTML = html;

return elem;
});
/**
 * Set the value of `elem` to `value`
 */
dommy.core.set_value_BANG_ = (function dommy$core$set_value_BANG_(elem,value){
elem.value = value;

return elem;
});
/**
 * Set the css class of `elem` to `elem`
 */
dommy.core.set_class_BANG_ = (function dommy$core$set_class_BANG_(elem,c){
return elem.className = c;
});
/**
 * Set the style of `elem` using key-value pairs:
 * 
 *    (set-style! elem :display "block" :color "red")
 */
dommy.core.set_style_BANG_ = (function dommy$core$set_style_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___31328 = arguments.length;
var i__4731__auto___31329 = (0);
while(true){
if((i__4731__auto___31329 < len__4730__auto___31328)){
args__4736__auto__.push((arguments[i__4731__auto___31329]));

var G__31330 = (i__4731__auto___31329 + (1));
i__4731__auto___31329 = G__31330;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,kvs){

var style = elem.style;
var seq__31312_31331 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),kvs));
var chunk__31313_31332 = null;
var count__31314_31333 = (0);
var i__31315_31334 = (0);
while(true){
if((i__31315_31334 < count__31314_31333)){
var vec__31322_31335 = chunk__31313_31332.cljs$core$IIndexed$_nth$arity$2(null,i__31315_31334);
var k_31336 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31322_31335,(0),null);
var v_31337 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31322_31335,(1),null);
style.setProperty(dommy.utils.as_str(k_31336),v_31337);


var G__31338 = seq__31312_31331;
var G__31339 = chunk__31313_31332;
var G__31340 = count__31314_31333;
var G__31341 = (i__31315_31334 + (1));
seq__31312_31331 = G__31338;
chunk__31313_31332 = G__31339;
count__31314_31333 = G__31340;
i__31315_31334 = G__31341;
continue;
} else {
var temp__5735__auto___31342 = cljs.core.seq(seq__31312_31331);
if(temp__5735__auto___31342){
var seq__31312_31343__$1 = temp__5735__auto___31342;
if(cljs.core.chunked_seq_QMARK_(seq__31312_31343__$1)){
var c__4550__auto___31344 = cljs.core.chunk_first(seq__31312_31343__$1);
var G__31345 = cljs.core.chunk_rest(seq__31312_31343__$1);
var G__31346 = c__4550__auto___31344;
var G__31347 = cljs.core.count(c__4550__auto___31344);
var G__31348 = (0);
seq__31312_31331 = G__31345;
chunk__31313_31332 = G__31346;
count__31314_31333 = G__31347;
i__31315_31334 = G__31348;
continue;
} else {
var vec__31325_31349 = cljs.core.first(seq__31312_31343__$1);
var k_31350 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31325_31349,(0),null);
var v_31351 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31325_31349,(1),null);
style.setProperty(dommy.utils.as_str(k_31350),v_31351);


var G__31352 = cljs.core.next(seq__31312_31343__$1);
var G__31353 = null;
var G__31354 = (0);
var G__31355 = (0);
seq__31312_31331 = G__31352;
chunk__31313_31332 = G__31353;
count__31314_31333 = G__31354;
i__31315_31334 = G__31355;
continue;
}
} else {
}
}
break;
}

return elem;
});

dommy.core.set_style_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
dommy.core.set_style_BANG_.cljs$lang$applyTo = (function (seq31310){
var G__31311 = cljs.core.first(seq31310);
var seq31310__$1 = cljs.core.next(seq31310);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31311,seq31310__$1);
});

/**
 * Remove the style of `elem` using keywords:
 *   
 *    (remove-style! elem :display :color)
 */
dommy.core.remove_style_BANG_ = (function dommy$core$remove_style_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___31362 = arguments.length;
var i__4731__auto___31363 = (0);
while(true){
if((i__4731__auto___31363 < len__4730__auto___31362)){
args__4736__auto__.push((arguments[i__4731__auto___31363]));

var G__31364 = (i__4731__auto___31363 + (1));
i__4731__auto___31363 = G__31364;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return dommy.core.remove_style_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

dommy.core.remove_style_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,keywords){
var style = elem.style;
var seq__31358_31365 = cljs.core.seq(keywords);
var chunk__31359_31366 = null;
var count__31360_31367 = (0);
var i__31361_31368 = (0);
while(true){
if((i__31361_31368 < count__31360_31367)){
var kw_31369 = chunk__31359_31366.cljs$core$IIndexed$_nth$arity$2(null,i__31361_31368);
style.removeProperty(dommy.utils.as_str(kw_31369));


var G__31370 = seq__31358_31365;
var G__31371 = chunk__31359_31366;
var G__31372 = count__31360_31367;
var G__31373 = (i__31361_31368 + (1));
seq__31358_31365 = G__31370;
chunk__31359_31366 = G__31371;
count__31360_31367 = G__31372;
i__31361_31368 = G__31373;
continue;
} else {
var temp__5735__auto___31374 = cljs.core.seq(seq__31358_31365);
if(temp__5735__auto___31374){
var seq__31358_31375__$1 = temp__5735__auto___31374;
if(cljs.core.chunked_seq_QMARK_(seq__31358_31375__$1)){
var c__4550__auto___31376 = cljs.core.chunk_first(seq__31358_31375__$1);
var G__31377 = cljs.core.chunk_rest(seq__31358_31375__$1);
var G__31378 = c__4550__auto___31376;
var G__31379 = cljs.core.count(c__4550__auto___31376);
var G__31380 = (0);
seq__31358_31365 = G__31377;
chunk__31359_31366 = G__31378;
count__31360_31367 = G__31379;
i__31361_31368 = G__31380;
continue;
} else {
var kw_31381 = cljs.core.first(seq__31358_31375__$1);
style.removeProperty(dommy.utils.as_str(kw_31381));


var G__31382 = cljs.core.next(seq__31358_31375__$1);
var G__31383 = null;
var G__31384 = (0);
var G__31385 = (0);
seq__31358_31365 = G__31382;
chunk__31359_31366 = G__31383;
count__31360_31367 = G__31384;
i__31361_31368 = G__31385;
continue;
}
} else {
}
}
break;
}

return elem;
});

dommy.core.remove_style_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
dommy.core.remove_style_BANG_.cljs$lang$applyTo = (function (seq31356){
var G__31357 = cljs.core.first(seq31356);
var seq31356__$1 = cljs.core.next(seq31356);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31357,seq31356__$1);
});

dommy.core.set_px_BANG_ = (function dommy$core$set_px_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___31404 = arguments.length;
var i__4731__auto___31405 = (0);
while(true){
if((i__4731__auto___31405 < len__4730__auto___31404)){
args__4736__auto__.push((arguments[i__4731__auto___31405]));

var G__31406 = (i__4731__auto___31405 + (1));
i__4731__auto___31405 = G__31406;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return dommy.core.set_px_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

dommy.core.set_px_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,kvs){


var seq__31388_31407 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),kvs));
var chunk__31389_31408 = null;
var count__31390_31409 = (0);
var i__31391_31410 = (0);
while(true){
if((i__31391_31410 < count__31390_31409)){
var vec__31398_31411 = chunk__31389_31408.cljs$core$IIndexed$_nth$arity$2(null,i__31391_31410);
var k_31412 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31398_31411,(0),null);
var v_31413 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31398_31411,(1),null);
dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([k_31412,[cljs.core.str.cljs$core$IFn$_invoke$arity$1(v_31413),"px"].join('')], 0));


var G__31414 = seq__31388_31407;
var G__31415 = chunk__31389_31408;
var G__31416 = count__31390_31409;
var G__31417 = (i__31391_31410 + (1));
seq__31388_31407 = G__31414;
chunk__31389_31408 = G__31415;
count__31390_31409 = G__31416;
i__31391_31410 = G__31417;
continue;
} else {
var temp__5735__auto___31418 = cljs.core.seq(seq__31388_31407);
if(temp__5735__auto___31418){
var seq__31388_31419__$1 = temp__5735__auto___31418;
if(cljs.core.chunked_seq_QMARK_(seq__31388_31419__$1)){
var c__4550__auto___31420 = cljs.core.chunk_first(seq__31388_31419__$1);
var G__31421 = cljs.core.chunk_rest(seq__31388_31419__$1);
var G__31422 = c__4550__auto___31420;
var G__31423 = cljs.core.count(c__4550__auto___31420);
var G__31424 = (0);
seq__31388_31407 = G__31421;
chunk__31389_31408 = G__31422;
count__31390_31409 = G__31423;
i__31391_31410 = G__31424;
continue;
} else {
var vec__31401_31425 = cljs.core.first(seq__31388_31419__$1);
var k_31426 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31401_31425,(0),null);
var v_31427 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31401_31425,(1),null);
dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([k_31426,[cljs.core.str.cljs$core$IFn$_invoke$arity$1(v_31427),"px"].join('')], 0));


var G__31428 = cljs.core.next(seq__31388_31419__$1);
var G__31429 = null;
var G__31430 = (0);
var G__31431 = (0);
seq__31388_31407 = G__31428;
chunk__31389_31408 = G__31429;
count__31390_31409 = G__31430;
i__31391_31410 = G__31431;
continue;
}
} else {
}
}
break;
}

return elem;
});

dommy.core.set_px_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
dommy.core.set_px_BANG_.cljs$lang$applyTo = (function (seq31386){
var G__31387 = cljs.core.first(seq31386);
var seq31386__$1 = cljs.core.next(seq31386);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31387,seq31386__$1);
});

/**
 * Sets dom attributes on and returns `elem`.
 * Attributes without values will be set to their name:
 * 
 *     (set-attr! elem :disabled)
 * 
 * With values, the function takes variadic kv pairs:
 * 
 *     (set-attr! elem :id "some-id"
 *                     :name "some-name")
 */
dommy.core.set_attr_BANG_ = (function dommy$core$set_attr_BANG_(var_args){
var G__31437 = arguments.length;
switch (G__31437) {
case 2:
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
var args_arr__4751__auto__ = [];
var len__4730__auto___31457 = arguments.length;
var i__4731__auto___31458 = (0);
while(true){
if((i__4731__auto___31458 < len__4730__auto___31457)){
args_arr__4751__auto__.push((arguments[i__4731__auto___31458]));

var G__31459 = (i__4731__auto___31458 + (1));
i__4731__auto___31458 = G__31459;
continue;
} else {
}
break;
}

var argseq__4752__auto__ = (new cljs.core.IndexedSeq(args_arr__4751__auto__.slice((3)),(0),null));
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__4752__auto__);

}
});

dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,k){
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3(elem,k,dommy.utils.as_str(k));
});

dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (elem,k,v){
var k__$1 = dommy.utils.as_str(k);
if(cljs.core.truth_(v)){
if(cljs.core.fn_QMARK_(v)){
var G__31438 = elem;
(G__31438[k__$1] = v);

return G__31438;
} else {
var G__31439 = elem;
G__31439.setAttribute(k__$1,v);

return G__31439;
}
} else {
return null;
}
});

dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,k,v,kvs){

var seq__31440_31460 = cljs.core.seq(cljs.core.cons(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [k,v], null),cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),kvs)));
var chunk__31441_31461 = null;
var count__31442_31462 = (0);
var i__31443_31463 = (0);
while(true){
if((i__31443_31463 < count__31442_31462)){
var vec__31450_31464 = chunk__31441_31461.cljs$core$IIndexed$_nth$arity$2(null,i__31443_31463);
var k_31465__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31450_31464,(0),null);
var v_31466__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31450_31464,(1),null);
dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3(elem,k_31465__$1,v_31466__$1);


var G__31467 = seq__31440_31460;
var G__31468 = chunk__31441_31461;
var G__31469 = count__31442_31462;
var G__31470 = (i__31443_31463 + (1));
seq__31440_31460 = G__31467;
chunk__31441_31461 = G__31468;
count__31442_31462 = G__31469;
i__31443_31463 = G__31470;
continue;
} else {
var temp__5735__auto___31471 = cljs.core.seq(seq__31440_31460);
if(temp__5735__auto___31471){
var seq__31440_31472__$1 = temp__5735__auto___31471;
if(cljs.core.chunked_seq_QMARK_(seq__31440_31472__$1)){
var c__4550__auto___31473 = cljs.core.chunk_first(seq__31440_31472__$1);
var G__31474 = cljs.core.chunk_rest(seq__31440_31472__$1);
var G__31475 = c__4550__auto___31473;
var G__31476 = cljs.core.count(c__4550__auto___31473);
var G__31477 = (0);
seq__31440_31460 = G__31474;
chunk__31441_31461 = G__31475;
count__31442_31462 = G__31476;
i__31443_31463 = G__31477;
continue;
} else {
var vec__31453_31478 = cljs.core.first(seq__31440_31472__$1);
var k_31479__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31453_31478,(0),null);
var v_31480__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31453_31478,(1),null);
dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$3(elem,k_31479__$1,v_31480__$1);


var G__31481 = cljs.core.next(seq__31440_31472__$1);
var G__31482 = null;
var G__31483 = (0);
var G__31484 = (0);
seq__31440_31460 = G__31481;
chunk__31441_31461 = G__31482;
count__31442_31462 = G__31483;
i__31443_31463 = G__31484;
continue;
}
} else {
}
}
break;
}

return elem;
});

/** @this {Function} */
dommy.core.set_attr_BANG_.cljs$lang$applyTo = (function (seq31433){
var G__31434 = cljs.core.first(seq31433);
var seq31433__$1 = cljs.core.next(seq31433);
var G__31435 = cljs.core.first(seq31433__$1);
var seq31433__$2 = cljs.core.next(seq31433__$1);
var G__31436 = cljs.core.first(seq31433__$2);
var seq31433__$3 = cljs.core.next(seq31433__$2);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31434,G__31435,G__31436,seq31433__$3);
});

dommy.core.set_attr_BANG_.cljs$lang$maxFixedArity = (3);

/**
 * Removes dom attributes on and returns `elem`.
 * `class` and `classes` are special cases which clear
 * out the class name on removal.
 */
dommy.core.remove_attr_BANG_ = (function dommy$core$remove_attr_BANG_(var_args){
var G__31489 = arguments.length;
switch (G__31489) {
case 2:
return dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4751__auto__ = [];
var len__4730__auto___31496 = arguments.length;
var i__4731__auto___31497 = (0);
while(true){
if((i__4731__auto___31497 < len__4730__auto___31496)){
args_arr__4751__auto__.push((arguments[i__4731__auto___31497]));

var G__31498 = (i__4731__auto___31497 + (1));
i__4731__auto___31497 = G__31498;
continue;
} else {
}
break;
}

var argseq__4752__auto__ = (new cljs.core.IndexedSeq(args_arr__4751__auto__.slice((2)),(0),null));
return dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4752__auto__);

}
});

dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,k){
var k_31499__$1 = dommy.utils.as_str(k);
if(cljs.core.truth_((function (){var fexpr__31490 = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, ["class",null,"classes",null], null), null);
return (fexpr__31490.cljs$core$IFn$_invoke$arity$1 ? fexpr__31490.cljs$core$IFn$_invoke$arity$1(k_31499__$1) : fexpr__31490.call(null,k_31499__$1));
})())){
dommy.core.set_class_BANG_(elem,"");
} else {
elem.removeAttribute(k_31499__$1);
}

return elem;
});

dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,k,ks){
var seq__31491_31500 = cljs.core.seq(cljs.core.cons(k,ks));
var chunk__31492_31501 = null;
var count__31493_31502 = (0);
var i__31494_31503 = (0);
while(true){
if((i__31494_31503 < count__31493_31502)){
var k_31504__$1 = chunk__31492_31501.cljs$core$IIndexed$_nth$arity$2(null,i__31494_31503);
dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2(elem,k_31504__$1);


var G__31505 = seq__31491_31500;
var G__31506 = chunk__31492_31501;
var G__31507 = count__31493_31502;
var G__31508 = (i__31494_31503 + (1));
seq__31491_31500 = G__31505;
chunk__31492_31501 = G__31506;
count__31493_31502 = G__31507;
i__31494_31503 = G__31508;
continue;
} else {
var temp__5735__auto___31509 = cljs.core.seq(seq__31491_31500);
if(temp__5735__auto___31509){
var seq__31491_31510__$1 = temp__5735__auto___31509;
if(cljs.core.chunked_seq_QMARK_(seq__31491_31510__$1)){
var c__4550__auto___31511 = cljs.core.chunk_first(seq__31491_31510__$1);
var G__31512 = cljs.core.chunk_rest(seq__31491_31510__$1);
var G__31513 = c__4550__auto___31511;
var G__31514 = cljs.core.count(c__4550__auto___31511);
var G__31515 = (0);
seq__31491_31500 = G__31512;
chunk__31492_31501 = G__31513;
count__31493_31502 = G__31514;
i__31494_31503 = G__31515;
continue;
} else {
var k_31516__$1 = cljs.core.first(seq__31491_31510__$1);
dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2(elem,k_31516__$1);


var G__31517 = cljs.core.next(seq__31491_31510__$1);
var G__31518 = null;
var G__31519 = (0);
var G__31520 = (0);
seq__31491_31500 = G__31517;
chunk__31492_31501 = G__31518;
count__31493_31502 = G__31519;
i__31494_31503 = G__31520;
continue;
}
} else {
}
}
break;
}

return elem;
});

/** @this {Function} */
dommy.core.remove_attr_BANG_.cljs$lang$applyTo = (function (seq31486){
var G__31487 = cljs.core.first(seq31486);
var seq31486__$1 = cljs.core.next(seq31486);
var G__31488 = cljs.core.first(seq31486__$1);
var seq31486__$2 = cljs.core.next(seq31486__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31487,G__31488,seq31486__$2);
});

dommy.core.remove_attr_BANG_.cljs$lang$maxFixedArity = (2);

/**
 * Toggles a dom attribute `k` on `elem`, optionally specifying
 * the boolean value with `add?`
 */
dommy.core.toggle_attr_BANG_ = (function dommy$core$toggle_attr_BANG_(var_args){
var G__31522 = arguments.length;
switch (G__31522) {
case 2:
return dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,k){
return dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$3(elem,k,cljs.core.boolean$(dommy.core.attr(elem,k)));
});

dommy.core.toggle_attr_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (elem,k,add_QMARK_){
if(add_QMARK_){
return dommy.core.set_attr_BANG_.cljs$core$IFn$_invoke$arity$2(elem,k);
} else {
return dommy.core.remove_attr_BANG_.cljs$core$IFn$_invoke$arity$2(elem,k);
}
});

dommy.core.toggle_attr_BANG_.cljs$lang$maxFixedArity = 3;

/**
 * Add `classes` to `elem`, trying to use Element::classList, and
 * falling back to fast string parsing/manipulation
 */
dommy.core.add_class_BANG_ = (function dommy$core$add_class_BANG_(var_args){
var G__31528 = arguments.length;
switch (G__31528) {
case 2:
return dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4751__auto__ = [];
var len__4730__auto___31542 = arguments.length;
var i__4731__auto___31543 = (0);
while(true){
if((i__4731__auto___31543 < len__4730__auto___31542)){
args_arr__4751__auto__.push((arguments[i__4731__auto___31543]));

var G__31544 = (i__4731__auto___31543 + (1));
i__4731__auto___31543 = G__31544;
continue;
} else {
}
break;
}

var argseq__4752__auto__ = (new cljs.core.IndexedSeq(args_arr__4751__auto__.slice((2)),(0),null));
return dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4752__auto__);

}
});

dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,classes){
var classes__$1 = clojure.string.trim(dommy.utils.as_str(classes)).split(/\s+/);
if(cljs.core.seq(classes__$1)){
var temp__5733__auto___31545 = elem.classList;
if(cljs.core.truth_(temp__5733__auto___31545)){
var class_list_31546 = temp__5733__auto___31545;
var seq__31529_31547 = cljs.core.seq(classes__$1);
var chunk__31530_31548 = null;
var count__31531_31549 = (0);
var i__31532_31550 = (0);
while(true){
if((i__31532_31550 < count__31531_31549)){
var c_31551 = chunk__31530_31548.cljs$core$IIndexed$_nth$arity$2(null,i__31532_31550);
class_list_31546.add(c_31551);


var G__31552 = seq__31529_31547;
var G__31553 = chunk__31530_31548;
var G__31554 = count__31531_31549;
var G__31555 = (i__31532_31550 + (1));
seq__31529_31547 = G__31552;
chunk__31530_31548 = G__31553;
count__31531_31549 = G__31554;
i__31532_31550 = G__31555;
continue;
} else {
var temp__5735__auto___31556 = cljs.core.seq(seq__31529_31547);
if(temp__5735__auto___31556){
var seq__31529_31557__$1 = temp__5735__auto___31556;
if(cljs.core.chunked_seq_QMARK_(seq__31529_31557__$1)){
var c__4550__auto___31558 = cljs.core.chunk_first(seq__31529_31557__$1);
var G__31559 = cljs.core.chunk_rest(seq__31529_31557__$1);
var G__31560 = c__4550__auto___31558;
var G__31561 = cljs.core.count(c__4550__auto___31558);
var G__31562 = (0);
seq__31529_31547 = G__31559;
chunk__31530_31548 = G__31560;
count__31531_31549 = G__31561;
i__31532_31550 = G__31562;
continue;
} else {
var c_31563 = cljs.core.first(seq__31529_31557__$1);
class_list_31546.add(c_31563);


var G__31564 = cljs.core.next(seq__31529_31557__$1);
var G__31565 = null;
var G__31566 = (0);
var G__31567 = (0);
seq__31529_31547 = G__31564;
chunk__31530_31548 = G__31565;
count__31531_31549 = G__31566;
i__31532_31550 = G__31567;
continue;
}
} else {
}
}
break;
}
} else {
var seq__31533_31568 = cljs.core.seq(classes__$1);
var chunk__31534_31569 = null;
var count__31535_31570 = (0);
var i__31536_31571 = (0);
while(true){
if((i__31536_31571 < count__31535_31570)){
var c_31572 = chunk__31534_31569.cljs$core$IIndexed$_nth$arity$2(null,i__31536_31571);
var class_name_31573 = dommy.core.class$(elem);
if(cljs.core.truth_(dommy.utils.class_index(class_name_31573,c_31572))){
} else {
dommy.core.set_class_BANG_(elem,(((class_name_31573 === ""))?c_31572:[cljs.core.str.cljs$core$IFn$_invoke$arity$1(class_name_31573)," ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(c_31572)].join('')));
}


var G__31574 = seq__31533_31568;
var G__31575 = chunk__31534_31569;
var G__31576 = count__31535_31570;
var G__31577 = (i__31536_31571 + (1));
seq__31533_31568 = G__31574;
chunk__31534_31569 = G__31575;
count__31535_31570 = G__31576;
i__31536_31571 = G__31577;
continue;
} else {
var temp__5735__auto___31578 = cljs.core.seq(seq__31533_31568);
if(temp__5735__auto___31578){
var seq__31533_31579__$1 = temp__5735__auto___31578;
if(cljs.core.chunked_seq_QMARK_(seq__31533_31579__$1)){
var c__4550__auto___31580 = cljs.core.chunk_first(seq__31533_31579__$1);
var G__31581 = cljs.core.chunk_rest(seq__31533_31579__$1);
var G__31582 = c__4550__auto___31580;
var G__31583 = cljs.core.count(c__4550__auto___31580);
var G__31584 = (0);
seq__31533_31568 = G__31581;
chunk__31534_31569 = G__31582;
count__31535_31570 = G__31583;
i__31536_31571 = G__31584;
continue;
} else {
var c_31585 = cljs.core.first(seq__31533_31579__$1);
var class_name_31586 = dommy.core.class$(elem);
if(cljs.core.truth_(dommy.utils.class_index(class_name_31586,c_31585))){
} else {
dommy.core.set_class_BANG_(elem,(((class_name_31586 === ""))?c_31585:[cljs.core.str.cljs$core$IFn$_invoke$arity$1(class_name_31586)," ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(c_31585)].join('')));
}


var G__31587 = cljs.core.next(seq__31533_31579__$1);
var G__31588 = null;
var G__31589 = (0);
var G__31590 = (0);
seq__31533_31568 = G__31587;
chunk__31534_31569 = G__31588;
count__31535_31570 = G__31589;
i__31536_31571 = G__31590;
continue;
}
} else {
}
}
break;
}
}
} else {
}

return elem;
});

dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,classes,more_classes){
var seq__31537_31591 = cljs.core.seq(cljs.core.conj.cljs$core$IFn$_invoke$arity$2(more_classes,classes));
var chunk__31538_31592 = null;
var count__31539_31593 = (0);
var i__31540_31594 = (0);
while(true){
if((i__31540_31594 < count__31539_31593)){
var c_31595 = chunk__31538_31592.cljs$core$IIndexed$_nth$arity$2(null,i__31540_31594);
dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,c_31595);


var G__31596 = seq__31537_31591;
var G__31597 = chunk__31538_31592;
var G__31598 = count__31539_31593;
var G__31599 = (i__31540_31594 + (1));
seq__31537_31591 = G__31596;
chunk__31538_31592 = G__31597;
count__31539_31593 = G__31598;
i__31540_31594 = G__31599;
continue;
} else {
var temp__5735__auto___31600 = cljs.core.seq(seq__31537_31591);
if(temp__5735__auto___31600){
var seq__31537_31601__$1 = temp__5735__auto___31600;
if(cljs.core.chunked_seq_QMARK_(seq__31537_31601__$1)){
var c__4550__auto___31602 = cljs.core.chunk_first(seq__31537_31601__$1);
var G__31603 = cljs.core.chunk_rest(seq__31537_31601__$1);
var G__31604 = c__4550__auto___31602;
var G__31605 = cljs.core.count(c__4550__auto___31602);
var G__31606 = (0);
seq__31537_31591 = G__31603;
chunk__31538_31592 = G__31604;
count__31539_31593 = G__31605;
i__31540_31594 = G__31606;
continue;
} else {
var c_31607 = cljs.core.first(seq__31537_31601__$1);
dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,c_31607);


var G__31608 = cljs.core.next(seq__31537_31601__$1);
var G__31609 = null;
var G__31610 = (0);
var G__31611 = (0);
seq__31537_31591 = G__31608;
chunk__31538_31592 = G__31609;
count__31539_31593 = G__31610;
i__31540_31594 = G__31611;
continue;
}
} else {
}
}
break;
}

return elem;
});

/** @this {Function} */
dommy.core.add_class_BANG_.cljs$lang$applyTo = (function (seq31525){
var G__31526 = cljs.core.first(seq31525);
var seq31525__$1 = cljs.core.next(seq31525);
var G__31527 = cljs.core.first(seq31525__$1);
var seq31525__$2 = cljs.core.next(seq31525__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31526,G__31527,seq31525__$2);
});

dommy.core.add_class_BANG_.cljs$lang$maxFixedArity = (2);

/**
 * Remove `c` from `elem` class list
 */
dommy.core.remove_class_BANG_ = (function dommy$core$remove_class_BANG_(var_args){
var G__31616 = arguments.length;
switch (G__31616) {
case 2:
return dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4751__auto__ = [];
var len__4730__auto___31622 = arguments.length;
var i__4731__auto___31623 = (0);
while(true){
if((i__4731__auto___31623 < len__4730__auto___31622)){
args_arr__4751__auto__.push((arguments[i__4731__auto___31623]));

var G__31624 = (i__4731__auto___31623 + (1));
i__4731__auto___31623 = G__31624;
continue;
} else {
}
break;
}

var argseq__4752__auto__ = (new cljs.core.IndexedSeq(args_arr__4751__auto__.slice((2)),(0),null));
return dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4752__auto__);

}
});

dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,c){
var c__$1 = dommy.utils.as_str(c);
var temp__5733__auto___31625 = elem.classList;
if(cljs.core.truth_(temp__5733__auto___31625)){
var class_list_31626 = temp__5733__auto___31625;
class_list_31626.remove(c__$1);
} else {
var class_name_31627 = dommy.core.class$(elem);
var new_class_name_31628 = dommy.utils.remove_class_str(class_name_31627,c__$1);
if((class_name_31627 === new_class_name_31628)){
} else {
dommy.core.set_class_BANG_(elem,new_class_name_31628);
}
}

return elem;
});

dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,class$,classes){
var seq__31617 = cljs.core.seq(cljs.core.conj.cljs$core$IFn$_invoke$arity$2(classes,class$));
var chunk__31618 = null;
var count__31619 = (0);
var i__31620 = (0);
while(true){
if((i__31620 < count__31619)){
var c = chunk__31618.cljs$core$IIndexed$_nth$arity$2(null,i__31620);
dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,c);


var G__31629 = seq__31617;
var G__31630 = chunk__31618;
var G__31631 = count__31619;
var G__31632 = (i__31620 + (1));
seq__31617 = G__31629;
chunk__31618 = G__31630;
count__31619 = G__31631;
i__31620 = G__31632;
continue;
} else {
var temp__5735__auto__ = cljs.core.seq(seq__31617);
if(temp__5735__auto__){
var seq__31617__$1 = temp__5735__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__31617__$1)){
var c__4550__auto__ = cljs.core.chunk_first(seq__31617__$1);
var G__31633 = cljs.core.chunk_rest(seq__31617__$1);
var G__31634 = c__4550__auto__;
var G__31635 = cljs.core.count(c__4550__auto__);
var G__31636 = (0);
seq__31617 = G__31633;
chunk__31618 = G__31634;
count__31619 = G__31635;
i__31620 = G__31636;
continue;
} else {
var c = cljs.core.first(seq__31617__$1);
dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,c);


var G__31637 = cljs.core.next(seq__31617__$1);
var G__31638 = null;
var G__31639 = (0);
var G__31640 = (0);
seq__31617 = G__31637;
chunk__31618 = G__31638;
count__31619 = G__31639;
i__31620 = G__31640;
continue;
}
} else {
return null;
}
}
break;
}
});

/** @this {Function} */
dommy.core.remove_class_BANG_.cljs$lang$applyTo = (function (seq31613){
var G__31614 = cljs.core.first(seq31613);
var seq31613__$1 = cljs.core.next(seq31613);
var G__31615 = cljs.core.first(seq31613__$1);
var seq31613__$2 = cljs.core.next(seq31613__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31614,G__31615,seq31613__$2);
});

dommy.core.remove_class_BANG_.cljs$lang$maxFixedArity = (2);

/**
 * (toggle-class! elem class) will add-class! if elem does not have class
 * and remove-class! otherwise.
 * (toggle-class! elem class add?) will add-class! if add? is truthy,
 * otherwise it will remove-class!
 */
dommy.core.toggle_class_BANG_ = (function dommy$core$toggle_class_BANG_(var_args){
var G__31642 = arguments.length;
switch (G__31642) {
case 2:
return dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,c){
var c__$1 = dommy.utils.as_str(c);
var temp__5733__auto___31644 = elem.classList;
if(cljs.core.truth_(temp__5733__auto___31644)){
var class_list_31645 = temp__5733__auto___31644;
class_list_31645.toggle(c__$1);
} else {
dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$3(elem,c__$1,(!(dommy.core.has_class_QMARK_(elem,c__$1))));
}

return elem;
});

dommy.core.toggle_class_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (elem,class$,add_QMARK_){
if(add_QMARK_){
dommy.core.add_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,class$);
} else {
dommy.core.remove_class_BANG_.cljs$core$IFn$_invoke$arity$2(elem,class$);
}

return elem;
});

dommy.core.toggle_class_BANG_.cljs$lang$maxFixedArity = 3;

/**
 * Display or hide the given `elem` (using display: none).
 * Takes an optional boolean `show?`
 */
dommy.core.toggle_BANG_ = (function dommy$core$toggle_BANG_(var_args){
var G__31647 = arguments.length;
switch (G__31647) {
case 2:
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 1:
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (elem,show_QMARK_){
return dommy.core.set_style_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([cljs.core.cst$kw$display,((show_QMARK_)?"":"none")], 0));
});

dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$1 = (function (elem){
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2(elem,dommy.core.hidden_QMARK_(elem));
});

dommy.core.toggle_BANG_.cljs$lang$maxFixedArity = 2;

dommy.core.hide_BANG_ = (function dommy$core$hide_BANG_(elem){
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2(elem,false);
});
dommy.core.show_BANG_ = (function dommy$core$show_BANG_(elem){
return dommy.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$2(elem,true);
});
dommy.core.scroll_into_view = (function dommy$core$scroll_into_view(elem,align_with_top_QMARK_){
var top = cljs.core.cst$kw$top.cljs$core$IFn$_invoke$arity$1(dommy.core.bounding_client_rect(elem));
if((window.innerHeight < (top + elem.offsetHeight))){
return elem.scrollIntoView(align_with_top_QMARK_);
} else {
return null;
}
});
dommy.core.create_element = (function dommy$core$create_element(var_args){
var G__31650 = arguments.length;
switch (G__31650) {
case 1:
return dommy.core.create_element.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return dommy.core.create_element.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.create_element.cljs$core$IFn$_invoke$arity$1 = (function (tag){
return document.createElement(dommy.utils.as_str(tag));
});

dommy.core.create_element.cljs$core$IFn$_invoke$arity$2 = (function (tag_ns,tag){
return document.createElementNS(dommy.utils.as_str(tag_ns),dommy.utils.as_str(tag));
});

dommy.core.create_element.cljs$lang$maxFixedArity = 2;

dommy.core.create_text_node = (function dommy$core$create_text_node(text){
return document.createTextNode(text);
});
/**
 * Clears all children from `elem`
 */
dommy.core.clear_BANG_ = (function dommy$core$clear_BANG_(elem){
return dommy.core.set_html_BANG_(elem,"");
});
/**
 * Append `child` to `parent`
 */
dommy.core.append_BANG_ = (function dommy$core$append_BANG_(var_args){
var G__31656 = arguments.length;
switch (G__31656) {
case 2:
return dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4751__auto__ = [];
var len__4730__auto___31663 = arguments.length;
var i__4731__auto___31664 = (0);
while(true){
if((i__4731__auto___31664 < len__4730__auto___31663)){
args_arr__4751__auto__.push((arguments[i__4731__auto___31664]));

var G__31665 = (i__4731__auto___31664 + (1));
i__4731__auto___31664 = G__31665;
continue;
} else {
}
break;
}

var argseq__4752__auto__ = (new cljs.core.IndexedSeq(args_arr__4751__auto__.slice((2)),(0),null));
return dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4752__auto__);

}
});

dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (parent,child){
var G__31657 = parent;
G__31657.appendChild(child);

return G__31657;
});

dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (parent,child,more_children){
var seq__31658_31666 = cljs.core.seq(cljs.core.cons(child,more_children));
var chunk__31659_31667 = null;
var count__31660_31668 = (0);
var i__31661_31669 = (0);
while(true){
if((i__31661_31669 < count__31660_31668)){
var c_31670 = chunk__31659_31667.cljs$core$IIndexed$_nth$arity$2(null,i__31661_31669);
dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2(parent,c_31670);


var G__31671 = seq__31658_31666;
var G__31672 = chunk__31659_31667;
var G__31673 = count__31660_31668;
var G__31674 = (i__31661_31669 + (1));
seq__31658_31666 = G__31671;
chunk__31659_31667 = G__31672;
count__31660_31668 = G__31673;
i__31661_31669 = G__31674;
continue;
} else {
var temp__5735__auto___31675 = cljs.core.seq(seq__31658_31666);
if(temp__5735__auto___31675){
var seq__31658_31676__$1 = temp__5735__auto___31675;
if(cljs.core.chunked_seq_QMARK_(seq__31658_31676__$1)){
var c__4550__auto___31677 = cljs.core.chunk_first(seq__31658_31676__$1);
var G__31678 = cljs.core.chunk_rest(seq__31658_31676__$1);
var G__31679 = c__4550__auto___31677;
var G__31680 = cljs.core.count(c__4550__auto___31677);
var G__31681 = (0);
seq__31658_31666 = G__31678;
chunk__31659_31667 = G__31679;
count__31660_31668 = G__31680;
i__31661_31669 = G__31681;
continue;
} else {
var c_31682 = cljs.core.first(seq__31658_31676__$1);
dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2(parent,c_31682);


var G__31683 = cljs.core.next(seq__31658_31676__$1);
var G__31684 = null;
var G__31685 = (0);
var G__31686 = (0);
seq__31658_31666 = G__31683;
chunk__31659_31667 = G__31684;
count__31660_31668 = G__31685;
i__31661_31669 = G__31686;
continue;
}
} else {
}
}
break;
}

return parent;
});

/** @this {Function} */
dommy.core.append_BANG_.cljs$lang$applyTo = (function (seq31653){
var G__31654 = cljs.core.first(seq31653);
var seq31653__$1 = cljs.core.next(seq31653);
var G__31655 = cljs.core.first(seq31653__$1);
var seq31653__$2 = cljs.core.next(seq31653__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31654,G__31655,seq31653__$2);
});

dommy.core.append_BANG_.cljs$lang$maxFixedArity = (2);

/**
 * Prepend `child` to `parent`
 */
dommy.core.prepend_BANG_ = (function dommy$core$prepend_BANG_(var_args){
var G__31691 = arguments.length;
switch (G__31691) {
case 2:
return dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
var args_arr__4751__auto__ = [];
var len__4730__auto___31698 = arguments.length;
var i__4731__auto___31699 = (0);
while(true){
if((i__4731__auto___31699 < len__4730__auto___31698)){
args_arr__4751__auto__.push((arguments[i__4731__auto___31699]));

var G__31700 = (i__4731__auto___31699 + (1));
i__4731__auto___31699 = G__31700;
continue;
} else {
}
break;
}

var argseq__4752__auto__ = (new cljs.core.IndexedSeq(args_arr__4751__auto__.slice((2)),(0),null));
return dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4752__auto__);

}
});

dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (parent,child){
var G__31692 = parent;
G__31692.insertBefore(child,parent.firstChild);

return G__31692;
});

dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (parent,child,more_children){
var seq__31693_31701 = cljs.core.seq(cljs.core.cons(child,more_children));
var chunk__31694_31702 = null;
var count__31695_31703 = (0);
var i__31696_31704 = (0);
while(true){
if((i__31696_31704 < count__31695_31703)){
var c_31705 = chunk__31694_31702.cljs$core$IIndexed$_nth$arity$2(null,i__31696_31704);
dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$2(parent,c_31705);


var G__31706 = seq__31693_31701;
var G__31707 = chunk__31694_31702;
var G__31708 = count__31695_31703;
var G__31709 = (i__31696_31704 + (1));
seq__31693_31701 = G__31706;
chunk__31694_31702 = G__31707;
count__31695_31703 = G__31708;
i__31696_31704 = G__31709;
continue;
} else {
var temp__5735__auto___31710 = cljs.core.seq(seq__31693_31701);
if(temp__5735__auto___31710){
var seq__31693_31711__$1 = temp__5735__auto___31710;
if(cljs.core.chunked_seq_QMARK_(seq__31693_31711__$1)){
var c__4550__auto___31712 = cljs.core.chunk_first(seq__31693_31711__$1);
var G__31713 = cljs.core.chunk_rest(seq__31693_31711__$1);
var G__31714 = c__4550__auto___31712;
var G__31715 = cljs.core.count(c__4550__auto___31712);
var G__31716 = (0);
seq__31693_31701 = G__31713;
chunk__31694_31702 = G__31714;
count__31695_31703 = G__31715;
i__31696_31704 = G__31716;
continue;
} else {
var c_31717 = cljs.core.first(seq__31693_31711__$1);
dommy.core.prepend_BANG_.cljs$core$IFn$_invoke$arity$2(parent,c_31717);


var G__31718 = cljs.core.next(seq__31693_31711__$1);
var G__31719 = null;
var G__31720 = (0);
var G__31721 = (0);
seq__31693_31701 = G__31718;
chunk__31694_31702 = G__31719;
count__31695_31703 = G__31720;
i__31696_31704 = G__31721;
continue;
}
} else {
}
}
break;
}

return parent;
});

/** @this {Function} */
dommy.core.prepend_BANG_.cljs$lang$applyTo = (function (seq31688){
var G__31689 = cljs.core.first(seq31688);
var seq31688__$1 = cljs.core.next(seq31688);
var G__31690 = cljs.core.first(seq31688__$1);
var seq31688__$2 = cljs.core.next(seq31688__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31689,G__31690,seq31688__$2);
});

dommy.core.prepend_BANG_.cljs$lang$maxFixedArity = (2);

/**
 * Insert `elem` before `other`, `other` must have a parent
 */
dommy.core.insert_before_BANG_ = (function dommy$core$insert_before_BANG_(elem,other){
var p = dommy.core.parent(other);

p.insertBefore(elem,other);

return elem;
});
/**
 * Insert `elem` after `other`, `other` must have a parent
 */
dommy.core.insert_after_BANG_ = (function dommy$core$insert_after_BANG_(elem,other){
var temp__5733__auto___31722 = other.nextSibling;
if(cljs.core.truth_(temp__5733__auto___31722)){
var next_31723 = temp__5733__auto___31722;
dommy.core.insert_before_BANG_(elem,next_31723);
} else {
dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2(dommy.core.parent(other),elem);
}

return elem;
});
/**
 * Replace `elem` with `new`, return `new`
 */
dommy.core.replace_BANG_ = (function dommy$core$replace_BANG_(elem,new$){
var p = dommy.core.parent(elem);

p.replaceChild(new$,elem);

return new$;
});
/**
 * Replace children of `elem` with `child`
 */
dommy.core.replace_contents_BANG_ = (function dommy$core$replace_contents_BANG_(p,child){
return dommy.core.append_BANG_.cljs$core$IFn$_invoke$arity$2(dommy.core.clear_BANG_(p),child);
});
/**
 * Remove `elem` from `parent`, return `parent`
 */
dommy.core.remove_BANG_ = (function dommy$core$remove_BANG_(var_args){
var G__31725 = arguments.length;
switch (G__31725) {
case 1:
return dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$1 = (function (elem){
var p = dommy.core.parent(elem);

return dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$2(p,elem);
});

dommy.core.remove_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (p,elem){
var G__31726 = p;
G__31726.removeChild(elem);

return G__31726;
});

dommy.core.remove_BANG_.cljs$lang$maxFixedArity = 2;

dommy.core.special_listener_makers = cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p__31728){
var vec__31729 = p__31728;
var special_mouse_event = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31729,(0),null);
var real_mouse_event = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31729,(1),null);
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [special_mouse_event,cljs.core.PersistentArrayMap.createAsIfByAssoc([real_mouse_event,((function (vec__31729,special_mouse_event,real_mouse_event){
return (function (f){
return ((function (vec__31729,special_mouse_event,real_mouse_event){
return (function (event){
var related_target = event.relatedTarget;
var listener_target = (function (){var or__4131__auto__ = event.selectedTarget;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return event.currentTarget;
}
})();
if(cljs.core.truth_((function (){var and__4120__auto__ = related_target;
if(cljs.core.truth_(and__4120__auto__)){
return dommy.core.descendant_QMARK_(related_target,listener_target);
} else {
return and__4120__auto__;
}
})())){
return null;
} else {
return (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(event) : f.call(null,event));
}
});
;})(vec__31729,special_mouse_event,real_mouse_event))
});})(vec__31729,special_mouse_event,real_mouse_event))
])], null);
}),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$mouseenter,cljs.core.cst$kw$mouseover,cljs.core.cst$kw$mouseleave,cljs.core.cst$kw$mouseout], null)));
/**
 * fires f if event.target is found with `selector`
 */
dommy.core.live_listener = (function dommy$core$live_listener(elem,selector,f){
return (function (event){
var selected_target = dommy.core.closest.cljs$core$IFn$_invoke$arity$3(elem,event.target,selector);
if(cljs.core.truth_((function (){var and__4120__auto__ = selected_target;
if(cljs.core.truth_(and__4120__auto__)){
return cljs.core.not(dommy.core.attr(selected_target,cljs.core.cst$kw$disabled));
} else {
return and__4120__auto__;
}
})())){
event.selectedTarget = selected_target;

return (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(event) : f.call(null,event));
} else {
return null;
}
});
});
/**
 * Returns a nested map of event listeners on `elem`
 */
dommy.core.event_listeners = (function dommy$core$event_listeners(elem){
var or__4131__auto__ = elem.dommyEventListeners;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return cljs.core.PersistentArrayMap.EMPTY;
}
});
dommy.core.update_event_listeners_BANG_ = (function dommy$core$update_event_listeners_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___31735 = arguments.length;
var i__4731__auto___31736 = (0);
while(true){
if((i__4731__auto___31736 < len__4730__auto___31735)){
args__4736__auto__.push((arguments[i__4731__auto___31736]));

var G__31737 = (i__4731__auto___31736 + (1));
i__4731__auto___31736 = G__31737;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem,f,args){
var elem__$1 = elem;
return elem__$1.dommyEventListeners = cljs.core.apply.cljs$core$IFn$_invoke$arity$3(f,dommy.core.event_listeners(elem__$1),args);
});

dommy.core.update_event_listeners_BANG_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
dommy.core.update_event_listeners_BANG_.cljs$lang$applyTo = (function (seq31732){
var G__31733 = cljs.core.first(seq31732);
var seq31732__$1 = cljs.core.next(seq31732);
var G__31734 = cljs.core.first(seq31732__$1);
var seq31732__$2 = cljs.core.next(seq31732__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31733,G__31734,seq31732__$2);
});

dommy.core.elem_and_selector = (function dommy$core$elem_and_selector(elem_sel){
if(cljs.core.sequential_QMARK_(elem_sel)){
var fexpr__31738 = cljs.core.juxt.cljs$core$IFn$_invoke$arity$2(cljs.core.first,cljs.core.rest);
return (fexpr__31738.cljs$core$IFn$_invoke$arity$1 ? fexpr__31738.cljs$core$IFn$_invoke$arity$1(elem_sel) : fexpr__31738.call(null,elem_sel));
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [elem_sel,null], null);
}
});
/**
 * Adds `f` as a listener for events of type `event-type` on
 * `elem-sel`, which must either be a DOM node, or a sequence
 * whose first item is a DOM node.
 * 
 * In other words, the call to `listen!` can take two forms:
 * 
 * If `elem-sel` is a DOM node, i.e., you're doing something like:
 * 
 *     (listen! elem :click click-handler)
 * 
 * then `click-handler` will be set as a listener for `click` events
 * on the `elem`.
 * 
 * If `elem-sel` is a sequence:
 * 
 *     (listen! [elem :.selector.for :.some.descendants] :click click-handler)
 * 
 * then `click-handler` will be set as a listener for `click` events
 * on descendants of `elem` that match the selector
 * 
 * Also accepts any number of event-type and handler pairs for setting
 * multiple listeners at once:
 * 
 *     (listen! some-elem :click click-handler :hover hover-handler)
 */
dommy.core.listen_BANG_ = (function dommy$core$listen_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___31852 = arguments.length;
var i__4731__auto___31853 = (0);
while(true){
if((i__4731__auto___31853 < len__4730__auto___31852)){
args__4736__auto__.push((arguments[i__4731__auto___31853]));

var G__31854 = (i__4731__auto___31853 + (1));
i__4731__auto___31853 = G__31854;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return dommy.core.listen_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

dommy.core.listen_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem_sel,type_fs){

var vec__31741_31855 = dommy.core.elem_and_selector(elem_sel);
var elem_31856 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31741_31855,(0),null);
var selector_31857 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31741_31855,(1),null);
var seq__31744_31858 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),type_fs));
var chunk__31751_31859 = null;
var count__31752_31860 = (0);
var i__31753_31861 = (0);
while(true){
if((i__31753_31861 < count__31752_31860)){
var vec__31806_31862 = chunk__31751_31859.cljs$core$IIndexed$_nth$arity$2(null,i__31753_31861);
var orig_type_31863 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31806_31862,(0),null);
var f_31864 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31806_31862,(1),null);
var seq__31754_31865 = cljs.core.seq(cljs.core.get.cljs$core$IFn$_invoke$arity$3(dommy.core.special_listener_makers,orig_type_31863,cljs.core.PersistentArrayMap.createAsIfByAssoc([orig_type_31863,cljs.core.identity])));
var chunk__31756_31866 = null;
var count__31757_31867 = (0);
var i__31758_31868 = (0);
while(true){
if((i__31758_31868 < count__31757_31867)){
var vec__31819_31869 = chunk__31756_31866.cljs$core$IIndexed$_nth$arity$2(null,i__31758_31868);
var actual_type_31870 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31819_31869,(0),null);
var factory_31871 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31819_31869,(1),null);
var canonical_f_31872 = (function (){var G__31823 = (factory_31871.cljs$core$IFn$_invoke$arity$1 ? factory_31871.cljs$core$IFn$_invoke$arity$1(f_31864) : factory_31871.call(null,f_31864));
var fexpr__31822 = (cljs.core.truth_(selector_31857)?cljs.core.partial.cljs$core$IFn$_invoke$arity$3(dommy.core.live_listener,elem_31856,selector_31857):cljs.core.identity);
return (fexpr__31822.cljs$core$IFn$_invoke$arity$1 ? fexpr__31822.cljs$core$IFn$_invoke$arity$1(G__31823) : fexpr__31822.call(null,G__31823));
})();
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_31856,cljs.core.assoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_31857,actual_type_31870,f_31864], null),canonical_f_31872], 0));

if(cljs.core.truth_(elem_31856.addEventListener)){
elem_31856.addEventListener(cljs.core.name(actual_type_31870),canonical_f_31872);
} else {
elem_31856.attachEvent(cljs.core.name(actual_type_31870),canonical_f_31872);
}


var G__31873 = seq__31754_31865;
var G__31874 = chunk__31756_31866;
var G__31875 = count__31757_31867;
var G__31876 = (i__31758_31868 + (1));
seq__31754_31865 = G__31873;
chunk__31756_31866 = G__31874;
count__31757_31867 = G__31875;
i__31758_31868 = G__31876;
continue;
} else {
var temp__5735__auto___31877 = cljs.core.seq(seq__31754_31865);
if(temp__5735__auto___31877){
var seq__31754_31878__$1 = temp__5735__auto___31877;
if(cljs.core.chunked_seq_QMARK_(seq__31754_31878__$1)){
var c__4550__auto___31879 = cljs.core.chunk_first(seq__31754_31878__$1);
var G__31880 = cljs.core.chunk_rest(seq__31754_31878__$1);
var G__31881 = c__4550__auto___31879;
var G__31882 = cljs.core.count(c__4550__auto___31879);
var G__31883 = (0);
seq__31754_31865 = G__31880;
chunk__31756_31866 = G__31881;
count__31757_31867 = G__31882;
i__31758_31868 = G__31883;
continue;
} else {
var vec__31824_31884 = cljs.core.first(seq__31754_31878__$1);
var actual_type_31885 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31824_31884,(0),null);
var factory_31886 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31824_31884,(1),null);
var canonical_f_31887 = (function (){var G__31828 = (factory_31886.cljs$core$IFn$_invoke$arity$1 ? factory_31886.cljs$core$IFn$_invoke$arity$1(f_31864) : factory_31886.call(null,f_31864));
var fexpr__31827 = (cljs.core.truth_(selector_31857)?cljs.core.partial.cljs$core$IFn$_invoke$arity$3(dommy.core.live_listener,elem_31856,selector_31857):cljs.core.identity);
return (fexpr__31827.cljs$core$IFn$_invoke$arity$1 ? fexpr__31827.cljs$core$IFn$_invoke$arity$1(G__31828) : fexpr__31827.call(null,G__31828));
})();
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_31856,cljs.core.assoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_31857,actual_type_31885,f_31864], null),canonical_f_31887], 0));

if(cljs.core.truth_(elem_31856.addEventListener)){
elem_31856.addEventListener(cljs.core.name(actual_type_31885),canonical_f_31887);
} else {
elem_31856.attachEvent(cljs.core.name(actual_type_31885),canonical_f_31887);
}


var G__31888 = cljs.core.next(seq__31754_31878__$1);
var G__31889 = null;
var G__31890 = (0);
var G__31891 = (0);
seq__31754_31865 = G__31888;
chunk__31756_31866 = G__31889;
count__31757_31867 = G__31890;
i__31758_31868 = G__31891;
continue;
}
} else {
}
}
break;
}

var G__31892 = seq__31744_31858;
var G__31893 = chunk__31751_31859;
var G__31894 = count__31752_31860;
var G__31895 = (i__31753_31861 + (1));
seq__31744_31858 = G__31892;
chunk__31751_31859 = G__31893;
count__31752_31860 = G__31894;
i__31753_31861 = G__31895;
continue;
} else {
var temp__5735__auto___31896 = cljs.core.seq(seq__31744_31858);
if(temp__5735__auto___31896){
var seq__31744_31897__$1 = temp__5735__auto___31896;
if(cljs.core.chunked_seq_QMARK_(seq__31744_31897__$1)){
var c__4550__auto___31898 = cljs.core.chunk_first(seq__31744_31897__$1);
var G__31899 = cljs.core.chunk_rest(seq__31744_31897__$1);
var G__31900 = c__4550__auto___31898;
var G__31901 = cljs.core.count(c__4550__auto___31898);
var G__31902 = (0);
seq__31744_31858 = G__31899;
chunk__31751_31859 = G__31900;
count__31752_31860 = G__31901;
i__31753_31861 = G__31902;
continue;
} else {
var vec__31829_31903 = cljs.core.first(seq__31744_31897__$1);
var orig_type_31904 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31829_31903,(0),null);
var f_31905 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31829_31903,(1),null);
var seq__31745_31906 = cljs.core.seq(cljs.core.get.cljs$core$IFn$_invoke$arity$3(dommy.core.special_listener_makers,orig_type_31904,cljs.core.PersistentArrayMap.createAsIfByAssoc([orig_type_31904,cljs.core.identity])));
var chunk__31747_31907 = null;
var count__31748_31908 = (0);
var i__31749_31909 = (0);
while(true){
if((i__31749_31909 < count__31748_31908)){
var vec__31842_31910 = chunk__31747_31907.cljs$core$IIndexed$_nth$arity$2(null,i__31749_31909);
var actual_type_31911 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31842_31910,(0),null);
var factory_31912 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31842_31910,(1),null);
var canonical_f_31913 = (function (){var G__31846 = (factory_31912.cljs$core$IFn$_invoke$arity$1 ? factory_31912.cljs$core$IFn$_invoke$arity$1(f_31905) : factory_31912.call(null,f_31905));
var fexpr__31845 = (cljs.core.truth_(selector_31857)?cljs.core.partial.cljs$core$IFn$_invoke$arity$3(dommy.core.live_listener,elem_31856,selector_31857):cljs.core.identity);
return (fexpr__31845.cljs$core$IFn$_invoke$arity$1 ? fexpr__31845.cljs$core$IFn$_invoke$arity$1(G__31846) : fexpr__31845.call(null,G__31846));
})();
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_31856,cljs.core.assoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_31857,actual_type_31911,f_31905], null),canonical_f_31913], 0));

if(cljs.core.truth_(elem_31856.addEventListener)){
elem_31856.addEventListener(cljs.core.name(actual_type_31911),canonical_f_31913);
} else {
elem_31856.attachEvent(cljs.core.name(actual_type_31911),canonical_f_31913);
}


var G__31914 = seq__31745_31906;
var G__31915 = chunk__31747_31907;
var G__31916 = count__31748_31908;
var G__31917 = (i__31749_31909 + (1));
seq__31745_31906 = G__31914;
chunk__31747_31907 = G__31915;
count__31748_31908 = G__31916;
i__31749_31909 = G__31917;
continue;
} else {
var temp__5735__auto___31918__$1 = cljs.core.seq(seq__31745_31906);
if(temp__5735__auto___31918__$1){
var seq__31745_31919__$1 = temp__5735__auto___31918__$1;
if(cljs.core.chunked_seq_QMARK_(seq__31745_31919__$1)){
var c__4550__auto___31920 = cljs.core.chunk_first(seq__31745_31919__$1);
var G__31921 = cljs.core.chunk_rest(seq__31745_31919__$1);
var G__31922 = c__4550__auto___31920;
var G__31923 = cljs.core.count(c__4550__auto___31920);
var G__31924 = (0);
seq__31745_31906 = G__31921;
chunk__31747_31907 = G__31922;
count__31748_31908 = G__31923;
i__31749_31909 = G__31924;
continue;
} else {
var vec__31847_31925 = cljs.core.first(seq__31745_31919__$1);
var actual_type_31926 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31847_31925,(0),null);
var factory_31927 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31847_31925,(1),null);
var canonical_f_31928 = (function (){var G__31851 = (factory_31927.cljs$core$IFn$_invoke$arity$1 ? factory_31927.cljs$core$IFn$_invoke$arity$1(f_31905) : factory_31927.call(null,f_31905));
var fexpr__31850 = (cljs.core.truth_(selector_31857)?cljs.core.partial.cljs$core$IFn$_invoke$arity$3(dommy.core.live_listener,elem_31856,selector_31857):cljs.core.identity);
return (fexpr__31850.cljs$core$IFn$_invoke$arity$1 ? fexpr__31850.cljs$core$IFn$_invoke$arity$1(G__31851) : fexpr__31850.call(null,G__31851));
})();
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_31856,cljs.core.assoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_31857,actual_type_31926,f_31905], null),canonical_f_31928], 0));

if(cljs.core.truth_(elem_31856.addEventListener)){
elem_31856.addEventListener(cljs.core.name(actual_type_31926),canonical_f_31928);
} else {
elem_31856.attachEvent(cljs.core.name(actual_type_31926),canonical_f_31928);
}


var G__31929 = cljs.core.next(seq__31745_31919__$1);
var G__31930 = null;
var G__31931 = (0);
var G__31932 = (0);
seq__31745_31906 = G__31929;
chunk__31747_31907 = G__31930;
count__31748_31908 = G__31931;
i__31749_31909 = G__31932;
continue;
}
} else {
}
}
break;
}

var G__31933 = cljs.core.next(seq__31744_31897__$1);
var G__31934 = null;
var G__31935 = (0);
var G__31936 = (0);
seq__31744_31858 = G__31933;
chunk__31751_31859 = G__31934;
count__31752_31860 = G__31935;
i__31753_31861 = G__31936;
continue;
}
} else {
}
}
break;
}

return elem_sel;
});

dommy.core.listen_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
dommy.core.listen_BANG_.cljs$lang$applyTo = (function (seq31739){
var G__31740 = cljs.core.first(seq31739);
var seq31739__$1 = cljs.core.next(seq31739);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31740,seq31739__$1);
});

/**
 * Removes event listener for the element defined in `elem-sel`,
 * which is the same format as listen!.
 * 
 *   The following forms are allowed, and will remove all handlers
 *   that match the parameters passed in:
 * 
 *    (unlisten! [elem :.selector] :click event-listener)
 * 
 *    (unlisten! [elem :.selector]
 *      :click event-listener
 *      :mouseover other-event-listener)
 */
dommy.core.unlisten_BANG_ = (function dommy$core$unlisten_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___32018 = arguments.length;
var i__4731__auto___32019 = (0);
while(true){
if((i__4731__auto___32019 < len__4730__auto___32018)){
args__4736__auto__.push((arguments[i__4731__auto___32019]));

var G__32020 = (i__4731__auto___32019 + (1));
i__4731__auto___32019 = G__32020;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return dommy.core.unlisten_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

dommy.core.unlisten_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem_sel,type_fs){

var vec__31939_32021 = dommy.core.elem_and_selector(elem_sel);
var elem_32022 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31939_32021,(0),null);
var selector_32023 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31939_32021,(1),null);
var seq__31942_32024 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),type_fs));
var chunk__31949_32025 = null;
var count__31950_32026 = (0);
var i__31951_32027 = (0);
while(true){
if((i__31951_32027 < count__31950_32026)){
var vec__31988_32028 = chunk__31949_32025.cljs$core$IIndexed$_nth$arity$2(null,i__31951_32027);
var orig_type_32029 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31988_32028,(0),null);
var f_32030 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31988_32028,(1),null);
var seq__31952_32031 = cljs.core.seq(cljs.core.get.cljs$core$IFn$_invoke$arity$3(dommy.core.special_listener_makers,orig_type_32029,cljs.core.PersistentArrayMap.createAsIfByAssoc([orig_type_32029,cljs.core.identity])));
var chunk__31954_32032 = null;
var count__31955_32033 = (0);
var i__31956_32034 = (0);
while(true){
if((i__31956_32034 < count__31955_32033)){
var vec__31997_32035 = chunk__31954_32032.cljs$core$IIndexed$_nth$arity$2(null,i__31956_32034);
var actual_type_32036 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31997_32035,(0),null);
var __32037 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__31997_32035,(1),null);
var keys_32038 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_32023,actual_type_32036,f_32030], null);
var canonical_f_32039 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(dommy.core.event_listeners(elem_32022),keys_32038);
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_32022,dommy.utils.dissoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([keys_32038], 0));

if(cljs.core.truth_(elem_32022.removeEventListener)){
elem_32022.removeEventListener(cljs.core.name(actual_type_32036),canonical_f_32039);
} else {
elem_32022.detachEvent(cljs.core.name(actual_type_32036),canonical_f_32039);
}


var G__32040 = seq__31952_32031;
var G__32041 = chunk__31954_32032;
var G__32042 = count__31955_32033;
var G__32043 = (i__31956_32034 + (1));
seq__31952_32031 = G__32040;
chunk__31954_32032 = G__32041;
count__31955_32033 = G__32042;
i__31956_32034 = G__32043;
continue;
} else {
var temp__5735__auto___32044 = cljs.core.seq(seq__31952_32031);
if(temp__5735__auto___32044){
var seq__31952_32045__$1 = temp__5735__auto___32044;
if(cljs.core.chunked_seq_QMARK_(seq__31952_32045__$1)){
var c__4550__auto___32046 = cljs.core.chunk_first(seq__31952_32045__$1);
var G__32047 = cljs.core.chunk_rest(seq__31952_32045__$1);
var G__32048 = c__4550__auto___32046;
var G__32049 = cljs.core.count(c__4550__auto___32046);
var G__32050 = (0);
seq__31952_32031 = G__32047;
chunk__31954_32032 = G__32048;
count__31955_32033 = G__32049;
i__31956_32034 = G__32050;
continue;
} else {
var vec__32000_32051 = cljs.core.first(seq__31952_32045__$1);
var actual_type_32052 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32000_32051,(0),null);
var __32053 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32000_32051,(1),null);
var keys_32054 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_32023,actual_type_32052,f_32030], null);
var canonical_f_32055 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(dommy.core.event_listeners(elem_32022),keys_32054);
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_32022,dommy.utils.dissoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([keys_32054], 0));

if(cljs.core.truth_(elem_32022.removeEventListener)){
elem_32022.removeEventListener(cljs.core.name(actual_type_32052),canonical_f_32055);
} else {
elem_32022.detachEvent(cljs.core.name(actual_type_32052),canonical_f_32055);
}


var G__32056 = cljs.core.next(seq__31952_32045__$1);
var G__32057 = null;
var G__32058 = (0);
var G__32059 = (0);
seq__31952_32031 = G__32056;
chunk__31954_32032 = G__32057;
count__31955_32033 = G__32058;
i__31956_32034 = G__32059;
continue;
}
} else {
}
}
break;
}

var G__32060 = seq__31942_32024;
var G__32061 = chunk__31949_32025;
var G__32062 = count__31950_32026;
var G__32063 = (i__31951_32027 + (1));
seq__31942_32024 = G__32060;
chunk__31949_32025 = G__32061;
count__31950_32026 = G__32062;
i__31951_32027 = G__32063;
continue;
} else {
var temp__5735__auto___32064 = cljs.core.seq(seq__31942_32024);
if(temp__5735__auto___32064){
var seq__31942_32065__$1 = temp__5735__auto___32064;
if(cljs.core.chunked_seq_QMARK_(seq__31942_32065__$1)){
var c__4550__auto___32066 = cljs.core.chunk_first(seq__31942_32065__$1);
var G__32067 = cljs.core.chunk_rest(seq__31942_32065__$1);
var G__32068 = c__4550__auto___32066;
var G__32069 = cljs.core.count(c__4550__auto___32066);
var G__32070 = (0);
seq__31942_32024 = G__32067;
chunk__31949_32025 = G__32068;
count__31950_32026 = G__32069;
i__31951_32027 = G__32070;
continue;
} else {
var vec__32003_32071 = cljs.core.first(seq__31942_32065__$1);
var orig_type_32072 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32003_32071,(0),null);
var f_32073 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32003_32071,(1),null);
var seq__31943_32074 = cljs.core.seq(cljs.core.get.cljs$core$IFn$_invoke$arity$3(dommy.core.special_listener_makers,orig_type_32072,cljs.core.PersistentArrayMap.createAsIfByAssoc([orig_type_32072,cljs.core.identity])));
var chunk__31945_32075 = null;
var count__31946_32076 = (0);
var i__31947_32077 = (0);
while(true){
if((i__31947_32077 < count__31946_32076)){
var vec__32012_32078 = chunk__31945_32075.cljs$core$IIndexed$_nth$arity$2(null,i__31947_32077);
var actual_type_32079 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32012_32078,(0),null);
var __32080 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32012_32078,(1),null);
var keys_32081 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_32023,actual_type_32079,f_32073], null);
var canonical_f_32082 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(dommy.core.event_listeners(elem_32022),keys_32081);
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_32022,dommy.utils.dissoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([keys_32081], 0));

if(cljs.core.truth_(elem_32022.removeEventListener)){
elem_32022.removeEventListener(cljs.core.name(actual_type_32079),canonical_f_32082);
} else {
elem_32022.detachEvent(cljs.core.name(actual_type_32079),canonical_f_32082);
}


var G__32083 = seq__31943_32074;
var G__32084 = chunk__31945_32075;
var G__32085 = count__31946_32076;
var G__32086 = (i__31947_32077 + (1));
seq__31943_32074 = G__32083;
chunk__31945_32075 = G__32084;
count__31946_32076 = G__32085;
i__31947_32077 = G__32086;
continue;
} else {
var temp__5735__auto___32087__$1 = cljs.core.seq(seq__31943_32074);
if(temp__5735__auto___32087__$1){
var seq__31943_32088__$1 = temp__5735__auto___32087__$1;
if(cljs.core.chunked_seq_QMARK_(seq__31943_32088__$1)){
var c__4550__auto___32089 = cljs.core.chunk_first(seq__31943_32088__$1);
var G__32090 = cljs.core.chunk_rest(seq__31943_32088__$1);
var G__32091 = c__4550__auto___32089;
var G__32092 = cljs.core.count(c__4550__auto___32089);
var G__32093 = (0);
seq__31943_32074 = G__32090;
chunk__31945_32075 = G__32091;
count__31946_32076 = G__32092;
i__31947_32077 = G__32093;
continue;
} else {
var vec__32015_32094 = cljs.core.first(seq__31943_32088__$1);
var actual_type_32095 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32015_32094,(0),null);
var __32096 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32015_32094,(1),null);
var keys_32097 = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [selector_32023,actual_type_32095,f_32073], null);
var canonical_f_32098 = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(dommy.core.event_listeners(elem_32022),keys_32097);
dommy.core.update_event_listeners_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_32022,dommy.utils.dissoc_in,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([keys_32097], 0));

if(cljs.core.truth_(elem_32022.removeEventListener)){
elem_32022.removeEventListener(cljs.core.name(actual_type_32095),canonical_f_32098);
} else {
elem_32022.detachEvent(cljs.core.name(actual_type_32095),canonical_f_32098);
}


var G__32099 = cljs.core.next(seq__31943_32088__$1);
var G__32100 = null;
var G__32101 = (0);
var G__32102 = (0);
seq__31943_32074 = G__32099;
chunk__31945_32075 = G__32100;
count__31946_32076 = G__32101;
i__31947_32077 = G__32102;
continue;
}
} else {
}
}
break;
}

var G__32103 = cljs.core.next(seq__31942_32065__$1);
var G__32104 = null;
var G__32105 = (0);
var G__32106 = (0);
seq__31942_32024 = G__32103;
chunk__31949_32025 = G__32104;
count__31950_32026 = G__32105;
i__31951_32027 = G__32106;
continue;
}
} else {
}
}
break;
}

return elem_sel;
});

dommy.core.unlisten_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
dommy.core.unlisten_BANG_.cljs$lang$applyTo = (function (seq31937){
var G__31938 = cljs.core.first(seq31937);
var seq31937__$1 = cljs.core.next(seq31937);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__31938,seq31937__$1);
});

/**
 * Behaves like `listen!`, but removes the listener after the first event occurs.
 */
dommy.core.listen_once_BANG_ = (function dommy$core$listen_once_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___32128 = arguments.length;
var i__4731__auto___32129 = (0);
while(true){
if((i__4731__auto___32129 < len__4730__auto___32128)){
args__4736__auto__.push((arguments[i__4731__auto___32129]));

var G__32130 = (i__4731__auto___32129 + (1));
i__4731__auto___32129 = G__32130;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return dommy.core.listen_once_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

dommy.core.listen_once_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (elem_sel,type_fs){

var vec__32109_32131 = dommy.core.elem_and_selector(elem_sel);
var elem_32132 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32109_32131,(0),null);
var selector_32133 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32109_32131,(1),null);
var seq__32112_32134 = cljs.core.seq(cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),type_fs));
var chunk__32113_32135 = null;
var count__32114_32136 = (0);
var i__32115_32137 = (0);
while(true){
if((i__32115_32137 < count__32114_32136)){
var vec__32122_32138 = chunk__32113_32135.cljs$core$IIndexed$_nth$arity$2(null,i__32115_32137);
var type_32139 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32122_32138,(0),null);
var f_32140 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32122_32138,(1),null);
dommy.core.listen_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_sel,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([type_32139,((function (seq__32112_32134,chunk__32113_32135,count__32114_32136,i__32115_32137,vec__32122_32138,type_32139,f_32140,vec__32109_32131,elem_32132,selector_32133){
return (function dommy$core$this_fn(e){
dommy.core.unlisten_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_sel,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([type_32139,dommy$core$this_fn], 0));

return (f_32140.cljs$core$IFn$_invoke$arity$1 ? f_32140.cljs$core$IFn$_invoke$arity$1(e) : f_32140.call(null,e));
});})(seq__32112_32134,chunk__32113_32135,count__32114_32136,i__32115_32137,vec__32122_32138,type_32139,f_32140,vec__32109_32131,elem_32132,selector_32133))
], 0));


var G__32141 = seq__32112_32134;
var G__32142 = chunk__32113_32135;
var G__32143 = count__32114_32136;
var G__32144 = (i__32115_32137 + (1));
seq__32112_32134 = G__32141;
chunk__32113_32135 = G__32142;
count__32114_32136 = G__32143;
i__32115_32137 = G__32144;
continue;
} else {
var temp__5735__auto___32145 = cljs.core.seq(seq__32112_32134);
if(temp__5735__auto___32145){
var seq__32112_32146__$1 = temp__5735__auto___32145;
if(cljs.core.chunked_seq_QMARK_(seq__32112_32146__$1)){
var c__4550__auto___32147 = cljs.core.chunk_first(seq__32112_32146__$1);
var G__32148 = cljs.core.chunk_rest(seq__32112_32146__$1);
var G__32149 = c__4550__auto___32147;
var G__32150 = cljs.core.count(c__4550__auto___32147);
var G__32151 = (0);
seq__32112_32134 = G__32148;
chunk__32113_32135 = G__32149;
count__32114_32136 = G__32150;
i__32115_32137 = G__32151;
continue;
} else {
var vec__32125_32152 = cljs.core.first(seq__32112_32146__$1);
var type_32153 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32125_32152,(0),null);
var f_32154 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32125_32152,(1),null);
dommy.core.listen_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_sel,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([type_32153,((function (seq__32112_32134,chunk__32113_32135,count__32114_32136,i__32115_32137,vec__32125_32152,type_32153,f_32154,seq__32112_32146__$1,temp__5735__auto___32145,vec__32109_32131,elem_32132,selector_32133){
return (function dommy$core$this_fn(e){
dommy.core.unlisten_BANG_.cljs$core$IFn$_invoke$arity$variadic(elem_sel,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([type_32153,dommy$core$this_fn], 0));

return (f_32154.cljs$core$IFn$_invoke$arity$1 ? f_32154.cljs$core$IFn$_invoke$arity$1(e) : f_32154.call(null,e));
});})(seq__32112_32134,chunk__32113_32135,count__32114_32136,i__32115_32137,vec__32125_32152,type_32153,f_32154,seq__32112_32146__$1,temp__5735__auto___32145,vec__32109_32131,elem_32132,selector_32133))
], 0));


var G__32155 = cljs.core.next(seq__32112_32146__$1);
var G__32156 = null;
var G__32157 = (0);
var G__32158 = (0);
seq__32112_32134 = G__32155;
chunk__32113_32135 = G__32156;
count__32114_32136 = G__32157;
i__32115_32137 = G__32158;
continue;
}
} else {
}
}
break;
}

return elem_sel;
});

dommy.core.listen_once_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
dommy.core.listen_once_BANG_.cljs$lang$applyTo = (function (seq32107){
var G__32108 = cljs.core.first(seq32107);
var seq32107__$1 = cljs.core.next(seq32107);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__32108,seq32107__$1);
});


// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('google_webmaster_tools_bulk_url_removal.background');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('google_webmaster_tools_bulk_url_removal.background.core');
if((typeof google_webmaster_tools_bulk_url_removal !== 'undefined') && (typeof google_webmaster_tools_bulk_url_removal.background !== 'undefined') && (typeof google_webmaster_tools_bulk_url_removal.background.runonce_1364499943 !== 'undefined')){
} else {
google_webmaster_tools_bulk_url_removal.background.runonce_1364499943 = new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$value,google_webmaster_tools_bulk_url_removal.background.core.init_BANG_(),cljs.core.cst$kw$code,"(do (core/init!))"], null);
}

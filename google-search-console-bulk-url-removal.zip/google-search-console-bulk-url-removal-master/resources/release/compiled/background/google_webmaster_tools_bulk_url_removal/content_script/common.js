// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('google_webmaster_tools_bulk_url_removal.content_script.common');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async');
goog.require('chromex.logging');
goog.require('cognitect.transit');
goog.require('cemerick.url');
google_webmaster_tools_bulk_url_removal.content_script.common.run_message_loop_BANG_ = (function google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG_(message_channel,message_handler_BANG_){
console.log("CONTENT SCRIPT: starting message loop...");


var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__){
return (function (state_17140){
var state_val_17141 = (state_17140[(1)]);
if((state_val_17141 === (1))){
var state_17140__$1 = state_17140;
var statearr_17142_17155 = state_17140__$1;
(statearr_17142_17155[(2)] = null);

(statearr_17142_17155[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17141 === (2))){
var state_17140__$1 = state_17140;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_17140__$1,(4),message_channel);
} else {
if((state_val_17141 === (3))){
var inst_17138 = (state_17140[(2)]);
var state_17140__$1 = state_17140;
return cljs.core.async.impl.ioc_helpers.return_chan(state_17140__$1,inst_17138);
} else {
if((state_val_17141 === (4))){
var inst_17128 = (state_17140[(7)]);
var inst_17128__$1 = (state_17140[(2)]);
var inst_17129 = (inst_17128__$1 == null);
var state_17140__$1 = (function (){var statearr_17143 = state_17140;
(statearr_17143[(7)] = inst_17128__$1);

return statearr_17143;
})();
if(cljs.core.truth_(inst_17129)){
var statearr_17144_17156 = state_17140__$1;
(statearr_17144_17156[(1)] = (5));

} else {
var statearr_17145_17157 = state_17140__$1;
(statearr_17145_17157[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17141 === (5))){
var state_17140__$1 = state_17140;
var statearr_17146_17158 = state_17140__$1;
(statearr_17146_17158[(2)] = null);

(statearr_17146_17158[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17141 === (6))){
var inst_17128 = (state_17140[(7)]);
var inst_17132 = (message_handler_BANG_.cljs$core$IFn$_invoke$arity$2 ? message_handler_BANG_.cljs$core$IFn$_invoke$arity$2(message_channel,inst_17128) : message_handler_BANG_.call(null,message_channel,inst_17128));
var state_17140__$1 = (function (){var statearr_17147 = state_17140;
(statearr_17147[(8)] = inst_17132);

return statearr_17147;
})();
var statearr_17148_17159 = state_17140__$1;
(statearr_17148_17159[(2)] = null);

(statearr_17148_17159[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17141 === (7))){
var inst_17135 = (state_17140[(2)]);
var inst_17136 = console.log("CONTENT SCRIPT: leaving message loop");
var state_17140__$1 = (function (){var statearr_17149 = state_17140;
(statearr_17149[(9)] = inst_17135);

(statearr_17149[(10)] = inst_17136);

return statearr_17149;
})();
var statearr_17150_17160 = state_17140__$1;
(statearr_17150_17160[(2)] = null);

(statearr_17150_17160[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(c__8052__auto__))
;
return ((function (switch__7945__auto__,c__8052__auto__){
return (function() {
var google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto____0 = (function (){
var statearr_17151 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_17151[(0)] = google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto__);

(statearr_17151[(1)] = (1));

return statearr_17151;
});
var google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto____1 = (function (state_17140){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_17140);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e17152){if((e17152 instanceof Object)){
var ex__7949__auto__ = e17152;
var statearr_17153_17161 = state_17140;
(statearr_17153_17161[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_17140);

return cljs.core.cst$kw$recur;
} else {
throw e17152;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__17162 = state_17140;
state_17140 = G__17162;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto__ = function(state_17140){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto____1.call(this,state_17140);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$content_script$common$run_message_loop_BANG__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_17154 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_17154[(6)] = c__8052__auto__);

return statearr_17154;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__))
);

return c__8052__auto__;
});
google_webmaster_tools_bulk_url_removal.content_script.common.connect_to_background_page_BANG_ = (function google_webmaster_tools_bulk_url_removal$content_script$common$connect_to_background_page_BANG_(background_port,message_handler_BANG_){
return google_webmaster_tools_bulk_url_removal.content_script.common.run_message_loop_BANG_(background_port,message_handler_BANG_);
});
google_webmaster_tools_bulk_url_removal.content_script.common.marshall = (function google_webmaster_tools_bulk_url_removal$content_script$common$marshall(edn_msg){
var w = cognitect.transit.writer.cljs$core$IFn$_invoke$arity$1(cljs.core.cst$kw$json);
return cognitect.transit.write(w,edn_msg);
});
google_webmaster_tools_bulk_url_removal.content_script.common.unmarshall = (function google_webmaster_tools_bulk_url_removal$content_script$common$unmarshall(msg_str){
var r = cognitect.transit.reader.cljs$core$IFn$_invoke$arity$1(cljs.core.cst$kw$json);
return cognitect.transit.read(r,msg_str);
});
google_webmaster_tools_bulk_url_removal.content_script.common.normalize_url_encoding = (function google_webmaster_tools_bulk_url_removal$content_script$common$normalize_url_encoding(fq_url){
var url_parts = cemerick.url.url.cljs$core$IFn$_invoke$arity$1(fq_url);
var normalized_path = cemerick.url.url_encode(cemerick.url.url_decode(cljs.core.subs.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$path.cljs$core$IFn$_invoke$arity$1(url_parts),(1))));
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(url_parts,cljs.core.cst$kw$path,["/",cljs.core.str.cljs$core$IFn$_invoke$arity$1(normalized_path)].join(''));
});
google_webmaster_tools_bulk_url_removal.content_script.common.fq_victim_url = (function google_webmaster_tools_bulk_url_removal$content_script$common$fq_victim_url(victim_url){
var domain_name = cljs.core.get_in.cljs$core$IFn$_invoke$arity$2(cemerick.url.url.cljs$core$IFn$_invoke$arity$1(window.location.href),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$query,"siteUrl"], null));
return google_webmaster_tools_bulk_url_removal.content_script.common.normalize_url_encoding(((clojure.string.starts_with_QMARK_(victim_url,"http"))?victim_url:((clojure.string.ends_with_QMARK_(victim_url,"/"))?[cljs.core.str.cljs$core$IFn$_invoke$arity$1(cemerick.url.url.cljs$core$IFn$_invoke$arity$variadic(domain_name,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([victim_url], 0))),"/"].join(''):cljs.core.str.cljs$core$IFn$_invoke$arity$1(cemerick.url.url.cljs$core$IFn$_invoke$arity$variadic(domain_name,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([victim_url], 0)))
)));
});

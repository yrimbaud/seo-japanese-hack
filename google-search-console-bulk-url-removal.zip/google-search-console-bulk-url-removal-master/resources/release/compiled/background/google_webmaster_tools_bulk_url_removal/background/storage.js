// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('google_webmaster_tools_bulk_url_removal.background.storage');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async');
goog.require('cljs_time.core');
goog.require('cljs_time.coerce');
goog.require('cljs_time.format');
goog.require('chromex.logging');
goog.require('chromex.protocols.chrome_storage_area');
goog.require('chromex.ext.storage');
google_webmaster_tools_bulk_url_removal.background.storage._STAR_DONE_FLAG_STAR_ = "**D0N3-FL@G**";
/**
 * status: pending, removed, removing, error
 *   CSV format : url, removal-method, url-type
 * 
 *   removal-method: 'remove-url' vs 'clear-cached'
 *   url-type: 'url-only' vs 'prefix'
 *   
 */
google_webmaster_tools_bulk_url_removal.background.storage.store_victims_BANG_ = (function google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG_(p__14863){
var map__14864 = p__14863;
var map__14864__$1 = (((((!((map__14864 == null))))?(((((map__14864.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__14864.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__14864):map__14864);
var data = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__14864__$1,cljs.core.cst$kw$data);
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
var data__$1 = cljs.core.concat.cljs$core$IFn$_invoke$arity$2(data,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, ["poison-pill",google_webmaster_tools_bulk_url_removal.background.storage._STAR_DONE_FLAG_STAR_], null)], null));
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__,local_storage,data__$1,map__14864,map__14864__$1,data){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__,local_storage,data__$1,map__14864,map__14864__$1,data){
return (function (state_14959){
var state_val_14960 = (state_14959[(1)]);
if((state_val_14960 === (7))){
var inst_14904 = (state_14959[(7)]);
var state_14959__$1 = state_14959;
var statearr_14961_15001 = state_14959__$1;
(statearr_14961_15001[(2)] = inst_14904);

(statearr_14961_15001[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (20))){
var inst_14933 = (state_14959[(8)]);
var inst_14897 = (state_14959[(9)]);
var inst_14935 = ["fetching ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(inst_14897),":"].join('');
var inst_14936 = (inst_14933.cljs$core$IFn$_invoke$arity$2 ? inst_14933.cljs$core$IFn$_invoke$arity$2(inst_14935,inst_14933) : inst_14933.call(null,inst_14935,inst_14933));
var state_14959__$1 = state_14959;
var statearr_14962_15002 = state_14959__$1;
(statearr_14962_15002[(2)] = inst_14936);

(statearr_14962_15002[(1)] = (22));


return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (1))){
var inst_14879 = cljs.core.seq(data__$1);
var inst_14880 = cljs.core.first(inst_14879);
var inst_14881 = cljs.core.next(inst_14879);
var inst_14882 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_14880,(0),null);
var inst_14883 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_14880,(1),null);
var inst_14884 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_14880,(2),null);
var inst_14885 = data__$1;
var inst_14886 = (0);
var state_14959__$1 = (function (){var statearr_14963 = state_14959;
(statearr_14963[(10)] = inst_14886);

(statearr_14963[(11)] = inst_14883);

(statearr_14963[(12)] = inst_14882);

(statearr_14963[(13)] = inst_14884);

(statearr_14963[(14)] = inst_14881);

(statearr_14963[(15)] = inst_14885);

return statearr_14963;
})();
var statearr_14964_15003 = state_14959__$1;
(statearr_14964_15003[(2)] = null);

(statearr_14964_15003[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (4))){
var state_14959__$1 = state_14959;
var statearr_14965_15004 = state_14959__$1;
(statearr_14965_15004[(2)] = null);

(statearr_14965_15004[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (15))){
var inst_14895 = (state_14959[(16)]);
var inst_14917 = (state_14959[(2)]);
var inst_14918 = (inst_14895 == null);
var state_14959__$1 = (function (){var statearr_14966 = state_14959;
(statearr_14966[(17)] = inst_14917);

return statearr_14966;
})();
if(cljs.core.truth_(inst_14918)){
var statearr_14967_15005 = state_14959__$1;
(statearr_14967_15005[(1)] = (16));

} else {
var statearr_14968_15006 = state_14959__$1;
(statearr_14968_15006[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (21))){
var inst_14886 = (state_14959[(10)]);
var inst_14917 = (state_14959[(17)]);
var inst_14908 = (state_14959[(18)]);
var inst_14897 = (state_14959[(9)]);
var inst_14938 = console.log("setting url: ",inst_14897," | method: ",inst_14908);
var inst_14939 = console.log("setting url: ",inst_14897," | url-type ",inst_14917);
var inst_14940 = [inst_14897];
var inst_14941 = ["submit-ts","remove-ts","removal-method","url-type","status","idx"];
var inst_14942 = cljs_time.core.now();
var inst_14943 = cljs_time.coerce.to_long(inst_14942);
var inst_14944 = [inst_14943,null,inst_14908,inst_14917,"pending",inst_14886];
var inst_14945 = cljs.core.PersistentHashMap.fromArrays(inst_14941,inst_14944);
var inst_14946 = [inst_14945];
var inst_14947 = cljs.core.PersistentHashMap.fromArrays(inst_14940,inst_14946);
var inst_14948 = cljs.core.clj__GT_js(inst_14947);
var inst_14949 = chromex.protocols.chrome_storage_area.set(local_storage,inst_14948);
var state_14959__$1 = (function (){var statearr_14969 = state_14959;
(statearr_14969[(19)] = inst_14939);

(statearr_14969[(20)] = inst_14938);

return statearr_14969;
})();
var statearr_14970_15007 = state_14959__$1;
(statearr_14970_15007[(2)] = inst_14949);

(statearr_14970_15007[(1)] = (22));


return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (13))){
var inst_14913 = (state_14959[(21)]);
var state_14959__$1 = state_14959;
var statearr_14971_15008 = state_14959__$1;
(statearr_14971_15008[(2)] = inst_14913);

(statearr_14971_15008[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (22))){
var inst_14886 = (state_14959[(10)]);
var inst_14896 = (state_14959[(22)]);
var inst_14951 = (state_14959[(2)]);
var inst_14952 = (inst_14886 + (1));
var inst_14885 = inst_14896;
var inst_14886__$1 = inst_14952;
var state_14959__$1 = (function (){var statearr_14972 = state_14959;
(statearr_14972[(10)] = inst_14886__$1);

(statearr_14972[(23)] = inst_14951);

(statearr_14972[(15)] = inst_14885);

return statearr_14972;
})();
var statearr_14973_15009 = state_14959__$1;
(statearr_14973_15009[(2)] = null);

(statearr_14973_15009[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (6))){
var inst_14904 = (state_14959[(7)]);
var inst_14904__$1 = (state_14959[(2)]);
var state_14959__$1 = (function (){var statearr_14974 = state_14959;
(statearr_14974[(7)] = inst_14904__$1);

return statearr_14974;
})();
if(cljs.core.truth_(inst_14904__$1)){
var statearr_14975_15010 = state_14959__$1;
(statearr_14975_15010[(1)] = (7));

} else {
var statearr_14976_15011 = state_14959__$1;
(statearr_14976_15011[(1)] = (8));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (17))){
var inst_14897 = (state_14959[(9)]);
var inst_14928 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$2(local_storage,inst_14897);
var state_14959__$1 = state_14959;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_14959__$1,(19),inst_14928);
} else {
if((state_val_14960 === (3))){
var inst_14957 = (state_14959[(2)]);
var state_14959__$1 = state_14959;
return cljs.core.async.impl.ioc_helpers.return_chan(state_14959__$1,inst_14957);
} else {
if((state_val_14960 === (12))){
var inst_14913 = (state_14959[(21)]);
var inst_14913__$1 = (state_14959[(2)]);
var state_14959__$1 = (function (){var statearr_14977 = state_14959;
(statearr_14977[(21)] = inst_14913__$1);

return statearr_14977;
})();
if(cljs.core.truth_(inst_14913__$1)){
var statearr_14978_15012 = state_14959__$1;
(statearr_14978_15012[(1)] = (13));

} else {
var statearr_14979_15013 = state_14959__$1;
(statearr_14979_15013[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (2))){
var inst_14898 = (state_14959[(24)]);
var inst_14895 = (state_14959[(16)]);
var inst_14885 = (state_14959[(15)]);
var inst_14894 = cljs.core.seq(inst_14885);
var inst_14895__$1 = cljs.core.first(inst_14894);
var inst_14896 = cljs.core.next(inst_14894);
var inst_14897 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_14895__$1,(0),null);
var inst_14898__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_14895__$1,(1),null);
var inst_14899 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_14895__$1,(2),null);
var inst_14900 = cljs.core.empty_QMARK_(inst_14898__$1);
var state_14959__$1 = (function (){var statearr_14980 = state_14959;
(statearr_14980[(24)] = inst_14898__$1);

(statearr_14980[(25)] = inst_14899);

(statearr_14980[(22)] = inst_14896);

(statearr_14980[(16)] = inst_14895__$1);

(statearr_14980[(9)] = inst_14897);

return statearr_14980;
})();
if(inst_14900){
var statearr_14981_15014 = state_14959__$1;
(statearr_14981_15014[(1)] = (4));

} else {
var statearr_14982_15015 = state_14959__$1;
(statearr_14982_15015[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (19))){
var inst_14933 = (state_14959[(8)]);
var inst_14930 = (state_14959[(2)]);
var inst_14931 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_14930,(0),null);
var inst_14932 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_14931,(0),null);
var inst_14933__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_14930,(1),null);
var state_14959__$1 = (function (){var statearr_14983 = state_14959;
(statearr_14983[(26)] = inst_14932);

(statearr_14983[(8)] = inst_14933__$1);

return statearr_14983;
})();
if(cljs.core.truth_(inst_14933__$1)){
var statearr_14984_15016 = state_14959__$1;
(statearr_14984_15016[(1)] = (20));

} else {
var statearr_14985_15017 = state_14959__$1;
(statearr_14985_15017[(1)] = (21));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (11))){
var inst_14899 = (state_14959[(25)]);
var state_14959__$1 = state_14959;
var statearr_14986_15018 = state_14959__$1;
(statearr_14986_15018[(2)] = inst_14899);

(statearr_14986_15018[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (9))){
var inst_14899 = (state_14959[(25)]);
var inst_14908 = (state_14959[(2)]);
var inst_14909 = cljs.core.empty_QMARK_(inst_14899);
var state_14959__$1 = (function (){var statearr_14987 = state_14959;
(statearr_14987[(18)] = inst_14908);

return statearr_14987;
})();
if(inst_14909){
var statearr_14988_15019 = state_14959__$1;
(statearr_14988_15019[(1)] = (10));

} else {
var statearr_14989_15020 = state_14959__$1;
(statearr_14989_15020[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (5))){
var inst_14898 = (state_14959[(24)]);
var state_14959__$1 = state_14959;
var statearr_14990_15021 = state_14959__$1;
(statearr_14990_15021[(2)] = inst_14898);

(statearr_14990_15021[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (14))){
var state_14959__$1 = state_14959;
var statearr_14991_15022 = state_14959__$1;
(statearr_14991_15022[(2)] = "url-only");

(statearr_14991_15022[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (16))){
var inst_14920 = console.log("DONE storing victims");
var state_14959__$1 = (function (){var statearr_14992 = state_14959;
(statearr_14992[(27)] = inst_14920);

return statearr_14992;
})();
var statearr_14993_15023 = state_14959__$1;
(statearr_14993_15023[(2)] = null);

(statearr_14993_15023[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (10))){
var state_14959__$1 = state_14959;
var statearr_14994_15024 = state_14959__$1;
(statearr_14994_15024[(2)] = null);

(statearr_14994_15024[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (18))){
var inst_14955 = (state_14959[(2)]);
var state_14959__$1 = state_14959;
var statearr_14995_15025 = state_14959__$1;
(statearr_14995_15025[(2)] = inst_14955);

(statearr_14995_15025[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_14960 === (8))){
var state_14959__$1 = state_14959;
var statearr_14996_15026 = state_14959__$1;
(statearr_14996_15026[(2)] = "remove-url");

(statearr_14996_15026[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto__,local_storage,data__$1,map__14864,map__14864__$1,data))
;
return ((function (switch__7945__auto__,c__8052__auto__,local_storage,data__$1,map__14864,map__14864__$1,data){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto____0 = (function (){
var statearr_14997 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_14997[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto__);

(statearr_14997[(1)] = (1));

return statearr_14997;
});
var google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto____1 = (function (state_14959){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_14959);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e14998){if((e14998 instanceof Object)){
var ex__7949__auto__ = e14998;
var statearr_14999_15027 = state_14959;
(statearr_14999_15027[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_14959);

return cljs.core.cst$kw$recur;
} else {
throw e14998;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__15028 = state_14959;
state_14959 = G__15028;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto__ = function(state_14959){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto____1.call(this,state_14959);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$store_victims_BANG__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__,local_storage,data__$1,map__14864,map__14864__$1,data))
})();
var state__8054__auto__ = (function (){var statearr_15000 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_15000[(6)] = c__8052__auto__);

return statearr_15000;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__,local_storage,data__$1,map__14864,map__14864__$1,data))
);

return c__8052__auto__;
});
google_webmaster_tools_bulk_url_removal.background.storage.update_storage = (function google_webmaster_tools_bulk_url_removal$background$storage$update_storage(var_args){
var args__4736__auto__ = [];
var len__4730__auto___15078 = arguments.length;
var i__4731__auto___15079 = (0);
while(true){
if((i__4731__auto___15079 < len__4730__auto___15078)){
args__4736__auto__.push((arguments[i__4731__auto___15079]));

var G__15080 = (i__4731__auto___15079 + (1));
i__4731__auto___15079 = G__15080;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return google_webmaster_tools_bulk_url_removal.background.storage.update_storage.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

google_webmaster_tools_bulk_url_removal.background.storage.update_storage.cljs$core$IFn$_invoke$arity$variadic = (function (url,args){

var kv_pairs = cljs.core.partition.cljs$core$IFn$_invoke$arity$2((2),args);
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var c__8052__auto___15081 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___15081,kv_pairs,local_storage,ch){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___15081,kv_pairs,local_storage,ch){
return (function (state_15063){
var state_val_15064 = (state_15063[(1)]);
if((state_val_15064 === (1))){
var inst_15037 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$2(local_storage,url);
var state_15063__$1 = state_15063;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_15063__$1,(2),inst_15037);
} else {
if((state_val_15064 === (2))){
var inst_15039 = (state_15063[(7)]);
var inst_15040 = (state_15063[(8)]);
var inst_15042 = (state_15063[(9)]);
var inst_15039__$1 = (state_15063[(2)]);
var inst_15040__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15039__$1,(0),null);
var inst_15041 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15040__$1,(0),null);
var inst_15042__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15039__$1,(1),null);
var state_15063__$1 = (function (){var statearr_15065 = state_15063;
(statearr_15065[(7)] = inst_15039__$1);

(statearr_15065[(8)] = inst_15040__$1);

(statearr_15065[(9)] = inst_15042__$1);

(statearr_15065[(10)] = inst_15041);

return statearr_15065;
})();
if(cljs.core.truth_(inst_15042__$1)){
var statearr_15066_15082 = state_15063__$1;
(statearr_15066_15082[(1)] = (3));

} else {
var statearr_15067_15083 = state_15063__$1;
(statearr_15067_15083[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_15064 === (3))){
var inst_15042 = (state_15063[(9)]);
var inst_15044 = ["fetching ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(url),":"].join('');
var inst_15045 = (inst_15042.cljs$core$IFn$_invoke$arity$2 ? inst_15042.cljs$core$IFn$_invoke$arity$2(inst_15044,inst_15042) : inst_15042.call(null,inst_15044,inst_15042));
var state_15063__$1 = state_15063;
var statearr_15068_15084 = state_15063__$1;
(statearr_15068_15084[(2)] = inst_15045);

(statearr_15068_15084[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15064 === (4))){
var inst_15039 = (state_15063[(7)]);
var inst_15040 = (state_15063[(8)]);
var inst_15042 = (state_15063[(9)]);
var inst_15041 = (state_15063[(10)]);
var inst_15047 = cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(inst_15041);
var inst_15048 = cljs.core.vals(inst_15047);
var inst_15049 = cljs.core.first(inst_15048);
var inst_15050 = [url];
var inst_15052 = (function (){var vec__15031 = inst_15039;
var vec__15034 = inst_15040;
var items = inst_15041;
var error = inst_15042;
var entry = inst_15049;
return ((function (vec__15031,vec__15034,items,error,entry,inst_15039,inst_15040,inst_15042,inst_15041,inst_15047,inst_15048,inst_15049,inst_15050,state_val_15064,c__8052__auto___15081,kv_pairs,local_storage,ch){
return (function (accum,p__15051){
var vec__15069 = p__15051;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15069,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15069,(1),null);
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(accum,k,v);
});
;})(vec__15031,vec__15034,items,error,entry,inst_15039,inst_15040,inst_15042,inst_15041,inst_15047,inst_15048,inst_15049,inst_15050,state_val_15064,c__8052__auto___15081,kv_pairs,local_storage,ch))
})();
var inst_15053 = cljs.core.reduce.cljs$core$IFn$_invoke$arity$3(inst_15052,inst_15049,kv_pairs);
var inst_15054 = [inst_15053];
var inst_15055 = cljs.core.PersistentHashMap.fromArrays(inst_15050,inst_15054);
var inst_15056 = cljs.core.clj__GT_js(inst_15055);
var inst_15057 = chromex.protocols.chrome_storage_area.set(local_storage,inst_15056);
var state_15063__$1 = (function (){var statearr_15072 = state_15063;
(statearr_15072[(11)] = inst_15057);

return statearr_15072;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_15063__$1,(6),ch,inst_15055);
} else {
if((state_val_15064 === (5))){
var inst_15061 = (state_15063[(2)]);
var state_15063__$1 = state_15063;
return cljs.core.async.impl.ioc_helpers.return_chan(state_15063__$1,inst_15061);
} else {
if((state_val_15064 === (6))){
var inst_15059 = (state_15063[(2)]);
var state_15063__$1 = state_15063;
var statearr_15073_15085 = state_15063__$1;
(statearr_15073_15085[(2)] = inst_15059);

(statearr_15073_15085[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
});})(c__8052__auto___15081,kv_pairs,local_storage,ch))
;
return ((function (switch__7945__auto__,c__8052__auto___15081,kv_pairs,local_storage,ch){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto____0 = (function (){
var statearr_15074 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_15074[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto__);

(statearr_15074[(1)] = (1));

return statearr_15074;
});
var google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto____1 = (function (state_15063){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_15063);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e15075){if((e15075 instanceof Object)){
var ex__7949__auto__ = e15075;
var statearr_15076_15086 = state_15063;
(statearr_15076_15086[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_15063);

return cljs.core.cst$kw$recur;
} else {
throw e15075;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__15087 = state_15063;
state_15063 = G__15087;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto__ = function(state_15063){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto____1.call(this,state_15063);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___15081,kv_pairs,local_storage,ch))
})();
var state__8054__auto__ = (function (){var statearr_15077 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_15077[(6)] = c__8052__auto___15081);

return statearr_15077;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___15081,kv_pairs,local_storage,ch))
);


return ch;
});

google_webmaster_tools_bulk_url_removal.background.storage.update_storage.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
google_webmaster_tools_bulk_url_removal.background.storage.update_storage.cljs$lang$applyTo = (function (seq15029){
var G__15030 = cljs.core.first(seq15029);
var seq15029__$1 = cljs.core.next(seq15029);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__15030,seq15029__$1);
});

/**
 * NOTE: There should only be one item that's undergoing removal.
 *   Return nil if not found.
 *   Return URL if found.
 *   
 */
google_webmaster_tools_bulk_url_removal.background.storage.current_removal_attempt = (function google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt(){
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__,local_storage){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__,local_storage){
return (function (state_15106){
var state_val_15107 = (state_15106[(1)]);
if((state_val_15107 === (1))){
var inst_15094 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$1(local_storage);
var state_15106__$1 = state_15106;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_15106__$1,(2),inst_15094);
} else {
if((state_val_15107 === (2))){
var inst_15096 = (state_15106[(2)]);
var inst_15097 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15096,(0),null);
var inst_15098 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15097,(0),null);
var inst_15099 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15096,(1),null);
var inst_15101 = (function (){var vec__15088 = inst_15096;
var vec__15091 = inst_15097;
var items = inst_15098;
var error = inst_15099;
return ((function (vec__15088,vec__15091,items,error,inst_15096,inst_15097,inst_15098,inst_15099,state_val_15107,c__8052__auto__,local_storage){
return (function (p__15100){
var vec__15108 = p__15100;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15108,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15108,(1),null);
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2("removing",cljs.core.get.cljs$core$IFn$_invoke$arity$2(v,"status"));
});
;})(vec__15088,vec__15091,items,error,inst_15096,inst_15097,inst_15098,inst_15099,state_val_15107,c__8052__auto__,local_storage))
})();
var inst_15102 = cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(inst_15098);
var inst_15103 = cljs.core.filter.cljs$core$IFn$_invoke$arity$2(inst_15101,inst_15102);
var inst_15104 = cljs.core.first(inst_15103);
var state_15106__$1 = state_15106;
return cljs.core.async.impl.ioc_helpers.return_chan(state_15106__$1,inst_15104);
} else {
return null;
}
}
});})(c__8052__auto__,local_storage))
;
return ((function (switch__7945__auto__,c__8052__auto__,local_storage){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto____0 = (function (){
var statearr_15111 = [null,null,null,null,null,null,null];
(statearr_15111[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto__);

(statearr_15111[(1)] = (1));

return statearr_15111;
});
var google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto____1 = (function (state_15106){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_15106);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e15112){if((e15112 instanceof Object)){
var ex__7949__auto__ = e15112;
var statearr_15113_15115 = state_15106;
(statearr_15113_15115[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_15106);

return cljs.core.cst$kw$recur;
} else {
throw e15112;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__15116 = state_15106;
state_15106 = G__15116;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto__ = function(state_15106){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto____1.call(this,state_15106);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$current_removal_attempt_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__,local_storage))
})();
var state__8054__auto__ = (function (){var statearr_15114 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_15114[(6)] = c__8052__auto__);

return statearr_15114;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__,local_storage))
);

return c__8052__auto__;
});
google_webmaster_tools_bulk_url_removal.background.storage.fresh_new_victim = (function google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim(){
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var c__8052__auto___15195 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___15195,local_storage,ch){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___15195,local_storage,ch){
return (function (state_15167){
var state_val_15168 = (state_15167[(1)]);
if((state_val_15168 === (7))){
var inst_15145 = (state_15167[(7)]);
var inst_15150 = google_webmaster_tools_bulk_url_removal.background.storage.update_storage.cljs$core$IFn$_invoke$arity$variadic(inst_15145,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["status","removing"], 0));
var state_15167__$1 = state_15167;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_15167__$1,(9),inst_15150);
} else {
if((state_val_15168 === (1))){
var inst_15126 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$1(local_storage);
var state_15167__$1 = state_15167;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_15167__$1,(2),inst_15126);
} else {
if((state_val_15168 === (4))){
var inst_15138 = cljs.core.List.EMPTY;
var state_15167__$1 = state_15167;
var statearr_15169_15196 = state_15167__$1;
(statearr_15169_15196[(2)] = inst_15138);

(statearr_15169_15196[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15168 === (13))){
var inst_15165 = (state_15167[(2)]);
var state_15167__$1 = state_15167;
return cljs.core.async.impl.ioc_helpers.return_chan(state_15167__$1,inst_15165);
} else {
if((state_val_15168 === (6))){
var state_15167__$1 = state_15167;
var statearr_15170_15197 = state_15167__$1;
(statearr_15170_15197[(2)] = null);

(statearr_15170_15197[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15168 === (3))){
var inst_15130 = (state_15167[(8)]);
var state_15167__$1 = state_15167;
var statearr_15171_15198 = state_15167__$1;
(statearr_15171_15198[(2)] = inst_15130);

(statearr_15171_15198[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15168 === (12))){
var inst_15157 = (state_15167[(9)]);
var state_15167__$1 = state_15167;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_15167__$1,(14),ch,inst_15157);
} else {
if((state_val_15168 === (2))){
var inst_15130 = (state_15167[(8)]);
var inst_15128 = (state_15167[(2)]);
var inst_15129 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15128,(0),null);
var inst_15130__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15129,(0),null);
var inst_15131 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15128,(1),null);
var inst_15133 = (function (){var vec__15117 = inst_15128;
var vec__15120 = inst_15129;
var items = inst_15130__$1;
var error = inst_15131;
return ((function (vec__15117,vec__15120,items,error,inst_15130,inst_15128,inst_15129,inst_15130__$1,inst_15131,state_val_15168,c__8052__auto___15195,local_storage,ch){
return (function (p__15132){
var vec__15172 = p__15132;
var _ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15172,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15172,(1),null);
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(v,"idx");
});
;})(vec__15117,vec__15120,items,error,inst_15130,inst_15128,inst_15129,inst_15130__$1,inst_15131,state_val_15168,c__8052__auto___15195,local_storage,ch))
})();
var inst_15135 = (function (){var vec__15117 = inst_15128;
var vec__15120 = inst_15129;
var items = inst_15130__$1;
var error = inst_15131;
return ((function (vec__15117,vec__15120,items,error,inst_15130,inst_15128,inst_15129,inst_15130__$1,inst_15131,inst_15133,state_val_15168,c__8052__auto___15195,local_storage,ch){
return (function (p__15134){
var vec__15175 = p__15134;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15175,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15175,(1),null);
var status = cljs.core.get.cljs$core$IFn$_invoke$arity$2(v,"status");
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2("pending",status);
});
;})(vec__15117,vec__15120,items,error,inst_15130,inst_15128,inst_15129,inst_15130__$1,inst_15131,inst_15133,state_val_15168,c__8052__auto___15195,local_storage,ch))
})();
var state_15167__$1 = (function (){var statearr_15178 = state_15167;
(statearr_15178[(10)] = inst_15133);

(statearr_15178[(11)] = inst_15135);

(statearr_15178[(8)] = inst_15130__$1);

return statearr_15178;
})();
if(cljs.core.truth_(inst_15130__$1)){
var statearr_15179_15199 = state_15167__$1;
(statearr_15179_15199[(1)] = (3));

} else {
var statearr_15180_15200 = state_15167__$1;
(statearr_15180_15200[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_15168 === (11))){
var inst_15160 = cljs.core.async.close_BANG_(ch);
var state_15167__$1 = state_15167;
var statearr_15181_15201 = state_15167__$1;
(statearr_15181_15201[(2)] = inst_15160);

(statearr_15181_15201[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15168 === (9))){
var inst_15152 = (state_15167[(2)]);
var state_15167__$1 = state_15167;
var statearr_15182_15202 = state_15167__$1;
(statearr_15182_15202[(2)] = inst_15152);

(statearr_15182_15202[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15168 === (5))){
var inst_15133 = (state_15167[(10)]);
var inst_15135 = (state_15167[(11)]);
var inst_15140 = (state_15167[(2)]);
var inst_15141 = cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(inst_15140);
var inst_15142 = cljs.core.filter.cljs$core$IFn$_invoke$arity$2(inst_15135,inst_15141);
var inst_15143 = cljs.core.sort_by.cljs$core$IFn$_invoke$arity$2(inst_15133,inst_15142);
var inst_15144 = cljs.core.first(inst_15143);
var inst_15145 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15144,(0),null);
var inst_15146 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15144,(1),null);
var inst_15147 = (inst_15146 == null);
var state_15167__$1 = (function (){var statearr_15183 = state_15167;
(statearr_15183[(7)] = inst_15145);

return statearr_15183;
})();
if(cljs.core.truth_(inst_15147)){
var statearr_15184_15203 = state_15167__$1;
(statearr_15184_15203[(1)] = (6));

} else {
var statearr_15185_15204 = state_15167__$1;
(statearr_15185_15204[(1)] = (7));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_15168 === (14))){
var inst_15163 = (state_15167[(2)]);
var state_15167__$1 = state_15167;
var statearr_15186_15205 = state_15167__$1;
(statearr_15186_15205[(2)] = inst_15163);

(statearr_15186_15205[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15168 === (10))){
var inst_15157 = (state_15167[(9)]);
var inst_15157__$1 = (state_15167[(2)]);
var inst_15158 = (inst_15157__$1 == null);
var state_15167__$1 = (function (){var statearr_15187 = state_15167;
(statearr_15187[(9)] = inst_15157__$1);

return statearr_15187;
})();
if(cljs.core.truth_(inst_15158)){
var statearr_15188_15206 = state_15167__$1;
(statearr_15188_15206[(1)] = (11));

} else {
var statearr_15189_15207 = state_15167__$1;
(statearr_15189_15207[(1)] = (12));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_15168 === (8))){
var inst_15154 = (state_15167[(2)]);
var inst_15155 = google_webmaster_tools_bulk_url_removal.background.storage.current_removal_attempt();
var state_15167__$1 = (function (){var statearr_15190 = state_15167;
(statearr_15190[(12)] = inst_15154);

return statearr_15190;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_15167__$1,(10),inst_15155);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___15195,local_storage,ch))
;
return ((function (switch__7945__auto__,c__8052__auto___15195,local_storage,ch){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto____0 = (function (){
var statearr_15191 = [null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_15191[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto__);

(statearr_15191[(1)] = (1));

return statearr_15191;
});
var google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto____1 = (function (state_15167){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_15167);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e15192){if((e15192 instanceof Object)){
var ex__7949__auto__ = e15192;
var statearr_15193_15208 = state_15167;
(statearr_15193_15208[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_15167);

return cljs.core.cst$kw$recur;
} else {
throw e15192;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__15209 = state_15167;
state_15167 = G__15209;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto__ = function(state_15167){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto____1.call(this,state_15167);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$fresh_new_victim_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___15195,local_storage,ch))
})();
var state__8054__auto__ = (function (){var statearr_15194 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_15194[(6)] = c__8052__auto___15195);

return statearr_15194;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___15195,local_storage,ch))
);


return ch;
});
google_webmaster_tools_bulk_url_removal.background.storage.next_victim = (function google_webmaster_tools_bulk_url_removal$background$storage$next_victim(){
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var c__8052__auto___15246 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___15246,ch){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___15246,ch){
return (function (state_15230){
var state_val_15231 = (state_15230[(1)]);
if((state_val_15231 === (7))){
var inst_15223 = cljs.core.async.close_BANG_(ch);
var state_15230__$1 = state_15230;
var statearr_15232_15247 = state_15230__$1;
(statearr_15232_15247[(2)] = inst_15223);

(statearr_15232_15247[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15231 === (1))){
var inst_15210 = google_webmaster_tools_bulk_url_removal.background.storage.current_removal_attempt();
var state_15230__$1 = state_15230;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_15230__$1,(2),inst_15210);
} else {
if((state_val_15231 === (4))){
var inst_15212 = (state_15230[(7)]);
var state_15230__$1 = state_15230;
var statearr_15233_15248 = state_15230__$1;
(statearr_15233_15248[(2)] = inst_15212);

(statearr_15233_15248[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15231 === (6))){
var inst_15217 = (state_15230[(2)]);
var state_15230__$1 = state_15230;
var statearr_15234_15249 = state_15230__$1;
(statearr_15234_15249[(2)] = inst_15217);

(statearr_15234_15249[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15231 === (3))){
var inst_15215 = google_webmaster_tools_bulk_url_removal.background.storage.fresh_new_victim();
var state_15230__$1 = state_15230;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_15230__$1,(6),inst_15215);
} else {
if((state_val_15231 === (2))){
var inst_15212 = (state_15230[(7)]);
var inst_15212__$1 = (state_15230[(2)]);
var inst_15213 = cljs.core.empty_QMARK_(inst_15212__$1);
var state_15230__$1 = (function (){var statearr_15235 = state_15230;
(statearr_15235[(7)] = inst_15212__$1);

return statearr_15235;
})();
if(inst_15213){
var statearr_15236_15250 = state_15230__$1;
(statearr_15236_15250[(1)] = (3));

} else {
var statearr_15237_15251 = state_15230__$1;
(statearr_15237_15251[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_15231 === (9))){
var inst_15228 = (state_15230[(2)]);
var state_15230__$1 = state_15230;
return cljs.core.async.impl.ioc_helpers.return_chan(state_15230__$1,inst_15228);
} else {
if((state_val_15231 === (5))){
var inst_15220 = (state_15230[(8)]);
var inst_15220__$1 = (state_15230[(2)]);
var inst_15221 = (inst_15220__$1 == null);
var state_15230__$1 = (function (){var statearr_15238 = state_15230;
(statearr_15238[(8)] = inst_15220__$1);

return statearr_15238;
})();
if(cljs.core.truth_(inst_15221)){
var statearr_15239_15252 = state_15230__$1;
(statearr_15239_15252[(1)] = (7));

} else {
var statearr_15240_15253 = state_15230__$1;
(statearr_15240_15253[(1)] = (8));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_15231 === (10))){
var inst_15226 = (state_15230[(2)]);
var state_15230__$1 = state_15230;
var statearr_15241_15254 = state_15230__$1;
(statearr_15241_15254[(2)] = inst_15226);

(statearr_15241_15254[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15231 === (8))){
var inst_15220 = (state_15230[(8)]);
var state_15230__$1 = state_15230;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_15230__$1,(10),ch,inst_15220);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___15246,ch))
;
return ((function (switch__7945__auto__,c__8052__auto___15246,ch){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto____0 = (function (){
var statearr_15242 = [null,null,null,null,null,null,null,null,null];
(statearr_15242[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto__);

(statearr_15242[(1)] = (1));

return statearr_15242;
});
var google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto____1 = (function (state_15230){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_15230);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e15243){if((e15243 instanceof Object)){
var ex__7949__auto__ = e15243;
var statearr_15244_15255 = state_15230;
(statearr_15244_15255[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_15230);

return cljs.core.cst$kw$recur;
} else {
throw e15243;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__15256 = state_15230;
state_15230 = G__15256;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto__ = function(state_15230){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto____1.call(this,state_15230);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$next_victim_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___15246,ch))
})();
var state__8054__auto__ = (function (){var statearr_15245 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_15245[(6)] = c__8052__auto___15246);

return statearr_15245;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___15246,ch))
);


return ch;
});
google_webmaster_tools_bulk_url_removal.background.storage.clear_victims_BANG_ = (function google_webmaster_tools_bulk_url_removal$background$storage$clear_victims_BANG_(){
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
return chromex.protocols.chrome_storage_area.clear(local_storage);
});
google_webmaster_tools_bulk_url_removal.background.storage.print_victims = (function google_webmaster_tools_bulk_url_removal$background$storage$print_victims(){
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__,local_storage){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__,local_storage){
return (function (state_15272){
var state_val_15273 = (state_15272[(1)]);
if((state_val_15273 === (1))){
var inst_15263 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$1(local_storage);
var state_15272__$1 = state_15272;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_15272__$1,(2),inst_15263);
} else {
if((state_val_15273 === (2))){
var inst_15265 = (state_15272[(2)]);
var inst_15266 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15265,(0),null);
var inst_15267 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15266,(0),null);
var inst_15268 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15265,(1),null);
var inst_15269 = cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(inst_15267);
var inst_15270 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([inst_15269], 0));
var state_15272__$1 = (function (){var statearr_15274 = state_15272;
(statearr_15274[(7)] = inst_15268);

return statearr_15274;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_15272__$1,inst_15270);
} else {
return null;
}
}
});})(c__8052__auto__,local_storage))
;
return ((function (switch__7945__auto__,c__8052__auto__,local_storage){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto____0 = (function (){
var statearr_15275 = [null,null,null,null,null,null,null,null];
(statearr_15275[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto__);

(statearr_15275[(1)] = (1));

return statearr_15275;
});
var google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto____1 = (function (state_15272){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_15272);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e15276){if((e15276 instanceof Object)){
var ex__7949__auto__ = e15276;
var statearr_15277_15279 = state_15272;
(statearr_15277_15279[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_15272);

return cljs.core.cst$kw$recur;
} else {
throw e15276;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__15280 = state_15272;
state_15272 = G__15280;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto__ = function(state_15272){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto____1.call(this,state_15272);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$print_victims_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__,local_storage))
})();
var state__8054__auto__ = (function (){var statearr_15278 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_15278[(6)] = c__8052__auto__);

return statearr_15278;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__,local_storage))
);

return c__8052__auto__;
});
google_webmaster_tools_bulk_url_removal.background.storage.get_bad_victims = (function google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims(){
var local_storage = chromex.ext.storage.local_STAR_(chromex.config.get_active_config());
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var c__8052__auto___15325 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___15325,local_storage,ch){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___15325,local_storage,ch){
return (function (state_15308){
var state_val_15309 = (state_15308[(1)]);
if((state_val_15309 === (1))){
var inst_15287 = chromex.protocols.chrome_storage_area.get.cljs$core$IFn$_invoke$arity$1(local_storage);
var state_15308__$1 = state_15308;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_15308__$1,(2),inst_15287);
} else {
if((state_val_15309 === (2))){
var inst_15291 = (state_15308[(7)]);
var inst_15289 = (state_15308[(2)]);
var inst_15290 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15289,(0),null);
var inst_15291__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15290,(0),null);
var inst_15292 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_15289,(1),null);
var inst_15294 = (function (){var vec__15281 = inst_15289;
var vec__15284 = inst_15290;
var items = inst_15291__$1;
var error = inst_15292;
return ((function (vec__15281,vec__15284,items,error,inst_15291,inst_15289,inst_15290,inst_15291__$1,inst_15292,state_val_15309,c__8052__auto___15325,local_storage,ch){
return (function (p__15293){
var vec__15310 = p__15293;
var _ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15310,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15310,(1),null);
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(v,"idx");
});
;})(vec__15281,vec__15284,items,error,inst_15291,inst_15289,inst_15290,inst_15291__$1,inst_15292,state_val_15309,c__8052__auto___15325,local_storage,ch))
})();
var inst_15296 = (function (){var vec__15281 = inst_15289;
var vec__15284 = inst_15290;
var items = inst_15291__$1;
var error = inst_15292;
return ((function (vec__15281,vec__15284,items,error,inst_15291,inst_15289,inst_15290,inst_15291__$1,inst_15292,inst_15294,state_val_15309,c__8052__auto___15325,local_storage,ch){
return (function (p__15295){
var vec__15313 = p__15295;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15313,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__15313,(1),null);
var status = cljs.core.get.cljs$core$IFn$_invoke$arity$2(v,"status");
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2("error",status);
});
;})(vec__15281,vec__15284,items,error,inst_15291,inst_15289,inst_15290,inst_15291__$1,inst_15292,inst_15294,state_val_15309,c__8052__auto___15325,local_storage,ch))
})();
var state_15308__$1 = (function (){var statearr_15316 = state_15308;
(statearr_15316[(7)] = inst_15291__$1);

(statearr_15316[(8)] = inst_15296);

(statearr_15316[(9)] = inst_15294);

return statearr_15316;
})();
if(cljs.core.truth_(inst_15291__$1)){
var statearr_15317_15326 = state_15308__$1;
(statearr_15317_15326[(1)] = (4));

} else {
var statearr_15318_15327 = state_15308__$1;
(statearr_15318_15327[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_15309 === (3))){
var inst_15306 = (state_15308[(2)]);
var state_15308__$1 = state_15308;
return cljs.core.async.impl.ioc_helpers.return_chan(state_15308__$1,inst_15306);
} else {
if((state_val_15309 === (4))){
var inst_15291 = (state_15308[(7)]);
var state_15308__$1 = state_15308;
var statearr_15319_15328 = state_15308__$1;
(statearr_15319_15328[(2)] = inst_15291);

(statearr_15319_15328[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15309 === (5))){
var inst_15299 = cljs.core.List.EMPTY;
var state_15308__$1 = state_15308;
var statearr_15320_15329 = state_15308__$1;
(statearr_15320_15329[(2)] = inst_15299);

(statearr_15320_15329[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_15309 === (6))){
var inst_15296 = (state_15308[(8)]);
var inst_15294 = (state_15308[(9)]);
var inst_15301 = (state_15308[(2)]);
var inst_15302 = cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(inst_15301);
var inst_15303 = cljs.core.filter.cljs$core$IFn$_invoke$arity$2(inst_15296,inst_15302);
var inst_15304 = cljs.core.sort_by.cljs$core$IFn$_invoke$arity$2(inst_15294,inst_15303);
var state_15308__$1 = state_15308;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_15308__$1,(3),ch,inst_15304);
} else {
return null;
}
}
}
}
}
}
});})(c__8052__auto___15325,local_storage,ch))
;
return ((function (switch__7945__auto__,c__8052__auto___15325,local_storage,ch){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto____0 = (function (){
var statearr_15321 = [null,null,null,null,null,null,null,null,null,null];
(statearr_15321[(0)] = google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto__);

(statearr_15321[(1)] = (1));

return statearr_15321;
});
var google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto____1 = (function (state_15308){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_15308);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e15322){if((e15322 instanceof Object)){
var ex__7949__auto__ = e15322;
var statearr_15323_15330 = state_15308;
(statearr_15323_15330[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_15308);

return cljs.core.cst$kw$recur;
} else {
throw e15322;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__15331 = state_15308;
state_15308 = G__15331;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto__ = function(state_15308){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto____1.call(this,state_15308);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$storage$get_bad_victims_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___15325,local_storage,ch))
})();
var state__8054__auto__ = (function (){var statearr_15324 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_15324[(6)] = c__8052__auto___15325);

return statearr_15324;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___15325,local_storage,ch))
);


return ch;
});

// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('google_webmaster_tools_bulk_url_removal.background.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('goog.string');
goog.require('goog.string.format');
goog.require('clojure.string');
goog.require('cljs.core.async');
goog.require('chromex.logging');
goog.require('chromex.chrome_event_channel');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.ext.tabs');
goog.require('chromex.ext.runtime');
goog.require('chromex.ext.web_request');
goog.require('chromex.ext.windows');
goog.require('cljs_time.core');
goog.require('cljs_time.coerce');
goog.require('cognitect.transit');
goog.require('chromex.ext.browser_action');
goog.require('google_webmaster_tools_bulk_url_removal.background.storage');
goog.require('google_webmaster_tools_bulk_url_removal.content_script.common');
google_webmaster_tools_bulk_url_removal.background.core.github_source_url = "This project is from https://github.com/noitcudni/google-webmaster-tools-bulk-url-removal";
goog.exportSymbol('google_webmaster_tools_bulk_url_removal.background.core.github_source_url', google_webmaster_tools_bulk_url_removal.background.core.github_source_url);
google_webmaster_tools_bulk_url_removal.background.core.clients = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentVector.EMPTY);
google_webmaster_tools_bulk_url_removal.background.core.my_status = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.cst$kw$done);
google_webmaster_tools_bulk_url_removal.background.core.add_client_BANG_ = (function google_webmaster_tools_bulk_url_removal$background$core$add_client_BANG_(client){
cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["BACKGROUND: client connected: ",chromex.protocols.chrome_port.get_sender(client)], 0));

chromex.protocols.chrome_port.on_disconnect_BANG_(client,(function (){
cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["on disconnect callback !!!"], 0));

return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(google_webmaster_tools_bulk_url_removal.background.core.clients,(function (curr,c){
return cljs.core.remove.cljs$core$IFn$_invoke$arity$2((function (p1__17165_SHARP_){
return cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(p1__17165_SHARP_,c);
}),curr);
}),client);
}));

return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(google_webmaster_tools_bulk_url_removal.background.core.clients,cljs.core.conj,client);
});
google_webmaster_tools_bulk_url_removal.background.core.remove_client_BANG_ = (function google_webmaster_tools_bulk_url_removal$background$core$remove_client_BANG_(client){
cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["BACKGROUND: client disconnected",chromex.protocols.chrome_port.get_sender(client)], 0));

var remove_item = (function (coll,item){
return cljs.core.remove.cljs$core$IFn$_invoke$arity$2((function (p1__17166_SHARP_){
return (item === p1__17166_SHARP_);
}),coll);
});
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(google_webmaster_tools_bulk_url_removal.background.core.clients,remove_item,client);
});
google_webmaster_tools_bulk_url_removal.background.core.popup_predicate = (function google_webmaster_tools_bulk_url_removal$background$core$popup_predicate(client){
return cljs.core.re_find(/popup.html/,cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.js__GT_clj.cljs$core$IFn$_invoke$arity$1(chromex.protocols.chrome_port.get_sender(client)),"url"));
});
google_webmaster_tools_bulk_url_removal.background.core.get_popup_client = (function google_webmaster_tools_bulk_url_removal$background$core$get_popup_client(){
return cljs.core.first(cljs.core.filter.cljs$core$IFn$_invoke$arity$2(google_webmaster_tools_bulk_url_removal.background.core.popup_predicate,cljs.core.deref(google_webmaster_tools_bulk_url_removal.background.core.clients)));
});
google_webmaster_tools_bulk_url_removal.background.core.get_content_client = (function google_webmaster_tools_bulk_url_removal$background$core$get_content_client(){
return cljs.core.first(cljs.core.filter.cljs$core$IFn$_invoke$arity$2(cljs.core.complement(google_webmaster_tools_bulk_url_removal.background.core.popup_predicate),cljs.core.deref(google_webmaster_tools_bulk_url_removal.background.core.clients)));
});
google_webmaster_tools_bulk_url_removal.background.core.fetch_next_victim = (function google_webmaster_tools_bulk_url_removal$background$core$fetch_next_victim(client){
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__){
return (function (state_17214){
var state_val_17215 = (state_17214[(1)]);
if((state_val_17215 === (7))){
var inst_17173 = (state_17214[(7)]);
var state_17214__$1 = state_17214;
var statearr_17216_17234 = state_17214__$1;
(statearr_17216_17234[(2)] = inst_17173);

(statearr_17216_17234[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17215 === (1))){
var inst_17170 = google_webmaster_tools_bulk_url_removal.background.storage.next_victim();
var state_17214__$1 = state_17214;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_17214__$1,(2),inst_17170);
} else {
if((state_val_17215 === (4))){
var inst_17173 = (state_17214[(7)]);
var state_17214__$1 = state_17214;
if(cljs.core.truth_(inst_17173)){
var statearr_17217_17235 = state_17214__$1;
(statearr_17217_17235[(1)] = (6));

} else {
var statearr_17218_17236 = state_17214__$1;
(statearr_17218_17236[(1)] = (7));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17215 === (6))){
var inst_17174 = (state_17214[(8)]);
var state_17214__$1 = state_17214;
var statearr_17219_17237 = state_17214__$1;
(statearr_17219_17237[(2)] = inst_17174);

(statearr_17219_17237[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17215 === (3))){
var inst_17182 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["DONE!!!"], 0));
var inst_17183 = cljs.core.reset_BANG_(google_webmaster_tools_bulk_url_removal.background.core.my_status,cljs.core.cst$kw$done);
var inst_17184 = google_webmaster_tools_bulk_url_removal.background.core.get_popup_client();
var inst_17185 = [cljs.core.cst$kw$type];
var inst_17186 = [cljs.core.cst$kw$done];
var inst_17187 = cljs.core.PersistentHashMap.fromArrays(inst_17185,inst_17186);
var inst_17188 = google_webmaster_tools_bulk_url_removal.content_script.common.marshall(inst_17187);
var inst_17189 = chromex.protocols.chrome_port.post_message_BANG_(inst_17184,inst_17188);
var inst_17190 = [cljs.core.cst$kw$type];
var inst_17191 = [cljs.core.cst$kw$done];
var inst_17192 = cljs.core.PersistentHashMap.fromArrays(inst_17190,inst_17191);
var inst_17193 = google_webmaster_tools_bulk_url_removal.content_script.common.marshall(inst_17192);
var inst_17194 = chromex.protocols.chrome_port.post_message_BANG_(client,inst_17193);
var state_17214__$1 = (function (){var statearr_17220 = state_17214;
(statearr_17220[(9)] = inst_17183);

(statearr_17220[(10)] = inst_17182);

(statearr_17220[(11)] = inst_17189);

return statearr_17220;
})();
var statearr_17221_17238 = state_17214__$1;
(statearr_17221_17238[(2)] = inst_17194);

(statearr_17221_17238[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17215 === (2))){
var inst_17173 = (state_17214[(7)]);
var inst_17174 = (state_17214[(8)]);
var inst_17172 = (state_17214[(2)]);
var inst_17173__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_17172,(0),null);
var inst_17174__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_17172,(1),null);
var inst_17175 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["BACKGROUND: victim-url: ",inst_17173__$1], 0));
var inst_17176 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["BACKGROUND: victim-entry: ",inst_17174__$1], 0));
var inst_17177 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_17173__$1,"poison-pill");
var inst_17178 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_17174__$1,"removal-method");
var inst_17179 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_17178,google_webmaster_tools_bulk_url_removal.background.storage._STAR_DONE_FLAG_STAR_);
var inst_17180 = ((inst_17177) && (inst_17179));
var state_17214__$1 = (function (){var statearr_17222 = state_17214;
(statearr_17222[(12)] = inst_17175);

(statearr_17222[(13)] = inst_17176);

(statearr_17222[(7)] = inst_17173__$1);

(statearr_17222[(8)] = inst_17174__$1);

return statearr_17222;
})();
if(cljs.core.truth_(inst_17180)){
var statearr_17223_17239 = state_17214__$1;
(statearr_17223_17239[(1)] = (3));

} else {
var statearr_17224_17240 = state_17214__$1;
(statearr_17224_17240[(1)] = (4));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17215 === (11))){
var inst_17210 = (state_17214[(2)]);
var state_17214__$1 = state_17214;
var statearr_17225_17241 = state_17214__$1;
(statearr_17225_17241[(2)] = inst_17210);

(statearr_17225_17241[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17215 === (9))){
var inst_17173 = (state_17214[(7)]);
var inst_17174 = (state_17214[(8)]);
var inst_17201 = [cljs.core.cst$kw$type,cljs.core.cst$kw$victim,cljs.core.cst$kw$removal_DASH_method,cljs.core.cst$kw$url_DASH_type];
var inst_17202 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_17174,"removal-method");
var inst_17203 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_17174,"url-type");
var inst_17204 = [cljs.core.cst$kw$remove_DASH_url,inst_17173,inst_17202,inst_17203];
var inst_17205 = cljs.core.PersistentHashMap.fromArrays(inst_17201,inst_17204);
var inst_17206 = google_webmaster_tools_bulk_url_removal.content_script.common.marshall(inst_17205);
var inst_17207 = chromex.protocols.chrome_port.post_message_BANG_(client,inst_17206);
var state_17214__$1 = state_17214;
var statearr_17226_17242 = state_17214__$1;
(statearr_17226_17242[(2)] = inst_17207);

(statearr_17226_17242[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17215 === (5))){
var inst_17212 = (state_17214[(2)]);
var state_17214__$1 = state_17214;
return cljs.core.async.impl.ioc_helpers.return_chan(state_17214__$1,inst_17212);
} else {
if((state_val_17215 === (10))){
var state_17214__$1 = state_17214;
var statearr_17227_17243 = state_17214__$1;
(statearr_17227_17243[(2)] = null);

(statearr_17227_17243[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17215 === (8))){
var inst_17199 = (state_17214[(2)]);
var state_17214__$1 = state_17214;
if(cljs.core.truth_(inst_17199)){
var statearr_17228_17244 = state_17214__$1;
(statearr_17228_17244[(1)] = (9));

} else {
var statearr_17229_17245 = state_17214__$1;
(statearr_17229_17245[(1)] = (10));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto__))
;
return ((function (switch__7945__auto__,c__8052__auto__){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$core$fetch_next_victim_$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$core$fetch_next_victim_$_state_machine__7946__auto____0 = (function (){
var statearr_17230 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_17230[(0)] = google_webmaster_tools_bulk_url_removal$background$core$fetch_next_victim_$_state_machine__7946__auto__);

(statearr_17230[(1)] = (1));

return statearr_17230;
});
var google_webmaster_tools_bulk_url_removal$background$core$fetch_next_victim_$_state_machine__7946__auto____1 = (function (state_17214){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_17214);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e17231){if((e17231 instanceof Object)){
var ex__7949__auto__ = e17231;
var statearr_17232_17246 = state_17214;
(statearr_17232_17246[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_17214);

return cljs.core.cst$kw$recur;
} else {
throw e17231;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__17247 = state_17214;
state_17214 = G__17247;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$core$fetch_next_victim_$_state_machine__7946__auto__ = function(state_17214){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$core$fetch_next_victim_$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$core$fetch_next_victim_$_state_machine__7946__auto____1.call(this,state_17214);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$core$fetch_next_victim_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$core$fetch_next_victim_$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$core$fetch_next_victim_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$core$fetch_next_victim_$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$core$fetch_next_victim_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_17233 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_17233[(6)] = c__8052__auto__);

return statearr_17233;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__))
);

return c__8052__auto__;
});
google_webmaster_tools_bulk_url_removal.background.core.run_client_message_loop_BANG_ = (function google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG_(client){
console.log("BACKGROUND: starting event loop for client:",chromex.protocols.chrome_port.get_sender(client));


var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__){
return (function (state_17456){
var state_val_17457 = (state_17456[(1)]);
if((state_val_17457 === (7))){
var inst_17449 = (state_17456[(2)]);
var inst_17450 = chromex.protocols.chrome_port.get_sender(client);
var inst_17451 = console.log("BACKGROUND: leaving event loop for client:",inst_17450);
var inst_17452 = google_webmaster_tools_bulk_url_removal.background.core.remove_client_BANG_(client);
var state_17456__$1 = (function (){var statearr_17458 = state_17456;
(statearr_17458[(7)] = inst_17451);

(statearr_17458[(8)] = inst_17449);

return statearr_17458;
})();
var statearr_17459_17558 = state_17456__$1;
(statearr_17459_17558[(2)] = inst_17452);

(statearr_17459_17558[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (20))){
var inst_17291 = (state_17456[(2)]);
var inst_17292 = google_webmaster_tools_bulk_url_removal.background.core.get_content_client();
var inst_17293 = [cljs.core.cst$kw$type];
var inst_17294 = [cljs.core.cst$kw$done_DASH_init_DASH_victims];
var inst_17295 = cljs.core.PersistentHashMap.fromArrays(inst_17293,inst_17294);
var inst_17296 = google_webmaster_tools_bulk_url_removal.content_script.common.marshall(inst_17295);
var inst_17297 = chromex.protocols.chrome_port.post_message_BANG_(inst_17292,inst_17296);
var state_17456__$1 = (function (){var statearr_17460 = state_17456;
(statearr_17460[(9)] = inst_17291);

return statearr_17460;
})();
var statearr_17461_17559 = state_17456__$1;
(statearr_17461_17559[(2)] = inst_17297);

(statearr_17461_17559[(1)] = (19));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (27))){
var inst_17442 = (state_17456[(2)]);
var state_17456__$1 = state_17456;
var statearr_17462_17560 = state_17456__$1;
(statearr_17462_17560[(2)] = inst_17442);

(statearr_17462_17560[(1)] = (23));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (1))){
var state_17456__$1 = state_17456;
var statearr_17463_17561 = state_17456__$1;
(statearr_17463_17561[(2)] = null);

(statearr_17463_17561[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (24))){
var inst_17303 = (state_17456[(2)]);
var state_17456__$1 = state_17456;
var statearr_17464_17562 = state_17456__$1;
(statearr_17464_17562[(2)] = inst_17303);

(statearr_17464_17562[(1)] = (23));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (4))){
var inst_17250 = (state_17456[(10)]);
var inst_17250__$1 = (state_17456[(2)]);
var inst_17251 = (inst_17250__$1 == null);
var state_17456__$1 = (function (){var statearr_17465 = state_17456;
(statearr_17465[(10)] = inst_17250__$1);

return statearr_17465;
})();
if(cljs.core.truth_(inst_17251)){
var statearr_17466_17563 = state_17456__$1;
(statearr_17466_17563[(1)] = (5));

} else {
var statearr_17467_17564 = state_17456__$1;
(statearr_17467_17564[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (15))){
var inst_17257 = (state_17456[(11)]);
var state_17456__$1 = state_17456;
var statearr_17468_17565 = state_17456__$1;
(statearr_17468_17565[(2)] = inst_17257);

(statearr_17468_17565[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (21))){
var inst_17301 = google_webmaster_tools_bulk_url_removal.background.core.fetch_next_victim(client);
var state_17456__$1 = state_17456;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_17456__$1,(24),inst_17301);
} else {
if((state_val_17457 === (31))){
var inst_17279 = (state_17456[(12)]);
var inst_17278 = (state_17456[(13)]);
var inst_17250 = (state_17456[(10)]);
var inst_17433 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var inst_17434 = (function (){var temp__5739__auto__ = inst_17250;
var message = inst_17250;
var map__17256 = inst_17278;
var whole_edn = inst_17278;
var type = inst_17279;
var c__8052__auto____$1 = inst_17433;
return ((function (temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17433,state_val_17457,c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17433,state_val_17457,c__8052__auto__){
return (function (state_17431){
var state_val_17432 = (state_17431[(1)]);
if((state_val_17432 === (1))){
var inst_17421 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["inside :fetch-initial-errors: "], 0));
var inst_17422 = google_webmaster_tools_bulk_url_removal.background.storage.get_bad_victims();
var state_17431__$1 = (function (){var statearr_17469 = state_17431;
(statearr_17469[(7)] = inst_17421);

return statearr_17469;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_17431__$1,(2),inst_17422);
} else {
if((state_val_17432 === (2))){
var inst_17424 = (state_17431[(2)]);
var inst_17425 = [cljs.core.cst$kw$type,cljs.core.cst$kw$bad_DASH_victims];
var inst_17426 = [cljs.core.cst$kw$init_DASH_errors,inst_17424];
var inst_17427 = cljs.core.PersistentHashMap.fromArrays(inst_17425,inst_17426);
var inst_17428 = google_webmaster_tools_bulk_url_removal.content_script.common.marshall(inst_17427);
var inst_17429 = chromex.protocols.chrome_port.post_message_BANG_(client,inst_17428);
var state_17431__$1 = state_17431;
return cljs.core.async.impl.ioc_helpers.return_chan(state_17431__$1,inst_17429);
} else {
return null;
}
}
});})(temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17433,state_val_17457,c__8052__auto__))
;
return ((function (switch__7945__auto__,temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17433,state_val_17457,c__8052__auto__){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____0 = (function (){
var statearr_17470 = [null,null,null,null,null,null,null,null];
(statearr_17470[(0)] = google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__);

(statearr_17470[(1)] = (1));

return statearr_17470;
});
var google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____1 = (function (state_17431){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_17431);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e17471){if((e17471 instanceof Object)){
var ex__7949__auto__ = e17471;
var statearr_17472_17566 = state_17431;
(statearr_17472_17566[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_17431);

return cljs.core.cst$kw$recur;
} else {
throw e17471;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__17567 = state_17431;
state_17431 = G__17567;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__ = function(state_17431){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____1.call(this,state_17431);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17433,state_val_17457,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_17473 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_17473[(6)] = c__8052__auto____$1);

return statearr_17473;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});
;})(temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17433,state_val_17457,c__8052__auto__))
})();
var inst_17435 = cljs.core.async.impl.dispatch.run(inst_17434);
var state_17456__$1 = (function (){var statearr_17474 = state_17456;
(statearr_17474[(14)] = inst_17435);

return statearr_17474;
})();
var statearr_17475_17568 = state_17456__$1;
(statearr_17475_17568[(2)] = inst_17433);

(statearr_17475_17568[(1)] = (33));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (32))){
var state_17456__$1 = state_17456;
var statearr_17476_17569 = state_17456__$1;
(statearr_17476_17569[(2)] = null);

(statearr_17476_17569[(1)] = (33));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (33))){
var inst_17438 = (state_17456[(2)]);
var state_17456__$1 = state_17456;
var statearr_17477_17570 = state_17456__$1;
(statearr_17477_17570[(2)] = inst_17438);

(statearr_17477_17570[(1)] = (30));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (13))){
var inst_17270 = (state_17456[(2)]);
var state_17456__$1 = state_17456;
var statearr_17478_17571 = state_17456__$1;
(statearr_17478_17571[(2)] = inst_17270);

(statearr_17478_17571[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (22))){
var inst_17279 = (state_17456[(12)]);
var inst_17305 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_17279,cljs.core.cst$kw$success);
var state_17456__$1 = state_17456;
if(inst_17305){
var statearr_17479_17572 = state_17456__$1;
(statearr_17479_17572[(1)] = (25));

} else {
var statearr_17480_17573 = state_17456__$1;
(statearr_17480_17573[(1)] = (26));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (29))){
var inst_17279 = (state_17456[(12)]);
var inst_17419 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_17279,cljs.core.cst$kw$fetch_DASH_initial_DASH_errors);
var state_17456__$1 = state_17456;
if(inst_17419){
var statearr_17481_17574 = state_17456__$1;
(statearr_17481_17574[(1)] = (31));

} else {
var statearr_17482_17575 = state_17456__$1;
(statearr_17482_17575[(1)] = (32));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (6))){
var inst_17250 = (state_17456[(10)]);
var inst_17257 = (state_17456[(11)]);
var inst_17254 = chromex.protocols.chrome_port.get_sender(client);
var inst_17255 = console.log("BACKGROUND: got client message:",inst_17250,"from",inst_17254);
var inst_17257__$1 = google_webmaster_tools_bulk_url_removal.content_script.common.unmarshall(inst_17250);
var inst_17259 = (inst_17257__$1 == null);
var inst_17260 = cljs.core.not(inst_17259);
var state_17456__$1 = (function (){var statearr_17483 = state_17456;
(statearr_17483[(15)] = inst_17255);

(statearr_17483[(11)] = inst_17257__$1);

return statearr_17483;
})();
if(inst_17260){
var statearr_17484_17576 = state_17456__$1;
(statearr_17484_17576[(1)] = (8));

} else {
var statearr_17485_17577 = state_17456__$1;
(statearr_17485_17577[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (28))){
var inst_17279 = (state_17456[(12)]);
var inst_17278 = (state_17456[(13)]);
var inst_17250 = (state_17456[(10)]);
var inst_17348 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["inside :skip-error:",inst_17278], 0));
var inst_17415 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var inst_17416 = (function (){var temp__5739__auto__ = inst_17250;
var message = inst_17250;
var map__17256 = inst_17278;
var whole_edn = inst_17278;
var type = inst_17279;
var c__8052__auto____$1 = inst_17415;
return ((function (temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17348,inst_17415,state_val_17457,c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17348,inst_17415,state_val_17457,c__8052__auto__){
return (function (state_17413){
var state_val_17414 = (state_17413[(1)]);
if((state_val_17414 === (7))){
var inst_17362 = (state_17413[(2)]);
var state_17413__$1 = state_17413;
var statearr_17486_17578 = state_17413__$1;
(statearr_17486_17578[(2)] = inst_17362);

(statearr_17486_17578[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17414 === (1))){
var inst_17351 = (whole_edn == null);
var inst_17352 = cljs.core.not(inst_17351);
var state_17413__$1 = state_17413;
if(inst_17352){
var statearr_17487_17579 = state_17413__$1;
(statearr_17487_17579[(1)] = (2));

} else {
var statearr_17488_17580 = state_17413__$1;
(statearr_17488_17580[(1)] = (3));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17414 === (4))){
var inst_17365 = (state_17413[(2)]);
var state_17413__$1 = state_17413;
if(cljs.core.truth_(inst_17365)){
var statearr_17489_17581 = state_17413__$1;
(statearr_17489_17581[(1)] = (8));

} else {
var statearr_17490_17582 = state_17413__$1;
(statearr_17490_17582[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17414 === (15))){
var inst_17408 = (state_17413[(2)]);
var inst_17409 = google_webmaster_tools_bulk_url_removal.background.core.fetch_next_victim(client);
var state_17413__$1 = (function (){var statearr_17491 = state_17413;
(statearr_17491[(7)] = inst_17408);

return statearr_17491;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_17413__$1,(16),inst_17409);
} else {
if((state_val_17414 === (13))){
var inst_17379 = (state_17413[(8)]);
var inst_17376 = (state_17413[(9)]);
var inst_17396 = [cljs.core.cst$kw$type,cljs.core.cst$kw$error];
var inst_17397 = [cljs.core.cst$kw$new_DASH_error,inst_17379];
var inst_17398 = cljs.core.PersistentHashMap.fromArrays(inst_17396,inst_17397);
var inst_17399 = google_webmaster_tools_bulk_url_removal.content_script.common.marshall(inst_17398);
var inst_17400 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["sending popup-client ",inst_17399], 0));
var inst_17401 = [cljs.core.cst$kw$type,cljs.core.cst$kw$error];
var inst_17402 = [cljs.core.cst$kw$new_DASH_error,inst_17379];
var inst_17403 = cljs.core.PersistentHashMap.fromArrays(inst_17401,inst_17402);
var inst_17404 = google_webmaster_tools_bulk_url_removal.content_script.common.marshall(inst_17403);
var inst_17405 = chromex.protocols.chrome_port.post_message_BANG_(inst_17376,inst_17404);
var state_17413__$1 = (function (){var statearr_17492 = state_17413;
(statearr_17492[(10)] = inst_17400);

return statearr_17492;
})();
var statearr_17493_17583 = state_17413__$1;
(statearr_17493_17583[(2)] = inst_17405);

(statearr_17493_17583[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17414 === (6))){
var state_17413__$1 = state_17413;
var statearr_17494_17584 = state_17413__$1;
(statearr_17494_17584[(2)] = false);

(statearr_17494_17584[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17414 === (3))){
var state_17413__$1 = state_17413;
var statearr_17495_17585 = state_17413__$1;
(statearr_17495_17585[(2)] = false);

(statearr_17495_17585[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17414 === (12))){
var inst_17379 = (state_17413[(8)]);
var inst_17376 = (state_17413[(9)]);
var inst_17382 = (state_17413[(2)]);
var inst_17383 = cljs.core.count(inst_17382);
var inst_17384 = cljs.core.str.cljs$core$IFn$_invoke$arity$1(inst_17383);
var inst_17385 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["updated-error-entry: ",inst_17379], 0));
var inst_17386 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["error-cnt: ",inst_17384], 0));
var inst_17387 = chromex.config.get_active_config();
var inst_17388 = ["text"];
var inst_17389 = [inst_17384];
var inst_17390 = cljs.core.PersistentHashMap.fromArrays(inst_17388,inst_17389);
var inst_17391 = cljs.core.clj__GT_js(inst_17390);
var inst_17392 = chromex.ext.browser_action.set_badge_text_STAR_(inst_17387,inst_17391);
var inst_17393 = chromex.config.get_active_config();
var inst_17394 = chromex.ext.browser_action.set_badge_background_color_STAR_(inst_17393,({"color": "#F00"}));
var state_17413__$1 = (function (){var statearr_17496 = state_17413;
(statearr_17496[(11)] = inst_17385);

(statearr_17496[(12)] = inst_17392);

(statearr_17496[(13)] = inst_17394);

(statearr_17496[(14)] = inst_17386);

return statearr_17496;
})();
if(cljs.core.truth_(inst_17376)){
var statearr_17497_17586 = state_17413__$1;
(statearr_17497_17586[(1)] = (13));

} else {
var statearr_17498_17587 = state_17413__$1;
(statearr_17498_17587[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17414 === (2))){
var inst_17354 = whole_edn.cljs$lang$protocol_mask$partition0$;
var inst_17355 = (inst_17354 & (64));
var inst_17356 = whole_edn.cljs$core$ISeq$;
var inst_17357 = (cljs.core.PROTOCOL_SENTINEL === inst_17356);
var inst_17358 = ((inst_17355) || (inst_17357));
var state_17413__$1 = state_17413;
if(cljs.core.truth_(inst_17358)){
var statearr_17499_17588 = state_17413__$1;
(statearr_17499_17588[(1)] = (5));

} else {
var statearr_17500_17589 = state_17413__$1;
(statearr_17500_17589[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17414 === (11))){
var inst_17379 = (state_17413[(2)]);
var inst_17380 = google_webmaster_tools_bulk_url_removal.background.storage.get_bad_victims();
var state_17413__$1 = (function (){var statearr_17501 = state_17413;
(statearr_17501[(8)] = inst_17379);

return statearr_17501;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_17413__$1,(12),inst_17380);
} else {
if((state_val_17414 === (9))){
var state_17413__$1 = state_17413;
var statearr_17502_17590 = state_17413__$1;
(statearr_17502_17590[(2)] = whole_edn);

(statearr_17502_17590[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17414 === (5))){
var state_17413__$1 = state_17413;
var statearr_17503_17591 = state_17413__$1;
(statearr_17503_17591[(2)] = true);

(statearr_17503_17591[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17414 === (14))){
var state_17413__$1 = state_17413;
var statearr_17504_17592 = state_17413__$1;
(statearr_17504_17592[(2)] = null);

(statearr_17504_17592[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17414 === (16))){
var inst_17411 = (state_17413[(2)]);
var state_17413__$1 = state_17413;
return cljs.core.async.impl.ioc_helpers.return_chan(state_17413__$1,inst_17411);
} else {
if((state_val_17414 === (10))){
var inst_17370 = (state_17413[(2)]);
var inst_17371 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_17370,cljs.core.cst$kw$url);
var inst_17372 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_17370,cljs.core.cst$kw$reason);
var inst_17373 = [cljs.core.cst$kw$url,cljs.core.cst$kw$reason];
var inst_17374 = [inst_17371,inst_17372];
var inst_17375 = cljs.core.PersistentHashMap.fromArrays(inst_17373,inst_17374);
var inst_17376 = google_webmaster_tools_bulk_url_removal.background.core.get_popup_client();
var inst_17377 = google_webmaster_tools_bulk_url_removal.background.storage.update_storage.cljs$core$IFn$_invoke$arity$variadic(inst_17371,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["status","error","error-reason",inst_17372], 0));
var state_17413__$1 = (function (){var statearr_17505 = state_17413;
(statearr_17505[(9)] = inst_17376);

(statearr_17505[(15)] = inst_17375);

return statearr_17505;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_17413__$1,(11),inst_17377);
} else {
if((state_val_17414 === (8))){
var inst_17367 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,whole_edn);
var state_17413__$1 = state_17413;
var statearr_17506_17593 = state_17413__$1;
(statearr_17506_17593[(2)] = inst_17367);

(statearr_17506_17593[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17348,inst_17415,state_val_17457,c__8052__auto__))
;
return ((function (switch__7945__auto__,temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17348,inst_17415,state_val_17457,c__8052__auto__){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____0 = (function (){
var statearr_17507 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_17507[(0)] = google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__);

(statearr_17507[(1)] = (1));

return statearr_17507;
});
var google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____1 = (function (state_17413){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_17413);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e17508){if((e17508 instanceof Object)){
var ex__7949__auto__ = e17508;
var statearr_17509_17594 = state_17413;
(statearr_17509_17594[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_17413);

return cljs.core.cst$kw$recur;
} else {
throw e17508;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__17595 = state_17413;
state_17413 = G__17595;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__ = function(state_17413){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____1.call(this,state_17413);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17348,inst_17415,state_val_17457,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_17510 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_17510[(6)] = c__8052__auto____$1);

return statearr_17510;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});
;})(temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17348,inst_17415,state_val_17457,c__8052__auto__))
})();
var inst_17417 = cljs.core.async.impl.dispatch.run(inst_17416);
var state_17456__$1 = (function (){var statearr_17511 = state_17456;
(statearr_17511[(16)] = inst_17348);

(statearr_17511[(17)] = inst_17417);

return statearr_17511;
})();
var statearr_17512_17596 = state_17456__$1;
(statearr_17512_17596[(2)] = inst_17415);

(statearr_17512_17596[(1)] = (30));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (25))){
var inst_17279 = (state_17456[(12)]);
var inst_17278 = (state_17456[(13)]);
var inst_17250 = (state_17456[(10)]);
var inst_17342 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var inst_17343 = (function (){var temp__5739__auto__ = inst_17250;
var message = inst_17250;
var map__17256 = inst_17278;
var whole_edn = inst_17278;
var type = inst_17279;
var c__8052__auto____$1 = inst_17342;
return ((function (temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17342,state_val_17457,c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17342,state_val_17457,c__8052__auto__){
return (function (state_17340){
var state_val_17341 = (state_17340[(1)]);
if((state_val_17341 === (7))){
var inst_17321 = (state_17340[(2)]);
var state_17340__$1 = state_17340;
var statearr_17513_17597 = state_17340__$1;
(statearr_17513_17597[(2)] = inst_17321);

(statearr_17513_17597[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17341 === (1))){
var inst_17307 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["handle success!!! : ",whole_edn], 0));
var inst_17310 = (whole_edn == null);
var inst_17311 = cljs.core.not(inst_17310);
var state_17340__$1 = (function (){var statearr_17514 = state_17340;
(statearr_17514[(7)] = inst_17307);

return statearr_17514;
})();
if(inst_17311){
var statearr_17515_17598 = state_17340__$1;
(statearr_17515_17598[(1)] = (2));

} else {
var statearr_17516_17599 = state_17340__$1;
(statearr_17516_17599[(1)] = (3));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17341 === (4))){
var inst_17324 = (state_17340[(2)]);
var state_17340__$1 = state_17340;
if(cljs.core.truth_(inst_17324)){
var statearr_17517_17600 = state_17340__$1;
(statearr_17517_17600[(1)] = (8));

} else {
var statearr_17518_17601 = state_17340__$1;
(statearr_17518_17601[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17341 === (6))){
var state_17340__$1 = state_17340;
var statearr_17519_17602 = state_17340__$1;
(statearr_17519_17602[(2)] = false);

(statearr_17519_17602[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17341 === (3))){
var state_17340__$1 = state_17340;
var statearr_17520_17603 = state_17340__$1;
(statearr_17520_17603[(2)] = false);

(statearr_17520_17603[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17341 === (12))){
var inst_17338 = (state_17340[(2)]);
var state_17340__$1 = state_17340;
return cljs.core.async.impl.ioc_helpers.return_chan(state_17340__$1,inst_17338);
} else {
if((state_val_17341 === (2))){
var inst_17313 = whole_edn.cljs$lang$protocol_mask$partition0$;
var inst_17314 = (inst_17313 & (64));
var inst_17315 = whole_edn.cljs$core$ISeq$;
var inst_17316 = (cljs.core.PROTOCOL_SENTINEL === inst_17315);
var inst_17317 = ((inst_17314) || (inst_17316));
var state_17340__$1 = state_17340;
if(cljs.core.truth_(inst_17317)){
var statearr_17521_17604 = state_17340__$1;
(statearr_17521_17604[(1)] = (5));

} else {
var statearr_17522_17605 = state_17340__$1;
(statearr_17522_17605[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17341 === (11))){
var inst_17335 = (state_17340[(2)]);
var inst_17336 = google_webmaster_tools_bulk_url_removal.background.core.fetch_next_victim(client);
var state_17340__$1 = (function (){var statearr_17523 = state_17340;
(statearr_17523[(8)] = inst_17335);

return statearr_17523;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_17340__$1,(12),inst_17336);
} else {
if((state_val_17341 === (9))){
var state_17340__$1 = state_17340;
var statearr_17524_17606 = state_17340__$1;
(statearr_17524_17606[(2)] = whole_edn);

(statearr_17524_17606[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17341 === (5))){
var state_17340__$1 = state_17340;
var statearr_17525_17607 = state_17340__$1;
(statearr_17525_17607[(2)] = true);

(statearr_17525_17607[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17341 === (10))){
var inst_17329 = (state_17340[(2)]);
var inst_17330 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_17329,cljs.core.cst$kw$url);
var inst_17331 = cljs_time.core.now();
var inst_17332 = cljs_time.coerce.to_long(inst_17331);
var inst_17333 = google_webmaster_tools_bulk_url_removal.background.storage.update_storage.cljs$core$IFn$_invoke$arity$variadic(inst_17330,cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["status","removed","remove-ts",inst_17332], 0));
var state_17340__$1 = state_17340;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_17340__$1,(11),inst_17333);
} else {
if((state_val_17341 === (8))){
var inst_17326 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,whole_edn);
var state_17340__$1 = state_17340;
var statearr_17526_17608 = state_17340__$1;
(statearr_17526_17608[(2)] = inst_17326);

(statearr_17526_17608[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
});})(temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17342,state_val_17457,c__8052__auto__))
;
return ((function (switch__7945__auto__,temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17342,state_val_17457,c__8052__auto__){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____0 = (function (){
var statearr_17527 = [null,null,null,null,null,null,null,null,null];
(statearr_17527[(0)] = google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__);

(statearr_17527[(1)] = (1));

return statearr_17527;
});
var google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____1 = (function (state_17340){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_17340);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e17528){if((e17528 instanceof Object)){
var ex__7949__auto__ = e17528;
var statearr_17529_17609 = state_17340;
(statearr_17529_17609[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_17340);

return cljs.core.cst$kw$recur;
} else {
throw e17528;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__17610 = state_17340;
state_17340 = G__17610;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__ = function(state_17340){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____1.call(this,state_17340);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17342,state_val_17457,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_17530 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_17530[(6)] = c__8052__auto____$1);

return statearr_17530;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});
;})(temp__5739__auto__,message,map__17256,whole_edn,type,c__8052__auto____$1,inst_17279,inst_17278,inst_17250,inst_17342,state_val_17457,c__8052__auto__))
})();
var inst_17344 = cljs.core.async.impl.dispatch.run(inst_17343);
var state_17456__$1 = (function (){var statearr_17531 = state_17456;
(statearr_17531[(18)] = inst_17344);

return statearr_17531;
})();
var statearr_17532_17611 = state_17456__$1;
(statearr_17532_17611[(2)] = inst_17342);

(statearr_17532_17611[(1)] = (27));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (17))){
var inst_17278 = (state_17456[(13)]);
var inst_17282 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["inside :init-victims --  whole-edn: ",inst_17278], 0));
var inst_17283 = google_webmaster_tools_bulk_url_removal.background.core.get_content_client();
var inst_17284 = cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["content-client: ",inst_17283], 0));
var inst_17285 = google_webmaster_tools_bulk_url_removal.background.storage.clear_victims_BANG_();
var inst_17286 = chromex.config.get_active_config();
var inst_17287 = chromex.ext.browser_action.set_badge_text_STAR_(inst_17286,({"text": ""}));
var inst_17288 = cljs.core.reset_BANG_(google_webmaster_tools_bulk_url_removal.background.core.my_status,cljs.core.cst$kw$running);
var inst_17289 = google_webmaster_tools_bulk_url_removal.background.storage.store_victims_BANG_(inst_17278);
var state_17456__$1 = (function (){var statearr_17533 = state_17456;
(statearr_17533[(19)] = inst_17285);

(statearr_17533[(20)] = inst_17282);

(statearr_17533[(21)] = inst_17284);

(statearr_17533[(22)] = inst_17288);

(statearr_17533[(23)] = inst_17287);

return statearr_17533;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_17456__$1,(20),inst_17289);
} else {
if((state_val_17457 === (3))){
var inst_17454 = (state_17456[(2)]);
var state_17456__$1 = state_17456;
return cljs.core.async.impl.ioc_helpers.return_chan(state_17456__$1,inst_17454);
} else {
if((state_val_17457 === (12))){
var state_17456__$1 = state_17456;
var statearr_17534_17612 = state_17456__$1;
(statearr_17534_17612[(2)] = false);

(statearr_17534_17612[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (2))){
var state_17456__$1 = state_17456;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_17456__$1,(4),client);
} else {
if((state_val_17457 === (23))){
var inst_17444 = (state_17456[(2)]);
var state_17456__$1 = state_17456;
var statearr_17535_17613 = state_17456__$1;
(statearr_17535_17613[(2)] = inst_17444);

(statearr_17535_17613[(1)] = (19));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (19))){
var inst_17446 = (state_17456[(2)]);
var state_17456__$1 = (function (){var statearr_17536 = state_17456;
(statearr_17536[(24)] = inst_17446);

return statearr_17536;
})();
var statearr_17537_17614 = state_17456__$1;
(statearr_17537_17614[(2)] = null);

(statearr_17537_17614[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (11))){
var state_17456__$1 = state_17456;
var statearr_17538_17615 = state_17456__$1;
(statearr_17538_17615[(2)] = true);

(statearr_17538_17615[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (9))){
var state_17456__$1 = state_17456;
var statearr_17539_17616 = state_17456__$1;
(statearr_17539_17616[(2)] = false);

(statearr_17539_17616[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (5))){
var state_17456__$1 = state_17456;
var statearr_17540_17617 = state_17456__$1;
(statearr_17540_17617[(2)] = null);

(statearr_17540_17617[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (14))){
var inst_17257 = (state_17456[(11)]);
var inst_17275 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_17257);
var state_17456__$1 = state_17456;
var statearr_17541_17618 = state_17456__$1;
(statearr_17541_17618[(2)] = inst_17275);

(statearr_17541_17618[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (26))){
var inst_17279 = (state_17456[(12)]);
var inst_17346 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_17279,cljs.core.cst$kw$skip_DASH_error);
var state_17456__$1 = state_17456;
if(inst_17346){
var statearr_17542_17619 = state_17456__$1;
(statearr_17542_17619[(1)] = (28));

} else {
var statearr_17543_17620 = state_17456__$1;
(statearr_17543_17620[(1)] = (29));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (16))){
var inst_17279 = (state_17456[(12)]);
var inst_17278 = (state_17456[(13)]);
var inst_17278__$1 = (state_17456[(2)]);
var inst_17279__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_17278__$1,cljs.core.cst$kw$type);
var inst_17280 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_17279__$1,cljs.core.cst$kw$init_DASH_victims);
var state_17456__$1 = (function (){var statearr_17544 = state_17456;
(statearr_17544[(12)] = inst_17279__$1);

(statearr_17544[(13)] = inst_17278__$1);

return statearr_17544;
})();
if(inst_17280){
var statearr_17545_17621 = state_17456__$1;
(statearr_17545_17621[(1)] = (17));

} else {
var statearr_17546_17622 = state_17456__$1;
(statearr_17546_17622[(1)] = (18));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (30))){
var inst_17440 = (state_17456[(2)]);
var state_17456__$1 = state_17456;
var statearr_17547_17623 = state_17456__$1;
(statearr_17547_17623[(2)] = inst_17440);

(statearr_17547_17623[(1)] = (27));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (10))){
var inst_17273 = (state_17456[(2)]);
var state_17456__$1 = state_17456;
if(cljs.core.truth_(inst_17273)){
var statearr_17548_17624 = state_17456__$1;
(statearr_17548_17624[(1)] = (14));

} else {
var statearr_17549_17625 = state_17456__$1;
(statearr_17549_17625[(1)] = (15));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (18))){
var inst_17279 = (state_17456[(12)]);
var inst_17299 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_17279,cljs.core.cst$kw$next_DASH_victim);
var state_17456__$1 = state_17456;
if(inst_17299){
var statearr_17550_17626 = state_17456__$1;
(statearr_17550_17626[(1)] = (21));

} else {
var statearr_17551_17627 = state_17456__$1;
(statearr_17551_17627[(1)] = (22));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17457 === (8))){
var inst_17257 = (state_17456[(11)]);
var inst_17262 = inst_17257.cljs$lang$protocol_mask$partition0$;
var inst_17263 = (inst_17262 & (64));
var inst_17264 = inst_17257.cljs$core$ISeq$;
var inst_17265 = (cljs.core.PROTOCOL_SENTINEL === inst_17264);
var inst_17266 = ((inst_17263) || (inst_17265));
var state_17456__$1 = state_17456;
if(cljs.core.truth_(inst_17266)){
var statearr_17552_17628 = state_17456__$1;
(statearr_17552_17628[(1)] = (11));

} else {
var statearr_17553_17629 = state_17456__$1;
(statearr_17553_17629[(1)] = (12));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto__))
;
return ((function (switch__7945__auto__,c__8052__auto__){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____0 = (function (){
var statearr_17554 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_17554[(0)] = google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__);

(statearr_17554[(1)] = (1));

return statearr_17554;
});
var google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____1 = (function (state_17456){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_17456);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e17555){if((e17555 instanceof Object)){
var ex__7949__auto__ = e17555;
var statearr_17556_17630 = state_17456;
(statearr_17556_17630[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_17456);

return cljs.core.cst$kw$recur;
} else {
throw e17555;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__17631 = state_17456;
state_17456 = G__17631;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__ = function(state_17456){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____1.call(this,state_17456);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$core$run_client_message_loop_BANG__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_17557 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_17557[(6)] = c__8052__auto__);

return statearr_17557;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__))
);

return c__8052__auto__;
});
google_webmaster_tools_bulk_url_removal.background.core.handle_client_connection_BANG_ = (function google_webmaster_tools_bulk_url_removal$background$core$handle_client_connection_BANG_(client){
google_webmaster_tools_bulk_url_removal.background.core.add_client_BANG_(client);

cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([">> number of client: ",cljs.core.count(cljs.core.deref(google_webmaster_tools_bulk_url_removal.background.core.clients))], 0));

return google_webmaster_tools_bulk_url_removal.background.core.run_client_message_loop_BANG_(client);
});
google_webmaster_tools_bulk_url_removal.background.core.process_chrome_event = (function google_webmaster_tools_bulk_url_removal$background$core$process_chrome_event(event_num,event){
console.log(goog.string.format("BACKGROUND: got chrome event (%05d)",event_num),event);


var vec__17632 = event;
var event_id = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__17632,(0),null);
var event_args = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__17632,(1),null);
var G__17635 = event_id;
var G__17635__$1 = (((G__17635 instanceof cljs.core.Keyword))?G__17635.fqn:null);
switch (G__17635__$1) {
case "chromex.ext.runtime/on-connect":
return cljs.core.apply.cljs$core$IFn$_invoke$arity$2(google_webmaster_tools_bulk_url_removal.background.core.handle_client_connection_BANG_,event_args);

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__17635__$1)].join('')));

}
});
google_webmaster_tools_bulk_url_removal.background.core.run_chrome_event_loop_BANG_ = (function google_webmaster_tools_bulk_url_removal$background$core$run_chrome_event_loop_BANG_(chrome_event_channel){
console.log("BACKGROUND: starting main event loop...");


var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__){
return (function (state_17653){
var state_val_17654 = (state_17653[(1)]);
if((state_val_17654 === (1))){
var inst_17637 = (1);
var state_17653__$1 = (function (){var statearr_17655 = state_17653;
(statearr_17655[(7)] = inst_17637);

return statearr_17655;
})();
var statearr_17656_17669 = state_17653__$1;
(statearr_17656_17669[(2)] = null);

(statearr_17656_17669[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17654 === (2))){
var state_17653__$1 = state_17653;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_17653__$1,(4),chrome_event_channel);
} else {
if((state_val_17654 === (3))){
var inst_17651 = (state_17653[(2)]);
var state_17653__$1 = state_17653;
return cljs.core.async.impl.ioc_helpers.return_chan(state_17653__$1,inst_17651);
} else {
if((state_val_17654 === (4))){
var inst_17640 = (state_17653[(8)]);
var inst_17640__$1 = (state_17653[(2)]);
var inst_17641 = (inst_17640__$1 == null);
var state_17653__$1 = (function (){var statearr_17657 = state_17653;
(statearr_17657[(8)] = inst_17640__$1);

return statearr_17657;
})();
if(cljs.core.truth_(inst_17641)){
var statearr_17658_17670 = state_17653__$1;
(statearr_17658_17670[(1)] = (5));

} else {
var statearr_17659_17671 = state_17653__$1;
(statearr_17659_17671[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_17654 === (5))){
var state_17653__$1 = state_17653;
var statearr_17660_17672 = state_17653__$1;
(statearr_17660_17672[(2)] = null);

(statearr_17660_17672[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17654 === (6))){
var inst_17640 = (state_17653[(8)]);
var inst_17637 = (state_17653[(7)]);
var inst_17644 = google_webmaster_tools_bulk_url_removal.background.core.process_chrome_event(inst_17637,inst_17640);
var inst_17645 = (inst_17637 + (1));
var inst_17637__$1 = inst_17645;
var state_17653__$1 = (function (){var statearr_17661 = state_17653;
(statearr_17661[(7)] = inst_17637__$1);

(statearr_17661[(9)] = inst_17644);

return statearr_17661;
})();
var statearr_17662_17673 = state_17653__$1;
(statearr_17662_17673[(2)] = null);

(statearr_17662_17673[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_17654 === (7))){
var inst_17648 = (state_17653[(2)]);
var inst_17649 = console.log("BACKGROUND: leaving main event loop");
var state_17653__$1 = (function (){var statearr_17663 = state_17653;
(statearr_17663[(10)] = inst_17648);

(statearr_17663[(11)] = inst_17649);

return statearr_17663;
})();
var statearr_17664_17674 = state_17653__$1;
(statearr_17664_17674[(2)] = null);

(statearr_17664_17674[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(c__8052__auto__))
;
return ((function (switch__7945__auto__,c__8052__auto__){
return (function() {
var google_webmaster_tools_bulk_url_removal$background$core$run_chrome_event_loop_BANG__$_state_machine__7946__auto__ = null;
var google_webmaster_tools_bulk_url_removal$background$core$run_chrome_event_loop_BANG__$_state_machine__7946__auto____0 = (function (){
var statearr_17665 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_17665[(0)] = google_webmaster_tools_bulk_url_removal$background$core$run_chrome_event_loop_BANG__$_state_machine__7946__auto__);

(statearr_17665[(1)] = (1));

return statearr_17665;
});
var google_webmaster_tools_bulk_url_removal$background$core$run_chrome_event_loop_BANG__$_state_machine__7946__auto____1 = (function (state_17653){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_17653);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e17666){if((e17666 instanceof Object)){
var ex__7949__auto__ = e17666;
var statearr_17667_17675 = state_17653;
(statearr_17667_17675[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_17653);

return cljs.core.cst$kw$recur;
} else {
throw e17666;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__17676 = state_17653;
state_17653 = G__17676;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
google_webmaster_tools_bulk_url_removal$background$core$run_chrome_event_loop_BANG__$_state_machine__7946__auto__ = function(state_17653){
switch(arguments.length){
case 0:
return google_webmaster_tools_bulk_url_removal$background$core$run_chrome_event_loop_BANG__$_state_machine__7946__auto____0.call(this);
case 1:
return google_webmaster_tools_bulk_url_removal$background$core$run_chrome_event_loop_BANG__$_state_machine__7946__auto____1.call(this,state_17653);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
google_webmaster_tools_bulk_url_removal$background$core$run_chrome_event_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = google_webmaster_tools_bulk_url_removal$background$core$run_chrome_event_loop_BANG__$_state_machine__7946__auto____0;
google_webmaster_tools_bulk_url_removal$background$core$run_chrome_event_loop_BANG__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = google_webmaster_tools_bulk_url_removal$background$core$run_chrome_event_loop_BANG__$_state_machine__7946__auto____1;
return google_webmaster_tools_bulk_url_removal$background$core$run_chrome_event_loop_BANG__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_17668 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_17668[(6)] = c__8052__auto__);

return statearr_17668;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__))
);

return c__8052__auto__;
});
google_webmaster_tools_bulk_url_removal.background.core.boot_chrome_event_loop_BANG_ = (function google_webmaster_tools_bulk_url_removal$background$core$boot_chrome_event_loop_BANG_(){
var chrome_event_channel = chromex.chrome_event_channel.make_chrome_event_channel(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0());
var chan17677_17679 = chrome_event_channel;
var config17678_17680 = chromex.config.get_active_config();
chromex.ext.runtime.on_startup_STAR_(config17678_17680,chan17677_17679);

chromex.ext.runtime.on_installed_STAR_(config17678_17680,chan17677_17679);

chromex.ext.runtime.on_suspend_STAR_(config17678_17680,chan17677_17679);

chromex.ext.runtime.on_suspend_canceled_STAR_(config17678_17680,chan17677_17679);

chromex.ext.runtime.on_update_available_STAR_(config17678_17680,chan17677_17679);

chromex.ext.runtime.on_connect_STAR_(config17678_17680,chan17677_17679);

chromex.ext.runtime.on_connect_external_STAR_(config17678_17680,chan17677_17679);

chromex.ext.runtime.on_message_STAR_(config17678_17680,chan17677_17679);

chromex.ext.runtime.on_message_external_STAR_(config17678_17680,chan17677_17679);

chromex.ext.runtime.on_restart_required_STAR_(config17678_17680,chan17677_17679);

return google_webmaster_tools_bulk_url_removal.background.core.run_chrome_event_loop_BANG_(chrome_event_channel);
});
google_webmaster_tools_bulk_url_removal.background.core.init_BANG_ = (function google_webmaster_tools_bulk_url_removal$background$core$init_BANG_(){
console.log("BACKGROUND: init");


return google_webmaster_tools_bulk_url_removal.background.core.boot_chrome_event_loop_BANG_();
});

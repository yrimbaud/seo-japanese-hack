// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('cljs.core.async');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async.impl.channels');
goog.require('cljs.core.async.impl.buffers');
goog.require('cljs.core.async.impl.timers');
goog.require('cljs.core.async.impl.dispatch');
goog.require('cljs.core.async.impl.ioc_helpers');
goog.require('goog.array');
cljs.core.async.fn_handler = (function cljs$core$async$fn_handler(var_args){
var G__8112 = arguments.length;
switch (G__8112) {
case 1:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1 = (function (f){
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(f,true);
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2 = (function (f,blockable){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async8113 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async8113 = (function (f,blockable,meta8114){
this.f = f;
this.blockable = blockable;
this.meta8114 = meta8114;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async8113.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_8115,meta8114__$1){
var self__ = this;
var _8115__$1 = this;
return (new cljs.core.async.t_cljs$core$async8113(self__.f,self__.blockable,meta8114__$1));
});

cljs.core.async.t_cljs$core$async8113.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_8115){
var self__ = this;
var _8115__$1 = this;
return self__.meta8114;
});

cljs.core.async.t_cljs$core$async8113.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8113.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async8113.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.blockable;
});

cljs.core.async.t_cljs$core$async8113.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.f;
});

cljs.core.async.t_cljs$core$async8113.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$blockable,cljs.core.cst$sym$meta8114], null);
});

cljs.core.async.t_cljs$core$async8113.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async8113.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async8113";

cljs.core.async.t_cljs$core$async8113.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async8113");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async8113.
 */
cljs.core.async.__GT_t_cljs$core$async8113 = (function cljs$core$async$__GT_t_cljs$core$async8113(f__$1,blockable__$1,meta8114){
return (new cljs.core.async.t_cljs$core$async8113(f__$1,blockable__$1,meta8114));
});

}

return (new cljs.core.async.t_cljs$core$async8113(f,blockable,cljs.core.PersistentArrayMap.EMPTY));
});

cljs.core.async.fn_handler.cljs$lang$maxFixedArity = 2;

/**
 * Returns a fixed buffer of size n. When full, puts will block/park.
 */
cljs.core.async.buffer = (function cljs$core$async$buffer(n){
return cljs.core.async.impl.buffers.fixed_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete but
 *   val will be dropped (no transfer).
 */
cljs.core.async.dropping_buffer = (function cljs$core$async$dropping_buffer(n){
return cljs.core.async.impl.buffers.dropping_buffer(n);
});
/**
 * Returns a buffer of size n. When full, puts will complete, and be
 *   buffered, but oldest elements in buffer will be dropped (not
 *   transferred).
 */
cljs.core.async.sliding_buffer = (function cljs$core$async$sliding_buffer(n){
return cljs.core.async.impl.buffers.sliding_buffer(n);
});
/**
 * Returns true if a channel created with buff will never block. That is to say,
 * puts into this buffer will never cause the buffer to be full. 
 */
cljs.core.async.unblocking_buffer_QMARK_ = (function cljs$core$async$unblocking_buffer_QMARK_(buff){
if((!((buff == null)))){
if(((false) || ((cljs.core.PROTOCOL_SENTINEL === buff.cljs$core$async$impl$protocols$UnblockingBuffer$)))){
return true;
} else {
if((!buff.cljs$lang$protocol_mask$partition$)){
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
} else {
return false;
}
}
} else {
return cljs.core.native_satisfies_QMARK_(cljs.core.async.impl.protocols.UnblockingBuffer,buff);
}
});
/**
 * Creates a channel with an optional buffer, an optional transducer (like (map f),
 *   (filter p) etc or a composition thereof), and an optional exception handler.
 *   If buf-or-n is a number, will create and use a fixed buffer of that size. If a
 *   transducer is supplied a buffer must be specified. ex-handler must be a
 *   fn of one argument - if an exception occurs during transformation it will be called
 *   with the thrown value as an argument, and any non-nil return value will be placed
 *   in the channel.
 */
cljs.core.async.chan = (function cljs$core$async$chan(var_args){
var G__8119 = arguments.length;
switch (G__8119) {
case 0:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1 = (function (buf_or_n){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2 = (function (buf_or_n,xform){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(buf_or_n,xform,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3 = (function (buf_or_n,xform,ex_handler){
var buf_or_n__$1 = ((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(buf_or_n,(0)))?null:buf_or_n);
if(cljs.core.truth_(xform)){
} else {
}

return cljs.core.async.impl.channels.chan.cljs$core$IFn$_invoke$arity$3(((typeof buf_or_n__$1 === 'number')?cljs.core.async.buffer(buf_or_n__$1):buf_or_n__$1),xform,ex_handler);
});

cljs.core.async.chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates a promise channel with an optional transducer, and an optional
 *   exception-handler. A promise channel can take exactly one value that consumers
 *   will receive. Once full, puts complete but val is dropped (no transfer).
 *   Consumers will block until either a value is placed in the channel or the
 *   channel is closed. See chan for the semantics of xform and ex-handler.
 */
cljs.core.async.promise_chan = (function cljs$core$async$promise_chan(var_args){
var G__8122 = arguments.length;
switch (G__8122) {
case 0:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1(null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1 = (function (xform){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2(xform,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2 = (function (xform,ex_handler){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3(cljs.core.async.impl.buffers.promise_buffer(),xform,ex_handler);
});

cljs.core.async.promise_chan.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel that will close after msecs
 */
cljs.core.async.timeout = (function cljs$core$async$timeout(msecs){
return cljs.core.async.impl.timers.timeout(msecs);
});
/**
 * takes a val from port. Must be called inside a (go ...) block. Will
 *   return nil if closed. Will park if nothing is available.
 *   Returns true unless port is already closed
 */
cljs.core.async._LT__BANG_ = (function cljs$core$async$_LT__BANG_(port){
throw (new Error("<! used not in (go ...) block"));
});
/**
 * Asynchronously takes a val from port, passing to fn1. Will pass nil
 * if closed. If on-caller? (default true) is true, and value is
 * immediately available, will call fn1 on calling thread.
 * Returns nil.
 */
cljs.core.async.take_BANG_ = (function cljs$core$async$take_BANG_(var_args){
var G__8125 = arguments.length;
switch (G__8125) {
case 2:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,fn1){
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3(port,fn1,true);
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,fn1,on_caller_QMARK_){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(ret)){
var val_8127 = cljs.core.deref(ret);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_8127) : fn1.call(null,val_8127));
} else {
cljs.core.async.impl.dispatch.run(((function (val_8127,ret){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(val_8127) : fn1.call(null,val_8127));
});})(val_8127,ret))
);
}
} else {
}

return null;
});

cljs.core.async.take_BANG_.cljs$lang$maxFixedArity = 3;

cljs.core.async.nop = (function cljs$core$async$nop(_){
return null;
});
cljs.core.async.fhnop = cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(cljs.core.async.nop);
/**
 * puts a val into port. nil values are not allowed. Must be called
 *   inside a (go ...) block. Will park if no buffer space is available.
 *   Returns true unless port is already closed.
 */
cljs.core.async._GT__BANG_ = (function cljs$core$async$_GT__BANG_(port,val){
throw (new Error(">! used not in (go ...) block"));
});
/**
 * Asynchronously puts a val into port, calling fn1 (if supplied) when
 * complete. nil values are not allowed. Will throw if closed. If
 * on-caller? (default true) is true, and the put is immediately
 * accepted, will call fn1 on calling thread.  Returns nil.
 */
cljs.core.async.put_BANG_ = (function cljs$core$async$put_BANG_(var_args){
var G__8129 = arguments.length;
switch (G__8129) {
case 2:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,val){
var temp__5733__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fhnop);
if(cljs.core.truth_(temp__5733__auto__)){
var ret = temp__5733__auto__;
return cljs.core.deref(ret);
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,val,fn1){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4(port,val,fn1,true);
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (port,val,fn1,on_caller_QMARK_){
var temp__5733__auto__ = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1(fn1));
if(cljs.core.truth_(temp__5733__auto__)){
var retb = temp__5733__auto__;
var ret = cljs.core.deref(retb);
if(cljs.core.truth_(on_caller_QMARK_)){
(fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
} else {
cljs.core.async.impl.dispatch.run(((function (ret,retb,temp__5733__auto__){
return (function (){
return (fn1.cljs$core$IFn$_invoke$arity$1 ? fn1.cljs$core$IFn$_invoke$arity$1(ret) : fn1.call(null,ret));
});})(ret,retb,temp__5733__auto__))
);
}

return ret;
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$lang$maxFixedArity = 4;

cljs.core.async.close_BANG_ = (function cljs$core$async$close_BANG_(port){
return cljs.core.async.impl.protocols.close_BANG_(port);
});
cljs.core.async.random_array = (function cljs$core$async$random_array(n){
var a = (new Array(n));
var n__4607__auto___8131 = n;
var x_8132 = (0);
while(true){
if((x_8132 < n__4607__auto___8131)){
(a[x_8132] = x_8132);

var G__8133 = (x_8132 + (1));
x_8132 = G__8133;
continue;
} else {
}
break;
}

goog.array.shuffle(a);

return a;
});
cljs.core.async.alt_flag = (function cljs$core$async$alt_flag(){
var flag = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(true);
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async8134 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async8134 = (function (flag,meta8135){
this.flag = flag;
this.meta8135 = meta8135;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async8134.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (flag){
return (function (_8136,meta8135__$1){
var self__ = this;
var _8136__$1 = this;
return (new cljs.core.async.t_cljs$core$async8134(self__.flag,meta8135__$1));
});})(flag))
;

cljs.core.async.t_cljs$core$async8134.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (flag){
return (function (_8136){
var self__ = this;
var _8136__$1 = this;
return self__.meta8135;
});})(flag))
;

cljs.core.async.t_cljs$core$async8134.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8134.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.deref(self__.flag);
});})(flag))
;

cljs.core.async.t_cljs$core$async8134.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async8134.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.flag,null);

return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async8134.getBasis = ((function (flag){
return (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$meta8135], null);
});})(flag))
;

cljs.core.async.t_cljs$core$async8134.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async8134.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async8134";

cljs.core.async.t_cljs$core$async8134.cljs$lang$ctorPrWriter = ((function (flag){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async8134");
});})(flag))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async8134.
 */
cljs.core.async.__GT_t_cljs$core$async8134 = ((function (flag){
return (function cljs$core$async$alt_flag_$___GT_t_cljs$core$async8134(flag__$1,meta8135){
return (new cljs.core.async.t_cljs$core$async8134(flag__$1,meta8135));
});})(flag))
;

}

return (new cljs.core.async.t_cljs$core$async8134(flag,cljs.core.PersistentArrayMap.EMPTY));
});
cljs.core.async.alt_handler = (function cljs$core$async$alt_handler(flag,cb){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async8137 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async8137 = (function (flag,cb,meta8138){
this.flag = flag;
this.cb = cb;
this.meta8138 = meta8138;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async8137.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_8139,meta8138__$1){
var self__ = this;
var _8139__$1 = this;
return (new cljs.core.async.t_cljs$core$async8137(self__.flag,self__.cb,meta8138__$1));
});

cljs.core.async.t_cljs$core$async8137.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_8139){
var self__ = this;
var _8139__$1 = this;
return self__.meta8138;
});

cljs.core.async.t_cljs$core$async8137.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8137.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.flag);
});

cljs.core.async.t_cljs$core$async8137.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async8137.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.async.impl.protocols.commit(self__.flag);

return self__.cb;
});

cljs.core.async.t_cljs$core$async8137.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$flag,cljs.core.cst$sym$cb,cljs.core.cst$sym$meta8138], null);
});

cljs.core.async.t_cljs$core$async8137.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async8137.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async8137";

cljs.core.async.t_cljs$core$async8137.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async8137");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async8137.
 */
cljs.core.async.__GT_t_cljs$core$async8137 = (function cljs$core$async$alt_handler_$___GT_t_cljs$core$async8137(flag__$1,cb__$1,meta8138){
return (new cljs.core.async.t_cljs$core$async8137(flag__$1,cb__$1,meta8138));
});

}

return (new cljs.core.async.t_cljs$core$async8137(flag,cb,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * returns derefable [val port] if immediate, nil if enqueued
 */
cljs.core.async.do_alts = (function cljs$core$async$do_alts(fret,ports,opts){

var flag = cljs.core.async.alt_flag();
var n = cljs.core.count(ports);
var idxs = cljs.core.async.random_array(n);
var priority = cljs.core.cst$kw$priority.cljs$core$IFn$_invoke$arity$1(opts);
var ret = (function (){var i = (0);
while(true){
if((i < n)){
var idx = (cljs.core.truth_(priority)?i:(idxs[i]));
var port = cljs.core.nth.cljs$core$IFn$_invoke$arity$2(ports,idx);
var wport = ((cljs.core.vector_QMARK_(port))?(port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((0)) : port.call(null,(0))):null);
var vbox = (cljs.core.truth_(wport)?(function (){var val = (port.cljs$core$IFn$_invoke$arity$1 ? port.cljs$core$IFn$_invoke$arity$1((1)) : port.call(null,(1)));
return cljs.core.async.impl.protocols.put_BANG_(wport,val,cljs.core.async.alt_handler(flag,((function (i,val,idx,port,wport,flag,n,idxs,priority){
return (function (p1__8140_SHARP_){
var G__8142 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__8140_SHARP_,wport], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__8142) : fret.call(null,G__8142));
});})(i,val,idx,port,wport,flag,n,idxs,priority))
));
})():cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.alt_handler(flag,((function (i,idx,port,wport,flag,n,idxs,priority){
return (function (p1__8141_SHARP_){
var G__8143 = new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__8141_SHARP_,port], null);
return (fret.cljs$core$IFn$_invoke$arity$1 ? fret.cljs$core$IFn$_invoke$arity$1(G__8143) : fret.call(null,G__8143));
});})(i,idx,port,wport,flag,n,idxs,priority))
)));
if(cljs.core.truth_(vbox)){
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.deref(vbox),(function (){var or__4131__auto__ = wport;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return port;
}
})()], null));
} else {
var G__8144 = (i + (1));
i = G__8144;
continue;
}
} else {
return null;
}
break;
}
})();
var or__4131__auto__ = ret;
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
if(cljs.core.contains_QMARK_(opts,cljs.core.cst$kw$default)){
var temp__5735__auto__ = (function (){var and__4120__auto__ = flag.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1(null);
if(cljs.core.truth_(and__4120__auto__)){
return flag.cljs$core$async$impl$protocols$Handler$commit$arity$1(null);
} else {
return and__4120__auto__;
}
})();
if(cljs.core.truth_(temp__5735__auto__)){
var got = temp__5735__auto__;
return cljs.core.async.impl.channels.box(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$kw$default.cljs$core$IFn$_invoke$arity$1(opts),cljs.core.cst$kw$default], null));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Completes at most one of several channel operations. Must be called
 * inside a (go ...) block. ports is a vector of channel endpoints,
 * which can be either a channel to take from or a vector of
 *   [channel-to-put-to val-to-put], in any combination. Takes will be
 *   made as if by <!, and puts will be made as if by >!. Unless
 *   the :priority option is true, if more than one port operation is
 *   ready a non-deterministic choice will be made. If no operation is
 *   ready and a :default value is supplied, [default-val :default] will
 *   be returned, otherwise alts! will park until the first operation to
 *   become ready completes. Returns [val port] of the completed
 *   operation, where val is the value taken for takes, and a
 *   boolean (true unless already closed, as per put!) for puts.
 * 
 *   opts are passed as :key val ... Supported options:
 * 
 *   :default val - the value to use if none of the operations are immediately ready
 *   :priority true - (default nil) when true, the operations will be tried in order.
 * 
 *   Note: there is no guarantee that the port exps or val exprs will be
 *   used, nor in what order should they be, so they should not be
 *   depended upon for side effects.
 */
cljs.core.async.alts_BANG_ = (function cljs$core$async$alts_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___8150 = arguments.length;
var i__4731__auto___8151 = (0);
while(true){
if((i__4731__auto___8151 < len__4730__auto___8150)){
args__4736__auto__.push((arguments[i__4731__auto___8151]));

var G__8152 = (i__4731__auto___8151 + (1));
i__4731__auto___8151 = G__8152;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ports,p__8147){
var map__8148 = p__8147;
var map__8148__$1 = (((((!((map__8148 == null))))?(((((map__8148.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__8148.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__8148):map__8148);
var opts = map__8148__$1;
throw (new Error("alts! used not in (go ...) block"));
});

cljs.core.async.alts_BANG_.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
cljs.core.async.alts_BANG_.cljs$lang$applyTo = (function (seq8145){
var G__8146 = cljs.core.first(seq8145);
var seq8145__$1 = cljs.core.next(seq8145);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__8146,seq8145__$1);
});

/**
 * Puts a val into port if it's possible to do so immediately.
 *   nil values are not allowed. Never blocks. Returns true if offer succeeds.
 */
cljs.core.async.offer_BANG_ = (function cljs$core$async$offer_BANG_(port,val){
var ret = cljs.core.async.impl.protocols.put_BANG_(port,val,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes a val from port if it's possible to do so immediately.
 *   Never blocks. Returns value if successful, nil otherwise.
 */
cljs.core.async.poll_BANG_ = (function cljs$core$async$poll_BANG_(port){
var ret = cljs.core.async.impl.protocols.take_BANG_(port,cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2(cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref(ret);
} else {
return null;
}
});
/**
 * Takes elements from the from channel and supplies them to the to
 * channel. By default, the to channel will be closed when the from
 * channel closes, but can be determined by the close?  parameter. Will
 * stop consuming the from channel if the to channel closes
 */
cljs.core.async.pipe = (function cljs$core$async$pipe(var_args){
var G__8154 = arguments.length;
switch (G__8154) {
case 2:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2 = (function (from,to){
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3(from,to,true);
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3 = (function (from,to,close_QMARK_){
var c__8052__auto___8200 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___8200){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___8200){
return (function (state_8178){
var state_val_8179 = (state_8178[(1)]);
if((state_val_8179 === (7))){
var inst_8174 = (state_8178[(2)]);
var state_8178__$1 = state_8178;
var statearr_8180_8201 = state_8178__$1;
(statearr_8180_8201[(2)] = inst_8174);

(statearr_8180_8201[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8179 === (1))){
var state_8178__$1 = state_8178;
var statearr_8181_8202 = state_8178__$1;
(statearr_8181_8202[(2)] = null);

(statearr_8181_8202[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8179 === (4))){
var inst_8157 = (state_8178[(7)]);
var inst_8157__$1 = (state_8178[(2)]);
var inst_8158 = (inst_8157__$1 == null);
var state_8178__$1 = (function (){var statearr_8182 = state_8178;
(statearr_8182[(7)] = inst_8157__$1);

return statearr_8182;
})();
if(cljs.core.truth_(inst_8158)){
var statearr_8183_8203 = state_8178__$1;
(statearr_8183_8203[(1)] = (5));

} else {
var statearr_8184_8204 = state_8178__$1;
(statearr_8184_8204[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8179 === (13))){
var state_8178__$1 = state_8178;
var statearr_8185_8205 = state_8178__$1;
(statearr_8185_8205[(2)] = null);

(statearr_8185_8205[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8179 === (6))){
var inst_8157 = (state_8178[(7)]);
var state_8178__$1 = state_8178;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8178__$1,(11),to,inst_8157);
} else {
if((state_val_8179 === (3))){
var inst_8176 = (state_8178[(2)]);
var state_8178__$1 = state_8178;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8178__$1,inst_8176);
} else {
if((state_val_8179 === (12))){
var state_8178__$1 = state_8178;
var statearr_8186_8206 = state_8178__$1;
(statearr_8186_8206[(2)] = null);

(statearr_8186_8206[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8179 === (2))){
var state_8178__$1 = state_8178;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8178__$1,(4),from);
} else {
if((state_val_8179 === (11))){
var inst_8167 = (state_8178[(2)]);
var state_8178__$1 = state_8178;
if(cljs.core.truth_(inst_8167)){
var statearr_8187_8207 = state_8178__$1;
(statearr_8187_8207[(1)] = (12));

} else {
var statearr_8188_8208 = state_8178__$1;
(statearr_8188_8208[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8179 === (9))){
var state_8178__$1 = state_8178;
var statearr_8189_8209 = state_8178__$1;
(statearr_8189_8209[(2)] = null);

(statearr_8189_8209[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8179 === (5))){
var state_8178__$1 = state_8178;
if(cljs.core.truth_(close_QMARK_)){
var statearr_8190_8210 = state_8178__$1;
(statearr_8190_8210[(1)] = (8));

} else {
var statearr_8191_8211 = state_8178__$1;
(statearr_8191_8211[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8179 === (14))){
var inst_8172 = (state_8178[(2)]);
var state_8178__$1 = state_8178;
var statearr_8192_8212 = state_8178__$1;
(statearr_8192_8212[(2)] = inst_8172);

(statearr_8192_8212[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8179 === (10))){
var inst_8164 = (state_8178[(2)]);
var state_8178__$1 = state_8178;
var statearr_8193_8213 = state_8178__$1;
(statearr_8193_8213[(2)] = inst_8164);

(statearr_8193_8213[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8179 === (8))){
var inst_8161 = cljs.core.async.close_BANG_(to);
var state_8178__$1 = state_8178;
var statearr_8194_8214 = state_8178__$1;
(statearr_8194_8214[(2)] = inst_8161);

(statearr_8194_8214[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___8200))
;
return ((function (switch__7945__auto__,c__8052__auto___8200){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_8195 = [null,null,null,null,null,null,null,null];
(statearr_8195[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_8195[(1)] = (1));

return statearr_8195;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_8178){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_8178);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e8196){if((e8196 instanceof Object)){
var ex__7949__auto__ = e8196;
var statearr_8197_8215 = state_8178;
(statearr_8197_8215[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8178);

return cljs.core.cst$kw$recur;
} else {
throw e8196;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__8216 = state_8178;
state_8178 = G__8216;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_8178){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_8178);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___8200))
})();
var state__8054__auto__ = (function (){var statearr_8198 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_8198[(6)] = c__8052__auto___8200);

return statearr_8198;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___8200))
);


return to;
});

cljs.core.async.pipe.cljs$lang$maxFixedArity = 3;

cljs.core.async.pipeline_STAR_ = (function cljs$core$async$pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,type){

var jobs = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var results = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(n);
var process = ((function (jobs,results){
return (function (p__8217){
var vec__8218 = p__8217;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__8218,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__8218,(1),null);
var job = vec__8218;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((1),xf,ex_handler);
var c__8052__auto___8389 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___8389,res,vec__8218,v,p,job,jobs,results){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___8389,res,vec__8218,v,p,job,jobs,results){
return (function (state_8225){
var state_val_8226 = (state_8225[(1)]);
if((state_val_8226 === (1))){
var state_8225__$1 = state_8225;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8225__$1,(2),res,v);
} else {
if((state_val_8226 === (2))){
var inst_8222 = (state_8225[(2)]);
var inst_8223 = cljs.core.async.close_BANG_(res);
var state_8225__$1 = (function (){var statearr_8227 = state_8225;
(statearr_8227[(7)] = inst_8222);

return statearr_8227;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_8225__$1,inst_8223);
} else {
return null;
}
}
});})(c__8052__auto___8389,res,vec__8218,v,p,job,jobs,results))
;
return ((function (switch__7945__auto__,c__8052__auto___8389,res,vec__8218,v,p,job,jobs,results){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0 = (function (){
var statearr_8228 = [null,null,null,null,null,null,null,null];
(statearr_8228[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__);

(statearr_8228[(1)] = (1));

return statearr_8228;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1 = (function (state_8225){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_8225);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e8229){if((e8229 instanceof Object)){
var ex__7949__auto__ = e8229;
var statearr_8230_8390 = state_8225;
(statearr_8230_8390[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8225);

return cljs.core.cst$kw$recur;
} else {
throw e8229;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__8391 = state_8225;
state_8225 = G__8391;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = function(state_8225){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1.call(this,state_8225);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___8389,res,vec__8218,v,p,job,jobs,results))
})();
var state__8054__auto__ = (function (){var statearr_8231 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_8231[(6)] = c__8052__auto___8389);

return statearr_8231;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___8389,res,vec__8218,v,p,job,jobs,results))
);


cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results))
;
var async = ((function (jobs,results,process){
return (function (p__8232){
var vec__8233 = p__8232;
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__8233,(0),null);
var p = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__8233,(1),null);
var job = vec__8233;
if((job == null)){
cljs.core.async.close_BANG_(results);

return null;
} else {
var res = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
(xf.cljs$core$IFn$_invoke$arity$2 ? xf.cljs$core$IFn$_invoke$arity$2(v,res) : xf.call(null,v,res));

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(p,res);

return true;
}
});})(jobs,results,process))
;
var n__4607__auto___8392 = n;
var __8393 = (0);
while(true){
if((__8393 < n__4607__auto___8392)){
var G__8236_8394 = type;
var G__8236_8395__$1 = (((G__8236_8394 instanceof cljs.core.Keyword))?G__8236_8394.fqn:null);
switch (G__8236_8395__$1) {
case "compute":
var c__8052__auto___8397 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__8393,c__8052__auto___8397,G__8236_8394,G__8236_8395__$1,n__4607__auto___8392,jobs,results,process,async){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (__8393,c__8052__auto___8397,G__8236_8394,G__8236_8395__$1,n__4607__auto___8392,jobs,results,process,async){
return (function (state_8249){
var state_val_8250 = (state_8249[(1)]);
if((state_val_8250 === (1))){
var state_8249__$1 = state_8249;
var statearr_8251_8398 = state_8249__$1;
(statearr_8251_8398[(2)] = null);

(statearr_8251_8398[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8250 === (2))){
var state_8249__$1 = state_8249;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8249__$1,(4),jobs);
} else {
if((state_val_8250 === (3))){
var inst_8247 = (state_8249[(2)]);
var state_8249__$1 = state_8249;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8249__$1,inst_8247);
} else {
if((state_val_8250 === (4))){
var inst_8239 = (state_8249[(2)]);
var inst_8240 = process(inst_8239);
var state_8249__$1 = state_8249;
if(cljs.core.truth_(inst_8240)){
var statearr_8252_8399 = state_8249__$1;
(statearr_8252_8399[(1)] = (5));

} else {
var statearr_8253_8400 = state_8249__$1;
(statearr_8253_8400[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8250 === (5))){
var state_8249__$1 = state_8249;
var statearr_8254_8401 = state_8249__$1;
(statearr_8254_8401[(2)] = null);

(statearr_8254_8401[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8250 === (6))){
var state_8249__$1 = state_8249;
var statearr_8255_8402 = state_8249__$1;
(statearr_8255_8402[(2)] = null);

(statearr_8255_8402[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8250 === (7))){
var inst_8245 = (state_8249[(2)]);
var state_8249__$1 = state_8249;
var statearr_8256_8403 = state_8249__$1;
(statearr_8256_8403[(2)] = inst_8245);

(statearr_8256_8403[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__8393,c__8052__auto___8397,G__8236_8394,G__8236_8395__$1,n__4607__auto___8392,jobs,results,process,async))
;
return ((function (__8393,switch__7945__auto__,c__8052__auto___8397,G__8236_8394,G__8236_8395__$1,n__4607__auto___8392,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0 = (function (){
var statearr_8257 = [null,null,null,null,null,null,null];
(statearr_8257[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__);

(statearr_8257[(1)] = (1));

return statearr_8257;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1 = (function (state_8249){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_8249);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e8258){if((e8258 instanceof Object)){
var ex__7949__auto__ = e8258;
var statearr_8259_8404 = state_8249;
(statearr_8259_8404[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8249);

return cljs.core.cst$kw$recur;
} else {
throw e8258;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__8405 = state_8249;
state_8249 = G__8405;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = function(state_8249){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1.call(this,state_8249);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__;
})()
;})(__8393,switch__7945__auto__,c__8052__auto___8397,G__8236_8394,G__8236_8395__$1,n__4607__auto___8392,jobs,results,process,async))
})();
var state__8054__auto__ = (function (){var statearr_8260 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_8260[(6)] = c__8052__auto___8397);

return statearr_8260;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(__8393,c__8052__auto___8397,G__8236_8394,G__8236_8395__$1,n__4607__auto___8392,jobs,results,process,async))
);


break;
case "async":
var c__8052__auto___8406 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (__8393,c__8052__auto___8406,G__8236_8394,G__8236_8395__$1,n__4607__auto___8392,jobs,results,process,async){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (__8393,c__8052__auto___8406,G__8236_8394,G__8236_8395__$1,n__4607__auto___8392,jobs,results,process,async){
return (function (state_8273){
var state_val_8274 = (state_8273[(1)]);
if((state_val_8274 === (1))){
var state_8273__$1 = state_8273;
var statearr_8275_8407 = state_8273__$1;
(statearr_8275_8407[(2)] = null);

(statearr_8275_8407[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8274 === (2))){
var state_8273__$1 = state_8273;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8273__$1,(4),jobs);
} else {
if((state_val_8274 === (3))){
var inst_8271 = (state_8273[(2)]);
var state_8273__$1 = state_8273;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8273__$1,inst_8271);
} else {
if((state_val_8274 === (4))){
var inst_8263 = (state_8273[(2)]);
var inst_8264 = async(inst_8263);
var state_8273__$1 = state_8273;
if(cljs.core.truth_(inst_8264)){
var statearr_8276_8408 = state_8273__$1;
(statearr_8276_8408[(1)] = (5));

} else {
var statearr_8277_8409 = state_8273__$1;
(statearr_8277_8409[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8274 === (5))){
var state_8273__$1 = state_8273;
var statearr_8278_8410 = state_8273__$1;
(statearr_8278_8410[(2)] = null);

(statearr_8278_8410[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8274 === (6))){
var state_8273__$1 = state_8273;
var statearr_8279_8411 = state_8273__$1;
(statearr_8279_8411[(2)] = null);

(statearr_8279_8411[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8274 === (7))){
var inst_8269 = (state_8273[(2)]);
var state_8273__$1 = state_8273;
var statearr_8280_8412 = state_8273__$1;
(statearr_8280_8412[(2)] = inst_8269);

(statearr_8280_8412[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
});})(__8393,c__8052__auto___8406,G__8236_8394,G__8236_8395__$1,n__4607__auto___8392,jobs,results,process,async))
;
return ((function (__8393,switch__7945__auto__,c__8052__auto___8406,G__8236_8394,G__8236_8395__$1,n__4607__auto___8392,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0 = (function (){
var statearr_8281 = [null,null,null,null,null,null,null];
(statearr_8281[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__);

(statearr_8281[(1)] = (1));

return statearr_8281;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1 = (function (state_8273){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_8273);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e8282){if((e8282 instanceof Object)){
var ex__7949__auto__ = e8282;
var statearr_8283_8413 = state_8273;
(statearr_8283_8413[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8273);

return cljs.core.cst$kw$recur;
} else {
throw e8282;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__8414 = state_8273;
state_8273 = G__8414;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = function(state_8273){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1.call(this,state_8273);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__;
})()
;})(__8393,switch__7945__auto__,c__8052__auto___8406,G__8236_8394,G__8236_8395__$1,n__4607__auto___8392,jobs,results,process,async))
})();
var state__8054__auto__ = (function (){var statearr_8284 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_8284[(6)] = c__8052__auto___8406);

return statearr_8284;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(__8393,c__8052__auto___8406,G__8236_8394,G__8236_8395__$1,n__4607__auto___8392,jobs,results,process,async))
);


break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__8236_8395__$1)].join('')));

}

var G__8415 = (__8393 + (1));
__8393 = G__8415;
continue;
} else {
}
break;
}

var c__8052__auto___8416 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___8416,jobs,results,process,async){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___8416,jobs,results,process,async){
return (function (state_8306){
var state_val_8307 = (state_8306[(1)]);
if((state_val_8307 === (7))){
var inst_8302 = (state_8306[(2)]);
var state_8306__$1 = state_8306;
var statearr_8308_8417 = state_8306__$1;
(statearr_8308_8417[(2)] = inst_8302);

(statearr_8308_8417[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8307 === (1))){
var state_8306__$1 = state_8306;
var statearr_8309_8418 = state_8306__$1;
(statearr_8309_8418[(2)] = null);

(statearr_8309_8418[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8307 === (4))){
var inst_8287 = (state_8306[(7)]);
var inst_8287__$1 = (state_8306[(2)]);
var inst_8288 = (inst_8287__$1 == null);
var state_8306__$1 = (function (){var statearr_8310 = state_8306;
(statearr_8310[(7)] = inst_8287__$1);

return statearr_8310;
})();
if(cljs.core.truth_(inst_8288)){
var statearr_8311_8419 = state_8306__$1;
(statearr_8311_8419[(1)] = (5));

} else {
var statearr_8312_8420 = state_8306__$1;
(statearr_8312_8420[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8307 === (6))){
var inst_8292 = (state_8306[(8)]);
var inst_8287 = (state_8306[(7)]);
var inst_8292__$1 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var inst_8293 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_8294 = [inst_8287,inst_8292__$1];
var inst_8295 = (new cljs.core.PersistentVector(null,2,(5),inst_8293,inst_8294,null));
var state_8306__$1 = (function (){var statearr_8313 = state_8306;
(statearr_8313[(8)] = inst_8292__$1);

return statearr_8313;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8306__$1,(8),jobs,inst_8295);
} else {
if((state_val_8307 === (3))){
var inst_8304 = (state_8306[(2)]);
var state_8306__$1 = state_8306;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8306__$1,inst_8304);
} else {
if((state_val_8307 === (2))){
var state_8306__$1 = state_8306;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8306__$1,(4),from);
} else {
if((state_val_8307 === (9))){
var inst_8299 = (state_8306[(2)]);
var state_8306__$1 = (function (){var statearr_8314 = state_8306;
(statearr_8314[(9)] = inst_8299);

return statearr_8314;
})();
var statearr_8315_8421 = state_8306__$1;
(statearr_8315_8421[(2)] = null);

(statearr_8315_8421[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8307 === (5))){
var inst_8290 = cljs.core.async.close_BANG_(jobs);
var state_8306__$1 = state_8306;
var statearr_8316_8422 = state_8306__$1;
(statearr_8316_8422[(2)] = inst_8290);

(statearr_8316_8422[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8307 === (8))){
var inst_8292 = (state_8306[(8)]);
var inst_8297 = (state_8306[(2)]);
var state_8306__$1 = (function (){var statearr_8317 = state_8306;
(statearr_8317[(10)] = inst_8297);

return statearr_8317;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8306__$1,(9),results,inst_8292);
} else {
return null;
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___8416,jobs,results,process,async))
;
return ((function (switch__7945__auto__,c__8052__auto___8416,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0 = (function (){
var statearr_8318 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_8318[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__);

(statearr_8318[(1)] = (1));

return statearr_8318;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1 = (function (state_8306){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_8306);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e8319){if((e8319 instanceof Object)){
var ex__7949__auto__ = e8319;
var statearr_8320_8423 = state_8306;
(statearr_8320_8423[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8306);

return cljs.core.cst$kw$recur;
} else {
throw e8319;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__8424 = state_8306;
state_8306 = G__8424;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = function(state_8306){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1.call(this,state_8306);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___8416,jobs,results,process,async))
})();
var state__8054__auto__ = (function (){var statearr_8321 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_8321[(6)] = c__8052__auto___8416);

return statearr_8321;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___8416,jobs,results,process,async))
);


var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__,jobs,results,process,async){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__,jobs,results,process,async){
return (function (state_8359){
var state_val_8360 = (state_8359[(1)]);
if((state_val_8360 === (7))){
var inst_8355 = (state_8359[(2)]);
var state_8359__$1 = state_8359;
var statearr_8361_8425 = state_8359__$1;
(statearr_8361_8425[(2)] = inst_8355);

(statearr_8361_8425[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (20))){
var state_8359__$1 = state_8359;
var statearr_8362_8426 = state_8359__$1;
(statearr_8362_8426[(2)] = null);

(statearr_8362_8426[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (1))){
var state_8359__$1 = state_8359;
var statearr_8363_8427 = state_8359__$1;
(statearr_8363_8427[(2)] = null);

(statearr_8363_8427[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (4))){
var inst_8324 = (state_8359[(7)]);
var inst_8324__$1 = (state_8359[(2)]);
var inst_8325 = (inst_8324__$1 == null);
var state_8359__$1 = (function (){var statearr_8364 = state_8359;
(statearr_8364[(7)] = inst_8324__$1);

return statearr_8364;
})();
if(cljs.core.truth_(inst_8325)){
var statearr_8365_8428 = state_8359__$1;
(statearr_8365_8428[(1)] = (5));

} else {
var statearr_8366_8429 = state_8359__$1;
(statearr_8366_8429[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (15))){
var inst_8337 = (state_8359[(8)]);
var state_8359__$1 = state_8359;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8359__$1,(18),to,inst_8337);
} else {
if((state_val_8360 === (21))){
var inst_8350 = (state_8359[(2)]);
var state_8359__$1 = state_8359;
var statearr_8367_8430 = state_8359__$1;
(statearr_8367_8430[(2)] = inst_8350);

(statearr_8367_8430[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (13))){
var inst_8352 = (state_8359[(2)]);
var state_8359__$1 = (function (){var statearr_8368 = state_8359;
(statearr_8368[(9)] = inst_8352);

return statearr_8368;
})();
var statearr_8369_8431 = state_8359__$1;
(statearr_8369_8431[(2)] = null);

(statearr_8369_8431[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (6))){
var inst_8324 = (state_8359[(7)]);
var state_8359__$1 = state_8359;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8359__$1,(11),inst_8324);
} else {
if((state_val_8360 === (17))){
var inst_8345 = (state_8359[(2)]);
var state_8359__$1 = state_8359;
if(cljs.core.truth_(inst_8345)){
var statearr_8370_8432 = state_8359__$1;
(statearr_8370_8432[(1)] = (19));

} else {
var statearr_8371_8433 = state_8359__$1;
(statearr_8371_8433[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (3))){
var inst_8357 = (state_8359[(2)]);
var state_8359__$1 = state_8359;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8359__$1,inst_8357);
} else {
if((state_val_8360 === (12))){
var inst_8334 = (state_8359[(10)]);
var state_8359__$1 = state_8359;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8359__$1,(14),inst_8334);
} else {
if((state_val_8360 === (2))){
var state_8359__$1 = state_8359;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8359__$1,(4),results);
} else {
if((state_val_8360 === (19))){
var state_8359__$1 = state_8359;
var statearr_8372_8434 = state_8359__$1;
(statearr_8372_8434[(2)] = null);

(statearr_8372_8434[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (11))){
var inst_8334 = (state_8359[(2)]);
var state_8359__$1 = (function (){var statearr_8373 = state_8359;
(statearr_8373[(10)] = inst_8334);

return statearr_8373;
})();
var statearr_8374_8435 = state_8359__$1;
(statearr_8374_8435[(2)] = null);

(statearr_8374_8435[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (9))){
var state_8359__$1 = state_8359;
var statearr_8375_8436 = state_8359__$1;
(statearr_8375_8436[(2)] = null);

(statearr_8375_8436[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (5))){
var state_8359__$1 = state_8359;
if(cljs.core.truth_(close_QMARK_)){
var statearr_8376_8437 = state_8359__$1;
(statearr_8376_8437[(1)] = (8));

} else {
var statearr_8377_8438 = state_8359__$1;
(statearr_8377_8438[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (14))){
var inst_8339 = (state_8359[(11)]);
var inst_8337 = (state_8359[(8)]);
var inst_8337__$1 = (state_8359[(2)]);
var inst_8338 = (inst_8337__$1 == null);
var inst_8339__$1 = cljs.core.not(inst_8338);
var state_8359__$1 = (function (){var statearr_8378 = state_8359;
(statearr_8378[(11)] = inst_8339__$1);

(statearr_8378[(8)] = inst_8337__$1);

return statearr_8378;
})();
if(inst_8339__$1){
var statearr_8379_8439 = state_8359__$1;
(statearr_8379_8439[(1)] = (15));

} else {
var statearr_8380_8440 = state_8359__$1;
(statearr_8380_8440[(1)] = (16));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (16))){
var inst_8339 = (state_8359[(11)]);
var state_8359__$1 = state_8359;
var statearr_8381_8441 = state_8359__$1;
(statearr_8381_8441[(2)] = inst_8339);

(statearr_8381_8441[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (10))){
var inst_8331 = (state_8359[(2)]);
var state_8359__$1 = state_8359;
var statearr_8382_8442 = state_8359__$1;
(statearr_8382_8442[(2)] = inst_8331);

(statearr_8382_8442[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (18))){
var inst_8342 = (state_8359[(2)]);
var state_8359__$1 = state_8359;
var statearr_8383_8443 = state_8359__$1;
(statearr_8383_8443[(2)] = inst_8342);

(statearr_8383_8443[(1)] = (17));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8360 === (8))){
var inst_8328 = cljs.core.async.close_BANG_(to);
var state_8359__$1 = state_8359;
var statearr_8384_8444 = state_8359__$1;
(statearr_8384_8444[(2)] = inst_8328);

(statearr_8384_8444[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto__,jobs,results,process,async))
;
return ((function (switch__7945__auto__,c__8052__auto__,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0 = (function (){
var statearr_8385 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_8385[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__);

(statearr_8385[(1)] = (1));

return statearr_8385;
});
var cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1 = (function (state_8359){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_8359);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e8386){if((e8386 instanceof Object)){
var ex__7949__auto__ = e8386;
var statearr_8387_8445 = state_8359;
(statearr_8387_8445[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8359);

return cljs.core.cst$kw$recur;
} else {
throw e8386;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__8446 = state_8359;
state_8359 = G__8446;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__ = function(state_8359){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1.call(this,state_8359);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__7946__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__,jobs,results,process,async))
})();
var state__8054__auto__ = (function (){var statearr_8388 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_8388[(6)] = c__8052__auto__);

return statearr_8388;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__,jobs,results,process,async))
);

return c__8052__auto__;
});
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the async function af, with parallelism n. af
 *   must be a function of two arguments, the first an input value and
 *   the second a channel on which to place the result(s). af must close!
 *   the channel before returning.  The presumption is that af will
 *   return immediately, having launched some asynchronous operation
 *   whose completion/callback will manipulate the result channel. Outputs
 *   will be returned in order relative to  the inputs. By default, the to
 *   channel will be closed when the from channel closes, but can be
 *   determined by the close?  parameter. Will stop consuming the from
 *   channel if the to channel closes.
 */
cljs.core.async.pipeline_async = (function cljs$core$async$pipeline_async(var_args){
var G__8448 = arguments.length;
switch (G__8448) {
case 4:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4 = (function (n,to,af,from){
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5(n,to,af,from,true);
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5 = (function (n,to,af,from,close_QMARK_){
return cljs.core.async.pipeline_STAR_(n,to,af,from,close_QMARK_,null,cljs.core.cst$kw$async);
});

cljs.core.async.pipeline_async.cljs$lang$maxFixedArity = 5;

/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the transducer xf, with parallelism n. Because
 *   it is parallel, the transducer will be applied independently to each
 *   element, not across elements, and may produce zero or more outputs
 *   per input.  Outputs will be returned in order relative to the
 *   inputs. By default, the to channel will be closed when the from
 *   channel closes, but can be determined by the close?  parameter. Will
 *   stop consuming the from channel if the to channel closes.
 * 
 *   Note this is supplied for API compatibility with the Clojure version.
 *   Values of N > 1 will not result in actual concurrency in a
 *   single-threaded runtime.
 */
cljs.core.async.pipeline = (function cljs$core$async$pipeline(var_args){
var G__8451 = arguments.length;
switch (G__8451) {
case 4:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
case 6:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4 = (function (n,to,xf,from){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5(n,to,xf,from,true);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5 = (function (n,to,xf,from,close_QMARK_){
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6(n,to,xf,from,close_QMARK_,null);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6 = (function (n,to,xf,from,close_QMARK_,ex_handler){
return cljs.core.async.pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,cljs.core.cst$kw$compute);
});

cljs.core.async.pipeline.cljs$lang$maxFixedArity = 6;

/**
 * Takes a predicate and a source channel and returns a vector of two
 *   channels, the first of which will contain the values for which the
 *   predicate returned true, the second those for which it returned
 *   false.
 * 
 *   The out channels will be unbuffered by default, or two buf-or-ns can
 *   be supplied. The channels will close after the source channel has
 *   closed.
 */
cljs.core.async.split = (function cljs$core$async$split(var_args){
var G__8454 = arguments.length;
switch (G__8454) {
case 2:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4(p,ch,null,null);
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$4 = (function (p,ch,t_buf_or_n,f_buf_or_n){
var tc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(t_buf_or_n);
var fc = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(f_buf_or_n);
var c__8052__auto___8503 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___8503,tc,fc){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___8503,tc,fc){
return (function (state_8480){
var state_val_8481 = (state_8480[(1)]);
if((state_val_8481 === (7))){
var inst_8476 = (state_8480[(2)]);
var state_8480__$1 = state_8480;
var statearr_8482_8504 = state_8480__$1;
(statearr_8482_8504[(2)] = inst_8476);

(statearr_8482_8504[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8481 === (1))){
var state_8480__$1 = state_8480;
var statearr_8483_8505 = state_8480__$1;
(statearr_8483_8505[(2)] = null);

(statearr_8483_8505[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8481 === (4))){
var inst_8457 = (state_8480[(7)]);
var inst_8457__$1 = (state_8480[(2)]);
var inst_8458 = (inst_8457__$1 == null);
var state_8480__$1 = (function (){var statearr_8484 = state_8480;
(statearr_8484[(7)] = inst_8457__$1);

return statearr_8484;
})();
if(cljs.core.truth_(inst_8458)){
var statearr_8485_8506 = state_8480__$1;
(statearr_8485_8506[(1)] = (5));

} else {
var statearr_8486_8507 = state_8480__$1;
(statearr_8486_8507[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8481 === (13))){
var state_8480__$1 = state_8480;
var statearr_8487_8508 = state_8480__$1;
(statearr_8487_8508[(2)] = null);

(statearr_8487_8508[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8481 === (6))){
var inst_8457 = (state_8480[(7)]);
var inst_8463 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_8457) : p.call(null,inst_8457));
var state_8480__$1 = state_8480;
if(cljs.core.truth_(inst_8463)){
var statearr_8488_8509 = state_8480__$1;
(statearr_8488_8509[(1)] = (9));

} else {
var statearr_8489_8510 = state_8480__$1;
(statearr_8489_8510[(1)] = (10));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8481 === (3))){
var inst_8478 = (state_8480[(2)]);
var state_8480__$1 = state_8480;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8480__$1,inst_8478);
} else {
if((state_val_8481 === (12))){
var state_8480__$1 = state_8480;
var statearr_8490_8511 = state_8480__$1;
(statearr_8490_8511[(2)] = null);

(statearr_8490_8511[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8481 === (2))){
var state_8480__$1 = state_8480;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8480__$1,(4),ch);
} else {
if((state_val_8481 === (11))){
var inst_8457 = (state_8480[(7)]);
var inst_8467 = (state_8480[(2)]);
var state_8480__$1 = state_8480;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8480__$1,(8),inst_8467,inst_8457);
} else {
if((state_val_8481 === (9))){
var state_8480__$1 = state_8480;
var statearr_8491_8512 = state_8480__$1;
(statearr_8491_8512[(2)] = tc);

(statearr_8491_8512[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8481 === (5))){
var inst_8460 = cljs.core.async.close_BANG_(tc);
var inst_8461 = cljs.core.async.close_BANG_(fc);
var state_8480__$1 = (function (){var statearr_8492 = state_8480;
(statearr_8492[(8)] = inst_8460);

return statearr_8492;
})();
var statearr_8493_8513 = state_8480__$1;
(statearr_8493_8513[(2)] = inst_8461);

(statearr_8493_8513[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8481 === (14))){
var inst_8474 = (state_8480[(2)]);
var state_8480__$1 = state_8480;
var statearr_8494_8514 = state_8480__$1;
(statearr_8494_8514[(2)] = inst_8474);

(statearr_8494_8514[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8481 === (10))){
var state_8480__$1 = state_8480;
var statearr_8495_8515 = state_8480__$1;
(statearr_8495_8515[(2)] = fc);

(statearr_8495_8515[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8481 === (8))){
var inst_8469 = (state_8480[(2)]);
var state_8480__$1 = state_8480;
if(cljs.core.truth_(inst_8469)){
var statearr_8496_8516 = state_8480__$1;
(statearr_8496_8516[(1)] = (12));

} else {
var statearr_8497_8517 = state_8480__$1;
(statearr_8497_8517[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___8503,tc,fc))
;
return ((function (switch__7945__auto__,c__8052__auto___8503,tc,fc){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_8498 = [null,null,null,null,null,null,null,null,null];
(statearr_8498[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_8498[(1)] = (1));

return statearr_8498;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_8480){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_8480);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e8499){if((e8499 instanceof Object)){
var ex__7949__auto__ = e8499;
var statearr_8500_8518 = state_8480;
(statearr_8500_8518[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8480);

return cljs.core.cst$kw$recur;
} else {
throw e8499;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__8519 = state_8480;
state_8480 = G__8519;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_8480){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_8480);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___8503,tc,fc))
})();
var state__8054__auto__ = (function (){var statearr_8501 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_8501[(6)] = c__8052__auto___8503);

return statearr_8501;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___8503,tc,fc))
);


return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [tc,fc], null);
});

cljs.core.async.split.cljs$lang$maxFixedArity = 4;

/**
 * f should be a function of 2 arguments. Returns a channel containing
 *   the single result of applying f to init and the first item from the
 *   channel, then applying f to that result and the 2nd item, etc. If
 *   the channel closes without yielding items, returns init and f is not
 *   called. ch must close before reduce produces a result.
 */
cljs.core.async.reduce = (function cljs$core$async$reduce(f,init,ch){
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__){
return (function (state_8540){
var state_val_8541 = (state_8540[(1)]);
if((state_val_8541 === (7))){
var inst_8536 = (state_8540[(2)]);
var state_8540__$1 = state_8540;
var statearr_8542_8560 = state_8540__$1;
(statearr_8542_8560[(2)] = inst_8536);

(statearr_8542_8560[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8541 === (1))){
var inst_8520 = init;
var state_8540__$1 = (function (){var statearr_8543 = state_8540;
(statearr_8543[(7)] = inst_8520);

return statearr_8543;
})();
var statearr_8544_8561 = state_8540__$1;
(statearr_8544_8561[(2)] = null);

(statearr_8544_8561[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8541 === (4))){
var inst_8523 = (state_8540[(8)]);
var inst_8523__$1 = (state_8540[(2)]);
var inst_8524 = (inst_8523__$1 == null);
var state_8540__$1 = (function (){var statearr_8545 = state_8540;
(statearr_8545[(8)] = inst_8523__$1);

return statearr_8545;
})();
if(cljs.core.truth_(inst_8524)){
var statearr_8546_8562 = state_8540__$1;
(statearr_8546_8562[(1)] = (5));

} else {
var statearr_8547_8563 = state_8540__$1;
(statearr_8547_8563[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8541 === (6))){
var inst_8527 = (state_8540[(9)]);
var inst_8523 = (state_8540[(8)]);
var inst_8520 = (state_8540[(7)]);
var inst_8527__$1 = (f.cljs$core$IFn$_invoke$arity$2 ? f.cljs$core$IFn$_invoke$arity$2(inst_8520,inst_8523) : f.call(null,inst_8520,inst_8523));
var inst_8528 = cljs.core.reduced_QMARK_(inst_8527__$1);
var state_8540__$1 = (function (){var statearr_8548 = state_8540;
(statearr_8548[(9)] = inst_8527__$1);

return statearr_8548;
})();
if(inst_8528){
var statearr_8549_8564 = state_8540__$1;
(statearr_8549_8564[(1)] = (8));

} else {
var statearr_8550_8565 = state_8540__$1;
(statearr_8550_8565[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8541 === (3))){
var inst_8538 = (state_8540[(2)]);
var state_8540__$1 = state_8540;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8540__$1,inst_8538);
} else {
if((state_val_8541 === (2))){
var state_8540__$1 = state_8540;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8540__$1,(4),ch);
} else {
if((state_val_8541 === (9))){
var inst_8527 = (state_8540[(9)]);
var inst_8520 = inst_8527;
var state_8540__$1 = (function (){var statearr_8551 = state_8540;
(statearr_8551[(7)] = inst_8520);

return statearr_8551;
})();
var statearr_8552_8566 = state_8540__$1;
(statearr_8552_8566[(2)] = null);

(statearr_8552_8566[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8541 === (5))){
var inst_8520 = (state_8540[(7)]);
var state_8540__$1 = state_8540;
var statearr_8553_8567 = state_8540__$1;
(statearr_8553_8567[(2)] = inst_8520);

(statearr_8553_8567[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8541 === (10))){
var inst_8534 = (state_8540[(2)]);
var state_8540__$1 = state_8540;
var statearr_8554_8568 = state_8540__$1;
(statearr_8554_8568[(2)] = inst_8534);

(statearr_8554_8568[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8541 === (8))){
var inst_8527 = (state_8540[(9)]);
var inst_8530 = cljs.core.deref(inst_8527);
var state_8540__$1 = state_8540;
var statearr_8555_8569 = state_8540__$1;
(statearr_8555_8569[(2)] = inst_8530);

(statearr_8555_8569[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto__))
;
return ((function (switch__7945__auto__,c__8052__auto__){
return (function() {
var cljs$core$async$reduce_$_state_machine__7946__auto__ = null;
var cljs$core$async$reduce_$_state_machine__7946__auto____0 = (function (){
var statearr_8556 = [null,null,null,null,null,null,null,null,null,null];
(statearr_8556[(0)] = cljs$core$async$reduce_$_state_machine__7946__auto__);

(statearr_8556[(1)] = (1));

return statearr_8556;
});
var cljs$core$async$reduce_$_state_machine__7946__auto____1 = (function (state_8540){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_8540);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e8557){if((e8557 instanceof Object)){
var ex__7949__auto__ = e8557;
var statearr_8558_8570 = state_8540;
(statearr_8558_8570[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8540);

return cljs.core.cst$kw$recur;
} else {
throw e8557;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__8571 = state_8540;
state_8540 = G__8571;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$reduce_$_state_machine__7946__auto__ = function(state_8540){
switch(arguments.length){
case 0:
return cljs$core$async$reduce_$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$reduce_$_state_machine__7946__auto____1.call(this,state_8540);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$reduce_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$reduce_$_state_machine__7946__auto____0;
cljs$core$async$reduce_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$reduce_$_state_machine__7946__auto____1;
return cljs$core$async$reduce_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_8559 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_8559[(6)] = c__8052__auto__);

return statearr_8559;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__))
);

return c__8052__auto__;
});
/**
 * async/reduces a channel with a transformation (xform f).
 *   Returns a channel containing the result.  ch must close before
 *   transduce produces a result.
 */
cljs.core.async.transduce = (function cljs$core$async$transduce(xform,f,init,ch){
var f__$1 = (xform.cljs$core$IFn$_invoke$arity$1 ? xform.cljs$core$IFn$_invoke$arity$1(f) : xform.call(null,f));
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__,f__$1){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__,f__$1){
return (function (state_8577){
var state_val_8578 = (state_8577[(1)]);
if((state_val_8578 === (1))){
var inst_8572 = cljs.core.async.reduce(f__$1,init,ch);
var state_8577__$1 = state_8577;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8577__$1,(2),inst_8572);
} else {
if((state_val_8578 === (2))){
var inst_8574 = (state_8577[(2)]);
var inst_8575 = (f__$1.cljs$core$IFn$_invoke$arity$1 ? f__$1.cljs$core$IFn$_invoke$arity$1(inst_8574) : f__$1.call(null,inst_8574));
var state_8577__$1 = state_8577;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8577__$1,inst_8575);
} else {
return null;
}
}
});})(c__8052__auto__,f__$1))
;
return ((function (switch__7945__auto__,c__8052__auto__,f__$1){
return (function() {
var cljs$core$async$transduce_$_state_machine__7946__auto__ = null;
var cljs$core$async$transduce_$_state_machine__7946__auto____0 = (function (){
var statearr_8579 = [null,null,null,null,null,null,null];
(statearr_8579[(0)] = cljs$core$async$transduce_$_state_machine__7946__auto__);

(statearr_8579[(1)] = (1));

return statearr_8579;
});
var cljs$core$async$transduce_$_state_machine__7946__auto____1 = (function (state_8577){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_8577);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e8580){if((e8580 instanceof Object)){
var ex__7949__auto__ = e8580;
var statearr_8581_8583 = state_8577;
(statearr_8581_8583[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8577);

return cljs.core.cst$kw$recur;
} else {
throw e8580;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__8584 = state_8577;
state_8577 = G__8584;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$transduce_$_state_machine__7946__auto__ = function(state_8577){
switch(arguments.length){
case 0:
return cljs$core$async$transduce_$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$transduce_$_state_machine__7946__auto____1.call(this,state_8577);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$transduce_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$transduce_$_state_machine__7946__auto____0;
cljs$core$async$transduce_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$transduce_$_state_machine__7946__auto____1;
return cljs$core$async$transduce_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__,f__$1))
})();
var state__8054__auto__ = (function (){var statearr_8582 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_8582[(6)] = c__8052__auto__);

return statearr_8582;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__,f__$1))
);

return c__8052__auto__;
});
/**
 * Puts the contents of coll into the supplied channel.
 * 
 *   By default the channel will be closed after the items are copied,
 *   but can be determined by the close? parameter.
 * 
 *   Returns a channel which will close after the items are copied.
 */
cljs.core.async.onto_chan = (function cljs$core$async$onto_chan(var_args){
var G__8586 = arguments.length;
switch (G__8586) {
case 2:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2 = (function (ch,coll){
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3(ch,coll,true);
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3 = (function (ch,coll,close_QMARK_){
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__){
return (function (state_8611){
var state_val_8612 = (state_8611[(1)]);
if((state_val_8612 === (7))){
var inst_8593 = (state_8611[(2)]);
var state_8611__$1 = state_8611;
var statearr_8613_8634 = state_8611__$1;
(statearr_8613_8634[(2)] = inst_8593);

(statearr_8613_8634[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8612 === (1))){
var inst_8587 = cljs.core.seq(coll);
var inst_8588 = inst_8587;
var state_8611__$1 = (function (){var statearr_8614 = state_8611;
(statearr_8614[(7)] = inst_8588);

return statearr_8614;
})();
var statearr_8615_8635 = state_8611__$1;
(statearr_8615_8635[(2)] = null);

(statearr_8615_8635[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8612 === (4))){
var inst_8588 = (state_8611[(7)]);
var inst_8591 = cljs.core.first(inst_8588);
var state_8611__$1 = state_8611;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_8611__$1,(7),ch,inst_8591);
} else {
if((state_val_8612 === (13))){
var inst_8605 = (state_8611[(2)]);
var state_8611__$1 = state_8611;
var statearr_8616_8636 = state_8611__$1;
(statearr_8616_8636[(2)] = inst_8605);

(statearr_8616_8636[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8612 === (6))){
var inst_8596 = (state_8611[(2)]);
var state_8611__$1 = state_8611;
if(cljs.core.truth_(inst_8596)){
var statearr_8617_8637 = state_8611__$1;
(statearr_8617_8637[(1)] = (8));

} else {
var statearr_8618_8638 = state_8611__$1;
(statearr_8618_8638[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8612 === (3))){
var inst_8609 = (state_8611[(2)]);
var state_8611__$1 = state_8611;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8611__$1,inst_8609);
} else {
if((state_val_8612 === (12))){
var state_8611__$1 = state_8611;
var statearr_8619_8639 = state_8611__$1;
(statearr_8619_8639[(2)] = null);

(statearr_8619_8639[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8612 === (2))){
var inst_8588 = (state_8611[(7)]);
var state_8611__$1 = state_8611;
if(cljs.core.truth_(inst_8588)){
var statearr_8620_8640 = state_8611__$1;
(statearr_8620_8640[(1)] = (4));

} else {
var statearr_8621_8641 = state_8611__$1;
(statearr_8621_8641[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8612 === (11))){
var inst_8602 = cljs.core.async.close_BANG_(ch);
var state_8611__$1 = state_8611;
var statearr_8622_8642 = state_8611__$1;
(statearr_8622_8642[(2)] = inst_8602);

(statearr_8622_8642[(1)] = (13));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8612 === (9))){
var state_8611__$1 = state_8611;
if(cljs.core.truth_(close_QMARK_)){
var statearr_8623_8643 = state_8611__$1;
(statearr_8623_8643[(1)] = (11));

} else {
var statearr_8624_8644 = state_8611__$1;
(statearr_8624_8644[(1)] = (12));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8612 === (5))){
var inst_8588 = (state_8611[(7)]);
var state_8611__$1 = state_8611;
var statearr_8625_8645 = state_8611__$1;
(statearr_8625_8645[(2)] = inst_8588);

(statearr_8625_8645[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8612 === (10))){
var inst_8607 = (state_8611[(2)]);
var state_8611__$1 = state_8611;
var statearr_8626_8646 = state_8611__$1;
(statearr_8626_8646[(2)] = inst_8607);

(statearr_8626_8646[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8612 === (8))){
var inst_8588 = (state_8611[(7)]);
var inst_8598 = cljs.core.next(inst_8588);
var inst_8588__$1 = inst_8598;
var state_8611__$1 = (function (){var statearr_8627 = state_8611;
(statearr_8627[(7)] = inst_8588__$1);

return statearr_8627;
})();
var statearr_8628_8647 = state_8611__$1;
(statearr_8628_8647[(2)] = null);

(statearr_8628_8647[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto__))
;
return ((function (switch__7945__auto__,c__8052__auto__){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_8629 = [null,null,null,null,null,null,null,null];
(statearr_8629[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_8629[(1)] = (1));

return statearr_8629;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_8611){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_8611);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e8630){if((e8630 instanceof Object)){
var ex__7949__auto__ = e8630;
var statearr_8631_8648 = state_8611;
(statearr_8631_8648[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8611);

return cljs.core.cst$kw$recur;
} else {
throw e8630;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__8649 = state_8611;
state_8611 = G__8649;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_8611){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_8611);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_8632 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_8632[(6)] = c__8052__auto__);

return statearr_8632;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__))
);

return c__8052__auto__;
});

cljs.core.async.onto_chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates and returns a channel which contains the contents of coll,
 *   closing when exhausted.
 */
cljs.core.async.to_chan = (function cljs$core$async$to_chan(coll){
var ch = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(cljs.core.bounded_count((100),coll));
cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2(ch,coll);

return ch;
});

/**
 * @interface
 */
cljs.core.async.Mux = function(){};

cljs.core.async.muxch_STAR_ = (function cljs$core$async$muxch_STAR_(_){
if((((!((_ == null)))) && ((!((_.cljs$core$async$Mux$muxch_STAR_$arity$1 == null)))))){
return _.cljs$core$async$Mux$muxch_STAR_$arity$1(_);
} else {
var x__4433__auto__ = (((_ == null))?null:_);
var m__4434__auto__ = (cljs.core.async.muxch_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(_) : m__4434__auto__.call(null,_));
} else {
var m__4431__auto__ = (cljs.core.async.muxch_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(_) : m__4431__auto__.call(null,_));
} else {
throw cljs.core.missing_protocol("Mux.muxch*",_);
}
}
}
});


/**
 * @interface
 */
cljs.core.async.Mult = function(){};

cljs.core.async.tap_STAR_ = (function cljs$core$async$tap_STAR_(m,ch,close_QMARK_){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$tap_STAR_$arity$3 == null)))))){
return m.cljs$core$async$Mult$tap_STAR_$arity$3(m,ch,close_QMARK_);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.tap_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4434__auto__.call(null,m,ch,close_QMARK_));
} else {
var m__4431__auto__ = (cljs.core.async.tap_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$3(m,ch,close_QMARK_) : m__4431__auto__.call(null,m,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Mult.tap*",m);
}
}
}
});

cljs.core.async.untap_STAR_ = (function cljs$core$async$untap_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mult$untap_STAR_$arity$2(m,ch);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.untap_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4434__auto__.call(null,m,ch));
} else {
var m__4431__auto__ = (cljs.core.async.untap_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4431__auto__.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mult.untap*",m);
}
}
}
});

cljs.core.async.untap_all_STAR_ = (function cljs$core$async$untap_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mult$untap_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mult$untap_all_STAR_$arity$1(m);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.untap_all_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4434__auto__.call(null,m));
} else {
var m__4431__auto__ = (cljs.core.async.untap_all_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4431__auto__.call(null,m));
} else {
throw cljs.core.missing_protocol("Mult.untap-all*",m);
}
}
}
});

/**
 * Creates and returns a mult(iple) of the supplied channel. Channels
 *   containing copies of the channel can be created with 'tap', and
 *   detached with 'untap'.
 * 
 *   Each item is distributed to all taps in parallel and synchronously,
 *   i.e. each tap must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow taps from holding up the mult.
 * 
 *   Items received when there are no taps get dropped.
 * 
 *   If a tap puts to a closed channel, it will be removed from the mult.
 */
cljs.core.async.mult = (function cljs$core$async$mult(ch){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async8650 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Mult}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async8650 = (function (ch,cs,meta8651){
this.ch = ch;
this.cs = cs;
this.meta8651 = meta8651;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async8650.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs){
return (function (_8652,meta8651__$1){
var self__ = this;
var _8652__$1 = this;
return (new cljs.core.async.t_cljs$core$async8650(self__.ch,self__.cs,meta8651__$1));
});})(cs))
;

cljs.core.async.t_cljs$core$async8650.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs){
return (function (_8652){
var self__ = this;
var _8652__$1 = this;
return self__.meta8651;
});})(cs))
;

cljs.core.async.t_cljs$core$async8650.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8650.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(cs))
;

cljs.core.async.t_cljs$core$async8650.prototype.cljs$core$async$Mult$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8650.prototype.cljs$core$async$Mult$tap_STAR_$arity$3 = ((function (cs){
return (function (_,ch__$1,close_QMARK_){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch__$1,close_QMARK_);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async8650.prototype.cljs$core$async$Mult$untap_STAR_$arity$2 = ((function (cs){
return (function (_,ch__$1){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch__$1);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async8650.prototype.cljs$core$async$Mult$untap_all_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async8650.getBasis = ((function (cs){
return (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$cs,cljs.core.cst$sym$meta8651], null);
});})(cs))
;

cljs.core.async.t_cljs$core$async8650.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async8650.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async8650";

cljs.core.async.t_cljs$core$async8650.cljs$lang$ctorPrWriter = ((function (cs){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async8650");
});})(cs))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async8650.
 */
cljs.core.async.__GT_t_cljs$core$async8650 = ((function (cs){
return (function cljs$core$async$mult_$___GT_t_cljs$core$async8650(ch__$1,cs__$1,meta8651){
return (new cljs.core.async.t_cljs$core$async8650(ch__$1,cs__$1,meta8651));
});})(cs))
;

}

return (new cljs.core.async.t_cljs$core$async8650(ch,cs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = ((function (cs,m,dchan,dctr){
return (function (_){
if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,true);
} else {
return null;
}
});})(cs,m,dchan,dctr))
;
var c__8052__auto___8872 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___8872,cs,m,dchan,dctr,done){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___8872,cs,m,dchan,dctr,done){
return (function (state_8787){
var state_val_8788 = (state_8787[(1)]);
if((state_val_8788 === (7))){
var inst_8783 = (state_8787[(2)]);
var state_8787__$1 = state_8787;
var statearr_8789_8873 = state_8787__$1;
(statearr_8789_8873[(2)] = inst_8783);

(statearr_8789_8873[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (20))){
var inst_8686 = (state_8787[(7)]);
var inst_8698 = cljs.core.first(inst_8686);
var inst_8699 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_8698,(0),null);
var inst_8700 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_8698,(1),null);
var state_8787__$1 = (function (){var statearr_8790 = state_8787;
(statearr_8790[(8)] = inst_8699);

return statearr_8790;
})();
if(cljs.core.truth_(inst_8700)){
var statearr_8791_8874 = state_8787__$1;
(statearr_8791_8874[(1)] = (22));

} else {
var statearr_8792_8875 = state_8787__$1;
(statearr_8792_8875[(1)] = (23));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (27))){
var inst_8735 = (state_8787[(9)]);
var inst_8728 = (state_8787[(10)]);
var inst_8655 = (state_8787[(11)]);
var inst_8730 = (state_8787[(12)]);
var inst_8735__$1 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_8728,inst_8730);
var inst_8736 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_8735__$1,inst_8655,done);
var state_8787__$1 = (function (){var statearr_8793 = state_8787;
(statearr_8793[(9)] = inst_8735__$1);

return statearr_8793;
})();
if(cljs.core.truth_(inst_8736)){
var statearr_8794_8876 = state_8787__$1;
(statearr_8794_8876[(1)] = (30));

} else {
var statearr_8795_8877 = state_8787__$1;
(statearr_8795_8877[(1)] = (31));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (1))){
var state_8787__$1 = state_8787;
var statearr_8796_8878 = state_8787__$1;
(statearr_8796_8878[(2)] = null);

(statearr_8796_8878[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (24))){
var inst_8686 = (state_8787[(7)]);
var inst_8705 = (state_8787[(2)]);
var inst_8706 = cljs.core.next(inst_8686);
var inst_8664 = inst_8706;
var inst_8665 = null;
var inst_8666 = (0);
var inst_8667 = (0);
var state_8787__$1 = (function (){var statearr_8797 = state_8787;
(statearr_8797[(13)] = inst_8666);

(statearr_8797[(14)] = inst_8705);

(statearr_8797[(15)] = inst_8664);

(statearr_8797[(16)] = inst_8665);

(statearr_8797[(17)] = inst_8667);

return statearr_8797;
})();
var statearr_8798_8879 = state_8787__$1;
(statearr_8798_8879[(2)] = null);

(statearr_8798_8879[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (39))){
var state_8787__$1 = state_8787;
var statearr_8802_8880 = state_8787__$1;
(statearr_8802_8880[(2)] = null);

(statearr_8802_8880[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (4))){
var inst_8655 = (state_8787[(11)]);
var inst_8655__$1 = (state_8787[(2)]);
var inst_8656 = (inst_8655__$1 == null);
var state_8787__$1 = (function (){var statearr_8803 = state_8787;
(statearr_8803[(11)] = inst_8655__$1);

return statearr_8803;
})();
if(cljs.core.truth_(inst_8656)){
var statearr_8804_8881 = state_8787__$1;
(statearr_8804_8881[(1)] = (5));

} else {
var statearr_8805_8882 = state_8787__$1;
(statearr_8805_8882[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (15))){
var inst_8666 = (state_8787[(13)]);
var inst_8664 = (state_8787[(15)]);
var inst_8665 = (state_8787[(16)]);
var inst_8667 = (state_8787[(17)]);
var inst_8682 = (state_8787[(2)]);
var inst_8683 = (inst_8667 + (1));
var tmp8799 = inst_8666;
var tmp8800 = inst_8664;
var tmp8801 = inst_8665;
var inst_8664__$1 = tmp8800;
var inst_8665__$1 = tmp8801;
var inst_8666__$1 = tmp8799;
var inst_8667__$1 = inst_8683;
var state_8787__$1 = (function (){var statearr_8806 = state_8787;
(statearr_8806[(13)] = inst_8666__$1);

(statearr_8806[(15)] = inst_8664__$1);

(statearr_8806[(16)] = inst_8665__$1);

(statearr_8806[(18)] = inst_8682);

(statearr_8806[(17)] = inst_8667__$1);

return statearr_8806;
})();
var statearr_8807_8883 = state_8787__$1;
(statearr_8807_8883[(2)] = null);

(statearr_8807_8883[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (21))){
var inst_8709 = (state_8787[(2)]);
var state_8787__$1 = state_8787;
var statearr_8811_8884 = state_8787__$1;
(statearr_8811_8884[(2)] = inst_8709);

(statearr_8811_8884[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (31))){
var inst_8735 = (state_8787[(9)]);
var inst_8739 = done(null);
var inst_8740 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_8735);
var state_8787__$1 = (function (){var statearr_8812 = state_8787;
(statearr_8812[(19)] = inst_8739);

return statearr_8812;
})();
var statearr_8813_8885 = state_8787__$1;
(statearr_8813_8885[(2)] = inst_8740);

(statearr_8813_8885[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (32))){
var inst_8727 = (state_8787[(20)]);
var inst_8728 = (state_8787[(10)]);
var inst_8730 = (state_8787[(12)]);
var inst_8729 = (state_8787[(21)]);
var inst_8742 = (state_8787[(2)]);
var inst_8743 = (inst_8730 + (1));
var tmp8808 = inst_8727;
var tmp8809 = inst_8728;
var tmp8810 = inst_8729;
var inst_8727__$1 = tmp8808;
var inst_8728__$1 = tmp8809;
var inst_8729__$1 = tmp8810;
var inst_8730__$1 = inst_8743;
var state_8787__$1 = (function (){var statearr_8814 = state_8787;
(statearr_8814[(20)] = inst_8727__$1);

(statearr_8814[(22)] = inst_8742);

(statearr_8814[(10)] = inst_8728__$1);

(statearr_8814[(12)] = inst_8730__$1);

(statearr_8814[(21)] = inst_8729__$1);

return statearr_8814;
})();
var statearr_8815_8886 = state_8787__$1;
(statearr_8815_8886[(2)] = null);

(statearr_8815_8886[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (40))){
var inst_8755 = (state_8787[(23)]);
var inst_8759 = done(null);
var inst_8760 = m.cljs$core$async$Mult$untap_STAR_$arity$2(null,inst_8755);
var state_8787__$1 = (function (){var statearr_8816 = state_8787;
(statearr_8816[(24)] = inst_8759);

return statearr_8816;
})();
var statearr_8817_8887 = state_8787__$1;
(statearr_8817_8887[(2)] = inst_8760);

(statearr_8817_8887[(1)] = (41));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (33))){
var inst_8746 = (state_8787[(25)]);
var inst_8748 = cljs.core.chunked_seq_QMARK_(inst_8746);
var state_8787__$1 = state_8787;
if(inst_8748){
var statearr_8818_8888 = state_8787__$1;
(statearr_8818_8888[(1)] = (36));

} else {
var statearr_8819_8889 = state_8787__$1;
(statearr_8819_8889[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (13))){
var inst_8676 = (state_8787[(26)]);
var inst_8679 = cljs.core.async.close_BANG_(inst_8676);
var state_8787__$1 = state_8787;
var statearr_8820_8890 = state_8787__$1;
(statearr_8820_8890[(2)] = inst_8679);

(statearr_8820_8890[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (22))){
var inst_8699 = (state_8787[(8)]);
var inst_8702 = cljs.core.async.close_BANG_(inst_8699);
var state_8787__$1 = state_8787;
var statearr_8821_8891 = state_8787__$1;
(statearr_8821_8891[(2)] = inst_8702);

(statearr_8821_8891[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (36))){
var inst_8746 = (state_8787[(25)]);
var inst_8750 = cljs.core.chunk_first(inst_8746);
var inst_8751 = cljs.core.chunk_rest(inst_8746);
var inst_8752 = cljs.core.count(inst_8750);
var inst_8727 = inst_8751;
var inst_8728 = inst_8750;
var inst_8729 = inst_8752;
var inst_8730 = (0);
var state_8787__$1 = (function (){var statearr_8822 = state_8787;
(statearr_8822[(20)] = inst_8727);

(statearr_8822[(10)] = inst_8728);

(statearr_8822[(12)] = inst_8730);

(statearr_8822[(21)] = inst_8729);

return statearr_8822;
})();
var statearr_8823_8892 = state_8787__$1;
(statearr_8823_8892[(2)] = null);

(statearr_8823_8892[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (41))){
var inst_8746 = (state_8787[(25)]);
var inst_8762 = (state_8787[(2)]);
var inst_8763 = cljs.core.next(inst_8746);
var inst_8727 = inst_8763;
var inst_8728 = null;
var inst_8729 = (0);
var inst_8730 = (0);
var state_8787__$1 = (function (){var statearr_8824 = state_8787;
(statearr_8824[(20)] = inst_8727);

(statearr_8824[(27)] = inst_8762);

(statearr_8824[(10)] = inst_8728);

(statearr_8824[(12)] = inst_8730);

(statearr_8824[(21)] = inst_8729);

return statearr_8824;
})();
var statearr_8825_8893 = state_8787__$1;
(statearr_8825_8893[(2)] = null);

(statearr_8825_8893[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (43))){
var state_8787__$1 = state_8787;
var statearr_8826_8894 = state_8787__$1;
(statearr_8826_8894[(2)] = null);

(statearr_8826_8894[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (29))){
var inst_8771 = (state_8787[(2)]);
var state_8787__$1 = state_8787;
var statearr_8827_8895 = state_8787__$1;
(statearr_8827_8895[(2)] = inst_8771);

(statearr_8827_8895[(1)] = (26));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (44))){
var inst_8780 = (state_8787[(2)]);
var state_8787__$1 = (function (){var statearr_8828 = state_8787;
(statearr_8828[(28)] = inst_8780);

return statearr_8828;
})();
var statearr_8829_8896 = state_8787__$1;
(statearr_8829_8896[(2)] = null);

(statearr_8829_8896[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (6))){
var inst_8719 = (state_8787[(29)]);
var inst_8718 = cljs.core.deref(cs);
var inst_8719__$1 = cljs.core.keys(inst_8718);
var inst_8720 = cljs.core.count(inst_8719__$1);
var inst_8721 = cljs.core.reset_BANG_(dctr,inst_8720);
var inst_8726 = cljs.core.seq(inst_8719__$1);
var inst_8727 = inst_8726;
var inst_8728 = null;
var inst_8729 = (0);
var inst_8730 = (0);
var state_8787__$1 = (function (){var statearr_8830 = state_8787;
(statearr_8830[(29)] = inst_8719__$1);

(statearr_8830[(20)] = inst_8727);

(statearr_8830[(30)] = inst_8721);

(statearr_8830[(10)] = inst_8728);

(statearr_8830[(12)] = inst_8730);

(statearr_8830[(21)] = inst_8729);

return statearr_8830;
})();
var statearr_8831_8897 = state_8787__$1;
(statearr_8831_8897[(2)] = null);

(statearr_8831_8897[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (28))){
var inst_8727 = (state_8787[(20)]);
var inst_8746 = (state_8787[(25)]);
var inst_8746__$1 = cljs.core.seq(inst_8727);
var state_8787__$1 = (function (){var statearr_8832 = state_8787;
(statearr_8832[(25)] = inst_8746__$1);

return statearr_8832;
})();
if(inst_8746__$1){
var statearr_8833_8898 = state_8787__$1;
(statearr_8833_8898[(1)] = (33));

} else {
var statearr_8834_8899 = state_8787__$1;
(statearr_8834_8899[(1)] = (34));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (25))){
var inst_8730 = (state_8787[(12)]);
var inst_8729 = (state_8787[(21)]);
var inst_8732 = (inst_8730 < inst_8729);
var inst_8733 = inst_8732;
var state_8787__$1 = state_8787;
if(cljs.core.truth_(inst_8733)){
var statearr_8835_8900 = state_8787__$1;
(statearr_8835_8900[(1)] = (27));

} else {
var statearr_8836_8901 = state_8787__$1;
(statearr_8836_8901[(1)] = (28));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (34))){
var state_8787__$1 = state_8787;
var statearr_8837_8902 = state_8787__$1;
(statearr_8837_8902[(2)] = null);

(statearr_8837_8902[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (17))){
var state_8787__$1 = state_8787;
var statearr_8838_8903 = state_8787__$1;
(statearr_8838_8903[(2)] = null);

(statearr_8838_8903[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (3))){
var inst_8785 = (state_8787[(2)]);
var state_8787__$1 = state_8787;
return cljs.core.async.impl.ioc_helpers.return_chan(state_8787__$1,inst_8785);
} else {
if((state_val_8788 === (12))){
var inst_8714 = (state_8787[(2)]);
var state_8787__$1 = state_8787;
var statearr_8839_8904 = state_8787__$1;
(statearr_8839_8904[(2)] = inst_8714);

(statearr_8839_8904[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (2))){
var state_8787__$1 = state_8787;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8787__$1,(4),ch);
} else {
if((state_val_8788 === (23))){
var state_8787__$1 = state_8787;
var statearr_8840_8905 = state_8787__$1;
(statearr_8840_8905[(2)] = null);

(statearr_8840_8905[(1)] = (24));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (35))){
var inst_8769 = (state_8787[(2)]);
var state_8787__$1 = state_8787;
var statearr_8841_8906 = state_8787__$1;
(statearr_8841_8906[(2)] = inst_8769);

(statearr_8841_8906[(1)] = (29));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (19))){
var inst_8686 = (state_8787[(7)]);
var inst_8690 = cljs.core.chunk_first(inst_8686);
var inst_8691 = cljs.core.chunk_rest(inst_8686);
var inst_8692 = cljs.core.count(inst_8690);
var inst_8664 = inst_8691;
var inst_8665 = inst_8690;
var inst_8666 = inst_8692;
var inst_8667 = (0);
var state_8787__$1 = (function (){var statearr_8842 = state_8787;
(statearr_8842[(13)] = inst_8666);

(statearr_8842[(15)] = inst_8664);

(statearr_8842[(16)] = inst_8665);

(statearr_8842[(17)] = inst_8667);

return statearr_8842;
})();
var statearr_8843_8907 = state_8787__$1;
(statearr_8843_8907[(2)] = null);

(statearr_8843_8907[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (11))){
var inst_8664 = (state_8787[(15)]);
var inst_8686 = (state_8787[(7)]);
var inst_8686__$1 = cljs.core.seq(inst_8664);
var state_8787__$1 = (function (){var statearr_8844 = state_8787;
(statearr_8844[(7)] = inst_8686__$1);

return statearr_8844;
})();
if(inst_8686__$1){
var statearr_8845_8908 = state_8787__$1;
(statearr_8845_8908[(1)] = (16));

} else {
var statearr_8846_8909 = state_8787__$1;
(statearr_8846_8909[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (9))){
var inst_8716 = (state_8787[(2)]);
var state_8787__$1 = state_8787;
var statearr_8847_8910 = state_8787__$1;
(statearr_8847_8910[(2)] = inst_8716);

(statearr_8847_8910[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (5))){
var inst_8662 = cljs.core.deref(cs);
var inst_8663 = cljs.core.seq(inst_8662);
var inst_8664 = inst_8663;
var inst_8665 = null;
var inst_8666 = (0);
var inst_8667 = (0);
var state_8787__$1 = (function (){var statearr_8848 = state_8787;
(statearr_8848[(13)] = inst_8666);

(statearr_8848[(15)] = inst_8664);

(statearr_8848[(16)] = inst_8665);

(statearr_8848[(17)] = inst_8667);

return statearr_8848;
})();
var statearr_8849_8911 = state_8787__$1;
(statearr_8849_8911[(2)] = null);

(statearr_8849_8911[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (14))){
var state_8787__$1 = state_8787;
var statearr_8850_8912 = state_8787__$1;
(statearr_8850_8912[(2)] = null);

(statearr_8850_8912[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (45))){
var inst_8777 = (state_8787[(2)]);
var state_8787__$1 = state_8787;
var statearr_8851_8913 = state_8787__$1;
(statearr_8851_8913[(2)] = inst_8777);

(statearr_8851_8913[(1)] = (44));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (26))){
var inst_8719 = (state_8787[(29)]);
var inst_8773 = (state_8787[(2)]);
var inst_8774 = cljs.core.seq(inst_8719);
var state_8787__$1 = (function (){var statearr_8852 = state_8787;
(statearr_8852[(31)] = inst_8773);

return statearr_8852;
})();
if(inst_8774){
var statearr_8853_8914 = state_8787__$1;
(statearr_8853_8914[(1)] = (42));

} else {
var statearr_8854_8915 = state_8787__$1;
(statearr_8854_8915[(1)] = (43));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (16))){
var inst_8686 = (state_8787[(7)]);
var inst_8688 = cljs.core.chunked_seq_QMARK_(inst_8686);
var state_8787__$1 = state_8787;
if(inst_8688){
var statearr_8855_8916 = state_8787__$1;
(statearr_8855_8916[(1)] = (19));

} else {
var statearr_8856_8917 = state_8787__$1;
(statearr_8856_8917[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (38))){
var inst_8766 = (state_8787[(2)]);
var state_8787__$1 = state_8787;
var statearr_8857_8918 = state_8787__$1;
(statearr_8857_8918[(2)] = inst_8766);

(statearr_8857_8918[(1)] = (35));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (30))){
var state_8787__$1 = state_8787;
var statearr_8858_8919 = state_8787__$1;
(statearr_8858_8919[(2)] = null);

(statearr_8858_8919[(1)] = (32));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (10))){
var inst_8665 = (state_8787[(16)]);
var inst_8667 = (state_8787[(17)]);
var inst_8675 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_8665,inst_8667);
var inst_8676 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_8675,(0),null);
var inst_8677 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_8675,(1),null);
var state_8787__$1 = (function (){var statearr_8859 = state_8787;
(statearr_8859[(26)] = inst_8676);

return statearr_8859;
})();
if(cljs.core.truth_(inst_8677)){
var statearr_8860_8920 = state_8787__$1;
(statearr_8860_8920[(1)] = (13));

} else {
var statearr_8861_8921 = state_8787__$1;
(statearr_8861_8921[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (18))){
var inst_8712 = (state_8787[(2)]);
var state_8787__$1 = state_8787;
var statearr_8862_8922 = state_8787__$1;
(statearr_8862_8922[(2)] = inst_8712);

(statearr_8862_8922[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (42))){
var state_8787__$1 = state_8787;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_8787__$1,(45),dchan);
} else {
if((state_val_8788 === (37))){
var inst_8755 = (state_8787[(23)]);
var inst_8746 = (state_8787[(25)]);
var inst_8655 = (state_8787[(11)]);
var inst_8755__$1 = cljs.core.first(inst_8746);
var inst_8756 = cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3(inst_8755__$1,inst_8655,done);
var state_8787__$1 = (function (){var statearr_8863 = state_8787;
(statearr_8863[(23)] = inst_8755__$1);

return statearr_8863;
})();
if(cljs.core.truth_(inst_8756)){
var statearr_8864_8923 = state_8787__$1;
(statearr_8864_8923[(1)] = (39));

} else {
var statearr_8865_8924 = state_8787__$1;
(statearr_8865_8924[(1)] = (40));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_8788 === (8))){
var inst_8666 = (state_8787[(13)]);
var inst_8667 = (state_8787[(17)]);
var inst_8669 = (inst_8667 < inst_8666);
var inst_8670 = inst_8669;
var state_8787__$1 = state_8787;
if(cljs.core.truth_(inst_8670)){
var statearr_8866_8925 = state_8787__$1;
(statearr_8866_8925[(1)] = (10));

} else {
var statearr_8867_8926 = state_8787__$1;
(statearr_8867_8926[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___8872,cs,m,dchan,dctr,done))
;
return ((function (switch__7945__auto__,c__8052__auto___8872,cs,m,dchan,dctr,done){
return (function() {
var cljs$core$async$mult_$_state_machine__7946__auto__ = null;
var cljs$core$async$mult_$_state_machine__7946__auto____0 = (function (){
var statearr_8868 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_8868[(0)] = cljs$core$async$mult_$_state_machine__7946__auto__);

(statearr_8868[(1)] = (1));

return statearr_8868;
});
var cljs$core$async$mult_$_state_machine__7946__auto____1 = (function (state_8787){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_8787);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e8869){if((e8869 instanceof Object)){
var ex__7949__auto__ = e8869;
var statearr_8870_8927 = state_8787;
(statearr_8870_8927[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_8787);

return cljs.core.cst$kw$recur;
} else {
throw e8869;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__8928 = state_8787;
state_8787 = G__8928;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$mult_$_state_machine__7946__auto__ = function(state_8787){
switch(arguments.length){
case 0:
return cljs$core$async$mult_$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$mult_$_state_machine__7946__auto____1.call(this,state_8787);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mult_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mult_$_state_machine__7946__auto____0;
cljs$core$async$mult_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mult_$_state_machine__7946__auto____1;
return cljs$core$async$mult_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___8872,cs,m,dchan,dctr,done))
})();
var state__8054__auto__ = (function (){var statearr_8871 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_8871[(6)] = c__8052__auto___8872);

return statearr_8871;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___8872,cs,m,dchan,dctr,done))
);


return m;
});
/**
 * Copies the mult source onto the supplied channel.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.tap = (function cljs$core$async$tap(var_args){
var G__8930 = arguments.length;
switch (G__8930) {
case 2:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2 = (function (mult,ch){
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(mult,ch,true);
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3 = (function (mult,ch,close_QMARK_){
cljs.core.async.tap_STAR_(mult,ch,close_QMARK_);

return ch;
});

cljs.core.async.tap.cljs$lang$maxFixedArity = 3;

/**
 * Disconnects a target channel from a mult
 */
cljs.core.async.untap = (function cljs$core$async$untap(mult,ch){
return cljs.core.async.untap_STAR_(mult,ch);
});
/**
 * Disconnects all target channels from a mult
 */
cljs.core.async.untap_all = (function cljs$core$async$untap_all(mult){
return cljs.core.async.untap_all_STAR_(mult);
});

/**
 * @interface
 */
cljs.core.async.Mix = function(){};

cljs.core.async.admix_STAR_ = (function cljs$core$async$admix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$admix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$admix_STAR_$arity$2(m,ch);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.admix_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4434__auto__.call(null,m,ch));
} else {
var m__4431__auto__ = (cljs.core.async.admix_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4431__auto__.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.admix*",m);
}
}
}
});

cljs.core.async.unmix_STAR_ = (function cljs$core$async$unmix_STAR_(m,ch){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$unmix_STAR_$arity$2(m,ch);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.unmix_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4434__auto__.call(null,m,ch));
} else {
var m__4431__auto__ = (cljs.core.async.unmix_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,ch) : m__4431__auto__.call(null,m,ch));
} else {
throw cljs.core.missing_protocol("Mix.unmix*",m);
}
}
}
});

cljs.core.async.unmix_all_STAR_ = (function cljs$core$async$unmix_all_STAR_(m){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$unmix_all_STAR_$arity$1 == null)))))){
return m.cljs$core$async$Mix$unmix_all_STAR_$arity$1(m);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.unmix_all_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4434__auto__.call(null,m));
} else {
var m__4431__auto__ = (cljs.core.async.unmix_all_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(m) : m__4431__auto__.call(null,m));
} else {
throw cljs.core.missing_protocol("Mix.unmix-all*",m);
}
}
}
});

cljs.core.async.toggle_STAR_ = (function cljs$core$async$toggle_STAR_(m,state_map){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$toggle_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$toggle_STAR_$arity$2(m,state_map);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.toggle_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4434__auto__.call(null,m,state_map));
} else {
var m__4431__auto__ = (cljs.core.async.toggle_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,state_map) : m__4431__auto__.call(null,m,state_map));
} else {
throw cljs.core.missing_protocol("Mix.toggle*",m);
}
}
}
});

cljs.core.async.solo_mode_STAR_ = (function cljs$core$async$solo_mode_STAR_(m,mode){
if((((!((m == null)))) && ((!((m.cljs$core$async$Mix$solo_mode_STAR_$arity$2 == null)))))){
return m.cljs$core$async$Mix$solo_mode_STAR_$arity$2(m,mode);
} else {
var x__4433__auto__ = (((m == null))?null:m);
var m__4434__auto__ = (cljs.core.async.solo_mode_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4434__auto__.call(null,m,mode));
} else {
var m__4431__auto__ = (cljs.core.async.solo_mode_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(m,mode) : m__4431__auto__.call(null,m,mode));
} else {
throw cljs.core.missing_protocol("Mix.solo-mode*",m);
}
}
}
});

cljs.core.async.ioc_alts_BANG_ = (function cljs$core$async$ioc_alts_BANG_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___8942 = arguments.length;
var i__4731__auto___8943 = (0);
while(true){
if((i__4731__auto___8943 < len__4730__auto___8942)){
args__4736__auto__.push((arguments[i__4731__auto___8943]));

var G__8944 = (i__4731__auto___8943 + (1));
i__4731__auto___8943 = G__8944;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((3) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((3)),(0),null)):null);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__4737__auto__);
});

cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (state,cont_block,ports,p__8936){
var map__8937 = p__8936;
var map__8937__$1 = (((((!((map__8937 == null))))?(((((map__8937.cljs$lang$protocol_mask$partition0$ & (64))) || ((cljs.core.PROTOCOL_SENTINEL === map__8937.cljs$core$ISeq$))))?true:false):false))?cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,map__8937):map__8937);
var opts = map__8937__$1;
var statearr_8939_8945 = state;
(statearr_8939_8945[(1)] = cont_block);


var temp__5735__auto__ = cljs.core.async.do_alts(((function (map__8937,map__8937__$1,opts){
return (function (val){
var statearr_8940_8946 = state;
(statearr_8940_8946[(2)] = val);


return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state);
});})(map__8937,map__8937__$1,opts))
,ports,opts);
if(cljs.core.truth_(temp__5735__auto__)){
var cb = temp__5735__auto__;
var statearr_8941_8947 = state;
(statearr_8941_8947[(2)] = cljs.core.deref(cb));


return cljs.core.cst$kw$recur;
} else {
return null;
}
});

cljs.core.async.ioc_alts_BANG_.cljs$lang$maxFixedArity = (3);

/** @this {Function} */
cljs.core.async.ioc_alts_BANG_.cljs$lang$applyTo = (function (seq8932){
var G__8933 = cljs.core.first(seq8932);
var seq8932__$1 = cljs.core.next(seq8932);
var G__8934 = cljs.core.first(seq8932__$1);
var seq8932__$2 = cljs.core.next(seq8932__$1);
var G__8935 = cljs.core.first(seq8932__$2);
var seq8932__$3 = cljs.core.next(seq8932__$2);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__8933,G__8934,G__8935,seq8932__$3);
});

/**
 * Creates and returns a mix of one or more input channels which will
 *   be put on the supplied out channel. Input sources can be added to
 *   the mix with 'admix', and removed with 'unmix'. A mix supports
 *   soloing, muting and pausing multiple inputs atomically using
 *   'toggle', and can solo using either muting or pausing as determined
 *   by 'solo-mode'.
 * 
 *   Each channel can have zero or more boolean modes set via 'toggle':
 * 
 *   :solo - when true, only this (ond other soloed) channel(s) will appear
 *        in the mix output channel. :mute and :pause states of soloed
 *        channels are ignored. If solo-mode is :mute, non-soloed
 *        channels are muted, if :pause, non-soloed channels are
 *        paused.
 * 
 *   :mute - muted channels will have their contents consumed but not included in the mix
 *   :pause - paused channels will not have their contents consumed (and thus also not included in the mix)
 */
cljs.core.async.mix = (function cljs$core$async$mix(out){
var cs = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var solo_modes = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$pause,null,cljs.core.cst$kw$mute,null], null), null);
var attrs = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(solo_modes,cljs.core.cst$kw$solo);
var solo_mode = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.cst$kw$mute);
var change = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
var changed = ((function (cs,solo_modes,attrs,solo_mode,change){
return (function (){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(change,true);
});})(cs,solo_modes,attrs,solo_mode,change))
;
var pick = ((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (attr,chs){
return cljs.core.reduce_kv(((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (ret,c,v){
if(cljs.core.truth_((attr.cljs$core$IFn$_invoke$arity$1 ? attr.cljs$core$IFn$_invoke$arity$1(v) : attr.call(null,v)))){
return cljs.core.conj.cljs$core$IFn$_invoke$arity$2(ret,c);
} else {
return ret;
}
});})(cs,solo_modes,attrs,solo_mode,change,changed))
,cljs.core.PersistentHashSet.EMPTY,chs);
});})(cs,solo_modes,attrs,solo_mode,change,changed))
;
var calc_state = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick){
return (function (){
var chs = cljs.core.deref(cs);
var mode = cljs.core.deref(solo_mode);
var solos = pick(cljs.core.cst$kw$solo,chs);
var pauses = pick(cljs.core.cst$kw$pause,chs);
return new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$solos,solos,cljs.core.cst$kw$mutes,pick(cljs.core.cst$kw$mute,chs),cljs.core.cst$kw$reads,cljs.core.conj.cljs$core$IFn$_invoke$arity$2(((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,cljs.core.cst$kw$pause)) && ((!(cljs.core.empty_QMARK_(solos))))))?cljs.core.vec(solos):cljs.core.vec(cljs.core.remove.cljs$core$IFn$_invoke$arity$2(pauses,cljs.core.keys(chs)))),change)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick))
;
var m = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async8948 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mix}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async8948 = (function (change,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,meta8949){
this.change = change;
this.solo_mode = solo_mode;
this.pick = pick;
this.cs = cs;
this.calc_state = calc_state;
this.out = out;
this.changed = changed;
this.solo_modes = solo_modes;
this.attrs = attrs;
this.meta8949 = meta8949;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async8948.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_8950,meta8949__$1){
var self__ = this;
var _8950__$1 = this;
return (new cljs.core.async.t_cljs$core$async8948(self__.change,self__.solo_mode,self__.pick,self__.cs,self__.calc_state,self__.out,self__.changed,self__.solo_modes,self__.attrs,meta8949__$1));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8948.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_8950){
var self__ = this;
var _8950__$1 = this;
return self__.meta8949;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8948.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8948.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.out;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8948.prototype.cljs$core$async$Mix$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async8948.prototype.cljs$core$async$Mix$admix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(self__.cs,cljs.core.assoc,ch,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8948.prototype.cljs$core$async$Mix$unmix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.dissoc,ch);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8948.prototype.cljs$core$async$Mix$unmix_all_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_(self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8948.prototype.cljs$core$async$Mix$toggle_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,state_map){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.cs,cljs.core.partial.cljs$core$IFn$_invoke$arity$2(cljs.core.merge_with,cljs.core.merge),state_map);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8948.prototype.cljs$core$async$Mix$solo_mode_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,mode){
var self__ = this;
var ___$1 = this;

cljs.core.reset_BANG_(self__.solo_mode,mode);

return (self__.changed.cljs$core$IFn$_invoke$arity$0 ? self__.changed.cljs$core$IFn$_invoke$arity$0() : self__.changed.call(null));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8948.getBasis = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (){
return new cljs.core.PersistentVector(null, 10, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$change,cljs.core.cst$sym$solo_DASH_mode,cljs.core.cst$sym$pick,cljs.core.cst$sym$cs,cljs.core.cst$sym$calc_DASH_state,cljs.core.cst$sym$out,cljs.core.cst$sym$changed,cljs.core.cst$sym$solo_DASH_modes,cljs.core.cst$sym$attrs,cljs.core.cst$sym$meta8949], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async8948.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async8948.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async8948";

cljs.core.async.t_cljs$core$async8948.cljs$lang$ctorPrWriter = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async8948");
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async8948.
 */
cljs.core.async.__GT_t_cljs$core$async8948 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function cljs$core$async$mix_$___GT_t_cljs$core$async8948(change__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta8949){
return (new cljs.core.async.t_cljs$core$async8948(change__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta8949));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

}

return (new cljs.core.async.t_cljs$core$async8948(change,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__8052__auto___9112 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___9112,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___9112,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (state_9052){
var state_val_9053 = (state_9052[(1)]);
if((state_val_9053 === (7))){
var inst_8967 = (state_9052[(2)]);
var state_9052__$1 = state_9052;
var statearr_9054_9113 = state_9052__$1;
(statearr_9054_9113[(2)] = inst_8967);

(statearr_9054_9113[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (20))){
var inst_8979 = (state_9052[(7)]);
var state_9052__$1 = state_9052;
var statearr_9055_9114 = state_9052__$1;
(statearr_9055_9114[(2)] = inst_8979);

(statearr_9055_9114[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (27))){
var state_9052__$1 = state_9052;
var statearr_9056_9115 = state_9052__$1;
(statearr_9056_9115[(2)] = null);

(statearr_9056_9115[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (1))){
var inst_8954 = (state_9052[(8)]);
var inst_8954__$1 = calc_state();
var inst_8956 = (inst_8954__$1 == null);
var inst_8957 = cljs.core.not(inst_8956);
var state_9052__$1 = (function (){var statearr_9057 = state_9052;
(statearr_9057[(8)] = inst_8954__$1);

return statearr_9057;
})();
if(inst_8957){
var statearr_9058_9116 = state_9052__$1;
(statearr_9058_9116[(1)] = (2));

} else {
var statearr_9059_9117 = state_9052__$1;
(statearr_9059_9117[(1)] = (3));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (24))){
var inst_9003 = (state_9052[(9)]);
var inst_9026 = (state_9052[(10)]);
var inst_9012 = (state_9052[(11)]);
var inst_9026__$1 = (inst_9003.cljs$core$IFn$_invoke$arity$1 ? inst_9003.cljs$core$IFn$_invoke$arity$1(inst_9012) : inst_9003.call(null,inst_9012));
var state_9052__$1 = (function (){var statearr_9060 = state_9052;
(statearr_9060[(10)] = inst_9026__$1);

return statearr_9060;
})();
if(cljs.core.truth_(inst_9026__$1)){
var statearr_9061_9118 = state_9052__$1;
(statearr_9061_9118[(1)] = (29));

} else {
var statearr_9062_9119 = state_9052__$1;
(statearr_9062_9119[(1)] = (30));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (4))){
var inst_8970 = (state_9052[(2)]);
var state_9052__$1 = state_9052;
if(cljs.core.truth_(inst_8970)){
var statearr_9063_9120 = state_9052__$1;
(statearr_9063_9120[(1)] = (8));

} else {
var statearr_9064_9121 = state_9052__$1;
(statearr_9064_9121[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (15))){
var inst_8997 = (state_9052[(2)]);
var state_9052__$1 = state_9052;
if(cljs.core.truth_(inst_8997)){
var statearr_9065_9122 = state_9052__$1;
(statearr_9065_9122[(1)] = (19));

} else {
var statearr_9066_9123 = state_9052__$1;
(statearr_9066_9123[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (21))){
var inst_9002 = (state_9052[(12)]);
var inst_9002__$1 = (state_9052[(2)]);
var inst_9003 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_9002__$1,cljs.core.cst$kw$solos);
var inst_9004 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_9002__$1,cljs.core.cst$kw$mutes);
var inst_9005 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_9002__$1,cljs.core.cst$kw$reads);
var state_9052__$1 = (function (){var statearr_9067 = state_9052;
(statearr_9067[(9)] = inst_9003);

(statearr_9067[(12)] = inst_9002__$1);

(statearr_9067[(13)] = inst_9004);

return statearr_9067;
})();
return cljs.core.async.ioc_alts_BANG_(state_9052__$1,(22),inst_9005);
} else {
if((state_val_9053 === (31))){
var inst_9034 = (state_9052[(2)]);
var state_9052__$1 = state_9052;
if(cljs.core.truth_(inst_9034)){
var statearr_9068_9124 = state_9052__$1;
(statearr_9068_9124[(1)] = (32));

} else {
var statearr_9069_9125 = state_9052__$1;
(statearr_9069_9125[(1)] = (33));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (32))){
var inst_9011 = (state_9052[(14)]);
var state_9052__$1 = state_9052;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9052__$1,(35),out,inst_9011);
} else {
if((state_val_9053 === (33))){
var inst_9002 = (state_9052[(12)]);
var inst_8979 = inst_9002;
var state_9052__$1 = (function (){var statearr_9070 = state_9052;
(statearr_9070[(7)] = inst_8979);

return statearr_9070;
})();
var statearr_9071_9126 = state_9052__$1;
(statearr_9071_9126[(2)] = null);

(statearr_9071_9126[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (13))){
var inst_8979 = (state_9052[(7)]);
var inst_8986 = inst_8979.cljs$lang$protocol_mask$partition0$;
var inst_8987 = (inst_8986 & (64));
var inst_8988 = inst_8979.cljs$core$ISeq$;
var inst_8989 = (cljs.core.PROTOCOL_SENTINEL === inst_8988);
var inst_8990 = ((inst_8987) || (inst_8989));
var state_9052__$1 = state_9052;
if(cljs.core.truth_(inst_8990)){
var statearr_9072_9127 = state_9052__$1;
(statearr_9072_9127[(1)] = (16));

} else {
var statearr_9073_9128 = state_9052__$1;
(statearr_9073_9128[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (22))){
var inst_9011 = (state_9052[(14)]);
var inst_9012 = (state_9052[(11)]);
var inst_9010 = (state_9052[(2)]);
var inst_9011__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_9010,(0),null);
var inst_9012__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_9010,(1),null);
var inst_9013 = (inst_9011__$1 == null);
var inst_9014 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_9012__$1,change);
var inst_9015 = ((inst_9013) || (inst_9014));
var state_9052__$1 = (function (){var statearr_9074 = state_9052;
(statearr_9074[(14)] = inst_9011__$1);

(statearr_9074[(11)] = inst_9012__$1);

return statearr_9074;
})();
if(cljs.core.truth_(inst_9015)){
var statearr_9075_9129 = state_9052__$1;
(statearr_9075_9129[(1)] = (23));

} else {
var statearr_9076_9130 = state_9052__$1;
(statearr_9076_9130[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (36))){
var inst_9002 = (state_9052[(12)]);
var inst_8979 = inst_9002;
var state_9052__$1 = (function (){var statearr_9077 = state_9052;
(statearr_9077[(7)] = inst_8979);

return statearr_9077;
})();
var statearr_9078_9131 = state_9052__$1;
(statearr_9078_9131[(2)] = null);

(statearr_9078_9131[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (29))){
var inst_9026 = (state_9052[(10)]);
var state_9052__$1 = state_9052;
var statearr_9079_9132 = state_9052__$1;
(statearr_9079_9132[(2)] = inst_9026);

(statearr_9079_9132[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (6))){
var state_9052__$1 = state_9052;
var statearr_9080_9133 = state_9052__$1;
(statearr_9080_9133[(2)] = false);

(statearr_9080_9133[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (28))){
var inst_9022 = (state_9052[(2)]);
var inst_9023 = calc_state();
var inst_8979 = inst_9023;
var state_9052__$1 = (function (){var statearr_9081 = state_9052;
(statearr_9081[(15)] = inst_9022);

(statearr_9081[(7)] = inst_8979);

return statearr_9081;
})();
var statearr_9082_9134 = state_9052__$1;
(statearr_9082_9134[(2)] = null);

(statearr_9082_9134[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (25))){
var inst_9048 = (state_9052[(2)]);
var state_9052__$1 = state_9052;
var statearr_9083_9135 = state_9052__$1;
(statearr_9083_9135[(2)] = inst_9048);

(statearr_9083_9135[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (34))){
var inst_9046 = (state_9052[(2)]);
var state_9052__$1 = state_9052;
var statearr_9084_9136 = state_9052__$1;
(statearr_9084_9136[(2)] = inst_9046);

(statearr_9084_9136[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (17))){
var state_9052__$1 = state_9052;
var statearr_9085_9137 = state_9052__$1;
(statearr_9085_9137[(2)] = false);

(statearr_9085_9137[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (3))){
var state_9052__$1 = state_9052;
var statearr_9086_9138 = state_9052__$1;
(statearr_9086_9138[(2)] = false);

(statearr_9086_9138[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (12))){
var inst_9050 = (state_9052[(2)]);
var state_9052__$1 = state_9052;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9052__$1,inst_9050);
} else {
if((state_val_9053 === (2))){
var inst_8954 = (state_9052[(8)]);
var inst_8959 = inst_8954.cljs$lang$protocol_mask$partition0$;
var inst_8960 = (inst_8959 & (64));
var inst_8961 = inst_8954.cljs$core$ISeq$;
var inst_8962 = (cljs.core.PROTOCOL_SENTINEL === inst_8961);
var inst_8963 = ((inst_8960) || (inst_8962));
var state_9052__$1 = state_9052;
if(cljs.core.truth_(inst_8963)){
var statearr_9087_9139 = state_9052__$1;
(statearr_9087_9139[(1)] = (5));

} else {
var statearr_9088_9140 = state_9052__$1;
(statearr_9088_9140[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (23))){
var inst_9011 = (state_9052[(14)]);
var inst_9017 = (inst_9011 == null);
var state_9052__$1 = state_9052;
if(cljs.core.truth_(inst_9017)){
var statearr_9089_9141 = state_9052__$1;
(statearr_9089_9141[(1)] = (26));

} else {
var statearr_9090_9142 = state_9052__$1;
(statearr_9090_9142[(1)] = (27));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (35))){
var inst_9037 = (state_9052[(2)]);
var state_9052__$1 = state_9052;
if(cljs.core.truth_(inst_9037)){
var statearr_9091_9143 = state_9052__$1;
(statearr_9091_9143[(1)] = (36));

} else {
var statearr_9092_9144 = state_9052__$1;
(statearr_9092_9144[(1)] = (37));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (19))){
var inst_8979 = (state_9052[(7)]);
var inst_8999 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_8979);
var state_9052__$1 = state_9052;
var statearr_9093_9145 = state_9052__$1;
(statearr_9093_9145[(2)] = inst_8999);

(statearr_9093_9145[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (11))){
var inst_8979 = (state_9052[(7)]);
var inst_8983 = (inst_8979 == null);
var inst_8984 = cljs.core.not(inst_8983);
var state_9052__$1 = state_9052;
if(inst_8984){
var statearr_9094_9146 = state_9052__$1;
(statearr_9094_9146[(1)] = (13));

} else {
var statearr_9095_9147 = state_9052__$1;
(statearr_9095_9147[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (9))){
var inst_8954 = (state_9052[(8)]);
var state_9052__$1 = state_9052;
var statearr_9096_9148 = state_9052__$1;
(statearr_9096_9148[(2)] = inst_8954);

(statearr_9096_9148[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (5))){
var state_9052__$1 = state_9052;
var statearr_9097_9149 = state_9052__$1;
(statearr_9097_9149[(2)] = true);

(statearr_9097_9149[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (14))){
var state_9052__$1 = state_9052;
var statearr_9098_9150 = state_9052__$1;
(statearr_9098_9150[(2)] = false);

(statearr_9098_9150[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (26))){
var inst_9012 = (state_9052[(11)]);
var inst_9019 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(cs,cljs.core.dissoc,inst_9012);
var state_9052__$1 = state_9052;
var statearr_9099_9151 = state_9052__$1;
(statearr_9099_9151[(2)] = inst_9019);

(statearr_9099_9151[(1)] = (28));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (16))){
var state_9052__$1 = state_9052;
var statearr_9100_9152 = state_9052__$1;
(statearr_9100_9152[(2)] = true);

(statearr_9100_9152[(1)] = (18));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (38))){
var inst_9042 = (state_9052[(2)]);
var state_9052__$1 = state_9052;
var statearr_9101_9153 = state_9052__$1;
(statearr_9101_9153[(2)] = inst_9042);

(statearr_9101_9153[(1)] = (34));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (30))){
var inst_9003 = (state_9052[(9)]);
var inst_9004 = (state_9052[(13)]);
var inst_9012 = (state_9052[(11)]);
var inst_9029 = cljs.core.empty_QMARK_(inst_9003);
var inst_9030 = (inst_9004.cljs$core$IFn$_invoke$arity$1 ? inst_9004.cljs$core$IFn$_invoke$arity$1(inst_9012) : inst_9004.call(null,inst_9012));
var inst_9031 = cljs.core.not(inst_9030);
var inst_9032 = ((inst_9029) && (inst_9031));
var state_9052__$1 = state_9052;
var statearr_9102_9154 = state_9052__$1;
(statearr_9102_9154[(2)] = inst_9032);

(statearr_9102_9154[(1)] = (31));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (10))){
var inst_8954 = (state_9052[(8)]);
var inst_8975 = (state_9052[(2)]);
var inst_8976 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_8975,cljs.core.cst$kw$solos);
var inst_8977 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_8975,cljs.core.cst$kw$mutes);
var inst_8978 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_8975,cljs.core.cst$kw$reads);
var inst_8979 = inst_8954;
var state_9052__$1 = (function (){var statearr_9103 = state_9052;
(statearr_9103[(16)] = inst_8977);

(statearr_9103[(17)] = inst_8978);

(statearr_9103[(18)] = inst_8976);

(statearr_9103[(7)] = inst_8979);

return statearr_9103;
})();
var statearr_9104_9155 = state_9052__$1;
(statearr_9104_9155[(2)] = null);

(statearr_9104_9155[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (18))){
var inst_8994 = (state_9052[(2)]);
var state_9052__$1 = state_9052;
var statearr_9105_9156 = state_9052__$1;
(statearr_9105_9156[(2)] = inst_8994);

(statearr_9105_9156[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (37))){
var state_9052__$1 = state_9052;
var statearr_9106_9157 = state_9052__$1;
(statearr_9106_9157[(2)] = null);

(statearr_9106_9157[(1)] = (38));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9053 === (8))){
var inst_8954 = (state_9052[(8)]);
var inst_8972 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(cljs.core.hash_map,inst_8954);
var state_9052__$1 = state_9052;
var statearr_9107_9158 = state_9052__$1;
(statearr_9107_9158[(2)] = inst_8972);

(statearr_9107_9158[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___9112,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
;
return ((function (switch__7945__auto__,c__8052__auto___9112,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function() {
var cljs$core$async$mix_$_state_machine__7946__auto__ = null;
var cljs$core$async$mix_$_state_machine__7946__auto____0 = (function (){
var statearr_9108 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9108[(0)] = cljs$core$async$mix_$_state_machine__7946__auto__);

(statearr_9108[(1)] = (1));

return statearr_9108;
});
var cljs$core$async$mix_$_state_machine__7946__auto____1 = (function (state_9052){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_9052);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e9109){if((e9109 instanceof Object)){
var ex__7949__auto__ = e9109;
var statearr_9110_9159 = state_9052;
(statearr_9110_9159[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9052);

return cljs.core.cst$kw$recur;
} else {
throw e9109;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__9160 = state_9052;
state_9052 = G__9160;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$mix_$_state_machine__7946__auto__ = function(state_9052){
switch(arguments.length){
case 0:
return cljs$core$async$mix_$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$mix_$_state_machine__7946__auto____1.call(this,state_9052);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mix_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mix_$_state_machine__7946__auto____0;
cljs$core$async$mix_$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mix_$_state_machine__7946__auto____1;
return cljs$core$async$mix_$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___9112,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
})();
var state__8054__auto__ = (function (){var statearr_9111 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_9111[(6)] = c__8052__auto___9112);

return statearr_9111;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___9112,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
);


return m;
});
/**
 * Adds ch as an input to the mix
 */
cljs.core.async.admix = (function cljs$core$async$admix(mix,ch){
return cljs.core.async.admix_STAR_(mix,ch);
});
/**
 * Removes ch as an input to the mix
 */
cljs.core.async.unmix = (function cljs$core$async$unmix(mix,ch){
return cljs.core.async.unmix_STAR_(mix,ch);
});
/**
 * removes all inputs from the mix
 */
cljs.core.async.unmix_all = (function cljs$core$async$unmix_all(mix){
return cljs.core.async.unmix_all_STAR_(mix);
});
/**
 * Atomically sets the state(s) of one or more channels in a mix. The
 *   state map is a map of channels -> channel-state-map. A
 *   channel-state-map is a map of attrs -> boolean, where attr is one or
 *   more of :mute, :pause or :solo. Any states supplied are merged with
 *   the current state.
 * 
 *   Note that channels can be added to a mix via toggle, which can be
 *   used to add channels in a particular (e.g. paused) state.
 */
cljs.core.async.toggle = (function cljs$core$async$toggle(mix,state_map){
return cljs.core.async.toggle_STAR_(mix,state_map);
});
/**
 * Sets the solo mode of the mix. mode must be one of :mute or :pause
 */
cljs.core.async.solo_mode = (function cljs$core$async$solo_mode(mix,mode){
return cljs.core.async.solo_mode_STAR_(mix,mode);
});

/**
 * @interface
 */
cljs.core.async.Pub = function(){};

cljs.core.async.sub_STAR_ = (function cljs$core$async$sub_STAR_(p,v,ch,close_QMARK_){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$sub_STAR_$arity$4 == null)))))){
return p.cljs$core$async$Pub$sub_STAR_$arity$4(p,v,ch,close_QMARK_);
} else {
var x__4433__auto__ = (((p == null))?null:p);
var m__4434__auto__ = (cljs.core.async.sub_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$4 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4434__auto__.call(null,p,v,ch,close_QMARK_));
} else {
var m__4431__auto__ = (cljs.core.async.sub_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$4 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$4(p,v,ch,close_QMARK_) : m__4431__auto__.call(null,p,v,ch,close_QMARK_));
} else {
throw cljs.core.missing_protocol("Pub.sub*",p);
}
}
}
});

cljs.core.async.unsub_STAR_ = (function cljs$core$async$unsub_STAR_(p,v,ch){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_STAR_$arity$3 == null)))))){
return p.cljs$core$async$Pub$unsub_STAR_$arity$3(p,v,ch);
} else {
var x__4433__auto__ = (((p == null))?null:p);
var m__4434__auto__ = (cljs.core.async.unsub_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4434__auto__.call(null,p,v,ch));
} else {
var m__4431__auto__ = (cljs.core.async.unsub_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$3 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$3(p,v,ch) : m__4431__auto__.call(null,p,v,ch));
} else {
throw cljs.core.missing_protocol("Pub.unsub*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_ = (function cljs$core$async$unsub_all_STAR_(var_args){
var G__9162 = arguments.length;
switch (G__9162) {
case 1:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1 = (function (p){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$1 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$1(p);
} else {
var x__4433__auto__ = (((p == null))?null:p);
var m__4434__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(p) : m__4434__auto__.call(null,p));
} else {
var m__4431__auto__ = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(p) : m__4431__auto__.call(null,p));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (p,v){
if((((!((p == null)))) && ((!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$2 == null)))))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$2(p,v);
} else {
var x__4433__auto__ = (((p == null))?null:p);
var m__4434__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(p,v) : m__4434__auto__.call(null,p,v));
} else {
var m__4431__auto__ = (cljs.core.async.unsub_all_STAR_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(p,v) : m__4431__auto__.call(null,p,v));
} else {
throw cljs.core.missing_protocol("Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$lang$maxFixedArity = 2;


/**
 * Creates and returns a pub(lication) of the supplied channel,
 *   partitioned into topics by the topic-fn. topic-fn will be applied to
 *   each value on the channel and the result will determine the 'topic'
 *   on which that value will be put. Channels can be subscribed to
 *   receive copies of topics using 'sub', and unsubscribed using
 *   'unsub'. Each topic will be handled by an internal mult on a
 *   dedicated channel. By default these internal channels are
 *   unbuffered, but a buf-fn can be supplied which, given a topic,
 *   creates a buffer with desired properties.
 * 
 *   Each item is distributed to all subs in parallel and synchronously,
 *   i.e. each sub must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow subs from holding up the pub.
 * 
 *   Items received when there are no matching subs get dropped.
 * 
 *   Note that if buf-fns are used then each topic is handled
 *   asynchronously, i.e. if a channel is subscribed to more than one
 *   topic it should not expect them to be interleaved identically with
 *   the source.
 */
cljs.core.async.pub = (function cljs$core$async$pub(var_args){
var G__9166 = arguments.length;
switch (G__9166) {
case 2:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2 = (function (ch,topic_fn){
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3(ch,topic_fn,cljs.core.constantly(null));
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3 = (function (ch,topic_fn,buf_fn){
var mults = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
var ensure_mult = ((function (mults){
return (function (topic){
var or__4131__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(mults),topic);
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(mults,((function (or__4131__auto__,mults){
return (function (p1__9164_SHARP_){
if(cljs.core.truth_((p1__9164_SHARP_.cljs$core$IFn$_invoke$arity$1 ? p1__9164_SHARP_.cljs$core$IFn$_invoke$arity$1(topic) : p1__9164_SHARP_.call(null,topic)))){
return p1__9164_SHARP_;
} else {
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(p1__9164_SHARP_,topic,cljs.core.async.mult(cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((buf_fn.cljs$core$IFn$_invoke$arity$1 ? buf_fn.cljs$core$IFn$_invoke$arity$1(topic) : buf_fn.call(null,topic)))));
}
});})(or__4131__auto__,mults))
),topic);
}
});})(mults))
;
var p = (function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async9167 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Pub}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async9167 = (function (ch,topic_fn,buf_fn,mults,ensure_mult,meta9168){
this.ch = ch;
this.topic_fn = topic_fn;
this.buf_fn = buf_fn;
this.mults = mults;
this.ensure_mult = ensure_mult;
this.meta9168 = meta9168;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async9167.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (mults,ensure_mult){
return (function (_9169,meta9168__$1){
var self__ = this;
var _9169__$1 = this;
return (new cljs.core.async.t_cljs$core$async9167(self__.ch,self__.topic_fn,self__.buf_fn,self__.mults,self__.ensure_mult,meta9168__$1));
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9167.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (mults,ensure_mult){
return (function (_9169){
var self__ = this;
var _9169__$1 = this;
return self__.meta9168;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9167.prototype.cljs$core$async$Mux$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9167.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9167.prototype.cljs$core$async$Pub$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9167.prototype.cljs$core$async$Pub$sub_STAR_$arity$4 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1,close_QMARK_){
var self__ = this;
var p__$1 = this;
var m = (self__.ensure_mult.cljs$core$IFn$_invoke$arity$1 ? self__.ensure_mult.cljs$core$IFn$_invoke$arity$1(topic) : self__.ensure_mult.call(null,topic));
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3(m,ch__$1,close_QMARK_);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9167.prototype.cljs$core$async$Pub$unsub_STAR_$arity$3 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1){
var self__ = this;
var p__$1 = this;
var temp__5735__auto__ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(self__.mults),topic);
if(cljs.core.truth_(temp__5735__auto__)){
var m = temp__5735__auto__;
return cljs.core.async.untap(m,ch__$1);
} else {
return null;
}
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9167.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.reset_BANG_(self__.mults,cljs.core.PersistentArrayMap.EMPTY);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9167.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$2 = ((function (mults,ensure_mult){
return (function (_,topic){
var self__ = this;
var ___$1 = this;
return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(self__.mults,cljs.core.dissoc,topic);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9167.getBasis = ((function (mults,ensure_mult){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$ch,cljs.core.cst$sym$topic_DASH_fn,cljs.core.cst$sym$buf_DASH_fn,cljs.core.cst$sym$mults,cljs.core.cst$sym$ensure_DASH_mult,cljs.core.cst$sym$meta9168], null);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async9167.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async9167.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async9167";

cljs.core.async.t_cljs$core$async9167.cljs$lang$ctorPrWriter = ((function (mults,ensure_mult){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async9167");
});})(mults,ensure_mult))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async9167.
 */
cljs.core.async.__GT_t_cljs$core$async9167 = ((function (mults,ensure_mult){
return (function cljs$core$async$__GT_t_cljs$core$async9167(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta9168){
return (new cljs.core.async.t_cljs$core$async9167(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta9168));
});})(mults,ensure_mult))
;

}

return (new cljs.core.async.t_cljs$core$async9167(ch,topic_fn,buf_fn,mults,ensure_mult,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__8052__auto___9287 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___9287,mults,ensure_mult,p){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___9287,mults,ensure_mult,p){
return (function (state_9241){
var state_val_9242 = (state_9241[(1)]);
if((state_val_9242 === (7))){
var inst_9237 = (state_9241[(2)]);
var state_9241__$1 = state_9241;
var statearr_9243_9288 = state_9241__$1;
(statearr_9243_9288[(2)] = inst_9237);

(statearr_9243_9288[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (20))){
var state_9241__$1 = state_9241;
var statearr_9244_9289 = state_9241__$1;
(statearr_9244_9289[(2)] = null);

(statearr_9244_9289[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (1))){
var state_9241__$1 = state_9241;
var statearr_9245_9290 = state_9241__$1;
(statearr_9245_9290[(2)] = null);

(statearr_9245_9290[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (24))){
var inst_9220 = (state_9241[(7)]);
var inst_9229 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(mults,cljs.core.dissoc,inst_9220);
var state_9241__$1 = state_9241;
var statearr_9246_9291 = state_9241__$1;
(statearr_9246_9291[(2)] = inst_9229);

(statearr_9246_9291[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (4))){
var inst_9172 = (state_9241[(8)]);
var inst_9172__$1 = (state_9241[(2)]);
var inst_9173 = (inst_9172__$1 == null);
var state_9241__$1 = (function (){var statearr_9247 = state_9241;
(statearr_9247[(8)] = inst_9172__$1);

return statearr_9247;
})();
if(cljs.core.truth_(inst_9173)){
var statearr_9248_9292 = state_9241__$1;
(statearr_9248_9292[(1)] = (5));

} else {
var statearr_9249_9293 = state_9241__$1;
(statearr_9249_9293[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (15))){
var inst_9214 = (state_9241[(2)]);
var state_9241__$1 = state_9241;
var statearr_9250_9294 = state_9241__$1;
(statearr_9250_9294[(2)] = inst_9214);

(statearr_9250_9294[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (21))){
var inst_9234 = (state_9241[(2)]);
var state_9241__$1 = (function (){var statearr_9251 = state_9241;
(statearr_9251[(9)] = inst_9234);

return statearr_9251;
})();
var statearr_9252_9295 = state_9241__$1;
(statearr_9252_9295[(2)] = null);

(statearr_9252_9295[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (13))){
var inst_9196 = (state_9241[(10)]);
var inst_9198 = cljs.core.chunked_seq_QMARK_(inst_9196);
var state_9241__$1 = state_9241;
if(inst_9198){
var statearr_9253_9296 = state_9241__$1;
(statearr_9253_9296[(1)] = (16));

} else {
var statearr_9254_9297 = state_9241__$1;
(statearr_9254_9297[(1)] = (17));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (22))){
var inst_9226 = (state_9241[(2)]);
var state_9241__$1 = state_9241;
if(cljs.core.truth_(inst_9226)){
var statearr_9255_9298 = state_9241__$1;
(statearr_9255_9298[(1)] = (23));

} else {
var statearr_9256_9299 = state_9241__$1;
(statearr_9256_9299[(1)] = (24));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (6))){
var inst_9222 = (state_9241[(11)]);
var inst_9172 = (state_9241[(8)]);
var inst_9220 = (state_9241[(7)]);
var inst_9220__$1 = (topic_fn.cljs$core$IFn$_invoke$arity$1 ? topic_fn.cljs$core$IFn$_invoke$arity$1(inst_9172) : topic_fn.call(null,inst_9172));
var inst_9221 = cljs.core.deref(mults);
var inst_9222__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(inst_9221,inst_9220__$1);
var state_9241__$1 = (function (){var statearr_9257 = state_9241;
(statearr_9257[(11)] = inst_9222__$1);

(statearr_9257[(7)] = inst_9220__$1);

return statearr_9257;
})();
if(cljs.core.truth_(inst_9222__$1)){
var statearr_9258_9300 = state_9241__$1;
(statearr_9258_9300[(1)] = (19));

} else {
var statearr_9259_9301 = state_9241__$1;
(statearr_9259_9301[(1)] = (20));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (25))){
var inst_9231 = (state_9241[(2)]);
var state_9241__$1 = state_9241;
var statearr_9260_9302 = state_9241__$1;
(statearr_9260_9302[(2)] = inst_9231);

(statearr_9260_9302[(1)] = (21));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (17))){
var inst_9196 = (state_9241[(10)]);
var inst_9205 = cljs.core.first(inst_9196);
var inst_9206 = cljs.core.async.muxch_STAR_(inst_9205);
var inst_9207 = cljs.core.async.close_BANG_(inst_9206);
var inst_9208 = cljs.core.next(inst_9196);
var inst_9182 = inst_9208;
var inst_9183 = null;
var inst_9184 = (0);
var inst_9185 = (0);
var state_9241__$1 = (function (){var statearr_9261 = state_9241;
(statearr_9261[(12)] = inst_9182);

(statearr_9261[(13)] = inst_9184);

(statearr_9261[(14)] = inst_9185);

(statearr_9261[(15)] = inst_9183);

(statearr_9261[(16)] = inst_9207);

return statearr_9261;
})();
var statearr_9262_9303 = state_9241__$1;
(statearr_9262_9303[(2)] = null);

(statearr_9262_9303[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (3))){
var inst_9239 = (state_9241[(2)]);
var state_9241__$1 = state_9241;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9241__$1,inst_9239);
} else {
if((state_val_9242 === (12))){
var inst_9216 = (state_9241[(2)]);
var state_9241__$1 = state_9241;
var statearr_9263_9304 = state_9241__$1;
(statearr_9263_9304[(2)] = inst_9216);

(statearr_9263_9304[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (2))){
var state_9241__$1 = state_9241;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9241__$1,(4),ch);
} else {
if((state_val_9242 === (23))){
var state_9241__$1 = state_9241;
var statearr_9264_9305 = state_9241__$1;
(statearr_9264_9305[(2)] = null);

(statearr_9264_9305[(1)] = (25));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (19))){
var inst_9222 = (state_9241[(11)]);
var inst_9172 = (state_9241[(8)]);
var inst_9224 = cljs.core.async.muxch_STAR_(inst_9222);
var state_9241__$1 = state_9241;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9241__$1,(22),inst_9224,inst_9172);
} else {
if((state_val_9242 === (11))){
var inst_9182 = (state_9241[(12)]);
var inst_9196 = (state_9241[(10)]);
var inst_9196__$1 = cljs.core.seq(inst_9182);
var state_9241__$1 = (function (){var statearr_9265 = state_9241;
(statearr_9265[(10)] = inst_9196__$1);

return statearr_9265;
})();
if(inst_9196__$1){
var statearr_9266_9306 = state_9241__$1;
(statearr_9266_9306[(1)] = (13));

} else {
var statearr_9267_9307 = state_9241__$1;
(statearr_9267_9307[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (9))){
var inst_9218 = (state_9241[(2)]);
var state_9241__$1 = state_9241;
var statearr_9268_9308 = state_9241__$1;
(statearr_9268_9308[(2)] = inst_9218);

(statearr_9268_9308[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (5))){
var inst_9179 = cljs.core.deref(mults);
var inst_9180 = cljs.core.vals(inst_9179);
var inst_9181 = cljs.core.seq(inst_9180);
var inst_9182 = inst_9181;
var inst_9183 = null;
var inst_9184 = (0);
var inst_9185 = (0);
var state_9241__$1 = (function (){var statearr_9269 = state_9241;
(statearr_9269[(12)] = inst_9182);

(statearr_9269[(13)] = inst_9184);

(statearr_9269[(14)] = inst_9185);

(statearr_9269[(15)] = inst_9183);

return statearr_9269;
})();
var statearr_9270_9309 = state_9241__$1;
(statearr_9270_9309[(2)] = null);

(statearr_9270_9309[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (14))){
var state_9241__$1 = state_9241;
var statearr_9274_9310 = state_9241__$1;
(statearr_9274_9310[(2)] = null);

(statearr_9274_9310[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (16))){
var inst_9196 = (state_9241[(10)]);
var inst_9200 = cljs.core.chunk_first(inst_9196);
var inst_9201 = cljs.core.chunk_rest(inst_9196);
var inst_9202 = cljs.core.count(inst_9200);
var inst_9182 = inst_9201;
var inst_9183 = inst_9200;
var inst_9184 = inst_9202;
var inst_9185 = (0);
var state_9241__$1 = (function (){var statearr_9275 = state_9241;
(statearr_9275[(12)] = inst_9182);

(statearr_9275[(13)] = inst_9184);

(statearr_9275[(14)] = inst_9185);

(statearr_9275[(15)] = inst_9183);

return statearr_9275;
})();
var statearr_9276_9311 = state_9241__$1;
(statearr_9276_9311[(2)] = null);

(statearr_9276_9311[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (10))){
var inst_9182 = (state_9241[(12)]);
var inst_9184 = (state_9241[(13)]);
var inst_9185 = (state_9241[(14)]);
var inst_9183 = (state_9241[(15)]);
var inst_9190 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_9183,inst_9185);
var inst_9191 = cljs.core.async.muxch_STAR_(inst_9190);
var inst_9192 = cljs.core.async.close_BANG_(inst_9191);
var inst_9193 = (inst_9185 + (1));
var tmp9271 = inst_9182;
var tmp9272 = inst_9184;
var tmp9273 = inst_9183;
var inst_9182__$1 = tmp9271;
var inst_9183__$1 = tmp9273;
var inst_9184__$1 = tmp9272;
var inst_9185__$1 = inst_9193;
var state_9241__$1 = (function (){var statearr_9277 = state_9241;
(statearr_9277[(12)] = inst_9182__$1);

(statearr_9277[(17)] = inst_9192);

(statearr_9277[(13)] = inst_9184__$1);

(statearr_9277[(14)] = inst_9185__$1);

(statearr_9277[(15)] = inst_9183__$1);

return statearr_9277;
})();
var statearr_9278_9312 = state_9241__$1;
(statearr_9278_9312[(2)] = null);

(statearr_9278_9312[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (18))){
var inst_9211 = (state_9241[(2)]);
var state_9241__$1 = state_9241;
var statearr_9279_9313 = state_9241__$1;
(statearr_9279_9313[(2)] = inst_9211);

(statearr_9279_9313[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9242 === (8))){
var inst_9184 = (state_9241[(13)]);
var inst_9185 = (state_9241[(14)]);
var inst_9187 = (inst_9185 < inst_9184);
var inst_9188 = inst_9187;
var state_9241__$1 = state_9241;
if(cljs.core.truth_(inst_9188)){
var statearr_9280_9314 = state_9241__$1;
(statearr_9280_9314[(1)] = (10));

} else {
var statearr_9281_9315 = state_9241__$1;
(statearr_9281_9315[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___9287,mults,ensure_mult,p))
;
return ((function (switch__7945__auto__,c__8052__auto___9287,mults,ensure_mult,p){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_9282 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9282[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_9282[(1)] = (1));

return statearr_9282;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_9241){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_9241);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e9283){if((e9283 instanceof Object)){
var ex__7949__auto__ = e9283;
var statearr_9284_9316 = state_9241;
(statearr_9284_9316[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9241);

return cljs.core.cst$kw$recur;
} else {
throw e9283;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__9317 = state_9241;
state_9241 = G__9317;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_9241){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_9241);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___9287,mults,ensure_mult,p))
})();
var state__8054__auto__ = (function (){var statearr_9285 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_9285[(6)] = c__8052__auto___9287);

return statearr_9285;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___9287,mults,ensure_mult,p))
);


return p;
});

cljs.core.async.pub.cljs$lang$maxFixedArity = 3;

/**
 * Subscribes a channel to a topic of a pub.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.sub = (function cljs$core$async$sub(var_args){
var G__9319 = arguments.length;
switch (G__9319) {
case 3:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3 = (function (p,topic,ch){
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4(p,topic,ch,true);
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4 = (function (p,topic,ch,close_QMARK_){
return cljs.core.async.sub_STAR_(p,topic,ch,close_QMARK_);
});

cljs.core.async.sub.cljs$lang$maxFixedArity = 4;

/**
 * Unsubscribes a channel from a topic of a pub
 */
cljs.core.async.unsub = (function cljs$core$async$unsub(p,topic,ch){
return cljs.core.async.unsub_STAR_(p,topic,ch);
});
/**
 * Unsubscribes all channels from a pub, or a topic of a pub
 */
cljs.core.async.unsub_all = (function cljs$core$async$unsub_all(var_args){
var G__9322 = arguments.length;
switch (G__9322) {
case 1:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1 = (function (p){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1(p);
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2 = (function (p,topic){
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2(p,topic);
});

cljs.core.async.unsub_all.cljs$lang$maxFixedArity = 2;

/**
 * Takes a function and a collection of source channels, and returns a
 *   channel which contains the values produced by applying f to the set
 *   of first items taken from each source channel, followed by applying
 *   f to the set of second items from each channel, until any one of the
 *   channels is closed, at which point the output channel will be
 *   closed. The returned channel will be unbuffered by default, or a
 *   buf-or-n can be supplied
 */
cljs.core.async.map = (function cljs$core$async$map(var_args){
var G__9325 = arguments.length;
switch (G__9325) {
case 2:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$2 = (function (f,chs){
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3(f,chs,null);
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$3 = (function (f,chs,buf_or_n){
var chs__$1 = cljs.core.vec(chs);
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var cnt = cljs.core.count(chs__$1);
var rets = cljs.core.object_array.cljs$core$IFn$_invoke$arity$1(cnt);
var dchan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
var dctr = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(null);
var done = cljs.core.mapv.cljs$core$IFn$_invoke$arity$2(((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (i){
return ((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (ret){
(rets[i] = ret);

if((cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(dchan,rets.slice((0)));
} else {
return null;
}
});
;})(chs__$1,out,cnt,rets,dchan,dctr))
});})(chs__$1,out,cnt,rets,dchan,dctr))
,cljs.core.range.cljs$core$IFn$_invoke$arity$1(cnt));
var c__8052__auto___9392 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___9392,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___9392,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (state_9364){
var state_val_9365 = (state_9364[(1)]);
if((state_val_9365 === (7))){
var state_9364__$1 = state_9364;
var statearr_9366_9393 = state_9364__$1;
(statearr_9366_9393[(2)] = null);

(statearr_9366_9393[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9365 === (1))){
var state_9364__$1 = state_9364;
var statearr_9367_9394 = state_9364__$1;
(statearr_9367_9394[(2)] = null);

(statearr_9367_9394[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9365 === (4))){
var inst_9328 = (state_9364[(7)]);
var inst_9330 = (inst_9328 < cnt);
var state_9364__$1 = state_9364;
if(cljs.core.truth_(inst_9330)){
var statearr_9368_9395 = state_9364__$1;
(statearr_9368_9395[(1)] = (6));

} else {
var statearr_9369_9396 = state_9364__$1;
(statearr_9369_9396[(1)] = (7));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9365 === (15))){
var inst_9360 = (state_9364[(2)]);
var state_9364__$1 = state_9364;
var statearr_9370_9397 = state_9364__$1;
(statearr_9370_9397[(2)] = inst_9360);

(statearr_9370_9397[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9365 === (13))){
var inst_9353 = cljs.core.async.close_BANG_(out);
var state_9364__$1 = state_9364;
var statearr_9371_9398 = state_9364__$1;
(statearr_9371_9398[(2)] = inst_9353);

(statearr_9371_9398[(1)] = (15));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9365 === (6))){
var state_9364__$1 = state_9364;
var statearr_9372_9399 = state_9364__$1;
(statearr_9372_9399[(2)] = null);

(statearr_9372_9399[(1)] = (11));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9365 === (3))){
var inst_9362 = (state_9364[(2)]);
var state_9364__$1 = state_9364;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9364__$1,inst_9362);
} else {
if((state_val_9365 === (12))){
var inst_9350 = (state_9364[(8)]);
var inst_9350__$1 = (state_9364[(2)]);
var inst_9351 = cljs.core.some(cljs.core.nil_QMARK_,inst_9350__$1);
var state_9364__$1 = (function (){var statearr_9373 = state_9364;
(statearr_9373[(8)] = inst_9350__$1);

return statearr_9373;
})();
if(cljs.core.truth_(inst_9351)){
var statearr_9374_9400 = state_9364__$1;
(statearr_9374_9400[(1)] = (13));

} else {
var statearr_9375_9401 = state_9364__$1;
(statearr_9375_9401[(1)] = (14));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9365 === (2))){
var inst_9327 = cljs.core.reset_BANG_(dctr,cnt);
var inst_9328 = (0);
var state_9364__$1 = (function (){var statearr_9376 = state_9364;
(statearr_9376[(7)] = inst_9328);

(statearr_9376[(9)] = inst_9327);

return statearr_9376;
})();
var statearr_9377_9402 = state_9364__$1;
(statearr_9377_9402[(2)] = null);

(statearr_9377_9402[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9365 === (11))){
var inst_9328 = (state_9364[(7)]);
var _ = cljs.core.async.impl.ioc_helpers.add_exception_frame(state_9364,(10),Object,null,(9));
var inst_9337 = (chs__$1.cljs$core$IFn$_invoke$arity$1 ? chs__$1.cljs$core$IFn$_invoke$arity$1(inst_9328) : chs__$1.call(null,inst_9328));
var inst_9338 = (done.cljs$core$IFn$_invoke$arity$1 ? done.cljs$core$IFn$_invoke$arity$1(inst_9328) : done.call(null,inst_9328));
var inst_9339 = cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2(inst_9337,inst_9338);
var state_9364__$1 = state_9364;
var statearr_9378_9403 = state_9364__$1;
(statearr_9378_9403[(2)] = inst_9339);


cljs.core.async.impl.ioc_helpers.process_exception(state_9364__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_9365 === (9))){
var inst_9328 = (state_9364[(7)]);
var inst_9341 = (state_9364[(2)]);
var inst_9342 = (inst_9328 + (1));
var inst_9328__$1 = inst_9342;
var state_9364__$1 = (function (){var statearr_9379 = state_9364;
(statearr_9379[(7)] = inst_9328__$1);

(statearr_9379[(10)] = inst_9341);

return statearr_9379;
})();
var statearr_9380_9404 = state_9364__$1;
(statearr_9380_9404[(2)] = null);

(statearr_9380_9404[(1)] = (4));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9365 === (5))){
var inst_9348 = (state_9364[(2)]);
var state_9364__$1 = (function (){var statearr_9381 = state_9364;
(statearr_9381[(11)] = inst_9348);

return statearr_9381;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9364__$1,(12),dchan);
} else {
if((state_val_9365 === (14))){
var inst_9350 = (state_9364[(8)]);
var inst_9355 = cljs.core.apply.cljs$core$IFn$_invoke$arity$2(f,inst_9350);
var state_9364__$1 = state_9364;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9364__$1,(16),out,inst_9355);
} else {
if((state_val_9365 === (16))){
var inst_9357 = (state_9364[(2)]);
var state_9364__$1 = (function (){var statearr_9382 = state_9364;
(statearr_9382[(12)] = inst_9357);

return statearr_9382;
})();
var statearr_9383_9405 = state_9364__$1;
(statearr_9383_9405[(2)] = null);

(statearr_9383_9405[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9365 === (10))){
var inst_9332 = (state_9364[(2)]);
var inst_9333 = cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(dctr,cljs.core.dec);
var state_9364__$1 = (function (){var statearr_9384 = state_9364;
(statearr_9384[(13)] = inst_9332);

return statearr_9384;
})();
var statearr_9385_9406 = state_9364__$1;
(statearr_9385_9406[(2)] = inst_9333);


cljs.core.async.impl.ioc_helpers.process_exception(state_9364__$1);

return cljs.core.cst$kw$recur;
} else {
if((state_val_9365 === (8))){
var inst_9346 = (state_9364[(2)]);
var state_9364__$1 = state_9364;
var statearr_9386_9407 = state_9364__$1;
(statearr_9386_9407[(2)] = inst_9346);

(statearr_9386_9407[(1)] = (5));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___9392,chs__$1,out,cnt,rets,dchan,dctr,done))
;
return ((function (switch__7945__auto__,c__8052__auto___9392,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_9387 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9387[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_9387[(1)] = (1));

return statearr_9387;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_9364){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_9364);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e9388){if((e9388 instanceof Object)){
var ex__7949__auto__ = e9388;
var statearr_9389_9408 = state_9364;
(statearr_9389_9408[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9364);

return cljs.core.cst$kw$recur;
} else {
throw e9388;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__9409 = state_9364;
state_9364 = G__9409;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_9364){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_9364);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___9392,chs__$1,out,cnt,rets,dchan,dctr,done))
})();
var state__8054__auto__ = (function (){var statearr_9390 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_9390[(6)] = c__8052__auto___9392);

return statearr_9390;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___9392,chs__$1,out,cnt,rets,dchan,dctr,done))
);


return out;
});

cljs.core.async.map.cljs$lang$maxFixedArity = 3;

/**
 * Takes a collection of source channels and returns a channel which
 *   contains all values taken from them. The returned channel will be
 *   unbuffered by default, or a buf-or-n can be supplied. The channel
 *   will close after all the source channels have closed.
 */
cljs.core.async.merge = (function cljs$core$async$merge(var_args){
var G__9412 = arguments.length;
switch (G__9412) {
case 1:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1 = (function (chs){
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2(chs,null);
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2 = (function (chs,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__8052__auto___9466 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___9466,out){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___9466,out){
return (function (state_9444){
var state_val_9445 = (state_9444[(1)]);
if((state_val_9445 === (7))){
var inst_9423 = (state_9444[(7)]);
var inst_9424 = (state_9444[(8)]);
var inst_9423__$1 = (state_9444[(2)]);
var inst_9424__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_9423__$1,(0),null);
var inst_9425 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(inst_9423__$1,(1),null);
var inst_9426 = (inst_9424__$1 == null);
var state_9444__$1 = (function (){var statearr_9446 = state_9444;
(statearr_9446[(7)] = inst_9423__$1);

(statearr_9446[(9)] = inst_9425);

(statearr_9446[(8)] = inst_9424__$1);

return statearr_9446;
})();
if(cljs.core.truth_(inst_9426)){
var statearr_9447_9467 = state_9444__$1;
(statearr_9447_9467[(1)] = (8));

} else {
var statearr_9448_9468 = state_9444__$1;
(statearr_9448_9468[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9445 === (1))){
var inst_9413 = cljs.core.vec(chs);
var inst_9414 = inst_9413;
var state_9444__$1 = (function (){var statearr_9449 = state_9444;
(statearr_9449[(10)] = inst_9414);

return statearr_9449;
})();
var statearr_9450_9469 = state_9444__$1;
(statearr_9450_9469[(2)] = null);

(statearr_9450_9469[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9445 === (4))){
var inst_9414 = (state_9444[(10)]);
var state_9444__$1 = state_9444;
return cljs.core.async.ioc_alts_BANG_(state_9444__$1,(7),inst_9414);
} else {
if((state_val_9445 === (6))){
var inst_9440 = (state_9444[(2)]);
var state_9444__$1 = state_9444;
var statearr_9451_9470 = state_9444__$1;
(statearr_9451_9470[(2)] = inst_9440);

(statearr_9451_9470[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9445 === (3))){
var inst_9442 = (state_9444[(2)]);
var state_9444__$1 = state_9444;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9444__$1,inst_9442);
} else {
if((state_val_9445 === (2))){
var inst_9414 = (state_9444[(10)]);
var inst_9416 = cljs.core.count(inst_9414);
var inst_9417 = (inst_9416 > (0));
var state_9444__$1 = state_9444;
if(cljs.core.truth_(inst_9417)){
var statearr_9453_9471 = state_9444__$1;
(statearr_9453_9471[(1)] = (4));

} else {
var statearr_9454_9472 = state_9444__$1;
(statearr_9454_9472[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9445 === (11))){
var inst_9414 = (state_9444[(10)]);
var inst_9433 = (state_9444[(2)]);
var tmp9452 = inst_9414;
var inst_9414__$1 = tmp9452;
var state_9444__$1 = (function (){var statearr_9455 = state_9444;
(statearr_9455[(11)] = inst_9433);

(statearr_9455[(10)] = inst_9414__$1);

return statearr_9455;
})();
var statearr_9456_9473 = state_9444__$1;
(statearr_9456_9473[(2)] = null);

(statearr_9456_9473[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9445 === (9))){
var inst_9424 = (state_9444[(8)]);
var state_9444__$1 = state_9444;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9444__$1,(11),out,inst_9424);
} else {
if((state_val_9445 === (5))){
var inst_9438 = cljs.core.async.close_BANG_(out);
var state_9444__$1 = state_9444;
var statearr_9457_9474 = state_9444__$1;
(statearr_9457_9474[(2)] = inst_9438);

(statearr_9457_9474[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9445 === (10))){
var inst_9436 = (state_9444[(2)]);
var state_9444__$1 = state_9444;
var statearr_9458_9475 = state_9444__$1;
(statearr_9458_9475[(2)] = inst_9436);

(statearr_9458_9475[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9445 === (8))){
var inst_9423 = (state_9444[(7)]);
var inst_9414 = (state_9444[(10)]);
var inst_9425 = (state_9444[(9)]);
var inst_9424 = (state_9444[(8)]);
var inst_9428 = (function (){var cs = inst_9414;
var vec__9419 = inst_9423;
var v = inst_9424;
var c = inst_9425;
return ((function (cs,vec__9419,v,c,inst_9423,inst_9414,inst_9425,inst_9424,state_val_9445,c__8052__auto___9466,out){
return (function (p1__9410_SHARP_){
return cljs.core.not_EQ_.cljs$core$IFn$_invoke$arity$2(c,p1__9410_SHARP_);
});
;})(cs,vec__9419,v,c,inst_9423,inst_9414,inst_9425,inst_9424,state_val_9445,c__8052__auto___9466,out))
})();
var inst_9429 = cljs.core.filterv(inst_9428,inst_9414);
var inst_9414__$1 = inst_9429;
var state_9444__$1 = (function (){var statearr_9459 = state_9444;
(statearr_9459[(10)] = inst_9414__$1);

return statearr_9459;
})();
var statearr_9460_9476 = state_9444__$1;
(statearr_9460_9476[(2)] = null);

(statearr_9460_9476[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___9466,out))
;
return ((function (switch__7945__auto__,c__8052__auto___9466,out){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_9461 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9461[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_9461[(1)] = (1));

return statearr_9461;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_9444){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_9444);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e9462){if((e9462 instanceof Object)){
var ex__7949__auto__ = e9462;
var statearr_9463_9477 = state_9444;
(statearr_9463_9477[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9444);

return cljs.core.cst$kw$recur;
} else {
throw e9462;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__9478 = state_9444;
state_9444 = G__9478;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_9444){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_9444);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___9466,out))
})();
var state__8054__auto__ = (function (){var statearr_9464 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_9464[(6)] = c__8052__auto___9466);

return statearr_9464;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___9466,out))
);


return out;
});

cljs.core.async.merge.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel containing the single (collection) result of the
 *   items taken from the channel conjoined to the supplied
 *   collection. ch must close before into produces a result.
 */
cljs.core.async.into = (function cljs$core$async$into(coll,ch){
return cljs.core.async.reduce(cljs.core.conj,coll,ch);
});
/**
 * Returns a channel that will return, at most, n items from ch. After n items
 * have been returned, or ch has been closed, the return chanel will close.
 * 
 *   The output channel is unbuffered by default, unless buf-or-n is given.
 */
cljs.core.async.take = (function cljs$core$async$take(var_args){
var G__9480 = arguments.length;
switch (G__9480) {
case 2:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__8052__auto___9525 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___9525,out){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___9525,out){
return (function (state_9504){
var state_val_9505 = (state_9504[(1)]);
if((state_val_9505 === (7))){
var inst_9486 = (state_9504[(7)]);
var inst_9486__$1 = (state_9504[(2)]);
var inst_9487 = (inst_9486__$1 == null);
var inst_9488 = cljs.core.not(inst_9487);
var state_9504__$1 = (function (){var statearr_9506 = state_9504;
(statearr_9506[(7)] = inst_9486__$1);

return statearr_9506;
})();
if(inst_9488){
var statearr_9507_9526 = state_9504__$1;
(statearr_9507_9526[(1)] = (8));

} else {
var statearr_9508_9527 = state_9504__$1;
(statearr_9508_9527[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9505 === (1))){
var inst_9481 = (0);
var state_9504__$1 = (function (){var statearr_9509 = state_9504;
(statearr_9509[(8)] = inst_9481);

return statearr_9509;
})();
var statearr_9510_9528 = state_9504__$1;
(statearr_9510_9528[(2)] = null);

(statearr_9510_9528[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9505 === (4))){
var state_9504__$1 = state_9504;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9504__$1,(7),ch);
} else {
if((state_val_9505 === (6))){
var inst_9499 = (state_9504[(2)]);
var state_9504__$1 = state_9504;
var statearr_9511_9529 = state_9504__$1;
(statearr_9511_9529[(2)] = inst_9499);

(statearr_9511_9529[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9505 === (3))){
var inst_9501 = (state_9504[(2)]);
var inst_9502 = cljs.core.async.close_BANG_(out);
var state_9504__$1 = (function (){var statearr_9512 = state_9504;
(statearr_9512[(9)] = inst_9501);

return statearr_9512;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_9504__$1,inst_9502);
} else {
if((state_val_9505 === (2))){
var inst_9481 = (state_9504[(8)]);
var inst_9483 = (inst_9481 < n);
var state_9504__$1 = state_9504;
if(cljs.core.truth_(inst_9483)){
var statearr_9513_9530 = state_9504__$1;
(statearr_9513_9530[(1)] = (4));

} else {
var statearr_9514_9531 = state_9504__$1;
(statearr_9514_9531[(1)] = (5));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9505 === (11))){
var inst_9481 = (state_9504[(8)]);
var inst_9491 = (state_9504[(2)]);
var inst_9492 = (inst_9481 + (1));
var inst_9481__$1 = inst_9492;
var state_9504__$1 = (function (){var statearr_9515 = state_9504;
(statearr_9515[(8)] = inst_9481__$1);

(statearr_9515[(10)] = inst_9491);

return statearr_9515;
})();
var statearr_9516_9532 = state_9504__$1;
(statearr_9516_9532[(2)] = null);

(statearr_9516_9532[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9505 === (9))){
var state_9504__$1 = state_9504;
var statearr_9517_9533 = state_9504__$1;
(statearr_9517_9533[(2)] = null);

(statearr_9517_9533[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9505 === (5))){
var state_9504__$1 = state_9504;
var statearr_9518_9534 = state_9504__$1;
(statearr_9518_9534[(2)] = null);

(statearr_9518_9534[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9505 === (10))){
var inst_9496 = (state_9504[(2)]);
var state_9504__$1 = state_9504;
var statearr_9519_9535 = state_9504__$1;
(statearr_9519_9535[(2)] = inst_9496);

(statearr_9519_9535[(1)] = (6));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9505 === (8))){
var inst_9486 = (state_9504[(7)]);
var state_9504__$1 = state_9504;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9504__$1,(11),out,inst_9486);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___9525,out))
;
return ((function (switch__7945__auto__,c__8052__auto___9525,out){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_9520 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_9520[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_9520[(1)] = (1));

return statearr_9520;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_9504){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_9504);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e9521){if((e9521 instanceof Object)){
var ex__7949__auto__ = e9521;
var statearr_9522_9536 = state_9504;
(statearr_9522_9536[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9504);

return cljs.core.cst$kw$recur;
} else {
throw e9521;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__9537 = state_9504;
state_9504 = G__9537;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_9504){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_9504);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___9525,out))
})();
var state__8054__auto__ = (function (){var statearr_9523 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_9523[(6)] = c__8052__auto___9525);

return statearr_9523;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___9525,out))
);


return out;
});

cljs.core.async.take.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_LT_ = (function cljs$core$async$map_LT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async9539 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async9539 = (function (f,ch,meta9540){
this.f = f;
this.ch = ch;
this.meta9540 = meta9540;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async9539.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_9541,meta9540__$1){
var self__ = this;
var _9541__$1 = this;
return (new cljs.core.async.t_cljs$core$async9539(self__.f,self__.ch,meta9540__$1));
});

cljs.core.async.t_cljs$core$async9539.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_9541){
var self__ = this;
var _9541__$1 = this;
return self__.meta9540;
});

cljs.core.async.t_cljs$core$async9539.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9539.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async9539.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async9539.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9539.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
var ret = cljs.core.async.impl.protocols.take_BANG_(self__.ch,(function (){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async9542 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async9542 = (function (f,ch,meta9540,_,fn1,meta9543){
this.f = f;
this.ch = ch;
this.meta9540 = meta9540;
this._ = _;
this.fn1 = fn1;
this.meta9543 = meta9543;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async9542.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (___$1){
return (function (_9544,meta9543__$1){
var self__ = this;
var _9544__$1 = this;
return (new cljs.core.async.t_cljs$core$async9542(self__.f,self__.ch,self__.meta9540,self__._,self__.fn1,meta9543__$1));
});})(___$1))
;

cljs.core.async.t_cljs$core$async9542.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (___$1){
return (function (_9544){
var self__ = this;
var _9544__$1 = this;
return self__.meta9543;
});})(___$1))
;

cljs.core.async.t_cljs$core$async9542.prototype.cljs$core$async$impl$protocols$Handler$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9542.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return cljs.core.async.impl.protocols.active_QMARK_(self__.fn1);
});})(___$1))
;

cljs.core.async.t_cljs$core$async9542.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return true;
});})(___$1))
;

cljs.core.async.t_cljs$core$async9542.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
var f1 = cljs.core.async.impl.protocols.commit(self__.fn1);
return ((function (f1,___$2,___$1){
return (function (p1__9538_SHARP_){
var G__9545 = (((p1__9538_SHARP_ == null))?null:(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(p1__9538_SHARP_) : self__.f.call(null,p1__9538_SHARP_)));
return (f1.cljs$core$IFn$_invoke$arity$1 ? f1.cljs$core$IFn$_invoke$arity$1(G__9545) : f1.call(null,G__9545));
});
;})(f1,___$2,___$1))
});})(___$1))
;

cljs.core.async.t_cljs$core$async9542.getBasis = ((function (___$1){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta9540,cljs.core.with_meta(cljs.core.cst$sym$_,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$tag,cljs.core.cst$sym$cljs$core$async_SLASH_t_cljs$core$async9539], null)),cljs.core.cst$sym$fn1,cljs.core.cst$sym$meta9543], null);
});})(___$1))
;

cljs.core.async.t_cljs$core$async9542.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async9542.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async9542";

cljs.core.async.t_cljs$core$async9542.cljs$lang$ctorPrWriter = ((function (___$1){
return (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async9542");
});})(___$1))
;

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async9542.
 */
cljs.core.async.__GT_t_cljs$core$async9542 = ((function (___$1){
return (function cljs$core$async$map_LT__$___GT_t_cljs$core$async9542(f__$1,ch__$1,meta9540__$1,___$2,fn1__$1,meta9543){
return (new cljs.core.async.t_cljs$core$async9542(f__$1,ch__$1,meta9540__$1,___$2,fn1__$1,meta9543));
});})(___$1))
;

}

return (new cljs.core.async.t_cljs$core$async9542(self__.f,self__.ch,self__.meta9540,___$1,fn1,cljs.core.PersistentArrayMap.EMPTY));
})()
);
if(cljs.core.truth_((function (){var and__4120__auto__ = ret;
if(cljs.core.truth_(and__4120__auto__)){
return (!((cljs.core.deref(ret) == null)));
} else {
return and__4120__auto__;
}
})())){
return cljs.core.async.impl.channels.box((function (){var G__9546 = cljs.core.deref(ret);
return (self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(G__9546) : self__.f.call(null,G__9546));
})());
} else {
return ret;
}
});

cljs.core.async.t_cljs$core$async9539.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9539.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
});

cljs.core.async.t_cljs$core$async9539.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta9540], null);
});

cljs.core.async.t_cljs$core$async9539.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async9539.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async9539";

cljs.core.async.t_cljs$core$async9539.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async9539");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async9539.
 */
cljs.core.async.__GT_t_cljs$core$async9539 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async9539(f__$1,ch__$1,meta9540){
return (new cljs.core.async.t_cljs$core$async9539(f__$1,ch__$1,meta9540));
});

}

return (new cljs.core.async.t_cljs$core$async9539(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_GT_ = (function cljs$core$async$map_GT_(f,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async9547 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async9547 = (function (f,ch,meta9548){
this.f = f;
this.ch = ch;
this.meta9548 = meta9548;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async9547.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_9549,meta9548__$1){
var self__ = this;
var _9549__$1 = this;
return (new cljs.core.async.t_cljs$core$async9547(self__.f,self__.ch,meta9548__$1));
});

cljs.core.async.t_cljs$core$async9547.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_9549){
var self__ = this;
var _9549__$1 = this;
return self__.meta9548;
});

cljs.core.async.t_cljs$core$async9547.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9547.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async9547.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9547.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async9547.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9547.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,(self__.f.cljs$core$IFn$_invoke$arity$1 ? self__.f.cljs$core$IFn$_invoke$arity$1(val) : self__.f.call(null,val)),fn1);
});

cljs.core.async.t_cljs$core$async9547.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$f,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta9548], null);
});

cljs.core.async.t_cljs$core$async9547.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async9547.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async9547";

cljs.core.async.t_cljs$core$async9547.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async9547");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async9547.
 */
cljs.core.async.__GT_t_cljs$core$async9547 = (function cljs$core$async$map_GT__$___GT_t_cljs$core$async9547(f__$1,ch__$1,meta9548){
return (new cljs.core.async.t_cljs$core$async9547(f__$1,ch__$1,meta9548));
});

}

return (new cljs.core.async.t_cljs$core$async9547(f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_GT_ = (function cljs$core$async$filter_GT_(p,ch){
if((typeof cljs !== 'undefined') && (typeof cljs.core !== 'undefined') && (typeof cljs.core.async !== 'undefined') && (typeof cljs.core.async.t_cljs$core$async9550 !== 'undefined')){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async9550 = (function (p,ch,meta9551){
this.p = p;
this.ch = ch;
this.meta9551 = meta9551;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
cljs.core.async.t_cljs$core$async9550.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_9552,meta9551__$1){
var self__ = this;
var _9552__$1 = this;
return (new cljs.core.async.t_cljs$core$async9550(self__.p,self__.ch,meta9551__$1));
});

cljs.core.async.t_cljs$core$async9550.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_9552){
var self__ = this;
var _9552__$1 = this;
return self__.meta9551;
});

cljs.core.async.t_cljs$core$async9550.prototype.cljs$core$async$impl$protocols$Channel$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9550.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_(self__.ch);
});

cljs.core.async.t_cljs$core$async9550.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_(self__.ch);
});

cljs.core.async.t_cljs$core$async9550.prototype.cljs$core$async$impl$protocols$ReadPort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9550.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_(self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async9550.prototype.cljs$core$async$impl$protocols$WritePort$ = cljs.core.PROTOCOL_SENTINEL;

cljs.core.async.t_cljs$core$async9550.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_((self__.p.cljs$core$IFn$_invoke$arity$1 ? self__.p.cljs$core$IFn$_invoke$arity$1(val) : self__.p.call(null,val)))){
return cljs.core.async.impl.protocols.put_BANG_(self__.ch,val,fn1);
} else {
return cljs.core.async.impl.channels.box(cljs.core.not(cljs.core.async.impl.protocols.closed_QMARK_(self__.ch)));
}
});

cljs.core.async.t_cljs$core$async9550.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$p,cljs.core.cst$sym$ch,cljs.core.cst$sym$meta9551], null);
});

cljs.core.async.t_cljs$core$async9550.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async9550.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async9550";

cljs.core.async.t_cljs$core$async9550.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"cljs.core.async/t_cljs$core$async9550");
});

/**
 * Positional factory function for cljs.core.async/t_cljs$core$async9550.
 */
cljs.core.async.__GT_t_cljs$core$async9550 = (function cljs$core$async$filter_GT__$___GT_t_cljs$core$async9550(p__$1,ch__$1,meta9551){
return (new cljs.core.async.t_cljs$core$async9550(p__$1,ch__$1,meta9551));
});

}

return (new cljs.core.async.t_cljs$core$async9550(p,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_GT_ = (function cljs$core$async$remove_GT_(p,ch){
return cljs.core.async.filter_GT_(cljs.core.complement(p),ch);
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_LT_ = (function cljs$core$async$filter_LT_(var_args){
var G__9554 = arguments.length;
switch (G__9554) {
case 2:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__8052__auto___9594 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___9594,out){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___9594,out){
return (function (state_9575){
var state_val_9576 = (state_9575[(1)]);
if((state_val_9576 === (7))){
var inst_9571 = (state_9575[(2)]);
var state_9575__$1 = state_9575;
var statearr_9577_9595 = state_9575__$1;
(statearr_9577_9595[(2)] = inst_9571);

(statearr_9577_9595[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9576 === (1))){
var state_9575__$1 = state_9575;
var statearr_9578_9596 = state_9575__$1;
(statearr_9578_9596[(2)] = null);

(statearr_9578_9596[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9576 === (4))){
var inst_9557 = (state_9575[(7)]);
var inst_9557__$1 = (state_9575[(2)]);
var inst_9558 = (inst_9557__$1 == null);
var state_9575__$1 = (function (){var statearr_9579 = state_9575;
(statearr_9579[(7)] = inst_9557__$1);

return statearr_9579;
})();
if(cljs.core.truth_(inst_9558)){
var statearr_9580_9597 = state_9575__$1;
(statearr_9580_9597[(1)] = (5));

} else {
var statearr_9581_9598 = state_9575__$1;
(statearr_9581_9598[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9576 === (6))){
var inst_9557 = (state_9575[(7)]);
var inst_9562 = (p.cljs$core$IFn$_invoke$arity$1 ? p.cljs$core$IFn$_invoke$arity$1(inst_9557) : p.call(null,inst_9557));
var state_9575__$1 = state_9575;
if(cljs.core.truth_(inst_9562)){
var statearr_9582_9599 = state_9575__$1;
(statearr_9582_9599[(1)] = (8));

} else {
var statearr_9583_9600 = state_9575__$1;
(statearr_9583_9600[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9576 === (3))){
var inst_9573 = (state_9575[(2)]);
var state_9575__$1 = state_9575;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9575__$1,inst_9573);
} else {
if((state_val_9576 === (2))){
var state_9575__$1 = state_9575;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9575__$1,(4),ch);
} else {
if((state_val_9576 === (11))){
var inst_9565 = (state_9575[(2)]);
var state_9575__$1 = state_9575;
var statearr_9584_9601 = state_9575__$1;
(statearr_9584_9601[(2)] = inst_9565);

(statearr_9584_9601[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9576 === (9))){
var state_9575__$1 = state_9575;
var statearr_9585_9602 = state_9575__$1;
(statearr_9585_9602[(2)] = null);

(statearr_9585_9602[(1)] = (10));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9576 === (5))){
var inst_9560 = cljs.core.async.close_BANG_(out);
var state_9575__$1 = state_9575;
var statearr_9586_9603 = state_9575__$1;
(statearr_9586_9603[(2)] = inst_9560);

(statearr_9586_9603[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9576 === (10))){
var inst_9568 = (state_9575[(2)]);
var state_9575__$1 = (function (){var statearr_9587 = state_9575;
(statearr_9587[(8)] = inst_9568);

return statearr_9587;
})();
var statearr_9588_9604 = state_9575__$1;
(statearr_9588_9604[(2)] = null);

(statearr_9588_9604[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9576 === (8))){
var inst_9557 = (state_9575[(7)]);
var state_9575__$1 = state_9575;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9575__$1,(11),out,inst_9557);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___9594,out))
;
return ((function (switch__7945__auto__,c__8052__auto___9594,out){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_9589 = [null,null,null,null,null,null,null,null,null];
(statearr_9589[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_9589[(1)] = (1));

return statearr_9589;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_9575){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_9575);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e9590){if((e9590 instanceof Object)){
var ex__7949__auto__ = e9590;
var statearr_9591_9605 = state_9575;
(statearr_9591_9605[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9575);

return cljs.core.cst$kw$recur;
} else {
throw e9590;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__9606 = state_9575;
state_9575 = G__9606;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_9575){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_9575);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___9594,out))
})();
var state__8054__auto__ = (function (){var statearr_9592 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_9592[(6)] = c__8052__auto___9594);

return statearr_9592;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___9594,out))
);


return out;
});

cljs.core.async.filter_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_LT_ = (function cljs$core$async$remove_LT_(var_args){
var G__9608 = arguments.length;
switch (G__9608) {
case 2:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3(p,ch,null);
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3(cljs.core.complement(p),ch,buf_or_n);
});

cljs.core.async.remove_LT_.cljs$lang$maxFixedArity = 3;

cljs.core.async.mapcat_STAR_ = (function cljs$core$async$mapcat_STAR_(f,in$,out){
var c__8052__auto__ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto__){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto__){
return (function (state_9671){
var state_val_9672 = (state_9671[(1)]);
if((state_val_9672 === (7))){
var inst_9667 = (state_9671[(2)]);
var state_9671__$1 = state_9671;
var statearr_9673_9711 = state_9671__$1;
(statearr_9673_9711[(2)] = inst_9667);

(statearr_9673_9711[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (20))){
var inst_9637 = (state_9671[(7)]);
var inst_9648 = (state_9671[(2)]);
var inst_9649 = cljs.core.next(inst_9637);
var inst_9623 = inst_9649;
var inst_9624 = null;
var inst_9625 = (0);
var inst_9626 = (0);
var state_9671__$1 = (function (){var statearr_9674 = state_9671;
(statearr_9674[(8)] = inst_9648);

(statearr_9674[(9)] = inst_9623);

(statearr_9674[(10)] = inst_9624);

(statearr_9674[(11)] = inst_9625);

(statearr_9674[(12)] = inst_9626);

return statearr_9674;
})();
var statearr_9675_9712 = state_9671__$1;
(statearr_9675_9712[(2)] = null);

(statearr_9675_9712[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (1))){
var state_9671__$1 = state_9671;
var statearr_9676_9713 = state_9671__$1;
(statearr_9676_9713[(2)] = null);

(statearr_9676_9713[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (4))){
var inst_9612 = (state_9671[(13)]);
var inst_9612__$1 = (state_9671[(2)]);
var inst_9613 = (inst_9612__$1 == null);
var state_9671__$1 = (function (){var statearr_9677 = state_9671;
(statearr_9677[(13)] = inst_9612__$1);

return statearr_9677;
})();
if(cljs.core.truth_(inst_9613)){
var statearr_9678_9714 = state_9671__$1;
(statearr_9678_9714[(1)] = (5));

} else {
var statearr_9679_9715 = state_9671__$1;
(statearr_9679_9715[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (15))){
var state_9671__$1 = state_9671;
var statearr_9683_9716 = state_9671__$1;
(statearr_9683_9716[(2)] = null);

(statearr_9683_9716[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (21))){
var state_9671__$1 = state_9671;
var statearr_9684_9717 = state_9671__$1;
(statearr_9684_9717[(2)] = null);

(statearr_9684_9717[(1)] = (23));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (13))){
var inst_9623 = (state_9671[(9)]);
var inst_9624 = (state_9671[(10)]);
var inst_9625 = (state_9671[(11)]);
var inst_9626 = (state_9671[(12)]);
var inst_9633 = (state_9671[(2)]);
var inst_9634 = (inst_9626 + (1));
var tmp9680 = inst_9623;
var tmp9681 = inst_9624;
var tmp9682 = inst_9625;
var inst_9623__$1 = tmp9680;
var inst_9624__$1 = tmp9681;
var inst_9625__$1 = tmp9682;
var inst_9626__$1 = inst_9634;
var state_9671__$1 = (function (){var statearr_9685 = state_9671;
(statearr_9685[(9)] = inst_9623__$1);

(statearr_9685[(10)] = inst_9624__$1);

(statearr_9685[(11)] = inst_9625__$1);

(statearr_9685[(14)] = inst_9633);

(statearr_9685[(12)] = inst_9626__$1);

return statearr_9685;
})();
var statearr_9686_9718 = state_9671__$1;
(statearr_9686_9718[(2)] = null);

(statearr_9686_9718[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (22))){
var state_9671__$1 = state_9671;
var statearr_9687_9719 = state_9671__$1;
(statearr_9687_9719[(2)] = null);

(statearr_9687_9719[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (6))){
var inst_9612 = (state_9671[(13)]);
var inst_9621 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_9612) : f.call(null,inst_9612));
var inst_9622 = cljs.core.seq(inst_9621);
var inst_9623 = inst_9622;
var inst_9624 = null;
var inst_9625 = (0);
var inst_9626 = (0);
var state_9671__$1 = (function (){var statearr_9688 = state_9671;
(statearr_9688[(9)] = inst_9623);

(statearr_9688[(10)] = inst_9624);

(statearr_9688[(11)] = inst_9625);

(statearr_9688[(12)] = inst_9626);

return statearr_9688;
})();
var statearr_9689_9720 = state_9671__$1;
(statearr_9689_9720[(2)] = null);

(statearr_9689_9720[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (17))){
var inst_9637 = (state_9671[(7)]);
var inst_9641 = cljs.core.chunk_first(inst_9637);
var inst_9642 = cljs.core.chunk_rest(inst_9637);
var inst_9643 = cljs.core.count(inst_9641);
var inst_9623 = inst_9642;
var inst_9624 = inst_9641;
var inst_9625 = inst_9643;
var inst_9626 = (0);
var state_9671__$1 = (function (){var statearr_9690 = state_9671;
(statearr_9690[(9)] = inst_9623);

(statearr_9690[(10)] = inst_9624);

(statearr_9690[(11)] = inst_9625);

(statearr_9690[(12)] = inst_9626);

return statearr_9690;
})();
var statearr_9691_9721 = state_9671__$1;
(statearr_9691_9721[(2)] = null);

(statearr_9691_9721[(1)] = (8));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (3))){
var inst_9669 = (state_9671[(2)]);
var state_9671__$1 = state_9671;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9671__$1,inst_9669);
} else {
if((state_val_9672 === (12))){
var inst_9657 = (state_9671[(2)]);
var state_9671__$1 = state_9671;
var statearr_9692_9722 = state_9671__$1;
(statearr_9692_9722[(2)] = inst_9657);

(statearr_9692_9722[(1)] = (9));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (2))){
var state_9671__$1 = state_9671;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9671__$1,(4),in$);
} else {
if((state_val_9672 === (23))){
var inst_9665 = (state_9671[(2)]);
var state_9671__$1 = state_9671;
var statearr_9693_9723 = state_9671__$1;
(statearr_9693_9723[(2)] = inst_9665);

(statearr_9693_9723[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (19))){
var inst_9652 = (state_9671[(2)]);
var state_9671__$1 = state_9671;
var statearr_9694_9724 = state_9671__$1;
(statearr_9694_9724[(2)] = inst_9652);

(statearr_9694_9724[(1)] = (16));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (11))){
var inst_9637 = (state_9671[(7)]);
var inst_9623 = (state_9671[(9)]);
var inst_9637__$1 = cljs.core.seq(inst_9623);
var state_9671__$1 = (function (){var statearr_9695 = state_9671;
(statearr_9695[(7)] = inst_9637__$1);

return statearr_9695;
})();
if(inst_9637__$1){
var statearr_9696_9725 = state_9671__$1;
(statearr_9696_9725[(1)] = (14));

} else {
var statearr_9697_9726 = state_9671__$1;
(statearr_9697_9726[(1)] = (15));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (9))){
var inst_9659 = (state_9671[(2)]);
var inst_9660 = cljs.core.async.impl.protocols.closed_QMARK_(out);
var state_9671__$1 = (function (){var statearr_9698 = state_9671;
(statearr_9698[(15)] = inst_9659);

return statearr_9698;
})();
if(cljs.core.truth_(inst_9660)){
var statearr_9699_9727 = state_9671__$1;
(statearr_9699_9727[(1)] = (21));

} else {
var statearr_9700_9728 = state_9671__$1;
(statearr_9700_9728[(1)] = (22));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (5))){
var inst_9615 = cljs.core.async.close_BANG_(out);
var state_9671__$1 = state_9671;
var statearr_9701_9729 = state_9671__$1;
(statearr_9701_9729[(2)] = inst_9615);

(statearr_9701_9729[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (14))){
var inst_9637 = (state_9671[(7)]);
var inst_9639 = cljs.core.chunked_seq_QMARK_(inst_9637);
var state_9671__$1 = state_9671;
if(inst_9639){
var statearr_9702_9730 = state_9671__$1;
(statearr_9702_9730[(1)] = (17));

} else {
var statearr_9703_9731 = state_9671__$1;
(statearr_9703_9731[(1)] = (18));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (16))){
var inst_9655 = (state_9671[(2)]);
var state_9671__$1 = state_9671;
var statearr_9704_9732 = state_9671__$1;
(statearr_9704_9732[(2)] = inst_9655);

(statearr_9704_9732[(1)] = (12));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9672 === (10))){
var inst_9624 = (state_9671[(10)]);
var inst_9626 = (state_9671[(12)]);
var inst_9631 = cljs.core._nth.cljs$core$IFn$_invoke$arity$2(inst_9624,inst_9626);
var state_9671__$1 = state_9671;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9671__$1,(13),out,inst_9631);
} else {
if((state_val_9672 === (18))){
var inst_9637 = (state_9671[(7)]);
var inst_9646 = cljs.core.first(inst_9637);
var state_9671__$1 = state_9671;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9671__$1,(20),out,inst_9646);
} else {
if((state_val_9672 === (8))){
var inst_9625 = (state_9671[(11)]);
var inst_9626 = (state_9671[(12)]);
var inst_9628 = (inst_9626 < inst_9625);
var inst_9629 = inst_9628;
var state_9671__$1 = state_9671;
if(cljs.core.truth_(inst_9629)){
var statearr_9705_9733 = state_9671__$1;
(statearr_9705_9733[(1)] = (10));

} else {
var statearr_9706_9734 = state_9671__$1;
(statearr_9706_9734[(1)] = (11));

}

return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto__))
;
return ((function (switch__7945__auto__,c__8052__auto__){
return (function() {
var cljs$core$async$mapcat_STAR__$_state_machine__7946__auto__ = null;
var cljs$core$async$mapcat_STAR__$_state_machine__7946__auto____0 = (function (){
var statearr_9707 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9707[(0)] = cljs$core$async$mapcat_STAR__$_state_machine__7946__auto__);

(statearr_9707[(1)] = (1));

return statearr_9707;
});
var cljs$core$async$mapcat_STAR__$_state_machine__7946__auto____1 = (function (state_9671){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_9671);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e9708){if((e9708 instanceof Object)){
var ex__7949__auto__ = e9708;
var statearr_9709_9735 = state_9671;
(statearr_9709_9735[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9671);

return cljs.core.cst$kw$recur;
} else {
throw e9708;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__9736 = state_9671;
state_9671 = G__9736;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$mapcat_STAR__$_state_machine__7946__auto__ = function(state_9671){
switch(arguments.length){
case 0:
return cljs$core$async$mapcat_STAR__$_state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$mapcat_STAR__$_state_machine__7946__auto____1.call(this,state_9671);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mapcat_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mapcat_STAR__$_state_machine__7946__auto____0;
cljs$core$async$mapcat_STAR__$_state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mapcat_STAR__$_state_machine__7946__auto____1;
return cljs$core$async$mapcat_STAR__$_state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto__))
})();
var state__8054__auto__ = (function (){var statearr_9710 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_9710[(6)] = c__8052__auto__);

return statearr_9710;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto__))
);

return c__8052__auto__;
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_LT_ = (function cljs$core$async$mapcat_LT_(var_args){
var G__9738 = arguments.length;
switch (G__9738) {
case 2:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2 = (function (f,in$){
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3(f,in$,null);
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3 = (function (f,in$,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return out;
});

cljs.core.async.mapcat_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_GT_ = (function cljs$core$async$mapcat_GT_(var_args){
var G__9741 = arguments.length;
switch (G__9741) {
case 2:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2 = (function (f,out){
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3(f,out,null);
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3 = (function (f,out,buf_or_n){
var in$ = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
cljs.core.async.mapcat_STAR_(f,in$,out);

return in$;
});

cljs.core.async.mapcat_GT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.unique = (function cljs$core$async$unique(var_args){
var G__9744 = arguments.length;
switch (G__9744) {
case 1:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1 = (function (ch){
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2(ch,null);
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2 = (function (ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__8052__auto___9791 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___9791,out){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___9791,out){
return (function (state_9768){
var state_val_9769 = (state_9768[(1)]);
if((state_val_9769 === (7))){
var inst_9763 = (state_9768[(2)]);
var state_9768__$1 = state_9768;
var statearr_9770_9792 = state_9768__$1;
(statearr_9770_9792[(2)] = inst_9763);

(statearr_9770_9792[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9769 === (1))){
var inst_9745 = null;
var state_9768__$1 = (function (){var statearr_9771 = state_9768;
(statearr_9771[(7)] = inst_9745);

return statearr_9771;
})();
var statearr_9772_9793 = state_9768__$1;
(statearr_9772_9793[(2)] = null);

(statearr_9772_9793[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9769 === (4))){
var inst_9748 = (state_9768[(8)]);
var inst_9748__$1 = (state_9768[(2)]);
var inst_9749 = (inst_9748__$1 == null);
var inst_9750 = cljs.core.not(inst_9749);
var state_9768__$1 = (function (){var statearr_9773 = state_9768;
(statearr_9773[(8)] = inst_9748__$1);

return statearr_9773;
})();
if(inst_9750){
var statearr_9774_9794 = state_9768__$1;
(statearr_9774_9794[(1)] = (5));

} else {
var statearr_9775_9795 = state_9768__$1;
(statearr_9775_9795[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9769 === (6))){
var state_9768__$1 = state_9768;
var statearr_9776_9796 = state_9768__$1;
(statearr_9776_9796[(2)] = null);

(statearr_9776_9796[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9769 === (3))){
var inst_9765 = (state_9768[(2)]);
var inst_9766 = cljs.core.async.close_BANG_(out);
var state_9768__$1 = (function (){var statearr_9777 = state_9768;
(statearr_9777[(9)] = inst_9765);

return statearr_9777;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_9768__$1,inst_9766);
} else {
if((state_val_9769 === (2))){
var state_9768__$1 = state_9768;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9768__$1,(4),ch);
} else {
if((state_val_9769 === (11))){
var inst_9748 = (state_9768[(8)]);
var inst_9757 = (state_9768[(2)]);
var inst_9745 = inst_9748;
var state_9768__$1 = (function (){var statearr_9778 = state_9768;
(statearr_9778[(10)] = inst_9757);

(statearr_9778[(7)] = inst_9745);

return statearr_9778;
})();
var statearr_9779_9797 = state_9768__$1;
(statearr_9779_9797[(2)] = null);

(statearr_9779_9797[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9769 === (9))){
var inst_9748 = (state_9768[(8)]);
var state_9768__$1 = state_9768;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9768__$1,(11),out,inst_9748);
} else {
if((state_val_9769 === (5))){
var inst_9748 = (state_9768[(8)]);
var inst_9745 = (state_9768[(7)]);
var inst_9752 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_9748,inst_9745);
var state_9768__$1 = state_9768;
if(inst_9752){
var statearr_9781_9798 = state_9768__$1;
(statearr_9781_9798[(1)] = (8));

} else {
var statearr_9782_9799 = state_9768__$1;
(statearr_9782_9799[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9769 === (10))){
var inst_9760 = (state_9768[(2)]);
var state_9768__$1 = state_9768;
var statearr_9783_9800 = state_9768__$1;
(statearr_9783_9800[(2)] = inst_9760);

(statearr_9783_9800[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9769 === (8))){
var inst_9745 = (state_9768[(7)]);
var tmp9780 = inst_9745;
var inst_9745__$1 = tmp9780;
var state_9768__$1 = (function (){var statearr_9784 = state_9768;
(statearr_9784[(7)] = inst_9745__$1);

return statearr_9784;
})();
var statearr_9785_9801 = state_9768__$1;
(statearr_9785_9801[(2)] = null);

(statearr_9785_9801[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___9791,out))
;
return ((function (switch__7945__auto__,c__8052__auto___9791,out){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_9786 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_9786[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_9786[(1)] = (1));

return statearr_9786;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_9768){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_9768);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e9787){if((e9787 instanceof Object)){
var ex__7949__auto__ = e9787;
var statearr_9788_9802 = state_9768;
(statearr_9788_9802[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9768);

return cljs.core.cst$kw$recur;
} else {
throw e9787;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__9803 = state_9768;
state_9768 = G__9803;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_9768){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_9768);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___9791,out))
})();
var state__8054__auto__ = (function (){var statearr_9789 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_9789[(6)] = c__8052__auto___9791);

return statearr_9789;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___9791,out))
);


return out;
});

cljs.core.async.unique.cljs$lang$maxFixedArity = 2;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition = (function cljs$core$async$partition(var_args){
var G__9805 = arguments.length;
switch (G__9805) {
case 2:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3(n,ch,null);
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__8052__auto___9871 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___9871,out){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___9871,out){
return (function (state_9843){
var state_val_9844 = (state_9843[(1)]);
if((state_val_9844 === (7))){
var inst_9839 = (state_9843[(2)]);
var state_9843__$1 = state_9843;
var statearr_9845_9872 = state_9843__$1;
(statearr_9845_9872[(2)] = inst_9839);

(statearr_9845_9872[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9844 === (1))){
var inst_9806 = (new Array(n));
var inst_9807 = inst_9806;
var inst_9808 = (0);
var state_9843__$1 = (function (){var statearr_9846 = state_9843;
(statearr_9846[(7)] = inst_9807);

(statearr_9846[(8)] = inst_9808);

return statearr_9846;
})();
var statearr_9847_9873 = state_9843__$1;
(statearr_9847_9873[(2)] = null);

(statearr_9847_9873[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9844 === (4))){
var inst_9811 = (state_9843[(9)]);
var inst_9811__$1 = (state_9843[(2)]);
var inst_9812 = (inst_9811__$1 == null);
var inst_9813 = cljs.core.not(inst_9812);
var state_9843__$1 = (function (){var statearr_9848 = state_9843;
(statearr_9848[(9)] = inst_9811__$1);

return statearr_9848;
})();
if(inst_9813){
var statearr_9849_9874 = state_9843__$1;
(statearr_9849_9874[(1)] = (5));

} else {
var statearr_9850_9875 = state_9843__$1;
(statearr_9850_9875[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9844 === (15))){
var inst_9833 = (state_9843[(2)]);
var state_9843__$1 = state_9843;
var statearr_9851_9876 = state_9843__$1;
(statearr_9851_9876[(2)] = inst_9833);

(statearr_9851_9876[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9844 === (13))){
var state_9843__$1 = state_9843;
var statearr_9852_9877 = state_9843__$1;
(statearr_9852_9877[(2)] = null);

(statearr_9852_9877[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9844 === (6))){
var inst_9808 = (state_9843[(8)]);
var inst_9829 = (inst_9808 > (0));
var state_9843__$1 = state_9843;
if(cljs.core.truth_(inst_9829)){
var statearr_9853_9878 = state_9843__$1;
(statearr_9853_9878[(1)] = (12));

} else {
var statearr_9854_9879 = state_9843__$1;
(statearr_9854_9879[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9844 === (3))){
var inst_9841 = (state_9843[(2)]);
var state_9843__$1 = state_9843;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9843__$1,inst_9841);
} else {
if((state_val_9844 === (12))){
var inst_9807 = (state_9843[(7)]);
var inst_9831 = cljs.core.vec(inst_9807);
var state_9843__$1 = state_9843;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9843__$1,(15),out,inst_9831);
} else {
if((state_val_9844 === (2))){
var state_9843__$1 = state_9843;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9843__$1,(4),ch);
} else {
if((state_val_9844 === (11))){
var inst_9823 = (state_9843[(2)]);
var inst_9824 = (new Array(n));
var inst_9807 = inst_9824;
var inst_9808 = (0);
var state_9843__$1 = (function (){var statearr_9855 = state_9843;
(statearr_9855[(7)] = inst_9807);

(statearr_9855[(8)] = inst_9808);

(statearr_9855[(10)] = inst_9823);

return statearr_9855;
})();
var statearr_9856_9880 = state_9843__$1;
(statearr_9856_9880[(2)] = null);

(statearr_9856_9880[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9844 === (9))){
var inst_9807 = (state_9843[(7)]);
var inst_9821 = cljs.core.vec(inst_9807);
var state_9843__$1 = state_9843;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9843__$1,(11),out,inst_9821);
} else {
if((state_val_9844 === (5))){
var inst_9807 = (state_9843[(7)]);
var inst_9808 = (state_9843[(8)]);
var inst_9816 = (state_9843[(11)]);
var inst_9811 = (state_9843[(9)]);
var inst_9815 = (inst_9807[inst_9808] = inst_9811);
var inst_9816__$1 = (inst_9808 + (1));
var inst_9817 = (inst_9816__$1 < n);
var state_9843__$1 = (function (){var statearr_9857 = state_9843;
(statearr_9857[(12)] = inst_9815);

(statearr_9857[(11)] = inst_9816__$1);

return statearr_9857;
})();
if(cljs.core.truth_(inst_9817)){
var statearr_9858_9881 = state_9843__$1;
(statearr_9858_9881[(1)] = (8));

} else {
var statearr_9859_9882 = state_9843__$1;
(statearr_9859_9882[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9844 === (14))){
var inst_9836 = (state_9843[(2)]);
var inst_9837 = cljs.core.async.close_BANG_(out);
var state_9843__$1 = (function (){var statearr_9861 = state_9843;
(statearr_9861[(13)] = inst_9836);

return statearr_9861;
})();
var statearr_9862_9883 = state_9843__$1;
(statearr_9862_9883[(2)] = inst_9837);

(statearr_9862_9883[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9844 === (10))){
var inst_9827 = (state_9843[(2)]);
var state_9843__$1 = state_9843;
var statearr_9863_9884 = state_9843__$1;
(statearr_9863_9884[(2)] = inst_9827);

(statearr_9863_9884[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9844 === (8))){
var inst_9807 = (state_9843[(7)]);
var inst_9816 = (state_9843[(11)]);
var tmp9860 = inst_9807;
var inst_9807__$1 = tmp9860;
var inst_9808 = inst_9816;
var state_9843__$1 = (function (){var statearr_9864 = state_9843;
(statearr_9864[(7)] = inst_9807__$1);

(statearr_9864[(8)] = inst_9808);

return statearr_9864;
})();
var statearr_9865_9885 = state_9843__$1;
(statearr_9865_9885[(2)] = null);

(statearr_9865_9885[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___9871,out))
;
return ((function (switch__7945__auto__,c__8052__auto___9871,out){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_9866 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9866[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_9866[(1)] = (1));

return statearr_9866;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_9843){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_9843);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e9867){if((e9867 instanceof Object)){
var ex__7949__auto__ = e9867;
var statearr_9868_9886 = state_9843;
(statearr_9868_9886[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9843);

return cljs.core.cst$kw$recur;
} else {
throw e9867;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__9887 = state_9843;
state_9843 = G__9887;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_9843){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_9843);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___9871,out))
})();
var state__8054__auto__ = (function (){var statearr_9869 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_9869[(6)] = c__8052__auto___9871);

return statearr_9869;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___9871,out))
);


return out;
});

cljs.core.async.partition.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition_by = (function cljs$core$async$partition_by(var_args){
var G__9889 = arguments.length;
switch (G__9889) {
case 2:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2 = (function (f,ch){
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3(f,ch,null);
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3 = (function (f,ch,buf_or_n){
var out = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1(buf_or_n);
var c__8052__auto___9959 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run(((function (c__8052__auto___9959,out){
return (function (){
var f__8053__auto__ = (function (){var switch__7945__auto__ = ((function (c__8052__auto___9959,out){
return (function (state_9931){
var state_val_9932 = (state_9931[(1)]);
if((state_val_9932 === (7))){
var inst_9927 = (state_9931[(2)]);
var state_9931__$1 = state_9931;
var statearr_9933_9960 = state_9931__$1;
(statearr_9933_9960[(2)] = inst_9927);

(statearr_9933_9960[(1)] = (3));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9932 === (1))){
var inst_9890 = [];
var inst_9891 = inst_9890;
var inst_9892 = cljs.core.cst$kw$cljs$core$async_SLASH_nothing;
var state_9931__$1 = (function (){var statearr_9934 = state_9931;
(statearr_9934[(7)] = inst_9892);

(statearr_9934[(8)] = inst_9891);

return statearr_9934;
})();
var statearr_9935_9961 = state_9931__$1;
(statearr_9935_9961[(2)] = null);

(statearr_9935_9961[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9932 === (4))){
var inst_9895 = (state_9931[(9)]);
var inst_9895__$1 = (state_9931[(2)]);
var inst_9896 = (inst_9895__$1 == null);
var inst_9897 = cljs.core.not(inst_9896);
var state_9931__$1 = (function (){var statearr_9936 = state_9931;
(statearr_9936[(9)] = inst_9895__$1);

return statearr_9936;
})();
if(inst_9897){
var statearr_9937_9962 = state_9931__$1;
(statearr_9937_9962[(1)] = (5));

} else {
var statearr_9938_9963 = state_9931__$1;
(statearr_9938_9963[(1)] = (6));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9932 === (15))){
var inst_9921 = (state_9931[(2)]);
var state_9931__$1 = state_9931;
var statearr_9939_9964 = state_9931__$1;
(statearr_9939_9964[(2)] = inst_9921);

(statearr_9939_9964[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9932 === (13))){
var state_9931__$1 = state_9931;
var statearr_9940_9965 = state_9931__$1;
(statearr_9940_9965[(2)] = null);

(statearr_9940_9965[(1)] = (14));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9932 === (6))){
var inst_9891 = (state_9931[(8)]);
var inst_9916 = inst_9891.length;
var inst_9917 = (inst_9916 > (0));
var state_9931__$1 = state_9931;
if(cljs.core.truth_(inst_9917)){
var statearr_9941_9966 = state_9931__$1;
(statearr_9941_9966[(1)] = (12));

} else {
var statearr_9942_9967 = state_9931__$1;
(statearr_9942_9967[(1)] = (13));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9932 === (3))){
var inst_9929 = (state_9931[(2)]);
var state_9931__$1 = state_9931;
return cljs.core.async.impl.ioc_helpers.return_chan(state_9931__$1,inst_9929);
} else {
if((state_val_9932 === (12))){
var inst_9891 = (state_9931[(8)]);
var inst_9919 = cljs.core.vec(inst_9891);
var state_9931__$1 = state_9931;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9931__$1,(15),out,inst_9919);
} else {
if((state_val_9932 === (2))){
var state_9931__$1 = state_9931;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_9931__$1,(4),ch);
} else {
if((state_val_9932 === (11))){
var inst_9899 = (state_9931[(10)]);
var inst_9895 = (state_9931[(9)]);
var inst_9909 = (state_9931[(2)]);
var inst_9910 = [];
var inst_9911 = inst_9910.push(inst_9895);
var inst_9891 = inst_9910;
var inst_9892 = inst_9899;
var state_9931__$1 = (function (){var statearr_9943 = state_9931;
(statearr_9943[(11)] = inst_9911);

(statearr_9943[(12)] = inst_9909);

(statearr_9943[(7)] = inst_9892);

(statearr_9943[(8)] = inst_9891);

return statearr_9943;
})();
var statearr_9944_9968 = state_9931__$1;
(statearr_9944_9968[(2)] = null);

(statearr_9944_9968[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9932 === (9))){
var inst_9891 = (state_9931[(8)]);
var inst_9907 = cljs.core.vec(inst_9891);
var state_9931__$1 = state_9931;
return cljs.core.async.impl.ioc_helpers.put_BANG_(state_9931__$1,(11),out,inst_9907);
} else {
if((state_val_9932 === (5))){
var inst_9899 = (state_9931[(10)]);
var inst_9892 = (state_9931[(7)]);
var inst_9895 = (state_9931[(9)]);
var inst_9899__$1 = (f.cljs$core$IFn$_invoke$arity$1 ? f.cljs$core$IFn$_invoke$arity$1(inst_9895) : f.call(null,inst_9895));
var inst_9900 = cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(inst_9899__$1,inst_9892);
var inst_9901 = cljs.core.keyword_identical_QMARK_(inst_9892,cljs.core.cst$kw$cljs$core$async_SLASH_nothing);
var inst_9902 = ((inst_9900) || (inst_9901));
var state_9931__$1 = (function (){var statearr_9945 = state_9931;
(statearr_9945[(10)] = inst_9899__$1);

return statearr_9945;
})();
if(cljs.core.truth_(inst_9902)){
var statearr_9946_9969 = state_9931__$1;
(statearr_9946_9969[(1)] = (8));

} else {
var statearr_9947_9970 = state_9931__$1;
(statearr_9947_9970[(1)] = (9));

}

return cljs.core.cst$kw$recur;
} else {
if((state_val_9932 === (14))){
var inst_9924 = (state_9931[(2)]);
var inst_9925 = cljs.core.async.close_BANG_(out);
var state_9931__$1 = (function (){var statearr_9949 = state_9931;
(statearr_9949[(13)] = inst_9924);

return statearr_9949;
})();
var statearr_9950_9971 = state_9931__$1;
(statearr_9950_9971[(2)] = inst_9925);

(statearr_9950_9971[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9932 === (10))){
var inst_9914 = (state_9931[(2)]);
var state_9931__$1 = state_9931;
var statearr_9951_9972 = state_9931__$1;
(statearr_9951_9972[(2)] = inst_9914);

(statearr_9951_9972[(1)] = (7));


return cljs.core.cst$kw$recur;
} else {
if((state_val_9932 === (8))){
var inst_9899 = (state_9931[(10)]);
var inst_9895 = (state_9931[(9)]);
var inst_9891 = (state_9931[(8)]);
var inst_9904 = inst_9891.push(inst_9895);
var tmp9948 = inst_9891;
var inst_9891__$1 = tmp9948;
var inst_9892 = inst_9899;
var state_9931__$1 = (function (){var statearr_9952 = state_9931;
(statearr_9952[(14)] = inst_9904);

(statearr_9952[(7)] = inst_9892);

(statearr_9952[(8)] = inst_9891__$1);

return statearr_9952;
})();
var statearr_9953_9973 = state_9931__$1;
(statearr_9953_9973[(2)] = null);

(statearr_9953_9973[(1)] = (2));


return cljs.core.cst$kw$recur;
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__8052__auto___9959,out))
;
return ((function (switch__7945__auto__,c__8052__auto___9959,out){
return (function() {
var cljs$core$async$state_machine__7946__auto__ = null;
var cljs$core$async$state_machine__7946__auto____0 = (function (){
var statearr_9954 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_9954[(0)] = cljs$core$async$state_machine__7946__auto__);

(statearr_9954[(1)] = (1));

return statearr_9954;
});
var cljs$core$async$state_machine__7946__auto____1 = (function (state_9931){
while(true){
var ret_value__7947__auto__ = (function (){try{while(true){
var result__7948__auto__ = switch__7945__auto__(state_9931);
if(cljs.core.keyword_identical_QMARK_(result__7948__auto__,cljs.core.cst$kw$recur)){
continue;
} else {
return result__7948__auto__;
}
break;
}
}catch (e9955){if((e9955 instanceof Object)){
var ex__7949__auto__ = e9955;
var statearr_9956_9974 = state_9931;
(statearr_9956_9974[(5)] = ex__7949__auto__);


cljs.core.async.impl.ioc_helpers.process_exception(state_9931);

return cljs.core.cst$kw$recur;
} else {
throw e9955;

}
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__7947__auto__,cljs.core.cst$kw$recur)){
var G__9975 = state_9931;
state_9931 = G__9975;
continue;
} else {
return ret_value__7947__auto__;
}
break;
}
});
cljs$core$async$state_machine__7946__auto__ = function(state_9931){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__7946__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__7946__auto____1.call(this,state_9931);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__7946__auto____0;
cljs$core$async$state_machine__7946__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__7946__auto____1;
return cljs$core$async$state_machine__7946__auto__;
})()
;})(switch__7945__auto__,c__8052__auto___9959,out))
})();
var state__8054__auto__ = (function (){var statearr_9957 = (f__8053__auto__.cljs$core$IFn$_invoke$arity$0 ? f__8053__auto__.cljs$core$IFn$_invoke$arity$0() : f__8053__auto__.call(null));
(statearr_9957[(6)] = c__8052__auto___9959);

return statearr_9957;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__8054__auto__);
});})(c__8052__auto___9959,out))
);


return out;
});

cljs.core.async.partition_by.cljs$lang$maxFixedArity = 3;


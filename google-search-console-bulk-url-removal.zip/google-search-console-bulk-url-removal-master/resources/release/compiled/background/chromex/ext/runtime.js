// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.runtime');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.runtime.last_error_STAR_ = (function chromex$ext$runtime$last_error_STAR_(config){
var result_12717 = (function (){var final_args_array_12718 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.lastError");
var ns_12719 = (function (){var target_obj_12722 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12723 = (target_obj_12722["chrome"]);
var next_obj_12724 = (next_obj_12723["runtime"]);
return next_obj_12724;
})();
var missing_api_12720 = null;
if(missing_api_12720 === true){
return null;
} else {

var target_12721 = (function (){var target_obj_12725 = ns_12719;
var next_obj_12726 = (target_obj_12725["lastError"]);
if((!((next_obj_12726 == null)))){
return next_obj_12726;
} else {
return null;
}
})();
return target_12721;
}
})();
return result_12717;
});
chromex.ext.runtime.id_STAR_ = (function chromex$ext$runtime$id_STAR_(config){
var result_12727 = (function (){var final_args_array_12728 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.id");
var ns_12729 = (function (){var target_obj_12732 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12733 = (target_obj_12732["chrome"]);
var next_obj_12734 = (next_obj_12733["runtime"]);
return next_obj_12734;
})();
var missing_api_12730 = null;
if(missing_api_12730 === true){
return null;
} else {

var target_12731 = (function (){var target_obj_12735 = ns_12729;
var next_obj_12736 = (target_obj_12735["id"]);
if((!((next_obj_12736 == null)))){
return next_obj_12736;
} else {
return null;
}
})();
return target_12731;
}
})();
return result_12727;
});
chromex.ext.runtime.get_background_page_STAR_ = (function chromex$ext$runtime$get_background_page_STAR_(config){
var callback_chan_12737 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_callback_12739_12757 = ((function (callback_chan_12737){
return (function (cb_background_page_12744){
var fexpr__12748 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__12749 = config__6203__auto__;
var G__12750 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_background_DASH_page,cljs.core.cst$kw$name,"getBackgroundPage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"background-page",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12751 = callback_chan_12737;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__12749,G__12750,G__12751) : handler__6205__auto__.call(null,G__12749,G__12750,G__12751));
})();
return (fexpr__12748.cljs$core$IFn$_invoke$arity$1 ? fexpr__12748.cljs$core$IFn$_invoke$arity$1(cb_background_page_12744) : fexpr__12748.call(null,cb_background_page_12744));
});})(callback_chan_12737))
;
var result_12738_12758 = (function (){var final_args_array_12740 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12739_12757,"callback",null], null)], null),"chrome.runtime.getBackgroundPage");
var ns_12741 = (function (){var target_obj_12752 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12753 = (target_obj_12752["chrome"]);
var next_obj_12754 = (next_obj_12753["runtime"]);
return next_obj_12754;
})();
var missing_api_12742 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getBackgroundPage",ns_12741,"getBackgroundPage") : api_check_fn__6242__auto__.call(null,"chrome.runtime.getBackgroundPage",ns_12741,"getBackgroundPage"));
})();
if(missing_api_12742 === true){
return null;
} else {

var target_12743 = (function (){var target_obj_12755 = ns_12741;
var next_obj_12756 = (target_obj_12755["getBackgroundPage"]);
if((!((next_obj_12756 == null)))){
return next_obj_12756;
} else {
return null;
}
})();
return target_12743.apply(ns_12741,final_args_array_12740);
}
})();

return callback_chan_12737;
});
chromex.ext.runtime.open_options_page_STAR_ = (function chromex$ext$runtime$open_options_page_STAR_(config){
var callback_chan_12759 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_callback_12761_12774 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__12766 = config__6203__auto__;
var G__12767 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_open_DASH_options_DASH_page,cljs.core.cst$kw$name,"openOptionsPage",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12768 = callback_chan_12759;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__12766,G__12767,G__12768) : handler__6205__auto__.call(null,G__12766,G__12767,G__12768));
})();
var result_12760_12775 = (function (){var final_args_array_12762 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12761_12774,"callback",true], null)], null),"chrome.runtime.openOptionsPage");
var ns_12763 = (function (){var target_obj_12769 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12770 = (target_obj_12769["chrome"]);
var next_obj_12771 = (next_obj_12770["runtime"]);
return next_obj_12771;
})();
var missing_api_12764 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.openOptionsPage",ns_12763,"openOptionsPage") : api_check_fn__6242__auto__.call(null,"chrome.runtime.openOptionsPage",ns_12763,"openOptionsPage"));
})();
if(missing_api_12764 === true){
return null;
} else {

var target_12765 = (function (){var target_obj_12772 = ns_12763;
var next_obj_12773 = (target_obj_12772["openOptionsPage"]);
if((!((next_obj_12773 == null)))){
return next_obj_12773;
} else {
return null;
}
})();
return target_12765.apply(ns_12763,final_args_array_12762);
}
})();

return callback_chan_12759;
});
chromex.ext.runtime.get_manifest_STAR_ = (function chromex$ext$runtime$get_manifest_STAR_(config){
var result_12776 = (function (){var final_args_array_12777 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.getManifest");
var ns_12778 = (function (){var target_obj_12781 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12782 = (target_obj_12781["chrome"]);
var next_obj_12783 = (next_obj_12782["runtime"]);
return next_obj_12783;
})();
var missing_api_12779 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getManifest",ns_12778,"getManifest") : api_check_fn__6242__auto__.call(null,"chrome.runtime.getManifest",ns_12778,"getManifest"));
})();
if(missing_api_12779 === true){
return null;
} else {

var target_12780 = (function (){var target_obj_12784 = ns_12778;
var next_obj_12785 = (target_obj_12784["getManifest"]);
if((!((next_obj_12785 == null)))){
return next_obj_12785;
} else {
return null;
}
})();
return target_12780.apply(ns_12778,final_args_array_12777);
}
})();
return result_12776;
});
chromex.ext.runtime.get_url_STAR_ = (function chromex$ext$runtime$get_url_STAR_(config,path){
var marshalled_path_12787 = (function (){var omit_test_12792 = path;
if(cljs.core.keyword_identical_QMARK_(omit_test_12792,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12792;
}
})();
var result_12786 = (function (){var final_args_array_12788 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_path_12787,"path",null], null)], null),"chrome.runtime.getURL");
var ns_12789 = (function (){var target_obj_12793 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12794 = (target_obj_12793["chrome"]);
var next_obj_12795 = (next_obj_12794["runtime"]);
return next_obj_12795;
})();
var missing_api_12790 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getURL",ns_12789,"getURL") : api_check_fn__6242__auto__.call(null,"chrome.runtime.getURL",ns_12789,"getURL"));
})();
if(missing_api_12790 === true){
return null;
} else {

var target_12791 = (function (){var target_obj_12796 = ns_12789;
var next_obj_12797 = (target_obj_12796["getURL"]);
if((!((next_obj_12797 == null)))){
return next_obj_12797;
} else {
return null;
}
})();
return target_12791.apply(ns_12789,final_args_array_12788);
}
})();
return result_12786;
});
chromex.ext.runtime.set_uninstall_url_STAR_ = (function chromex$ext$runtime$set_uninstall_url_STAR_(config,url){
var callback_chan_12798 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_url_12800_12815 = (function (){var omit_test_12806 = url;
if(cljs.core.keyword_identical_QMARK_(omit_test_12806,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12806;
}
})();
var marshalled_callback_12801_12816 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__12807 = config__6203__auto__;
var G__12808 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_set_DASH_uninstall_DASH_url,cljs.core.cst$kw$name,"setUninstallURL",cljs.core.cst$kw$since,"41",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"url",cljs.core.cst$kw$since,"34",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12809 = callback_chan_12798;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__12807,G__12808,G__12809) : handler__6205__auto__.call(null,G__12807,G__12808,G__12809));
})();
var result_12799_12817 = (function (){var final_args_array_12802 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_url_12800_12815,"url",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12801_12816,"callback",true], null)], null),"chrome.runtime.setUninstallURL");
var ns_12803 = (function (){var target_obj_12810 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12811 = (target_obj_12810["chrome"]);
var next_obj_12812 = (next_obj_12811["runtime"]);
return next_obj_12812;
})();
var missing_api_12804 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.setUninstallURL",ns_12803,"setUninstallURL") : api_check_fn__6242__auto__.call(null,"chrome.runtime.setUninstallURL",ns_12803,"setUninstallURL"));
})();
if(missing_api_12804 === true){
return null;
} else {

var target_12805 = (function (){var target_obj_12813 = ns_12803;
var next_obj_12814 = (target_obj_12813["setUninstallURL"]);
if((!((next_obj_12814 == null)))){
return next_obj_12814;
} else {
return null;
}
})();
return target_12805.apply(ns_12803,final_args_array_12802);
}
})();

return callback_chan_12798;
});
chromex.ext.runtime.reload_STAR_ = (function chromex$ext$runtime$reload_STAR_(config){
var result_12818 = (function (){var final_args_array_12819 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.reload");
var ns_12820 = (function (){var target_obj_12823 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12824 = (target_obj_12823["chrome"]);
var next_obj_12825 = (next_obj_12824["runtime"]);
return next_obj_12825;
})();
var missing_api_12821 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.reload",ns_12820,"reload") : api_check_fn__6242__auto__.call(null,"chrome.runtime.reload",ns_12820,"reload"));
})();
if(missing_api_12821 === true){
return null;
} else {

var target_12822 = (function (){var target_obj_12826 = ns_12820;
var next_obj_12827 = (target_obj_12826["reload"]);
if((!((next_obj_12827 == null)))){
return next_obj_12827;
} else {
return null;
}
})();
return target_12822.apply(ns_12820,final_args_array_12819);
}
})();
return result_12818;
});
chromex.ext.runtime.request_update_check_STAR_ = (function chromex$ext$runtime$request_update_check_STAR_(config){
var callback_chan_12828 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_callback_12830_12849 = ((function (callback_chan_12828){
return (function (cb_status_12835,cb_details_12836){
var fexpr__12840 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__12841 = config__6203__auto__;
var G__12842 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_request_DASH_update_DASH_check,cljs.core.cst$kw$name,"requestUpdateCheck",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"status",cljs.core.cst$kw$type,"runtime.RequestUpdateCheckStatus"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12843 = callback_chan_12828;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__12841,G__12842,G__12843) : handler__6205__auto__.call(null,G__12841,G__12842,G__12843));
})();
return (fexpr__12840.cljs$core$IFn$_invoke$arity$2 ? fexpr__12840.cljs$core$IFn$_invoke$arity$2(cb_status_12835,cb_details_12836) : fexpr__12840.call(null,cb_status_12835,cb_details_12836));
});})(callback_chan_12828))
;
var result_12829_12850 = (function (){var final_args_array_12831 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12830_12849,"callback",null], null)], null),"chrome.runtime.requestUpdateCheck");
var ns_12832 = (function (){var target_obj_12844 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12845 = (target_obj_12844["chrome"]);
var next_obj_12846 = (next_obj_12845["runtime"]);
return next_obj_12846;
})();
var missing_api_12833 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.requestUpdateCheck",ns_12832,"requestUpdateCheck") : api_check_fn__6242__auto__.call(null,"chrome.runtime.requestUpdateCheck",ns_12832,"requestUpdateCheck"));
})();
if(missing_api_12833 === true){
return null;
} else {

var target_12834 = (function (){var target_obj_12847 = ns_12832;
var next_obj_12848 = (target_obj_12847["requestUpdateCheck"]);
if((!((next_obj_12848 == null)))){
return next_obj_12848;
} else {
return null;
}
})();
return target_12834.apply(ns_12832,final_args_array_12831);
}
})();

return callback_chan_12828;
});
chromex.ext.runtime.restart_STAR_ = (function chromex$ext$runtime$restart_STAR_(config){
var result_12851 = (function (){var final_args_array_12852 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.runtime.restart");
var ns_12853 = (function (){var target_obj_12856 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12857 = (target_obj_12856["chrome"]);
var next_obj_12858 = (next_obj_12857["runtime"]);
return next_obj_12858;
})();
var missing_api_12854 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restart",ns_12853,"restart") : api_check_fn__6242__auto__.call(null,"chrome.runtime.restart",ns_12853,"restart"));
})();
if(missing_api_12854 === true){
return null;
} else {

var target_12855 = (function (){var target_obj_12859 = ns_12853;
var next_obj_12860 = (target_obj_12859["restart"]);
if((!((next_obj_12860 == null)))){
return next_obj_12860;
} else {
return null;
}
})();
return target_12855.apply(ns_12853,final_args_array_12852);
}
})();
return result_12851;
});
chromex.ext.runtime.restart_after_delay_STAR_ = (function chromex$ext$runtime$restart_after_delay_STAR_(config,seconds){
var callback_chan_12861 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_seconds_12863_12878 = (function (){var omit_test_12869 = seconds;
if(cljs.core.keyword_identical_QMARK_(omit_test_12869,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12869;
}
})();
var marshalled_callback_12864_12879 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__12870 = config__6203__auto__;
var G__12871 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_restart_DASH_after_DASH_delay,cljs.core.cst$kw$name,"restartAfterDelay",cljs.core.cst$kw$since,"53",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"seconds",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12872 = callback_chan_12861;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__12870,G__12871,G__12872) : handler__6205__auto__.call(null,G__12870,G__12871,G__12872));
})();
var result_12862_12880 = (function (){var final_args_array_12865 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_seconds_12863_12878,"seconds",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12864_12879,"callback",true], null)], null),"chrome.runtime.restartAfterDelay");
var ns_12866 = (function (){var target_obj_12873 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12874 = (target_obj_12873["chrome"]);
var next_obj_12875 = (next_obj_12874["runtime"]);
return next_obj_12875;
})();
var missing_api_12867 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.restartAfterDelay",ns_12866,"restartAfterDelay") : api_check_fn__6242__auto__.call(null,"chrome.runtime.restartAfterDelay",ns_12866,"restartAfterDelay"));
})();
if(missing_api_12867 === true){
return null;
} else {

var target_12868 = (function (){var target_obj_12876 = ns_12866;
var next_obj_12877 = (target_obj_12876["restartAfterDelay"]);
if((!((next_obj_12877 == null)))){
return next_obj_12877;
} else {
return null;
}
})();
return target_12868.apply(ns_12866,final_args_array_12865);
}
})();

return callback_chan_12861;
});
chromex.ext.runtime.connect_STAR_ = (function chromex$ext$runtime$connect_STAR_(config,extension_id,connect_info){
var marshalled_extension_id_12882 = (function (){var omit_test_12888 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_12888,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12888;
}
})();
var marshalled_connect_info_12883 = (function (){var omit_test_12889 = connect_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_12889,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12889;
}
})();
var result_12881 = (function (){var final_args_array_12884 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_12882,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_12883,"connect-info",true], null)], null),"chrome.runtime.connect");
var ns_12885 = (function (){var target_obj_12890 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12891 = (target_obj_12890["chrome"]);
var next_obj_12892 = (next_obj_12891["runtime"]);
return next_obj_12892;
})();
var missing_api_12886 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connect",ns_12885,"connect") : api_check_fn__6242__auto__.call(null,"chrome.runtime.connect",ns_12885,"connect"));
})();
if(missing_api_12886 === true){
return null;
} else {

var target_12887 = (function (){var target_obj_12893 = ns_12885;
var next_obj_12894 = (target_obj_12893["connect"]);
if((!((next_obj_12894 == null)))){
return next_obj_12894;
} else {
return null;
}
})();
return target_12887.apply(ns_12885,final_args_array_12884);
}
})();
return chromex.marshalling.from_native_chrome_port(config,result_12881);
});
chromex.ext.runtime.connect_native_STAR_ = (function chromex$ext$runtime$connect_native_STAR_(config,application){
var marshalled_application_12896 = (function (){var omit_test_12901 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_12901,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12901;
}
})();
var result_12895 = (function (){var final_args_array_12897 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_12896,"application",null], null)], null),"chrome.runtime.connectNative");
var ns_12898 = (function (){var target_obj_12902 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12903 = (target_obj_12902["chrome"]);
var next_obj_12904 = (next_obj_12903["runtime"]);
return next_obj_12904;
})();
var missing_api_12899 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.connectNative",ns_12898,"connectNative") : api_check_fn__6242__auto__.call(null,"chrome.runtime.connectNative",ns_12898,"connectNative"));
})();
if(missing_api_12899 === true){
return null;
} else {

var target_12900 = (function (){var target_obj_12905 = ns_12898;
var next_obj_12906 = (target_obj_12905["connectNative"]);
if((!((next_obj_12906 == null)))){
return next_obj_12906;
} else {
return null;
}
})();
return target_12900.apply(ns_12898,final_args_array_12897);
}
})();
return chromex.marshalling.from_native_chrome_port(config,result_12895);
});
chromex.ext.runtime.send_message_STAR_ = (function chromex$ext$runtime$send_message_STAR_(config,extension_id,message,options){
var callback_chan_12907 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_extension_id_12909_12933 = (function (){var omit_test_12917 = extension_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_12917,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12917;
}
})();
var marshalled_message_12910_12934 = (function (){var omit_test_12918 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_12918,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12918;
}
})();
var marshalled_options_12911_12935 = (function (){var omit_test_12919 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_12919,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12919;
}
})();
var marshalled_response_callback_12912_12936 = ((function (marshalled_extension_id_12909_12933,marshalled_message_12910_12934,marshalled_options_12911_12935,callback_chan_12907){
return (function (cb_response_12920){
var fexpr__12924 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__12925 = config__6203__auto__;
var G__12926 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_message,cljs.core.cst$kw$name,"sendMessage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"extension-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$since,"32",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12927 = callback_chan_12907;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__12925,G__12926,G__12927) : handler__6205__auto__.call(null,G__12925,G__12926,G__12927));
})();
return (fexpr__12924.cljs$core$IFn$_invoke$arity$1 ? fexpr__12924.cljs$core$IFn$_invoke$arity$1(cb_response_12920) : fexpr__12924.call(null,cb_response_12920));
});})(marshalled_extension_id_12909_12933,marshalled_message_12910_12934,marshalled_options_12911_12935,callback_chan_12907))
;
var result_12908_12937 = (function (){var final_args_array_12913 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_extension_id_12909_12933,"extension-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_12910_12934,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_12911_12935,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_12912_12936,"response-callback",true], null)], null),"chrome.runtime.sendMessage");
var ns_12914 = (function (){var target_obj_12928 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12929 = (target_obj_12928["chrome"]);
var next_obj_12930 = (next_obj_12929["runtime"]);
return next_obj_12930;
})();
var missing_api_12915 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendMessage",ns_12914,"sendMessage") : api_check_fn__6242__auto__.call(null,"chrome.runtime.sendMessage",ns_12914,"sendMessage"));
})();
if(missing_api_12915 === true){
return null;
} else {

var target_12916 = (function (){var target_obj_12931 = ns_12914;
var next_obj_12932 = (target_obj_12931["sendMessage"]);
if((!((next_obj_12932 == null)))){
return next_obj_12932;
} else {
return null;
}
})();
return target_12916.apply(ns_12914,final_args_array_12913);
}
})();

return callback_chan_12907;
});
chromex.ext.runtime.send_native_message_STAR_ = (function chromex$ext$runtime$send_native_message_STAR_(config,application,message){
var callback_chan_12938 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_application_12940_12962 = (function (){var omit_test_12947 = application;
if(cljs.core.keyword_identical_QMARK_(omit_test_12947,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12947;
}
})();
var marshalled_message_12941_12963 = (function (){var omit_test_12948 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_12948,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_12948;
}
})();
var marshalled_response_callback_12942_12964 = ((function (marshalled_application_12940_12962,marshalled_message_12941_12963,callback_chan_12938){
return (function (cb_response_12949){
var fexpr__12953 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__12954 = config__6203__auto__;
var G__12955 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_send_DASH_native_DASH_message,cljs.core.cst$kw$name,"sendNativeMessage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"application",cljs.core.cst$kw$type,"string"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12956 = callback_chan_12938;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__12954,G__12955,G__12956) : handler__6205__auto__.call(null,G__12954,G__12955,G__12956));
})();
return (fexpr__12953.cljs$core$IFn$_invoke$arity$1 ? fexpr__12953.cljs$core$IFn$_invoke$arity$1(cb_response_12949) : fexpr__12953.call(null,cb_response_12949));
});})(marshalled_application_12940_12962,marshalled_message_12941_12963,callback_chan_12938))
;
var result_12939_12965 = (function (){var final_args_array_12943 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_application_12940_12962,"application",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_12941_12963,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_12942_12964,"response-callback",true], null)], null),"chrome.runtime.sendNativeMessage");
var ns_12944 = (function (){var target_obj_12957 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12958 = (target_obj_12957["chrome"]);
var next_obj_12959 = (next_obj_12958["runtime"]);
return next_obj_12959;
})();
var missing_api_12945 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.sendNativeMessage",ns_12944,"sendNativeMessage") : api_check_fn__6242__auto__.call(null,"chrome.runtime.sendNativeMessage",ns_12944,"sendNativeMessage"));
})();
if(missing_api_12945 === true){
return null;
} else {

var target_12946 = (function (){var target_obj_12960 = ns_12944;
var next_obj_12961 = (target_obj_12960["sendNativeMessage"]);
if((!((next_obj_12961 == null)))){
return next_obj_12961;
} else {
return null;
}
})();
return target_12946.apply(ns_12944,final_args_array_12943);
}
})();

return callback_chan_12938;
});
chromex.ext.runtime.get_platform_info_STAR_ = (function chromex$ext$runtime$get_platform_info_STAR_(config){
var callback_chan_12966 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_callback_12968_12986 = ((function (callback_chan_12966){
return (function (cb_platform_info_12973){
var fexpr__12977 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__12978 = config__6203__auto__;
var G__12979 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_platform_DASH_info,cljs.core.cst$kw$name,"getPlatformInfo",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"platform-info",cljs.core.cst$kw$type,"runtime.PlatformInfo"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__12980 = callback_chan_12966;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__12978,G__12979,G__12980) : handler__6205__auto__.call(null,G__12978,G__12979,G__12980));
})();
return (fexpr__12977.cljs$core$IFn$_invoke$arity$1 ? fexpr__12977.cljs$core$IFn$_invoke$arity$1(cb_platform_info_12973) : fexpr__12977.call(null,cb_platform_info_12973));
});})(callback_chan_12966))
;
var result_12967_12987 = (function (){var final_args_array_12969 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12968_12986,"callback",null], null)], null),"chrome.runtime.getPlatformInfo");
var ns_12970 = (function (){var target_obj_12981 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12982 = (target_obj_12981["chrome"]);
var next_obj_12983 = (next_obj_12982["runtime"]);
return next_obj_12983;
})();
var missing_api_12971 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPlatformInfo",ns_12970,"getPlatformInfo") : api_check_fn__6242__auto__.call(null,"chrome.runtime.getPlatformInfo",ns_12970,"getPlatformInfo"));
})();
if(missing_api_12971 === true){
return null;
} else {

var target_12972 = (function (){var target_obj_12984 = ns_12970;
var next_obj_12985 = (target_obj_12984["getPlatformInfo"]);
if((!((next_obj_12985 == null)))){
return next_obj_12985;
} else {
return null;
}
})();
return target_12972.apply(ns_12970,final_args_array_12969);
}
})();

return callback_chan_12966;
});
chromex.ext.runtime.get_package_directory_entry_STAR_ = (function chromex$ext$runtime$get_package_directory_entry_STAR_(config){
var callback_chan_12988 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_callback_12990_13008 = ((function (callback_chan_12988){
return (function (cb_directory_entry_12995){
var fexpr__12999 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13000 = config__6203__auto__;
var G__13001 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$runtime_SLASH_get_DASH_package_DASH_directory_DASH_entry,cljs.core.cst$kw$name,"getPackageDirectoryEntry",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"directory-entry",cljs.core.cst$kw$type,"DirectoryEntry"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13002 = callback_chan_12988;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13000,G__13001,G__13002) : handler__6205__auto__.call(null,G__13000,G__13001,G__13002));
})();
return (fexpr__12999.cljs$core$IFn$_invoke$arity$1 ? fexpr__12999.cljs$core$IFn$_invoke$arity$1(cb_directory_entry_12995) : fexpr__12999.call(null,cb_directory_entry_12995));
});})(callback_chan_12988))
;
var result_12989_13009 = (function (){var final_args_array_12991 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_12990_13008,"callback",null], null)], null),"chrome.runtime.getPackageDirectoryEntry");
var ns_12992 = (function (){var target_obj_13003 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13004 = (target_obj_13003["chrome"]);
var next_obj_13005 = (next_obj_13004["runtime"]);
return next_obj_13005;
})();
var missing_api_12993 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.getPackageDirectoryEntry",ns_12992,"getPackageDirectoryEntry") : api_check_fn__6242__auto__.call(null,"chrome.runtime.getPackageDirectoryEntry",ns_12992,"getPackageDirectoryEntry"));
})();
if(missing_api_12993 === true){
return null;
} else {

var target_12994 = (function (){var target_obj_13006 = ns_12992;
var next_obj_13007 = (target_obj_13006["getPackageDirectoryEntry"]);
if((!((next_obj_13007 == null)))){
return next_obj_13007;
} else {
return null;
}
})();
return target_12994.apply(ns_12992,final_args_array_12991);
}
})();

return callback_chan_12988;
});
chromex.ext.runtime.on_startup_STAR_ = (function chromex$ext$runtime$on_startup_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13028 = arguments.length;
var i__4731__auto___13029 = (0);
while(true){
if((i__4731__auto___13029 < len__4730__auto___13028)){
args__4736__auto__.push((arguments[i__4731__auto___13029]));

var G__13030 = (i__4731__auto___13029 + (1));
i__4731__auto___13029 = G__13030;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_startup_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13013 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13020 = config__6203__auto__;
var G__13021 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_startup;
var G__13022 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13020,G__13021,G__13022) : handler__6205__auto__.call(null,G__13020,G__13021,G__13022));
})();
var handler_fn_13014 = event_fn_13013;
var logging_fn_13015 = ((function (event_fn_13013,handler_fn_13014){
return (function (){

return (handler_fn_13014.cljs$core$IFn$_invoke$arity$0 ? handler_fn_13014.cljs$core$IFn$_invoke$arity$0() : handler_fn_13014.call(null));
});})(event_fn_13013,handler_fn_13014))
;
var ns_obj_13018 = (function (){var target_obj_13023 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13024 = (target_obj_13023["chrome"]);
var next_obj_13025 = (next_obj_13024["runtime"]);
return next_obj_13025;
})();
var missing_api_13019 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onStartup",ns_obj_13018,"onStartup") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onStartup",ns_obj_13018,"onStartup"));
})();
if(missing_api_13019 === true){
return null;
} else {
var event_obj_13016 = (function (){var target_obj_13026 = ns_obj_13018;
var next_obj_13027 = (target_obj_13026["onStartup"]);
return next_obj_13027;
})();
var result_13017 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13016,logging_fn_13015,channel);
result_13017.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13017;
}
});

chromex.ext.runtime.on_startup_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_startup_STAR_.cljs$lang$applyTo = (function (seq13010){
var G__13011 = cljs.core.first(seq13010);
var seq13010__$1 = cljs.core.next(seq13010);
var G__13012 = cljs.core.first(seq13010__$1);
var seq13010__$2 = cljs.core.next(seq13010__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13011,G__13012,seq13010__$2);
});

chromex.ext.runtime.on_installed_STAR_ = (function chromex$ext$runtime$on_installed_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13051 = arguments.length;
var i__4731__auto___13052 = (0);
while(true){
if((i__4731__auto___13052 < len__4730__auto___13051)){
args__4736__auto__.push((arguments[i__4731__auto___13052]));

var G__13053 = (i__4731__auto___13052 + (1));
i__4731__auto___13052 = G__13053;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_installed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13034 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13043 = config__6203__auto__;
var G__13044 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_installed;
var G__13045 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13043,G__13044,G__13045) : handler__6205__auto__.call(null,G__13043,G__13044,G__13045));
})();
var handler_fn_13035 = ((function (event_fn_13034){
return (function (cb_details_13041){
return (event_fn_13034.cljs$core$IFn$_invoke$arity$1 ? event_fn_13034.cljs$core$IFn$_invoke$arity$1(cb_details_13041) : event_fn_13034.call(null,cb_details_13041));
});})(event_fn_13034))
;
var logging_fn_13036 = ((function (event_fn_13034,handler_fn_13035){
return (function (cb_param_details_13042){

return handler_fn_13035(cb_param_details_13042);
});})(event_fn_13034,handler_fn_13035))
;
var ns_obj_13039 = (function (){var target_obj_13046 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13047 = (target_obj_13046["chrome"]);
var next_obj_13048 = (next_obj_13047["runtime"]);
return next_obj_13048;
})();
var missing_api_13040 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onInstalled",ns_obj_13039,"onInstalled") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onInstalled",ns_obj_13039,"onInstalled"));
})();
if(missing_api_13040 === true){
return null;
} else {
var event_obj_13037 = (function (){var target_obj_13049 = ns_obj_13039;
var next_obj_13050 = (target_obj_13049["onInstalled"]);
return next_obj_13050;
})();
var result_13038 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13037,logging_fn_13036,channel);
result_13038.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13038;
}
});

chromex.ext.runtime.on_installed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_installed_STAR_.cljs$lang$applyTo = (function (seq13031){
var G__13032 = cljs.core.first(seq13031);
var seq13031__$1 = cljs.core.next(seq13031);
var G__13033 = cljs.core.first(seq13031__$1);
var seq13031__$2 = cljs.core.next(seq13031__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13032,G__13033,seq13031__$2);
});

chromex.ext.runtime.on_suspend_STAR_ = (function chromex$ext$runtime$on_suspend_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13072 = arguments.length;
var i__4731__auto___13073 = (0);
while(true){
if((i__4731__auto___13073 < len__4730__auto___13072)){
args__4736__auto__.push((arguments[i__4731__auto___13073]));

var G__13074 = (i__4731__auto___13073 + (1));
i__4731__auto___13073 = G__13074;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_suspend_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13057 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13064 = config__6203__auto__;
var G__13065 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend;
var G__13066 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13064,G__13065,G__13066) : handler__6205__auto__.call(null,G__13064,G__13065,G__13066));
})();
var handler_fn_13058 = event_fn_13057;
var logging_fn_13059 = ((function (event_fn_13057,handler_fn_13058){
return (function (){

return (handler_fn_13058.cljs$core$IFn$_invoke$arity$0 ? handler_fn_13058.cljs$core$IFn$_invoke$arity$0() : handler_fn_13058.call(null));
});})(event_fn_13057,handler_fn_13058))
;
var ns_obj_13062 = (function (){var target_obj_13067 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13068 = (target_obj_13067["chrome"]);
var next_obj_13069 = (next_obj_13068["runtime"]);
return next_obj_13069;
})();
var missing_api_13063 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspend",ns_obj_13062,"onSuspend") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onSuspend",ns_obj_13062,"onSuspend"));
})();
if(missing_api_13063 === true){
return null;
} else {
var event_obj_13060 = (function (){var target_obj_13070 = ns_obj_13062;
var next_obj_13071 = (target_obj_13070["onSuspend"]);
return next_obj_13071;
})();
var result_13061 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13060,logging_fn_13059,channel);
result_13061.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13061;
}
});

chromex.ext.runtime.on_suspend_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_suspend_STAR_.cljs$lang$applyTo = (function (seq13054){
var G__13055 = cljs.core.first(seq13054);
var seq13054__$1 = cljs.core.next(seq13054);
var G__13056 = cljs.core.first(seq13054__$1);
var seq13054__$2 = cljs.core.next(seq13054__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13055,G__13056,seq13054__$2);
});

chromex.ext.runtime.on_suspend_canceled_STAR_ = (function chromex$ext$runtime$on_suspend_canceled_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13093 = arguments.length;
var i__4731__auto___13094 = (0);
while(true){
if((i__4731__auto___13094 < len__4730__auto___13093)){
args__4736__auto__.push((arguments[i__4731__auto___13094]));

var G__13095 = (i__4731__auto___13094 + (1));
i__4731__auto___13094 = G__13095;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13078 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13085 = config__6203__auto__;
var G__13086 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_suspend_DASH_canceled;
var G__13087 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13085,G__13086,G__13087) : handler__6205__auto__.call(null,G__13085,G__13086,G__13087));
})();
var handler_fn_13079 = event_fn_13078;
var logging_fn_13080 = ((function (event_fn_13078,handler_fn_13079){
return (function (){

return (handler_fn_13079.cljs$core$IFn$_invoke$arity$0 ? handler_fn_13079.cljs$core$IFn$_invoke$arity$0() : handler_fn_13079.call(null));
});})(event_fn_13078,handler_fn_13079))
;
var ns_obj_13083 = (function (){var target_obj_13088 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13089 = (target_obj_13088["chrome"]);
var next_obj_13090 = (next_obj_13089["runtime"]);
return next_obj_13090;
})();
var missing_api_13084 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onSuspendCanceled",ns_obj_13083,"onSuspendCanceled") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onSuspendCanceled",ns_obj_13083,"onSuspendCanceled"));
})();
if(missing_api_13084 === true){
return null;
} else {
var event_obj_13081 = (function (){var target_obj_13091 = ns_obj_13083;
var next_obj_13092 = (target_obj_13091["onSuspendCanceled"]);
return next_obj_13092;
})();
var result_13082 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13081,logging_fn_13080,channel);
result_13082.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13082;
}
});

chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_suspend_canceled_STAR_.cljs$lang$applyTo = (function (seq13075){
var G__13076 = cljs.core.first(seq13075);
var seq13075__$1 = cljs.core.next(seq13075);
var G__13077 = cljs.core.first(seq13075__$1);
var seq13075__$2 = cljs.core.next(seq13075__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13076,G__13077,seq13075__$2);
});

chromex.ext.runtime.on_update_available_STAR_ = (function chromex$ext$runtime$on_update_available_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13116 = arguments.length;
var i__4731__auto___13117 = (0);
while(true){
if((i__4731__auto___13117 < len__4730__auto___13116)){
args__4736__auto__.push((arguments[i__4731__auto___13117]));

var G__13118 = (i__4731__auto___13117 + (1));
i__4731__auto___13117 = G__13118;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13099 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13108 = config__6203__auto__;
var G__13109 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_update_DASH_available;
var G__13110 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13108,G__13109,G__13110) : handler__6205__auto__.call(null,G__13108,G__13109,G__13110));
})();
var handler_fn_13100 = ((function (event_fn_13099){
return (function (cb_details_13106){
return (event_fn_13099.cljs$core$IFn$_invoke$arity$1 ? event_fn_13099.cljs$core$IFn$_invoke$arity$1(cb_details_13106) : event_fn_13099.call(null,cb_details_13106));
});})(event_fn_13099))
;
var logging_fn_13101 = ((function (event_fn_13099,handler_fn_13100){
return (function (cb_param_details_13107){

return handler_fn_13100(cb_param_details_13107);
});})(event_fn_13099,handler_fn_13100))
;
var ns_obj_13104 = (function (){var target_obj_13111 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13112 = (target_obj_13111["chrome"]);
var next_obj_13113 = (next_obj_13112["runtime"]);
return next_obj_13113;
})();
var missing_api_13105 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onUpdateAvailable",ns_obj_13104,"onUpdateAvailable") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onUpdateAvailable",ns_obj_13104,"onUpdateAvailable"));
})();
if(missing_api_13105 === true){
return null;
} else {
var event_obj_13102 = (function (){var target_obj_13114 = ns_obj_13104;
var next_obj_13115 = (target_obj_13114["onUpdateAvailable"]);
return next_obj_13115;
})();
var result_13103 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13102,logging_fn_13101,channel);
result_13103.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13103;
}
});

chromex.ext.runtime.on_update_available_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_update_available_STAR_.cljs$lang$applyTo = (function (seq13096){
var G__13097 = cljs.core.first(seq13096);
var seq13096__$1 = cljs.core.next(seq13096);
var G__13098 = cljs.core.first(seq13096__$1);
var seq13096__$2 = cljs.core.next(seq13096__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13097,G__13098,seq13096__$2);
});

chromex.ext.runtime.on_browser_update_available_STAR_ = (function chromex$ext$runtime$on_browser_update_available_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13137 = arguments.length;
var i__4731__auto___13138 = (0);
while(true){
if((i__4731__auto___13138 < len__4730__auto___13137)){
args__4736__auto__.push((arguments[i__4731__auto___13138]));

var G__13139 = (i__4731__auto___13138 + (1));
i__4731__auto___13138 = G__13139;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13122 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13129 = config__6203__auto__;
var G__13130 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_browser_DASH_update_DASH_available;
var G__13131 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13129,G__13130,G__13131) : handler__6205__auto__.call(null,G__13129,G__13130,G__13131));
})();
var handler_fn_13123 = event_fn_13122;
var logging_fn_13124 = ((function (event_fn_13122,handler_fn_13123){
return (function (){

return (handler_fn_13123.cljs$core$IFn$_invoke$arity$0 ? handler_fn_13123.cljs$core$IFn$_invoke$arity$0() : handler_fn_13123.call(null));
});})(event_fn_13122,handler_fn_13123))
;
var ns_obj_13127 = (function (){var target_obj_13132 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13133 = (target_obj_13132["chrome"]);
var next_obj_13134 = (next_obj_13133["runtime"]);
return next_obj_13134;
})();
var missing_api_13128 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onBrowserUpdateAvailable",ns_obj_13127,"onBrowserUpdateAvailable") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onBrowserUpdateAvailable",ns_obj_13127,"onBrowserUpdateAvailable"));
})();
if(missing_api_13128 === true){
return null;
} else {
var event_obj_13125 = (function (){var target_obj_13135 = ns_obj_13127;
var next_obj_13136 = (target_obj_13135["onBrowserUpdateAvailable"]);
return next_obj_13136;
})();
var result_13126 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13125,logging_fn_13124,channel);
result_13126.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13126;
}
});

chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_browser_update_available_STAR_.cljs$lang$applyTo = (function (seq13119){
var G__13120 = cljs.core.first(seq13119);
var seq13119__$1 = cljs.core.next(seq13119);
var G__13121 = cljs.core.first(seq13119__$1);
var seq13119__$2 = cljs.core.next(seq13119__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13120,G__13121,seq13119__$2);
});

chromex.ext.runtime.on_connect_STAR_ = (function chromex$ext$runtime$on_connect_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13161 = arguments.length;
var i__4731__auto___13162 = (0);
while(true){
if((i__4731__auto___13162 < len__4730__auto___13161)){
args__4736__auto__.push((arguments[i__4731__auto___13162]));

var G__13163 = (i__4731__auto___13162 + (1));
i__4731__auto___13162 = G__13163;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_connect_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13143 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13152 = config__6203__auto__;
var G__13153 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect;
var G__13154 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13152,G__13153,G__13154) : handler__6205__auto__.call(null,G__13152,G__13153,G__13154));
})();
var handler_fn_13144 = ((function (event_fn_13143){
return (function (cb_port_13150){
var G__13155 = chromex.marshalling.from_native_chrome_port(config,cb_port_13150);
return (event_fn_13143.cljs$core$IFn$_invoke$arity$1 ? event_fn_13143.cljs$core$IFn$_invoke$arity$1(G__13155) : event_fn_13143.call(null,G__13155));
});})(event_fn_13143))
;
var logging_fn_13145 = ((function (event_fn_13143,handler_fn_13144){
return (function (cb_param_port_13151){

return handler_fn_13144(cb_param_port_13151);
});})(event_fn_13143,handler_fn_13144))
;
var ns_obj_13148 = (function (){var target_obj_13156 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13157 = (target_obj_13156["chrome"]);
var next_obj_13158 = (next_obj_13157["runtime"]);
return next_obj_13158;
})();
var missing_api_13149 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnect",ns_obj_13148,"onConnect") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onConnect",ns_obj_13148,"onConnect"));
})();
if(missing_api_13149 === true){
return null;
} else {
var event_obj_13146 = (function (){var target_obj_13159 = ns_obj_13148;
var next_obj_13160 = (target_obj_13159["onConnect"]);
return next_obj_13160;
})();
var result_13147 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13146,logging_fn_13145,channel);
result_13147.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13147;
}
});

chromex.ext.runtime.on_connect_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_connect_STAR_.cljs$lang$applyTo = (function (seq13140){
var G__13141 = cljs.core.first(seq13140);
var seq13140__$1 = cljs.core.next(seq13140);
var G__13142 = cljs.core.first(seq13140__$1);
var seq13140__$2 = cljs.core.next(seq13140__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13141,G__13142,seq13140__$2);
});

chromex.ext.runtime.on_connect_external_STAR_ = (function chromex$ext$runtime$on_connect_external_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13185 = arguments.length;
var i__4731__auto___13186 = (0);
while(true){
if((i__4731__auto___13186 < len__4730__auto___13185)){
args__4736__auto__.push((arguments[i__4731__auto___13186]));

var G__13187 = (i__4731__auto___13186 + (1));
i__4731__auto___13186 = G__13187;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13167 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13176 = config__6203__auto__;
var G__13177 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect_DASH_external;
var G__13178 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13176,G__13177,G__13178) : handler__6205__auto__.call(null,G__13176,G__13177,G__13178));
})();
var handler_fn_13168 = ((function (event_fn_13167){
return (function (cb_port_13174){
var G__13179 = chromex.marshalling.from_native_chrome_port(config,cb_port_13174);
return (event_fn_13167.cljs$core$IFn$_invoke$arity$1 ? event_fn_13167.cljs$core$IFn$_invoke$arity$1(G__13179) : event_fn_13167.call(null,G__13179));
});})(event_fn_13167))
;
var logging_fn_13169 = ((function (event_fn_13167,handler_fn_13168){
return (function (cb_param_port_13175){

return handler_fn_13168(cb_param_port_13175);
});})(event_fn_13167,handler_fn_13168))
;
var ns_obj_13172 = (function (){var target_obj_13180 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13181 = (target_obj_13180["chrome"]);
var next_obj_13182 = (next_obj_13181["runtime"]);
return next_obj_13182;
})();
var missing_api_13173 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnectExternal",ns_obj_13172,"onConnectExternal") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onConnectExternal",ns_obj_13172,"onConnectExternal"));
})();
if(missing_api_13173 === true){
return null;
} else {
var event_obj_13170 = (function (){var target_obj_13183 = ns_obj_13172;
var next_obj_13184 = (target_obj_13183["onConnectExternal"]);
return next_obj_13184;
})();
var result_13171 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13170,logging_fn_13169,channel);
result_13171.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13171;
}
});

chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_connect_external_STAR_.cljs$lang$applyTo = (function (seq13164){
var G__13165 = cljs.core.first(seq13164);
var seq13164__$1 = cljs.core.next(seq13164);
var G__13166 = cljs.core.first(seq13164__$1);
var seq13164__$2 = cljs.core.next(seq13164__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13165,G__13166,seq13164__$2);
});

chromex.ext.runtime.on_connect_native_STAR_ = (function chromex$ext$runtime$on_connect_native_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13209 = arguments.length;
var i__4731__auto___13210 = (0);
while(true){
if((i__4731__auto___13210 < len__4730__auto___13209)){
args__4736__auto__.push((arguments[i__4731__auto___13210]));

var G__13211 = (i__4731__auto___13210 + (1));
i__4731__auto___13210 = G__13211;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_connect_native_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_connect_native_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13191 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13200 = config__6203__auto__;
var G__13201 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_connect_DASH_native;
var G__13202 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13200,G__13201,G__13202) : handler__6205__auto__.call(null,G__13200,G__13201,G__13202));
})();
var handler_fn_13192 = ((function (event_fn_13191){
return (function (cb_port_13198){
var G__13203 = chromex.marshalling.from_native_chrome_port(config,cb_port_13198);
return (event_fn_13191.cljs$core$IFn$_invoke$arity$1 ? event_fn_13191.cljs$core$IFn$_invoke$arity$1(G__13203) : event_fn_13191.call(null,G__13203));
});})(event_fn_13191))
;
var logging_fn_13193 = ((function (event_fn_13191,handler_fn_13192){
return (function (cb_param_port_13199){

return handler_fn_13192(cb_param_port_13199);
});})(event_fn_13191,handler_fn_13192))
;
var ns_obj_13196 = (function (){var target_obj_13204 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13205 = (target_obj_13204["chrome"]);
var next_obj_13206 = (next_obj_13205["runtime"]);
return next_obj_13206;
})();
var missing_api_13197 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onConnectNative",ns_obj_13196,"onConnectNative") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onConnectNative",ns_obj_13196,"onConnectNative"));
})();
if(missing_api_13197 === true){
return null;
} else {
var event_obj_13194 = (function (){var target_obj_13207 = ns_obj_13196;
var next_obj_13208 = (target_obj_13207["onConnectNative"]);
return next_obj_13208;
})();
var result_13195 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13194,logging_fn_13193,channel);
result_13195.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13195;
}
});

chromex.ext.runtime.on_connect_native_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_connect_native_STAR_.cljs$lang$applyTo = (function (seq13188){
var G__13189 = cljs.core.first(seq13188);
var seq13188__$1 = cljs.core.next(seq13188);
var G__13190 = cljs.core.first(seq13188__$1);
var seq13188__$2 = cljs.core.next(seq13188__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13189,G__13190,seq13188__$2);
});

chromex.ext.runtime.on_message_STAR_ = (function chromex$ext$runtime$on_message_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13236 = arguments.length;
var i__4731__auto___13237 = (0);
while(true){
if((i__4731__auto___13237 < len__4730__auto___13236)){
args__4736__auto__.push((arguments[i__4731__auto___13237]));

var G__13238 = (i__4731__auto___13237 + (1));
i__4731__auto___13237 = G__13238;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_message_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13215 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13228 = config__6203__auto__;
var G__13229 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message;
var G__13230 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13228,G__13229,G__13230) : handler__6205__auto__.call(null,G__13228,G__13229,G__13230));
})();
var handler_fn_13216 = ((function (event_fn_13215){
return (function (cb_message_13222,cb_sender_13223,cb_send_response_13224){
return (event_fn_13215.cljs$core$IFn$_invoke$arity$3 ? event_fn_13215.cljs$core$IFn$_invoke$arity$3(cb_message_13222,cb_sender_13223,cb_send_response_13224) : event_fn_13215.call(null,cb_message_13222,cb_sender_13223,cb_send_response_13224));
});})(event_fn_13215))
;
var logging_fn_13217 = ((function (event_fn_13215,handler_fn_13216){
return (function (cb_param_message_13225,cb_param_sender_13226,cb_param_send_response_13227){

return handler_fn_13216(cb_param_message_13225,cb_param_sender_13226,cb_param_send_response_13227);
});})(event_fn_13215,handler_fn_13216))
;
var ns_obj_13220 = (function (){var target_obj_13231 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13232 = (target_obj_13231["chrome"]);
var next_obj_13233 = (next_obj_13232["runtime"]);
return next_obj_13233;
})();
var missing_api_13221 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessage",ns_obj_13220,"onMessage") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onMessage",ns_obj_13220,"onMessage"));
})();
if(missing_api_13221 === true){
return null;
} else {
var event_obj_13218 = (function (){var target_obj_13234 = ns_obj_13220;
var next_obj_13235 = (target_obj_13234["onMessage"]);
return next_obj_13235;
})();
var result_13219 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13218,logging_fn_13217,channel);
result_13219.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13219;
}
});

chromex.ext.runtime.on_message_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_message_STAR_.cljs$lang$applyTo = (function (seq13212){
var G__13213 = cljs.core.first(seq13212);
var seq13212__$1 = cljs.core.next(seq13212);
var G__13214 = cljs.core.first(seq13212__$1);
var seq13212__$2 = cljs.core.next(seq13212__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13213,G__13214,seq13212__$2);
});

chromex.ext.runtime.on_message_external_STAR_ = (function chromex$ext$runtime$on_message_external_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13263 = arguments.length;
var i__4731__auto___13264 = (0);
while(true){
if((i__4731__auto___13264 < len__4730__auto___13263)){
args__4736__auto__.push((arguments[i__4731__auto___13264]));

var G__13265 = (i__4731__auto___13264 + (1));
i__4731__auto___13264 = G__13265;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_message_external_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13242 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13255 = config__6203__auto__;
var G__13256 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_message_DASH_external;
var G__13257 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13255,G__13256,G__13257) : handler__6205__auto__.call(null,G__13255,G__13256,G__13257));
})();
var handler_fn_13243 = ((function (event_fn_13242){
return (function (cb_message_13249,cb_sender_13250,cb_send_response_13251){
return (event_fn_13242.cljs$core$IFn$_invoke$arity$3 ? event_fn_13242.cljs$core$IFn$_invoke$arity$3(cb_message_13249,cb_sender_13250,cb_send_response_13251) : event_fn_13242.call(null,cb_message_13249,cb_sender_13250,cb_send_response_13251));
});})(event_fn_13242))
;
var logging_fn_13244 = ((function (event_fn_13242,handler_fn_13243){
return (function (cb_param_message_13252,cb_param_sender_13253,cb_param_send_response_13254){

return handler_fn_13243(cb_param_message_13252,cb_param_sender_13253,cb_param_send_response_13254);
});})(event_fn_13242,handler_fn_13243))
;
var ns_obj_13247 = (function (){var target_obj_13258 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13259 = (target_obj_13258["chrome"]);
var next_obj_13260 = (next_obj_13259["runtime"]);
return next_obj_13260;
})();
var missing_api_13248 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onMessageExternal",ns_obj_13247,"onMessageExternal") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onMessageExternal",ns_obj_13247,"onMessageExternal"));
})();
if(missing_api_13248 === true){
return null;
} else {
var event_obj_13245 = (function (){var target_obj_13261 = ns_obj_13247;
var next_obj_13262 = (target_obj_13261["onMessageExternal"]);
return next_obj_13262;
})();
var result_13246 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13245,logging_fn_13244,channel);
result_13246.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13246;
}
});

chromex.ext.runtime.on_message_external_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_message_external_STAR_.cljs$lang$applyTo = (function (seq13239){
var G__13240 = cljs.core.first(seq13239);
var seq13239__$1 = cljs.core.next(seq13239);
var G__13241 = cljs.core.first(seq13239__$1);
var seq13239__$2 = cljs.core.next(seq13239__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13240,G__13241,seq13239__$2);
});

chromex.ext.runtime.on_restart_required_STAR_ = (function chromex$ext$runtime$on_restart_required_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13286 = arguments.length;
var i__4731__auto___13287 = (0);
while(true){
if((i__4731__auto___13287 < len__4730__auto___13286)){
args__4736__auto__.push((arguments[i__4731__auto___13287]));

var G__13288 = (i__4731__auto___13287 + (1));
i__4731__auto___13287 = G__13288;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13269 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13278 = config__6203__auto__;
var G__13279 = cljs.core.cst$kw$chromex$ext$runtime_SLASH_on_DASH_restart_DASH_required;
var G__13280 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13278,G__13279,G__13280) : handler__6205__auto__.call(null,G__13278,G__13279,G__13280));
})();
var handler_fn_13270 = ((function (event_fn_13269){
return (function (cb_reason_13276){
return (event_fn_13269.cljs$core$IFn$_invoke$arity$1 ? event_fn_13269.cljs$core$IFn$_invoke$arity$1(cb_reason_13276) : event_fn_13269.call(null,cb_reason_13276));
});})(event_fn_13269))
;
var logging_fn_13271 = ((function (event_fn_13269,handler_fn_13270){
return (function (cb_param_reason_13277){

return handler_fn_13270(cb_param_reason_13277);
});})(event_fn_13269,handler_fn_13270))
;
var ns_obj_13274 = (function (){var target_obj_13281 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13282 = (target_obj_13281["chrome"]);
var next_obj_13283 = (next_obj_13282["runtime"]);
return next_obj_13283;
})();
var missing_api_13275 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.runtime.onRestartRequired",ns_obj_13274,"onRestartRequired") : api_check_fn__6242__auto__.call(null,"chrome.runtime.onRestartRequired",ns_obj_13274,"onRestartRequired"));
})();
if(missing_api_13275 === true){
return null;
} else {
var event_obj_13272 = (function (){var target_obj_13284 = ns_obj_13274;
var next_obj_13285 = (target_obj_13284["onRestartRequired"]);
return next_obj_13285;
})();
var result_13273 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13272,logging_fn_13271,channel);
result_13273.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13273;
}
});

chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.runtime.on_restart_required_STAR_.cljs$lang$applyTo = (function (seq13266){
var G__13267 = cljs.core.first(seq13266);
var seq13266__$1 = cljs.core.next(seq13266);
var G__13268 = cljs.core.first(seq13266__$1);
var seq13266__$2 = cljs.core.next(seq13266__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13267,G__13268,seq13266__$2);
});


// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.tabs');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.tabs.tab_id_none_STAR_ = (function chromex$ext$tabs$tab_id_none_STAR_(config){
var result_16060 = (function (){var final_args_array_16061 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.tabs.TAB_ID_NONE");
var ns_16062 = (function (){var target_obj_16065 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16066 = (target_obj_16065["chrome"]);
var next_obj_16067 = (next_obj_16066["tabs"]);
return next_obj_16067;
})();
var missing_api_16063 = null;
if(missing_api_16063 === true){
return null;
} else {

var target_16064 = (function (){var target_obj_16068 = ns_16062;
var next_obj_16069 = (target_obj_16068["TAB_ID_NONE"]);
if((!((next_obj_16069 == null)))){
return next_obj_16069;
} else {
return null;
}
})();
return target_16064;
}
})();
return result_16060;
});
chromex.ext.tabs.get_STAR_ = (function chromex$ext$tabs$get_STAR_(config,tab_id){
var callback_chan_16070 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16072_16092 = (function (){var omit_test_16078 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16078,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16078;
}
})();
var marshalled_callback_16073_16093 = ((function (marshalled_tab_id_16072_16092,callback_chan_16070){
return (function (cb_tab_16079){
var fexpr__16083 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16084 = config__6203__auto__;
var G__16085 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get,cljs.core.cst$kw$name,"get",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16086 = callback_chan_16070;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16084,G__16085,G__16086) : handler__6205__auto__.call(null,G__16084,G__16085,G__16086));
})();
return (fexpr__16083.cljs$core$IFn$_invoke$arity$1 ? fexpr__16083.cljs$core$IFn$_invoke$arity$1(cb_tab_16079) : fexpr__16083.call(null,cb_tab_16079));
});})(marshalled_tab_id_16072_16092,callback_chan_16070))
;
var result_16071_16094 = (function (){var final_args_array_16074 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16072_16092,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16073_16093,"callback",null], null)], null),"chrome.tabs.get");
var ns_16075 = (function (){var target_obj_16087 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16088 = (target_obj_16087["chrome"]);
var next_obj_16089 = (next_obj_16088["tabs"]);
return next_obj_16089;
})();
var missing_api_16076 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.get",ns_16075,"get") : api_check_fn__6242__auto__.call(null,"chrome.tabs.get",ns_16075,"get"));
})();
if(missing_api_16076 === true){
return null;
} else {

var target_16077 = (function (){var target_obj_16090 = ns_16075;
var next_obj_16091 = (target_obj_16090["get"]);
if((!((next_obj_16091 == null)))){
return next_obj_16091;
} else {
return null;
}
})();
return target_16077.apply(ns_16075,final_args_array_16074);
}
})();

return callback_chan_16070;
});
chromex.ext.tabs.get_current_STAR_ = (function chromex$ext$tabs$get_current_STAR_(config){
var callback_chan_16095 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_callback_16097_16115 = ((function (callback_chan_16095){
return (function (cb_tab_16102){
var fexpr__16106 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16107 = config__6203__auto__;
var G__16108 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_current,cljs.core.cst$kw$name,"getCurrent",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16109 = callback_chan_16095;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16107,G__16108,G__16109) : handler__6205__auto__.call(null,G__16107,G__16108,G__16109));
})();
return (fexpr__16106.cljs$core$IFn$_invoke$arity$1 ? fexpr__16106.cljs$core$IFn$_invoke$arity$1(cb_tab_16102) : fexpr__16106.call(null,cb_tab_16102));
});})(callback_chan_16095))
;
var result_16096_16116 = (function (){var final_args_array_16098 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16097_16115,"callback",null], null)], null),"chrome.tabs.getCurrent");
var ns_16099 = (function (){var target_obj_16110 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16111 = (target_obj_16110["chrome"]);
var next_obj_16112 = (next_obj_16111["tabs"]);
return next_obj_16112;
})();
var missing_api_16100 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getCurrent",ns_16099,"getCurrent") : api_check_fn__6242__auto__.call(null,"chrome.tabs.getCurrent",ns_16099,"getCurrent"));
})();
if(missing_api_16100 === true){
return null;
} else {

var target_16101 = (function (){var target_obj_16113 = ns_16099;
var next_obj_16114 = (target_obj_16113["getCurrent"]);
if((!((next_obj_16114 == null)))){
return next_obj_16114;
} else {
return null;
}
})();
return target_16101.apply(ns_16099,final_args_array_16098);
}
})();

return callback_chan_16095;
});
chromex.ext.tabs.connect_STAR_ = (function chromex$ext$tabs$connect_STAR_(config,tab_id,connect_info){
var marshalled_tab_id_16118 = (function (){var omit_test_16124 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16124,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16124;
}
})();
var marshalled_connect_info_16119 = (function (){var omit_test_16125 = connect_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_16125,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16125;
}
})();
var result_16117 = (function (){var final_args_array_16120 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16118,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_connect_info_16119,"connect-info",true], null)], null),"chrome.tabs.connect");
var ns_16121 = (function (){var target_obj_16126 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16127 = (target_obj_16126["chrome"]);
var next_obj_16128 = (next_obj_16127["tabs"]);
return next_obj_16128;
})();
var missing_api_16122 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.connect",ns_16121,"connect") : api_check_fn__6242__auto__.call(null,"chrome.tabs.connect",ns_16121,"connect"));
})();
if(missing_api_16122 === true){
return null;
} else {

var target_16123 = (function (){var target_obj_16129 = ns_16121;
var next_obj_16130 = (target_obj_16129["connect"]);
if((!((next_obj_16130 == null)))){
return next_obj_16130;
} else {
return null;
}
})();
return target_16123.apply(ns_16121,final_args_array_16120);
}
})();
return chromex.marshalling.from_native_chrome_port(config,result_16117);
});
chromex.ext.tabs.send_request_STAR_ = (function chromex$ext$tabs$send_request_STAR_(config,tab_id,request){
var callback_chan_16131 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16133_16155 = (function (){var omit_test_16140 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16140,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16140;
}
})();
var marshalled_request_16134_16156 = (function (){var omit_test_16141 = request;
if(cljs.core.keyword_identical_QMARK_(omit_test_16141,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16141;
}
})();
var marshalled_response_callback_16135_16157 = ((function (marshalled_tab_id_16133_16155,marshalled_request_16134_16156,callback_chan_16131){
return (function (cb_response_16142){
var fexpr__16146 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16147 = config__6203__auto__;
var G__16148 = new cljs.core.PersistentArrayMap(null, 7, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_send_DASH_request,cljs.core.cst$kw$name,"sendRequest",cljs.core.cst$kw$since,"33",cljs.core.cst$kw$deprecated,"Please use 'runtime.sendMessage'.",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"request",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16149 = callback_chan_16131;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16147,G__16148,G__16149) : handler__6205__auto__.call(null,G__16147,G__16148,G__16149));
})();
return (fexpr__16146.cljs$core$IFn$_invoke$arity$1 ? fexpr__16146.cljs$core$IFn$_invoke$arity$1(cb_response_16142) : fexpr__16146.call(null,cb_response_16142));
});})(marshalled_tab_id_16133_16155,marshalled_request_16134_16156,callback_chan_16131))
;
var result_16132_16158 = (function (){var final_args_array_16136 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16133_16155,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_request_16134_16156,"request",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_16135_16157,"response-callback",true], null)], null),"chrome.tabs.sendRequest");
var ns_16137 = (function (){var target_obj_16150 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16151 = (target_obj_16150["chrome"]);
var next_obj_16152 = (next_obj_16151["tabs"]);
return next_obj_16152;
})();
var missing_api_16138 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.sendRequest",ns_16137,"sendRequest") : api_check_fn__6242__auto__.call(null,"chrome.tabs.sendRequest",ns_16137,"sendRequest"));
})();
if(missing_api_16138 === true){
return null;
} else {

var target_16139 = (function (){var target_obj_16153 = ns_16137;
var next_obj_16154 = (target_obj_16153["sendRequest"]);
if((!((next_obj_16154 == null)))){
return next_obj_16154;
} else {
return null;
}
})();
return target_16139.apply(ns_16137,final_args_array_16136);
}
})();

return callback_chan_16131;
});
chromex.ext.tabs.send_message_STAR_ = (function chromex$ext$tabs$send_message_STAR_(config,tab_id,message,options){
var callback_chan_16159 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16161_16185 = (function (){var omit_test_16169 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16169,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16169;
}
})();
var marshalled_message_16162_16186 = (function (){var omit_test_16170 = message;
if(cljs.core.keyword_identical_QMARK_(omit_test_16170,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16170;
}
})();
var marshalled_options_16163_16187 = (function (){var omit_test_16171 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_16171,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16171;
}
})();
var marshalled_response_callback_16164_16188 = ((function (marshalled_tab_id_16161_16185,marshalled_message_16162_16186,marshalled_options_16163_16187,callback_chan_16159){
return (function (cb_response_16172){
var fexpr__16176 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16177 = config__6203__auto__;
var G__16178 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_send_DASH_message,cljs.core.cst$kw$name,"sendMessage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"message",cljs.core.cst$kw$type,"any"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$since,"41",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"response-callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"response",cljs.core.cst$kw$type,"any"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16179 = callback_chan_16159;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16177,G__16178,G__16179) : handler__6205__auto__.call(null,G__16177,G__16178,G__16179));
})();
return (fexpr__16176.cljs$core$IFn$_invoke$arity$1 ? fexpr__16176.cljs$core$IFn$_invoke$arity$1(cb_response_16172) : fexpr__16176.call(null,cb_response_16172));
});})(marshalled_tab_id_16161_16185,marshalled_message_16162_16186,marshalled_options_16163_16187,callback_chan_16159))
;
var result_16160_16189 = (function (){var final_args_array_16165 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16161_16185,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_message_16162_16186,"message",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_16163_16187,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_response_callback_16164_16188,"response-callback",true], null)], null),"chrome.tabs.sendMessage");
var ns_16166 = (function (){var target_obj_16180 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16181 = (target_obj_16180["chrome"]);
var next_obj_16182 = (next_obj_16181["tabs"]);
return next_obj_16182;
})();
var missing_api_16167 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.sendMessage",ns_16166,"sendMessage") : api_check_fn__6242__auto__.call(null,"chrome.tabs.sendMessage",ns_16166,"sendMessage"));
})();
if(missing_api_16167 === true){
return null;
} else {

var target_16168 = (function (){var target_obj_16183 = ns_16166;
var next_obj_16184 = (target_obj_16183["sendMessage"]);
if((!((next_obj_16184 == null)))){
return next_obj_16184;
} else {
return null;
}
})();
return target_16168.apply(ns_16166,final_args_array_16165);
}
})();

return callback_chan_16159;
});
chromex.ext.tabs.get_selected_STAR_ = (function chromex$ext$tabs$get_selected_STAR_(config,window_id){
var callback_chan_16190 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_window_id_16192_16212 = (function (){var omit_test_16198 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16198,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16198;
}
})();
var marshalled_callback_16193_16213 = ((function (marshalled_window_id_16192_16212,callback_chan_16190){
return (function (cb_tab_16199){
var fexpr__16203 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16204 = config__6203__auto__;
var G__16205 = new cljs.core.PersistentArrayMap(null, 7, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_selected,cljs.core.cst$kw$name,"getSelected",cljs.core.cst$kw$since,"33",cljs.core.cst$kw$deprecated,"Please use 'tabs.query' {active: true}.",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16206 = callback_chan_16190;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16204,G__16205,G__16206) : handler__6205__auto__.call(null,G__16204,G__16205,G__16206));
})();
return (fexpr__16203.cljs$core$IFn$_invoke$arity$1 ? fexpr__16203.cljs$core$IFn$_invoke$arity$1(cb_tab_16199) : fexpr__16203.call(null,cb_tab_16199));
});})(marshalled_window_id_16192_16212,callback_chan_16190))
;
var result_16191_16214 = (function (){var final_args_array_16194 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_16192_16212,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16193_16213,"callback",null], null)], null),"chrome.tabs.getSelected");
var ns_16195 = (function (){var target_obj_16207 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16208 = (target_obj_16207["chrome"]);
var next_obj_16209 = (next_obj_16208["tabs"]);
return next_obj_16209;
})();
var missing_api_16196 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getSelected",ns_16195,"getSelected") : api_check_fn__6242__auto__.call(null,"chrome.tabs.getSelected",ns_16195,"getSelected"));
})();
if(missing_api_16196 === true){
return null;
} else {

var target_16197 = (function (){var target_obj_16210 = ns_16195;
var next_obj_16211 = (target_obj_16210["getSelected"]);
if((!((next_obj_16211 == null)))){
return next_obj_16211;
} else {
return null;
}
})();
return target_16197.apply(ns_16195,final_args_array_16194);
}
})();

return callback_chan_16190;
});
chromex.ext.tabs.get_all_in_window_STAR_ = (function chromex$ext$tabs$get_all_in_window_STAR_(config,window_id){
var callback_chan_16215 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_window_id_16217_16237 = (function (){var omit_test_16223 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16223,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16223;
}
})();
var marshalled_callback_16218_16238 = ((function (marshalled_window_id_16217_16237,callback_chan_16215){
return (function (cb_tabs_16224){
var fexpr__16228 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16229 = config__6203__auto__;
var G__16230 = new cljs.core.PersistentArrayMap(null, 7, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_all_DASH_in_DASH_window,cljs.core.cst$kw$name,"getAllInWindow",cljs.core.cst$kw$since,"33",cljs.core.cst$kw$deprecated,"Please use 'tabs.query' {windowId: windowId}.",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tabs",cljs.core.cst$kw$type,"[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16231 = callback_chan_16215;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16229,G__16230,G__16231) : handler__6205__auto__.call(null,G__16229,G__16230,G__16231));
})();
return (fexpr__16228.cljs$core$IFn$_invoke$arity$1 ? fexpr__16228.cljs$core$IFn$_invoke$arity$1(cb_tabs_16224) : fexpr__16228.call(null,cb_tabs_16224));
});})(marshalled_window_id_16217_16237,callback_chan_16215))
;
var result_16216_16239 = (function (){var final_args_array_16219 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_16217_16237,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16218_16238,"callback",null], null)], null),"chrome.tabs.getAllInWindow");
var ns_16220 = (function (){var target_obj_16232 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16233 = (target_obj_16232["chrome"]);
var next_obj_16234 = (next_obj_16233["tabs"]);
return next_obj_16234;
})();
var missing_api_16221 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getAllInWindow",ns_16220,"getAllInWindow") : api_check_fn__6242__auto__.call(null,"chrome.tabs.getAllInWindow",ns_16220,"getAllInWindow"));
})();
if(missing_api_16221 === true){
return null;
} else {

var target_16222 = (function (){var target_obj_16235 = ns_16220;
var next_obj_16236 = (target_obj_16235["getAllInWindow"]);
if((!((next_obj_16236 == null)))){
return next_obj_16236;
} else {
return null;
}
})();
return target_16222.apply(ns_16220,final_args_array_16219);
}
})();

return callback_chan_16215;
});
chromex.ext.tabs.create_STAR_ = (function chromex$ext$tabs$create_STAR_(config,create_properties){
var callback_chan_16240 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_create_properties_16242_16262 = (function (){var omit_test_16248 = create_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_16248,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16248;
}
})();
var marshalled_callback_16243_16263 = ((function (marshalled_create_properties_16242_16262,callback_chan_16240){
return (function (cb_tab_16249){
var fexpr__16253 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16254 = config__6203__auto__;
var G__16255 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_create,cljs.core.cst$kw$name,"create",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"create-properties",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16256 = callback_chan_16240;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16254,G__16255,G__16256) : handler__6205__auto__.call(null,G__16254,G__16255,G__16256));
})();
return (fexpr__16253.cljs$core$IFn$_invoke$arity$1 ? fexpr__16253.cljs$core$IFn$_invoke$arity$1(cb_tab_16249) : fexpr__16253.call(null,cb_tab_16249));
});})(marshalled_create_properties_16242_16262,callback_chan_16240))
;
var result_16241_16264 = (function (){var final_args_array_16244 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_create_properties_16242_16262,"create-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16243_16263,"callback",true], null)], null),"chrome.tabs.create");
var ns_16245 = (function (){var target_obj_16257 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16258 = (target_obj_16257["chrome"]);
var next_obj_16259 = (next_obj_16258["tabs"]);
return next_obj_16259;
})();
var missing_api_16246 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.create",ns_16245,"create") : api_check_fn__6242__auto__.call(null,"chrome.tabs.create",ns_16245,"create"));
})();
if(missing_api_16246 === true){
return null;
} else {

var target_16247 = (function (){var target_obj_16260 = ns_16245;
var next_obj_16261 = (target_obj_16260["create"]);
if((!((next_obj_16261 == null)))){
return next_obj_16261;
} else {
return null;
}
})();
return target_16247.apply(ns_16245,final_args_array_16244);
}
})();

return callback_chan_16240;
});
chromex.ext.tabs.duplicate_STAR_ = (function chromex$ext$tabs$duplicate_STAR_(config,tab_id){
var callback_chan_16265 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16267_16287 = (function (){var omit_test_16273 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16273,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16273;
}
})();
var marshalled_callback_16268_16288 = ((function (marshalled_tab_id_16267_16287,callback_chan_16265){
return (function (cb_tab_16274){
var fexpr__16278 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16279 = config__6203__auto__;
var G__16280 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_duplicate,cljs.core.cst$kw$name,"duplicate",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16281 = callback_chan_16265;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16279,G__16280,G__16281) : handler__6205__auto__.call(null,G__16279,G__16280,G__16281));
})();
return (fexpr__16278.cljs$core$IFn$_invoke$arity$1 ? fexpr__16278.cljs$core$IFn$_invoke$arity$1(cb_tab_16274) : fexpr__16278.call(null,cb_tab_16274));
});})(marshalled_tab_id_16267_16287,callback_chan_16265))
;
var result_16266_16289 = (function (){var final_args_array_16269 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16267_16287,"tab-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16268_16288,"callback",true], null)], null),"chrome.tabs.duplicate");
var ns_16270 = (function (){var target_obj_16282 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16283 = (target_obj_16282["chrome"]);
var next_obj_16284 = (next_obj_16283["tabs"]);
return next_obj_16284;
})();
var missing_api_16271 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.duplicate",ns_16270,"duplicate") : api_check_fn__6242__auto__.call(null,"chrome.tabs.duplicate",ns_16270,"duplicate"));
})();
if(missing_api_16271 === true){
return null;
} else {

var target_16272 = (function (){var target_obj_16285 = ns_16270;
var next_obj_16286 = (target_obj_16285["duplicate"]);
if((!((next_obj_16286 == null)))){
return next_obj_16286;
} else {
return null;
}
})();
return target_16272.apply(ns_16270,final_args_array_16269);
}
})();

return callback_chan_16265;
});
chromex.ext.tabs.query_STAR_ = (function chromex$ext$tabs$query_STAR_(config,query_info){
var callback_chan_16290 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_query_info_16292_16312 = (function (){var omit_test_16298 = query_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_16298,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16298;
}
})();
var marshalled_callback_16293_16313 = ((function (marshalled_query_info_16292_16312,callback_chan_16290){
return (function (cb_result_16299){
var fexpr__16303 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16304 = config__6203__auto__;
var G__16305 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_query,cljs.core.cst$kw$name,"query",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"query-info",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$type,"[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16306 = callback_chan_16290;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16304,G__16305,G__16306) : handler__6205__auto__.call(null,G__16304,G__16305,G__16306));
})();
return (fexpr__16303.cljs$core$IFn$_invoke$arity$1 ? fexpr__16303.cljs$core$IFn$_invoke$arity$1(cb_result_16299) : fexpr__16303.call(null,cb_result_16299));
});})(marshalled_query_info_16292_16312,callback_chan_16290))
;
var result_16291_16314 = (function (){var final_args_array_16294 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_query_info_16292_16312,"query-info",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16293_16313,"callback",null], null)], null),"chrome.tabs.query");
var ns_16295 = (function (){var target_obj_16307 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16308 = (target_obj_16307["chrome"]);
var next_obj_16309 = (next_obj_16308["tabs"]);
return next_obj_16309;
})();
var missing_api_16296 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.query",ns_16295,"query") : api_check_fn__6242__auto__.call(null,"chrome.tabs.query",ns_16295,"query"));
})();
if(missing_api_16296 === true){
return null;
} else {

var target_16297 = (function (){var target_obj_16310 = ns_16295;
var next_obj_16311 = (target_obj_16310["query"]);
if((!((next_obj_16311 == null)))){
return next_obj_16311;
} else {
return null;
}
})();
return target_16297.apply(ns_16295,final_args_array_16294);
}
})();

return callback_chan_16290;
});
chromex.ext.tabs.highlight_STAR_ = (function chromex$ext$tabs$highlight_STAR_(config,highlight_info){
var callback_chan_16315 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_highlight_info_16317_16337 = (function (){var omit_test_16323 = highlight_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_16323,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16323;
}
})();
var marshalled_callback_16318_16338 = ((function (marshalled_highlight_info_16317_16337,callback_chan_16315){
return (function (cb_window_16324){
var fexpr__16328 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16329 = config__6203__auto__;
var G__16330 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_highlight,cljs.core.cst$kw$name,"highlight",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"highlight-info",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"window",cljs.core.cst$kw$type,"windows.Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16331 = callback_chan_16315;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16329,G__16330,G__16331) : handler__6205__auto__.call(null,G__16329,G__16330,G__16331));
})();
return (fexpr__16328.cljs$core$IFn$_invoke$arity$1 ? fexpr__16328.cljs$core$IFn$_invoke$arity$1(cb_window_16324) : fexpr__16328.call(null,cb_window_16324));
});})(marshalled_highlight_info_16317_16337,callback_chan_16315))
;
var result_16316_16339 = (function (){var final_args_array_16319 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_highlight_info_16317_16337,"highlight-info",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16318_16338,"callback",true], null)], null),"chrome.tabs.highlight");
var ns_16320 = (function (){var target_obj_16332 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16333 = (target_obj_16332["chrome"]);
var next_obj_16334 = (next_obj_16333["tabs"]);
return next_obj_16334;
})();
var missing_api_16321 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.highlight",ns_16320,"highlight") : api_check_fn__6242__auto__.call(null,"chrome.tabs.highlight",ns_16320,"highlight"));
})();
if(missing_api_16321 === true){
return null;
} else {

var target_16322 = (function (){var target_obj_16335 = ns_16320;
var next_obj_16336 = (target_obj_16335["highlight"]);
if((!((next_obj_16336 == null)))){
return next_obj_16336;
} else {
return null;
}
})();
return target_16322.apply(ns_16320,final_args_array_16319);
}
})();

return callback_chan_16315;
});
chromex.ext.tabs.update_STAR_ = (function chromex$ext$tabs$update_STAR_(config,tab_id,update_properties){
var callback_chan_16340 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16342_16364 = (function (){var omit_test_16349 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16349,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16349;
}
})();
var marshalled_update_properties_16343_16365 = (function (){var omit_test_16350 = update_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_16350,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16350;
}
})();
var marshalled_callback_16344_16366 = ((function (marshalled_tab_id_16342_16364,marshalled_update_properties_16343_16365,callback_chan_16340){
return (function (cb_tab_16351){
var fexpr__16355 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16356 = config__6203__auto__;
var G__16357 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_update,cljs.core.cst$kw$name,"update",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"update-properties",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16358 = callback_chan_16340;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16356,G__16357,G__16358) : handler__6205__auto__.call(null,G__16356,G__16357,G__16358));
})();
return (fexpr__16355.cljs$core$IFn$_invoke$arity$1 ? fexpr__16355.cljs$core$IFn$_invoke$arity$1(cb_tab_16351) : fexpr__16355.call(null,cb_tab_16351));
});})(marshalled_tab_id_16342_16364,marshalled_update_properties_16343_16365,callback_chan_16340))
;
var result_16341_16367 = (function (){var final_args_array_16345 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16342_16364,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_update_properties_16343_16365,"update-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16344_16366,"callback",true], null)], null),"chrome.tabs.update");
var ns_16346 = (function (){var target_obj_16359 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16360 = (target_obj_16359["chrome"]);
var next_obj_16361 = (next_obj_16360["tabs"]);
return next_obj_16361;
})();
var missing_api_16347 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.update",ns_16346,"update") : api_check_fn__6242__auto__.call(null,"chrome.tabs.update",ns_16346,"update"));
})();
if(missing_api_16347 === true){
return null;
} else {

var target_16348 = (function (){var target_obj_16362 = ns_16346;
var next_obj_16363 = (target_obj_16362["update"]);
if((!((next_obj_16363 == null)))){
return next_obj_16363;
} else {
return null;
}
})();
return target_16348.apply(ns_16346,final_args_array_16345);
}
})();

return callback_chan_16340;
});
chromex.ext.tabs.move_STAR_ = (function chromex$ext$tabs$move_STAR_(config,tab_ids,move_properties){
var callback_chan_16368 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_ids_16370_16392 = (function (){var omit_test_16377 = tab_ids;
if(cljs.core.keyword_identical_QMARK_(omit_test_16377,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16377;
}
})();
var marshalled_move_properties_16371_16393 = (function (){var omit_test_16378 = move_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_16378,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16378;
}
})();
var marshalled_callback_16372_16394 = ((function (marshalled_tab_ids_16370_16392,marshalled_move_properties_16371_16393,callback_chan_16368){
return (function (cb_tabs_16379){
var fexpr__16383 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16384 = config__6203__auto__;
var G__16385 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_move,cljs.core.cst$kw$name,"move",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-ids",cljs.core.cst$kw$type,"integer-or-[array-of-integers]"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"move-properties",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tabs",cljs.core.cst$kw$type,"tabs.Tab-or-[array-of-tabs.Tabs]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16386 = callback_chan_16368;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16384,G__16385,G__16386) : handler__6205__auto__.call(null,G__16384,G__16385,G__16386));
})();
return (fexpr__16383.cljs$core$IFn$_invoke$arity$1 ? fexpr__16383.cljs$core$IFn$_invoke$arity$1(cb_tabs_16379) : fexpr__16383.call(null,cb_tabs_16379));
});})(marshalled_tab_ids_16370_16392,marshalled_move_properties_16371_16393,callback_chan_16368))
;
var result_16369_16395 = (function (){var final_args_array_16373 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_ids_16370_16392,"tab-ids",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_move_properties_16371_16393,"move-properties",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16372_16394,"callback",true], null)], null),"chrome.tabs.move");
var ns_16374 = (function (){var target_obj_16387 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16388 = (target_obj_16387["chrome"]);
var next_obj_16389 = (next_obj_16388["tabs"]);
return next_obj_16389;
})();
var missing_api_16375 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.move",ns_16374,"move") : api_check_fn__6242__auto__.call(null,"chrome.tabs.move",ns_16374,"move"));
})();
if(missing_api_16375 === true){
return null;
} else {

var target_16376 = (function (){var target_obj_16390 = ns_16374;
var next_obj_16391 = (target_obj_16390["move"]);
if((!((next_obj_16391 == null)))){
return next_obj_16391;
} else {
return null;
}
})();
return target_16376.apply(ns_16374,final_args_array_16373);
}
})();

return callback_chan_16368;
});
chromex.ext.tabs.reload_STAR_ = (function chromex$ext$tabs$reload_STAR_(config,tab_id,reload_properties){
var callback_chan_16396 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16398_16415 = (function (){var omit_test_16405 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16405,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16405;
}
})();
var marshalled_reload_properties_16399_16416 = (function (){var omit_test_16406 = reload_properties;
if(cljs.core.keyword_identical_QMARK_(omit_test_16406,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16406;
}
})();
var marshalled_callback_16400_16417 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16407 = config__6203__auto__;
var G__16408 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_reload,cljs.core.cst$kw$name,"reload",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"reload-properties",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16409 = callback_chan_16396;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16407,G__16408,G__16409) : handler__6205__auto__.call(null,G__16407,G__16408,G__16409));
})();
var result_16397_16418 = (function (){var final_args_array_16401 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16398_16415,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_reload_properties_16399_16416,"reload-properties",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16400_16417,"callback",true], null)], null),"chrome.tabs.reload");
var ns_16402 = (function (){var target_obj_16410 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16411 = (target_obj_16410["chrome"]);
var next_obj_16412 = (next_obj_16411["tabs"]);
return next_obj_16412;
})();
var missing_api_16403 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.reload",ns_16402,"reload") : api_check_fn__6242__auto__.call(null,"chrome.tabs.reload",ns_16402,"reload"));
})();
if(missing_api_16403 === true){
return null;
} else {

var target_16404 = (function (){var target_obj_16413 = ns_16402;
var next_obj_16414 = (target_obj_16413["reload"]);
if((!((next_obj_16414 == null)))){
return next_obj_16414;
} else {
return null;
}
})();
return target_16404.apply(ns_16402,final_args_array_16401);
}
})();

return callback_chan_16396;
});
chromex.ext.tabs.remove_STAR_ = (function chromex$ext$tabs$remove_STAR_(config,tab_ids){
var callback_chan_16419 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_ids_16421_16436 = (function (){var omit_test_16427 = tab_ids;
if(cljs.core.keyword_identical_QMARK_(omit_test_16427,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16427;
}
})();
var marshalled_callback_16422_16437 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16428 = config__6203__auto__;
var G__16429 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_remove,cljs.core.cst$kw$name,"remove",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"tab-ids",cljs.core.cst$kw$type,"integer-or-[array-of-integers]"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16430 = callback_chan_16419;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16428,G__16429,G__16430) : handler__6205__auto__.call(null,G__16428,G__16429,G__16430));
})();
var result_16420_16438 = (function (){var final_args_array_16423 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_ids_16421_16436,"tab-ids",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16422_16437,"callback",true], null)], null),"chrome.tabs.remove");
var ns_16424 = (function (){var target_obj_16431 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16432 = (target_obj_16431["chrome"]);
var next_obj_16433 = (next_obj_16432["tabs"]);
return next_obj_16433;
})();
var missing_api_16425 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.remove",ns_16424,"remove") : api_check_fn__6242__auto__.call(null,"chrome.tabs.remove",ns_16424,"remove"));
})();
if(missing_api_16425 === true){
return null;
} else {

var target_16426 = (function (){var target_obj_16434 = ns_16424;
var next_obj_16435 = (target_obj_16434["remove"]);
if((!((next_obj_16435 == null)))){
return next_obj_16435;
} else {
return null;
}
})();
return target_16426.apply(ns_16424,final_args_array_16423);
}
})();

return callback_chan_16419;
});
chromex.ext.tabs.detect_language_STAR_ = (function chromex$ext$tabs$detect_language_STAR_(config,tab_id){
var callback_chan_16439 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16441_16461 = (function (){var omit_test_16447 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16447,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16447;
}
})();
var marshalled_callback_16442_16462 = ((function (marshalled_tab_id_16441_16461,callback_chan_16439){
return (function (cb_language_16448){
var fexpr__16452 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16453 = config__6203__auto__;
var G__16454 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_detect_DASH_language,cljs.core.cst$kw$name,"detectLanguage",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"language",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16455 = callback_chan_16439;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16453,G__16454,G__16455) : handler__6205__auto__.call(null,G__16453,G__16454,G__16455));
})();
return (fexpr__16452.cljs$core$IFn$_invoke$arity$1 ? fexpr__16452.cljs$core$IFn$_invoke$arity$1(cb_language_16448) : fexpr__16452.call(null,cb_language_16448));
});})(marshalled_tab_id_16441_16461,callback_chan_16439))
;
var result_16440_16463 = (function (){var final_args_array_16443 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16441_16461,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16442_16462,"callback",null], null)], null),"chrome.tabs.detectLanguage");
var ns_16444 = (function (){var target_obj_16456 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16457 = (target_obj_16456["chrome"]);
var next_obj_16458 = (next_obj_16457["tabs"]);
return next_obj_16458;
})();
var missing_api_16445 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.detectLanguage",ns_16444,"detectLanguage") : api_check_fn__6242__auto__.call(null,"chrome.tabs.detectLanguage",ns_16444,"detectLanguage"));
})();
if(missing_api_16445 === true){
return null;
} else {

var target_16446 = (function (){var target_obj_16459 = ns_16444;
var next_obj_16460 = (target_obj_16459["detectLanguage"]);
if((!((next_obj_16460 == null)))){
return next_obj_16460;
} else {
return null;
}
})();
return target_16446.apply(ns_16444,final_args_array_16443);
}
})();

return callback_chan_16439;
});
chromex.ext.tabs.capture_visible_tab_STAR_ = (function chromex$ext$tabs$capture_visible_tab_STAR_(config,window_id,options){
var callback_chan_16464 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_window_id_16466_16488 = (function (){var omit_test_16473 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16473,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16473;
}
})();
var marshalled_options_16467_16489 = (function (){var omit_test_16474 = options;
if(cljs.core.keyword_identical_QMARK_(omit_test_16474,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16474;
}
})();
var marshalled_callback_16468_16490 = ((function (marshalled_window_id_16466_16488,marshalled_options_16467_16489,callback_chan_16464){
return (function (cb_data_url_16475){
var fexpr__16479 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16480 = config__6203__auto__;
var G__16481 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_capture_DASH_visible_DASH_tab,cljs.core.cst$kw$name,"captureVisibleTab",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"options",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"data-url",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16482 = callback_chan_16464;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16480,G__16481,G__16482) : handler__6205__auto__.call(null,G__16480,G__16481,G__16482));
})();
return (fexpr__16479.cljs$core$IFn$_invoke$arity$1 ? fexpr__16479.cljs$core$IFn$_invoke$arity$1(cb_data_url_16475) : fexpr__16479.call(null,cb_data_url_16475));
});})(marshalled_window_id_16466_16488,marshalled_options_16467_16489,callback_chan_16464))
;
var result_16465_16491 = (function (){var final_args_array_16469 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_16466_16488,"window-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_options_16467_16489,"options",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16468_16490,"callback",null], null)], null),"chrome.tabs.captureVisibleTab");
var ns_16470 = (function (){var target_obj_16483 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16484 = (target_obj_16483["chrome"]);
var next_obj_16485 = (next_obj_16484["tabs"]);
return next_obj_16485;
})();
var missing_api_16471 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.captureVisibleTab",ns_16470,"captureVisibleTab") : api_check_fn__6242__auto__.call(null,"chrome.tabs.captureVisibleTab",ns_16470,"captureVisibleTab"));
})();
if(missing_api_16471 === true){
return null;
} else {

var target_16472 = (function (){var target_obj_16486 = ns_16470;
var next_obj_16487 = (target_obj_16486["captureVisibleTab"]);
if((!((next_obj_16487 == null)))){
return next_obj_16487;
} else {
return null;
}
})();
return target_16472.apply(ns_16470,final_args_array_16469);
}
})();

return callback_chan_16464;
});
chromex.ext.tabs.execute_script_STAR_ = (function chromex$ext$tabs$execute_script_STAR_(config,tab_id,details){
var callback_chan_16492 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16494_16516 = (function (){var omit_test_16501 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16501,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16501;
}
})();
var marshalled_details_16495_16517 = (function (){var omit_test_16502 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_16502,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16502;
}
})();
var marshalled_callback_16496_16518 = ((function (marshalled_tab_id_16494_16516,marshalled_details_16495_16517,callback_chan_16492){
return (function (cb_result_16503){
var fexpr__16507 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16508 = config__6203__auto__;
var G__16509 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_execute_DASH_script,cljs.core.cst$kw$name,"executeScript",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"[array-of-anys]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16510 = callback_chan_16492;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16508,G__16509,G__16510) : handler__6205__auto__.call(null,G__16508,G__16509,G__16510));
})();
return (fexpr__16507.cljs$core$IFn$_invoke$arity$1 ? fexpr__16507.cljs$core$IFn$_invoke$arity$1(cb_result_16503) : fexpr__16507.call(null,cb_result_16503));
});})(marshalled_tab_id_16494_16516,marshalled_details_16495_16517,callback_chan_16492))
;
var result_16493_16519 = (function (){var final_args_array_16497 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16494_16516,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_16495_16517,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16496_16518,"callback",true], null)], null),"chrome.tabs.executeScript");
var ns_16498 = (function (){var target_obj_16511 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16512 = (target_obj_16511["chrome"]);
var next_obj_16513 = (next_obj_16512["tabs"]);
return next_obj_16513;
})();
var missing_api_16499 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.executeScript",ns_16498,"executeScript") : api_check_fn__6242__auto__.call(null,"chrome.tabs.executeScript",ns_16498,"executeScript"));
})();
if(missing_api_16499 === true){
return null;
} else {

var target_16500 = (function (){var target_obj_16514 = ns_16498;
var next_obj_16515 = (target_obj_16514["executeScript"]);
if((!((next_obj_16515 == null)))){
return next_obj_16515;
} else {
return null;
}
})();
return target_16500.apply(ns_16498,final_args_array_16497);
}
})();

return callback_chan_16492;
});
chromex.ext.tabs.insert_css_STAR_ = (function chromex$ext$tabs$insert_css_STAR_(config,tab_id,details){
var callback_chan_16520 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16522_16539 = (function (){var omit_test_16529 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16529,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16529;
}
})();
var marshalled_details_16523_16540 = (function (){var omit_test_16530 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_16530,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16530;
}
})();
var marshalled_callback_16524_16541 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16531 = config__6203__auto__;
var G__16532 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_insert_DASH_css,cljs.core.cst$kw$name,"insertCSS",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16533 = callback_chan_16520;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16531,G__16532,G__16533) : handler__6205__auto__.call(null,G__16531,G__16532,G__16533));
})();
var result_16521_16542 = (function (){var final_args_array_16525 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16522_16539,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_16523_16540,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16524_16541,"callback",true], null)], null),"chrome.tabs.insertCSS");
var ns_16526 = (function (){var target_obj_16534 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16535 = (target_obj_16534["chrome"]);
var next_obj_16536 = (next_obj_16535["tabs"]);
return next_obj_16536;
})();
var missing_api_16527 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.insertCSS",ns_16526,"insertCSS") : api_check_fn__6242__auto__.call(null,"chrome.tabs.insertCSS",ns_16526,"insertCSS"));
})();
if(missing_api_16527 === true){
return null;
} else {

var target_16528 = (function (){var target_obj_16537 = ns_16526;
var next_obj_16538 = (target_obj_16537["insertCSS"]);
if((!((next_obj_16538 == null)))){
return next_obj_16538;
} else {
return null;
}
})();
return target_16528.apply(ns_16526,final_args_array_16525);
}
})();

return callback_chan_16520;
});
chromex.ext.tabs.set_zoom_STAR_ = (function chromex$ext$tabs$set_zoom_STAR_(config,tab_id,zoom_factor){
var callback_chan_16543 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16545_16562 = (function (){var omit_test_16552 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16552,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16552;
}
})();
var marshalled_zoom_factor_16546_16563 = (function (){var omit_test_16553 = zoom_factor;
if(cljs.core.keyword_identical_QMARK_(omit_test_16553,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16553;
}
})();
var marshalled_callback_16547_16564 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16554 = config__6203__auto__;
var G__16555 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_set_DASH_zoom,cljs.core.cst$kw$name,"setZoom",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$since,"38",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"zoom-factor",cljs.core.cst$kw$since,"38",cljs.core.cst$kw$type,"double"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16556 = callback_chan_16543;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16554,G__16555,G__16556) : handler__6205__auto__.call(null,G__16554,G__16555,G__16556));
})();
var result_16544_16565 = (function (){var final_args_array_16548 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16545_16562,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_zoom_factor_16546_16563,"zoom-factor",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16547_16564,"callback",true], null)], null),"chrome.tabs.setZoom");
var ns_16549 = (function (){var target_obj_16557 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16558 = (target_obj_16557["chrome"]);
var next_obj_16559 = (next_obj_16558["tabs"]);
return next_obj_16559;
})();
var missing_api_16550 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.setZoom",ns_16549,"setZoom") : api_check_fn__6242__auto__.call(null,"chrome.tabs.setZoom",ns_16549,"setZoom"));
})();
if(missing_api_16550 === true){
return null;
} else {

var target_16551 = (function (){var target_obj_16560 = ns_16549;
var next_obj_16561 = (target_obj_16560["setZoom"]);
if((!((next_obj_16561 == null)))){
return next_obj_16561;
} else {
return null;
}
})();
return target_16551.apply(ns_16549,final_args_array_16548);
}
})();

return callback_chan_16543;
});
chromex.ext.tabs.get_zoom_STAR_ = (function chromex$ext$tabs$get_zoom_STAR_(config,tab_id){
var callback_chan_16566 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16568_16588 = (function (){var omit_test_16574 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16574,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16574;
}
})();
var marshalled_callback_16569_16589 = ((function (marshalled_tab_id_16568_16588,callback_chan_16566){
return (function (cb_zoom_factor_16575){
var fexpr__16579 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16580 = config__6203__auto__;
var G__16581 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_zoom,cljs.core.cst$kw$name,"getZoom",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$since,"38",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-factor",cljs.core.cst$kw$type,"double"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16582 = callback_chan_16566;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16580,G__16581,G__16582) : handler__6205__auto__.call(null,G__16580,G__16581,G__16582));
})();
return (fexpr__16579.cljs$core$IFn$_invoke$arity$1 ? fexpr__16579.cljs$core$IFn$_invoke$arity$1(cb_zoom_factor_16575) : fexpr__16579.call(null,cb_zoom_factor_16575));
});})(marshalled_tab_id_16568_16588,callback_chan_16566))
;
var result_16567_16590 = (function (){var final_args_array_16570 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16568_16588,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16569_16589,"callback",null], null)], null),"chrome.tabs.getZoom");
var ns_16571 = (function (){var target_obj_16583 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16584 = (target_obj_16583["chrome"]);
var next_obj_16585 = (next_obj_16584["tabs"]);
return next_obj_16585;
})();
var missing_api_16572 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getZoom",ns_16571,"getZoom") : api_check_fn__6242__auto__.call(null,"chrome.tabs.getZoom",ns_16571,"getZoom"));
})();
if(missing_api_16572 === true){
return null;
} else {

var target_16573 = (function (){var target_obj_16586 = ns_16571;
var next_obj_16587 = (target_obj_16586["getZoom"]);
if((!((next_obj_16587 == null)))){
return next_obj_16587;
} else {
return null;
}
})();
return target_16573.apply(ns_16571,final_args_array_16570);
}
})();

return callback_chan_16566;
});
chromex.ext.tabs.set_zoom_settings_STAR_ = (function chromex$ext$tabs$set_zoom_settings_STAR_(config,tab_id,zoom_settings){
var callback_chan_16591 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16593_16610 = (function (){var omit_test_16600 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16600,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16600;
}
})();
var marshalled_zoom_settings_16594_16611 = (function (){var omit_test_16601 = zoom_settings;
if(cljs.core.keyword_identical_QMARK_(omit_test_16601,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16601;
}
})();
var marshalled_callback_16595_16612 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16602 = config__6203__auto__;
var G__16603 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_set_DASH_zoom_DASH_settings,cljs.core.cst$kw$name,"setZoomSettings",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$since,"38",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"zoom-settings",cljs.core.cst$kw$since,"38",cljs.core.cst$kw$type,"tabs.ZoomSettings"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16604 = callback_chan_16591;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16602,G__16603,G__16604) : handler__6205__auto__.call(null,G__16602,G__16603,G__16604));
})();
var result_16592_16613 = (function (){var final_args_array_16596 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16593_16610,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_zoom_settings_16594_16611,"zoom-settings",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16595_16612,"callback",true], null)], null),"chrome.tabs.setZoomSettings");
var ns_16597 = (function (){var target_obj_16605 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16606 = (target_obj_16605["chrome"]);
var next_obj_16607 = (next_obj_16606["tabs"]);
return next_obj_16607;
})();
var missing_api_16598 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.setZoomSettings",ns_16597,"setZoomSettings") : api_check_fn__6242__auto__.call(null,"chrome.tabs.setZoomSettings",ns_16597,"setZoomSettings"));
})();
if(missing_api_16598 === true){
return null;
} else {

var target_16599 = (function (){var target_obj_16608 = ns_16597;
var next_obj_16609 = (target_obj_16608["setZoomSettings"]);
if((!((next_obj_16609 == null)))){
return next_obj_16609;
} else {
return null;
}
})();
return target_16599.apply(ns_16597,final_args_array_16596);
}
})();

return callback_chan_16591;
});
chromex.ext.tabs.get_zoom_settings_STAR_ = (function chromex$ext$tabs$get_zoom_settings_STAR_(config,tab_id){
var callback_chan_16614 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16616_16636 = (function (){var omit_test_16622 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16622,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16622;
}
})();
var marshalled_callback_16617_16637 = ((function (marshalled_tab_id_16616_16636,callback_chan_16614){
return (function (cb_zoom_settings_16623){
var fexpr__16627 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16628 = config__6203__auto__;
var G__16629 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_get_DASH_zoom_DASH_settings,cljs.core.cst$kw$name,"getZoomSettings",cljs.core.cst$kw$since,"42",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$since,"38",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"zoom-settings",cljs.core.cst$kw$type,"tabs.ZoomSettings"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16630 = callback_chan_16614;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16628,G__16629,G__16630) : handler__6205__auto__.call(null,G__16628,G__16629,G__16630));
})();
return (fexpr__16627.cljs$core$IFn$_invoke$arity$1 ? fexpr__16627.cljs$core$IFn$_invoke$arity$1(cb_zoom_settings_16623) : fexpr__16627.call(null,cb_zoom_settings_16623));
});})(marshalled_tab_id_16616_16636,callback_chan_16614))
;
var result_16615_16638 = (function (){var final_args_array_16618 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16616_16636,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16617_16637,"callback",null], null)], null),"chrome.tabs.getZoomSettings");
var ns_16619 = (function (){var target_obj_16631 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16632 = (target_obj_16631["chrome"]);
var next_obj_16633 = (next_obj_16632["tabs"]);
return next_obj_16633;
})();
var missing_api_16620 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.getZoomSettings",ns_16619,"getZoomSettings") : api_check_fn__6242__auto__.call(null,"chrome.tabs.getZoomSettings",ns_16619,"getZoomSettings"));
})();
if(missing_api_16620 === true){
return null;
} else {

var target_16621 = (function (){var target_obj_16634 = ns_16619;
var next_obj_16635 = (target_obj_16634["getZoomSettings"]);
if((!((next_obj_16635 == null)))){
return next_obj_16635;
} else {
return null;
}
})();
return target_16621.apply(ns_16619,final_args_array_16618);
}
})();

return callback_chan_16614;
});
chromex.ext.tabs.discard_STAR_ = (function chromex$ext$tabs$discard_STAR_(config,tab_id){
var callback_chan_16639 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16641_16661 = (function (){var omit_test_16647 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16647,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16647;
}
})();
var marshalled_callback_16642_16662 = ((function (marshalled_tab_id_16641_16661,callback_chan_16639){
return (function (cb_tab_16648){
var fexpr__16652 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16653 = config__6203__auto__;
var G__16654 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_discard,cljs.core.cst$kw$name,"discard",cljs.core.cst$kw$since,"54",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"tabs.Tab"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16655 = callback_chan_16639;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16653,G__16654,G__16655) : handler__6205__auto__.call(null,G__16653,G__16654,G__16655));
})();
return (fexpr__16652.cljs$core$IFn$_invoke$arity$1 ? fexpr__16652.cljs$core$IFn$_invoke$arity$1(cb_tab_16648) : fexpr__16652.call(null,cb_tab_16648));
});})(marshalled_tab_id_16641_16661,callback_chan_16639))
;
var result_16640_16663 = (function (){var final_args_array_16643 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16641_16661,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16642_16662,"callback",true], null)], null),"chrome.tabs.discard");
var ns_16644 = (function (){var target_obj_16656 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16657 = (target_obj_16656["chrome"]);
var next_obj_16658 = (next_obj_16657["tabs"]);
return next_obj_16658;
})();
var missing_api_16645 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.discard",ns_16644,"discard") : api_check_fn__6242__auto__.call(null,"chrome.tabs.discard",ns_16644,"discard"));
})();
if(missing_api_16645 === true){
return null;
} else {

var target_16646 = (function (){var target_obj_16659 = ns_16644;
var next_obj_16660 = (target_obj_16659["discard"]);
if((!((next_obj_16660 == null)))){
return next_obj_16660;
} else {
return null;
}
})();
return target_16646.apply(ns_16644,final_args_array_16643);
}
})();

return callback_chan_16639;
});
chromex.ext.tabs.go_forward_STAR_ = (function chromex$ext$tabs$go_forward_STAR_(config,tab_id){
var callback_chan_16664 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16666_16681 = (function (){var omit_test_16672 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16672,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16672;
}
})();
var marshalled_callback_16667_16682 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16673 = config__6203__auto__;
var G__16674 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_go_DASH_forward,cljs.core.cst$kw$name,"goForward",cljs.core.cst$kw$since,"72",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16675 = callback_chan_16664;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16673,G__16674,G__16675) : handler__6205__auto__.call(null,G__16673,G__16674,G__16675));
})();
var result_16665_16683 = (function (){var final_args_array_16668 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16666_16681,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16667_16682,"callback",true], null)], null),"chrome.tabs.goForward");
var ns_16669 = (function (){var target_obj_16676 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16677 = (target_obj_16676["chrome"]);
var next_obj_16678 = (next_obj_16677["tabs"]);
return next_obj_16678;
})();
var missing_api_16670 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.goForward",ns_16669,"goForward") : api_check_fn__6242__auto__.call(null,"chrome.tabs.goForward",ns_16669,"goForward"));
})();
if(missing_api_16670 === true){
return null;
} else {

var target_16671 = (function (){var target_obj_16679 = ns_16669;
var next_obj_16680 = (target_obj_16679["goForward"]);
if((!((next_obj_16680 == null)))){
return next_obj_16680;
} else {
return null;
}
})();
return target_16671.apply(ns_16669,final_args_array_16668);
}
})();

return callback_chan_16664;
});
chromex.ext.tabs.go_back_STAR_ = (function chromex$ext$tabs$go_back_STAR_(config,tab_id){
var callback_chan_16684 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_16686_16701 = (function (){var omit_test_16692 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_16692,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_16692;
}
})();
var marshalled_callback_16687_16702 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16693 = config__6203__auto__;
var G__16694 = new cljs.core.PersistentArrayMap(null, 6, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$tabs_SLASH_go_DASH_back,cljs.core.cst$kw$name,"goBack",cljs.core.cst$kw$since,"72",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__16695 = callback_chan_16684;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16693,G__16694,G__16695) : handler__6205__auto__.call(null,G__16693,G__16694,G__16695));
})();
var result_16685_16703 = (function (){var final_args_array_16688 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_16686_16701,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_16687_16702,"callback",true], null)], null),"chrome.tabs.goBack");
var ns_16689 = (function (){var target_obj_16696 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16697 = (target_obj_16696["chrome"]);
var next_obj_16698 = (next_obj_16697["tabs"]);
return next_obj_16698;
})();
var missing_api_16690 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.goBack",ns_16689,"goBack") : api_check_fn__6242__auto__.call(null,"chrome.tabs.goBack",ns_16689,"goBack"));
})();
if(missing_api_16690 === true){
return null;
} else {

var target_16691 = (function (){var target_obj_16699 = ns_16689;
var next_obj_16700 = (target_obj_16699["goBack"]);
if((!((next_obj_16700 == null)))){
return next_obj_16700;
} else {
return null;
}
})();
return target_16691.apply(ns_16689,final_args_array_16688);
}
})();

return callback_chan_16684;
});
chromex.ext.tabs.on_created_STAR_ = (function chromex$ext$tabs$on_created_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___16724 = arguments.length;
var i__4731__auto___16725 = (0);
while(true){
if((i__4731__auto___16725 < len__4730__auto___16724)){
args__4736__auto__.push((arguments[i__4731__auto___16725]));

var G__16726 = (i__4731__auto___16725 + (1));
i__4731__auto___16725 = G__16726;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.tabs.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_16707 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16716 = config__6203__auto__;
var G__16717 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_created;
var G__16718 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16716,G__16717,G__16718) : handler__6205__auto__.call(null,G__16716,G__16717,G__16718));
})();
var handler_fn_16708 = ((function (event_fn_16707){
return (function (cb_tab_16714){
return (event_fn_16707.cljs$core$IFn$_invoke$arity$1 ? event_fn_16707.cljs$core$IFn$_invoke$arity$1(cb_tab_16714) : event_fn_16707.call(null,cb_tab_16714));
});})(event_fn_16707))
;
var logging_fn_16709 = ((function (event_fn_16707,handler_fn_16708){
return (function (cb_param_tab_16715){

return handler_fn_16708(cb_param_tab_16715);
});})(event_fn_16707,handler_fn_16708))
;
var ns_obj_16712 = (function (){var target_obj_16719 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16720 = (target_obj_16719["chrome"]);
var next_obj_16721 = (next_obj_16720["tabs"]);
return next_obj_16721;
})();
var missing_api_16713 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onCreated",ns_obj_16712,"onCreated") : api_check_fn__6242__auto__.call(null,"chrome.tabs.onCreated",ns_obj_16712,"onCreated"));
})();
if(missing_api_16713 === true){
return null;
} else {
var event_obj_16710 = (function (){var target_obj_16722 = ns_obj_16712;
var next_obj_16723 = (target_obj_16722["onCreated"]);
return next_obj_16723;
})();
var result_16711 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_16710,logging_fn_16709,channel);
result_16711.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_16711;
}
});

chromex.ext.tabs.on_created_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_created_STAR_.cljs$lang$applyTo = (function (seq16704){
var G__16705 = cljs.core.first(seq16704);
var seq16704__$1 = cljs.core.next(seq16704);
var G__16706 = cljs.core.first(seq16704__$1);
var seq16704__$2 = cljs.core.next(seq16704__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__16705,G__16706,seq16704__$2);
});

chromex.ext.tabs.on_updated_STAR_ = (function chromex$ext$tabs$on_updated_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___16751 = arguments.length;
var i__4731__auto___16752 = (0);
while(true){
if((i__4731__auto___16752 < len__4730__auto___16751)){
args__4736__auto__.push((arguments[i__4731__auto___16752]));

var G__16753 = (i__4731__auto___16752 + (1));
i__4731__auto___16752 = G__16753;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_updated_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.tabs.on_updated_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_16730 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16743 = config__6203__auto__;
var G__16744 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_updated;
var G__16745 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16743,G__16744,G__16745) : handler__6205__auto__.call(null,G__16743,G__16744,G__16745));
})();
var handler_fn_16731 = ((function (event_fn_16730){
return (function (cb_tab_id_16737,cb_change_info_16738,cb_tab_16739){
return (event_fn_16730.cljs$core$IFn$_invoke$arity$3 ? event_fn_16730.cljs$core$IFn$_invoke$arity$3(cb_tab_id_16737,cb_change_info_16738,cb_tab_16739) : event_fn_16730.call(null,cb_tab_id_16737,cb_change_info_16738,cb_tab_16739));
});})(event_fn_16730))
;
var logging_fn_16732 = ((function (event_fn_16730,handler_fn_16731){
return (function (cb_param_tab_id_16740,cb_param_change_info_16741,cb_param_tab_16742){

return handler_fn_16731(cb_param_tab_id_16740,cb_param_change_info_16741,cb_param_tab_16742);
});})(event_fn_16730,handler_fn_16731))
;
var ns_obj_16735 = (function (){var target_obj_16746 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16747 = (target_obj_16746["chrome"]);
var next_obj_16748 = (next_obj_16747["tabs"]);
return next_obj_16748;
})();
var missing_api_16736 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onUpdated",ns_obj_16735,"onUpdated") : api_check_fn__6242__auto__.call(null,"chrome.tabs.onUpdated",ns_obj_16735,"onUpdated"));
})();
if(missing_api_16736 === true){
return null;
} else {
var event_obj_16733 = (function (){var target_obj_16749 = ns_obj_16735;
var next_obj_16750 = (target_obj_16749["onUpdated"]);
return next_obj_16750;
})();
var result_16734 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_16733,logging_fn_16732,channel);
result_16734.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_16734;
}
});

chromex.ext.tabs.on_updated_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_updated_STAR_.cljs$lang$applyTo = (function (seq16727){
var G__16728 = cljs.core.first(seq16727);
var seq16727__$1 = cljs.core.next(seq16727);
var G__16729 = cljs.core.first(seq16727__$1);
var seq16727__$2 = cljs.core.next(seq16727__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__16728,G__16729,seq16727__$2);
});

chromex.ext.tabs.on_moved_STAR_ = (function chromex$ext$tabs$on_moved_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___16776 = arguments.length;
var i__4731__auto___16777 = (0);
while(true){
if((i__4731__auto___16777 < len__4730__auto___16776)){
args__4736__auto__.push((arguments[i__4731__auto___16777]));

var G__16778 = (i__4731__auto___16777 + (1));
i__4731__auto___16777 = G__16778;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_moved_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.tabs.on_moved_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_16757 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16768 = config__6203__auto__;
var G__16769 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_moved;
var G__16770 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16768,G__16769,G__16770) : handler__6205__auto__.call(null,G__16768,G__16769,G__16770));
})();
var handler_fn_16758 = ((function (event_fn_16757){
return (function (cb_tab_id_16764,cb_move_info_16765){
return (event_fn_16757.cljs$core$IFn$_invoke$arity$2 ? event_fn_16757.cljs$core$IFn$_invoke$arity$2(cb_tab_id_16764,cb_move_info_16765) : event_fn_16757.call(null,cb_tab_id_16764,cb_move_info_16765));
});})(event_fn_16757))
;
var logging_fn_16759 = ((function (event_fn_16757,handler_fn_16758){
return (function (cb_param_tab_id_16766,cb_param_move_info_16767){

return handler_fn_16758(cb_param_tab_id_16766,cb_param_move_info_16767);
});})(event_fn_16757,handler_fn_16758))
;
var ns_obj_16762 = (function (){var target_obj_16771 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16772 = (target_obj_16771["chrome"]);
var next_obj_16773 = (next_obj_16772["tabs"]);
return next_obj_16773;
})();
var missing_api_16763 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onMoved",ns_obj_16762,"onMoved") : api_check_fn__6242__auto__.call(null,"chrome.tabs.onMoved",ns_obj_16762,"onMoved"));
})();
if(missing_api_16763 === true){
return null;
} else {
var event_obj_16760 = (function (){var target_obj_16774 = ns_obj_16762;
var next_obj_16775 = (target_obj_16774["onMoved"]);
return next_obj_16775;
})();
var result_16761 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_16760,logging_fn_16759,channel);
result_16761.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_16761;
}
});

chromex.ext.tabs.on_moved_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_moved_STAR_.cljs$lang$applyTo = (function (seq16754){
var G__16755 = cljs.core.first(seq16754);
var seq16754__$1 = cljs.core.next(seq16754);
var G__16756 = cljs.core.first(seq16754__$1);
var seq16754__$2 = cljs.core.next(seq16754__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__16755,G__16756,seq16754__$2);
});

chromex.ext.tabs.on_selection_changed_STAR_ = (function chromex$ext$tabs$on_selection_changed_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___16801 = arguments.length;
var i__4731__auto___16802 = (0);
while(true){
if((i__4731__auto___16802 < len__4730__auto___16801)){
args__4736__auto__.push((arguments[i__4731__auto___16802]));

var G__16803 = (i__4731__auto___16802 + (1));
i__4731__auto___16802 = G__16803;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_selection_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.tabs.on_selection_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_16782 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16793 = config__6203__auto__;
var G__16794 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_selection_DASH_changed;
var G__16795 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16793,G__16794,G__16795) : handler__6205__auto__.call(null,G__16793,G__16794,G__16795));
})();
var handler_fn_16783 = ((function (event_fn_16782){
return (function (cb_tab_id_16789,cb_select_info_16790){
return (event_fn_16782.cljs$core$IFn$_invoke$arity$2 ? event_fn_16782.cljs$core$IFn$_invoke$arity$2(cb_tab_id_16789,cb_select_info_16790) : event_fn_16782.call(null,cb_tab_id_16789,cb_select_info_16790));
});})(event_fn_16782))
;
var logging_fn_16784 = ((function (event_fn_16782,handler_fn_16783){
return (function (cb_param_tab_id_16791,cb_param_select_info_16792){

return handler_fn_16783(cb_param_tab_id_16791,cb_param_select_info_16792);
});})(event_fn_16782,handler_fn_16783))
;
var ns_obj_16787 = (function (){var target_obj_16796 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16797 = (target_obj_16796["chrome"]);
var next_obj_16798 = (next_obj_16797["tabs"]);
return next_obj_16798;
})();
var missing_api_16788 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onSelectionChanged",ns_obj_16787,"onSelectionChanged") : api_check_fn__6242__auto__.call(null,"chrome.tabs.onSelectionChanged",ns_obj_16787,"onSelectionChanged"));
})();
if(missing_api_16788 === true){
return null;
} else {
var event_obj_16785 = (function (){var target_obj_16799 = ns_obj_16787;
var next_obj_16800 = (target_obj_16799["onSelectionChanged"]);
return next_obj_16800;
})();
var result_16786 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_16785,logging_fn_16784,channel);
result_16786.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_16786;
}
});

chromex.ext.tabs.on_selection_changed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_selection_changed_STAR_.cljs$lang$applyTo = (function (seq16779){
var G__16780 = cljs.core.first(seq16779);
var seq16779__$1 = cljs.core.next(seq16779);
var G__16781 = cljs.core.first(seq16779__$1);
var seq16779__$2 = cljs.core.next(seq16779__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__16780,G__16781,seq16779__$2);
});

chromex.ext.tabs.on_active_changed_STAR_ = (function chromex$ext$tabs$on_active_changed_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___16826 = arguments.length;
var i__4731__auto___16827 = (0);
while(true){
if((i__4731__auto___16827 < len__4730__auto___16826)){
args__4736__auto__.push((arguments[i__4731__auto___16827]));

var G__16828 = (i__4731__auto___16827 + (1));
i__4731__auto___16827 = G__16828;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_active_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.tabs.on_active_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_16807 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16818 = config__6203__auto__;
var G__16819 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_active_DASH_changed;
var G__16820 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16818,G__16819,G__16820) : handler__6205__auto__.call(null,G__16818,G__16819,G__16820));
})();
var handler_fn_16808 = ((function (event_fn_16807){
return (function (cb_tab_id_16814,cb_select_info_16815){
return (event_fn_16807.cljs$core$IFn$_invoke$arity$2 ? event_fn_16807.cljs$core$IFn$_invoke$arity$2(cb_tab_id_16814,cb_select_info_16815) : event_fn_16807.call(null,cb_tab_id_16814,cb_select_info_16815));
});})(event_fn_16807))
;
var logging_fn_16809 = ((function (event_fn_16807,handler_fn_16808){
return (function (cb_param_tab_id_16816,cb_param_select_info_16817){

return handler_fn_16808(cb_param_tab_id_16816,cb_param_select_info_16817);
});})(event_fn_16807,handler_fn_16808))
;
var ns_obj_16812 = (function (){var target_obj_16821 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16822 = (target_obj_16821["chrome"]);
var next_obj_16823 = (next_obj_16822["tabs"]);
return next_obj_16823;
})();
var missing_api_16813 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onActiveChanged",ns_obj_16812,"onActiveChanged") : api_check_fn__6242__auto__.call(null,"chrome.tabs.onActiveChanged",ns_obj_16812,"onActiveChanged"));
})();
if(missing_api_16813 === true){
return null;
} else {
var event_obj_16810 = (function (){var target_obj_16824 = ns_obj_16812;
var next_obj_16825 = (target_obj_16824["onActiveChanged"]);
return next_obj_16825;
})();
var result_16811 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_16810,logging_fn_16809,channel);
result_16811.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_16811;
}
});

chromex.ext.tabs.on_active_changed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_active_changed_STAR_.cljs$lang$applyTo = (function (seq16804){
var G__16805 = cljs.core.first(seq16804);
var seq16804__$1 = cljs.core.next(seq16804);
var G__16806 = cljs.core.first(seq16804__$1);
var seq16804__$2 = cljs.core.next(seq16804__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__16805,G__16806,seq16804__$2);
});

chromex.ext.tabs.on_activated_STAR_ = (function chromex$ext$tabs$on_activated_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___16849 = arguments.length;
var i__4731__auto___16850 = (0);
while(true){
if((i__4731__auto___16850 < len__4730__auto___16849)){
args__4736__auto__.push((arguments[i__4731__auto___16850]));

var G__16851 = (i__4731__auto___16850 + (1));
i__4731__auto___16850 = G__16851;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_activated_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.tabs.on_activated_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_16832 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16841 = config__6203__auto__;
var G__16842 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_activated;
var G__16843 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16841,G__16842,G__16843) : handler__6205__auto__.call(null,G__16841,G__16842,G__16843));
})();
var handler_fn_16833 = ((function (event_fn_16832){
return (function (cb_active_info_16839){
return (event_fn_16832.cljs$core$IFn$_invoke$arity$1 ? event_fn_16832.cljs$core$IFn$_invoke$arity$1(cb_active_info_16839) : event_fn_16832.call(null,cb_active_info_16839));
});})(event_fn_16832))
;
var logging_fn_16834 = ((function (event_fn_16832,handler_fn_16833){
return (function (cb_param_active_info_16840){

return handler_fn_16833(cb_param_active_info_16840);
});})(event_fn_16832,handler_fn_16833))
;
var ns_obj_16837 = (function (){var target_obj_16844 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16845 = (target_obj_16844["chrome"]);
var next_obj_16846 = (next_obj_16845["tabs"]);
return next_obj_16846;
})();
var missing_api_16838 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onActivated",ns_obj_16837,"onActivated") : api_check_fn__6242__auto__.call(null,"chrome.tabs.onActivated",ns_obj_16837,"onActivated"));
})();
if(missing_api_16838 === true){
return null;
} else {
var event_obj_16835 = (function (){var target_obj_16847 = ns_obj_16837;
var next_obj_16848 = (target_obj_16847["onActivated"]);
return next_obj_16848;
})();
var result_16836 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_16835,logging_fn_16834,channel);
result_16836.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_16836;
}
});

chromex.ext.tabs.on_activated_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_activated_STAR_.cljs$lang$applyTo = (function (seq16829){
var G__16830 = cljs.core.first(seq16829);
var seq16829__$1 = cljs.core.next(seq16829);
var G__16831 = cljs.core.first(seq16829__$1);
var seq16829__$2 = cljs.core.next(seq16829__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__16830,G__16831,seq16829__$2);
});

chromex.ext.tabs.on_highlight_changed_STAR_ = (function chromex$ext$tabs$on_highlight_changed_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___16872 = arguments.length;
var i__4731__auto___16873 = (0);
while(true){
if((i__4731__auto___16873 < len__4730__auto___16872)){
args__4736__auto__.push((arguments[i__4731__auto___16873]));

var G__16874 = (i__4731__auto___16873 + (1));
i__4731__auto___16873 = G__16874;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_highlight_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.tabs.on_highlight_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_16855 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16864 = config__6203__auto__;
var G__16865 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_highlight_DASH_changed;
var G__16866 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16864,G__16865,G__16866) : handler__6205__auto__.call(null,G__16864,G__16865,G__16866));
})();
var handler_fn_16856 = ((function (event_fn_16855){
return (function (cb_select_info_16862){
return (event_fn_16855.cljs$core$IFn$_invoke$arity$1 ? event_fn_16855.cljs$core$IFn$_invoke$arity$1(cb_select_info_16862) : event_fn_16855.call(null,cb_select_info_16862));
});})(event_fn_16855))
;
var logging_fn_16857 = ((function (event_fn_16855,handler_fn_16856){
return (function (cb_param_select_info_16863){

return handler_fn_16856(cb_param_select_info_16863);
});})(event_fn_16855,handler_fn_16856))
;
var ns_obj_16860 = (function (){var target_obj_16867 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16868 = (target_obj_16867["chrome"]);
var next_obj_16869 = (next_obj_16868["tabs"]);
return next_obj_16869;
})();
var missing_api_16861 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onHighlightChanged",ns_obj_16860,"onHighlightChanged") : api_check_fn__6242__auto__.call(null,"chrome.tabs.onHighlightChanged",ns_obj_16860,"onHighlightChanged"));
})();
if(missing_api_16861 === true){
return null;
} else {
var event_obj_16858 = (function (){var target_obj_16870 = ns_obj_16860;
var next_obj_16871 = (target_obj_16870["onHighlightChanged"]);
return next_obj_16871;
})();
var result_16859 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_16858,logging_fn_16857,channel);
result_16859.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_16859;
}
});

chromex.ext.tabs.on_highlight_changed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_highlight_changed_STAR_.cljs$lang$applyTo = (function (seq16852){
var G__16853 = cljs.core.first(seq16852);
var seq16852__$1 = cljs.core.next(seq16852);
var G__16854 = cljs.core.first(seq16852__$1);
var seq16852__$2 = cljs.core.next(seq16852__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__16853,G__16854,seq16852__$2);
});

chromex.ext.tabs.on_highlighted_STAR_ = (function chromex$ext$tabs$on_highlighted_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___16895 = arguments.length;
var i__4731__auto___16896 = (0);
while(true){
if((i__4731__auto___16896 < len__4730__auto___16895)){
args__4736__auto__.push((arguments[i__4731__auto___16896]));

var G__16897 = (i__4731__auto___16896 + (1));
i__4731__auto___16896 = G__16897;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_highlighted_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.tabs.on_highlighted_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_16878 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16887 = config__6203__auto__;
var G__16888 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_highlighted;
var G__16889 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16887,G__16888,G__16889) : handler__6205__auto__.call(null,G__16887,G__16888,G__16889));
})();
var handler_fn_16879 = ((function (event_fn_16878){
return (function (cb_highlight_info_16885){
return (event_fn_16878.cljs$core$IFn$_invoke$arity$1 ? event_fn_16878.cljs$core$IFn$_invoke$arity$1(cb_highlight_info_16885) : event_fn_16878.call(null,cb_highlight_info_16885));
});})(event_fn_16878))
;
var logging_fn_16880 = ((function (event_fn_16878,handler_fn_16879){
return (function (cb_param_highlight_info_16886){

return handler_fn_16879(cb_param_highlight_info_16886);
});})(event_fn_16878,handler_fn_16879))
;
var ns_obj_16883 = (function (){var target_obj_16890 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16891 = (target_obj_16890["chrome"]);
var next_obj_16892 = (next_obj_16891["tabs"]);
return next_obj_16892;
})();
var missing_api_16884 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onHighlighted",ns_obj_16883,"onHighlighted") : api_check_fn__6242__auto__.call(null,"chrome.tabs.onHighlighted",ns_obj_16883,"onHighlighted"));
})();
if(missing_api_16884 === true){
return null;
} else {
var event_obj_16881 = (function (){var target_obj_16893 = ns_obj_16883;
var next_obj_16894 = (target_obj_16893["onHighlighted"]);
return next_obj_16894;
})();
var result_16882 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_16881,logging_fn_16880,channel);
result_16882.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_16882;
}
});

chromex.ext.tabs.on_highlighted_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_highlighted_STAR_.cljs$lang$applyTo = (function (seq16875){
var G__16876 = cljs.core.first(seq16875);
var seq16875__$1 = cljs.core.next(seq16875);
var G__16877 = cljs.core.first(seq16875__$1);
var seq16875__$2 = cljs.core.next(seq16875__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__16876,G__16877,seq16875__$2);
});

chromex.ext.tabs.on_detached_STAR_ = (function chromex$ext$tabs$on_detached_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___16920 = arguments.length;
var i__4731__auto___16921 = (0);
while(true){
if((i__4731__auto___16921 < len__4730__auto___16920)){
args__4736__auto__.push((arguments[i__4731__auto___16921]));

var G__16922 = (i__4731__auto___16921 + (1));
i__4731__auto___16921 = G__16922;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_detached_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.tabs.on_detached_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_16901 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16912 = config__6203__auto__;
var G__16913 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_detached;
var G__16914 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16912,G__16913,G__16914) : handler__6205__auto__.call(null,G__16912,G__16913,G__16914));
})();
var handler_fn_16902 = ((function (event_fn_16901){
return (function (cb_tab_id_16908,cb_detach_info_16909){
return (event_fn_16901.cljs$core$IFn$_invoke$arity$2 ? event_fn_16901.cljs$core$IFn$_invoke$arity$2(cb_tab_id_16908,cb_detach_info_16909) : event_fn_16901.call(null,cb_tab_id_16908,cb_detach_info_16909));
});})(event_fn_16901))
;
var logging_fn_16903 = ((function (event_fn_16901,handler_fn_16902){
return (function (cb_param_tab_id_16910,cb_param_detach_info_16911){

return handler_fn_16902(cb_param_tab_id_16910,cb_param_detach_info_16911);
});})(event_fn_16901,handler_fn_16902))
;
var ns_obj_16906 = (function (){var target_obj_16915 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16916 = (target_obj_16915["chrome"]);
var next_obj_16917 = (next_obj_16916["tabs"]);
return next_obj_16917;
})();
var missing_api_16907 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onDetached",ns_obj_16906,"onDetached") : api_check_fn__6242__auto__.call(null,"chrome.tabs.onDetached",ns_obj_16906,"onDetached"));
})();
if(missing_api_16907 === true){
return null;
} else {
var event_obj_16904 = (function (){var target_obj_16918 = ns_obj_16906;
var next_obj_16919 = (target_obj_16918["onDetached"]);
return next_obj_16919;
})();
var result_16905 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_16904,logging_fn_16903,channel);
result_16905.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_16905;
}
});

chromex.ext.tabs.on_detached_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_detached_STAR_.cljs$lang$applyTo = (function (seq16898){
var G__16899 = cljs.core.first(seq16898);
var seq16898__$1 = cljs.core.next(seq16898);
var G__16900 = cljs.core.first(seq16898__$1);
var seq16898__$2 = cljs.core.next(seq16898__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__16899,G__16900,seq16898__$2);
});

chromex.ext.tabs.on_attached_STAR_ = (function chromex$ext$tabs$on_attached_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___16945 = arguments.length;
var i__4731__auto___16946 = (0);
while(true){
if((i__4731__auto___16946 < len__4730__auto___16945)){
args__4736__auto__.push((arguments[i__4731__auto___16946]));

var G__16947 = (i__4731__auto___16946 + (1));
i__4731__auto___16946 = G__16947;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_attached_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.tabs.on_attached_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_16926 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16937 = config__6203__auto__;
var G__16938 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_attached;
var G__16939 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16937,G__16938,G__16939) : handler__6205__auto__.call(null,G__16937,G__16938,G__16939));
})();
var handler_fn_16927 = ((function (event_fn_16926){
return (function (cb_tab_id_16933,cb_attach_info_16934){
return (event_fn_16926.cljs$core$IFn$_invoke$arity$2 ? event_fn_16926.cljs$core$IFn$_invoke$arity$2(cb_tab_id_16933,cb_attach_info_16934) : event_fn_16926.call(null,cb_tab_id_16933,cb_attach_info_16934));
});})(event_fn_16926))
;
var logging_fn_16928 = ((function (event_fn_16926,handler_fn_16927){
return (function (cb_param_tab_id_16935,cb_param_attach_info_16936){

return handler_fn_16927(cb_param_tab_id_16935,cb_param_attach_info_16936);
});})(event_fn_16926,handler_fn_16927))
;
var ns_obj_16931 = (function (){var target_obj_16940 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16941 = (target_obj_16940["chrome"]);
var next_obj_16942 = (next_obj_16941["tabs"]);
return next_obj_16942;
})();
var missing_api_16932 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onAttached",ns_obj_16931,"onAttached") : api_check_fn__6242__auto__.call(null,"chrome.tabs.onAttached",ns_obj_16931,"onAttached"));
})();
if(missing_api_16932 === true){
return null;
} else {
var event_obj_16929 = (function (){var target_obj_16943 = ns_obj_16931;
var next_obj_16944 = (target_obj_16943["onAttached"]);
return next_obj_16944;
})();
var result_16930 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_16929,logging_fn_16928,channel);
result_16930.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_16930;
}
});

chromex.ext.tabs.on_attached_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_attached_STAR_.cljs$lang$applyTo = (function (seq16923){
var G__16924 = cljs.core.first(seq16923);
var seq16923__$1 = cljs.core.next(seq16923);
var G__16925 = cljs.core.first(seq16923__$1);
var seq16923__$2 = cljs.core.next(seq16923__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__16924,G__16925,seq16923__$2);
});

chromex.ext.tabs.on_removed_STAR_ = (function chromex$ext$tabs$on_removed_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___16970 = arguments.length;
var i__4731__auto___16971 = (0);
while(true){
if((i__4731__auto___16971 < len__4730__auto___16970)){
args__4736__auto__.push((arguments[i__4731__auto___16971]));

var G__16972 = (i__4731__auto___16971 + (1));
i__4731__auto___16971 = G__16972;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.tabs.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_16951 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16962 = config__6203__auto__;
var G__16963 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_removed;
var G__16964 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16962,G__16963,G__16964) : handler__6205__auto__.call(null,G__16962,G__16963,G__16964));
})();
var handler_fn_16952 = ((function (event_fn_16951){
return (function (cb_tab_id_16958,cb_remove_info_16959){
return (event_fn_16951.cljs$core$IFn$_invoke$arity$2 ? event_fn_16951.cljs$core$IFn$_invoke$arity$2(cb_tab_id_16958,cb_remove_info_16959) : event_fn_16951.call(null,cb_tab_id_16958,cb_remove_info_16959));
});})(event_fn_16951))
;
var logging_fn_16953 = ((function (event_fn_16951,handler_fn_16952){
return (function (cb_param_tab_id_16960,cb_param_remove_info_16961){

return handler_fn_16952(cb_param_tab_id_16960,cb_param_remove_info_16961);
});})(event_fn_16951,handler_fn_16952))
;
var ns_obj_16956 = (function (){var target_obj_16965 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16966 = (target_obj_16965["chrome"]);
var next_obj_16967 = (next_obj_16966["tabs"]);
return next_obj_16967;
})();
var missing_api_16957 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onRemoved",ns_obj_16956,"onRemoved") : api_check_fn__6242__auto__.call(null,"chrome.tabs.onRemoved",ns_obj_16956,"onRemoved"));
})();
if(missing_api_16957 === true){
return null;
} else {
var event_obj_16954 = (function (){var target_obj_16968 = ns_obj_16956;
var next_obj_16969 = (target_obj_16968["onRemoved"]);
return next_obj_16969;
})();
var result_16955 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_16954,logging_fn_16953,channel);
result_16955.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_16955;
}
});

chromex.ext.tabs.on_removed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_removed_STAR_.cljs$lang$applyTo = (function (seq16948){
var G__16949 = cljs.core.first(seq16948);
var seq16948__$1 = cljs.core.next(seq16948);
var G__16950 = cljs.core.first(seq16948__$1);
var seq16948__$2 = cljs.core.next(seq16948__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__16949,G__16950,seq16948__$2);
});

chromex.ext.tabs.on_replaced_STAR_ = (function chromex$ext$tabs$on_replaced_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___16995 = arguments.length;
var i__4731__auto___16996 = (0);
while(true){
if((i__4731__auto___16996 < len__4730__auto___16995)){
args__4736__auto__.push((arguments[i__4731__auto___16996]));

var G__16997 = (i__4731__auto___16996 + (1));
i__4731__auto___16996 = G__16997;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_replaced_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.tabs.on_replaced_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_16976 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__16987 = config__6203__auto__;
var G__16988 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_replaced;
var G__16989 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__16987,G__16988,G__16989) : handler__6205__auto__.call(null,G__16987,G__16988,G__16989));
})();
var handler_fn_16977 = ((function (event_fn_16976){
return (function (cb_added_tab_id_16983,cb_removed_tab_id_16984){
return (event_fn_16976.cljs$core$IFn$_invoke$arity$2 ? event_fn_16976.cljs$core$IFn$_invoke$arity$2(cb_added_tab_id_16983,cb_removed_tab_id_16984) : event_fn_16976.call(null,cb_added_tab_id_16983,cb_removed_tab_id_16984));
});})(event_fn_16976))
;
var logging_fn_16978 = ((function (event_fn_16976,handler_fn_16977){
return (function (cb_param_added_tab_id_16985,cb_param_removed_tab_id_16986){

return handler_fn_16977(cb_param_added_tab_id_16985,cb_param_removed_tab_id_16986);
});})(event_fn_16976,handler_fn_16977))
;
var ns_obj_16981 = (function (){var target_obj_16990 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_16991 = (target_obj_16990["chrome"]);
var next_obj_16992 = (next_obj_16991["tabs"]);
return next_obj_16992;
})();
var missing_api_16982 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onReplaced",ns_obj_16981,"onReplaced") : api_check_fn__6242__auto__.call(null,"chrome.tabs.onReplaced",ns_obj_16981,"onReplaced"));
})();
if(missing_api_16982 === true){
return null;
} else {
var event_obj_16979 = (function (){var target_obj_16993 = ns_obj_16981;
var next_obj_16994 = (target_obj_16993["onReplaced"]);
return next_obj_16994;
})();
var result_16980 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_16979,logging_fn_16978,channel);
result_16980.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_16980;
}
});

chromex.ext.tabs.on_replaced_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_replaced_STAR_.cljs$lang$applyTo = (function (seq16973){
var G__16974 = cljs.core.first(seq16973);
var seq16973__$1 = cljs.core.next(seq16973);
var G__16975 = cljs.core.first(seq16973__$1);
var seq16973__$2 = cljs.core.next(seq16973__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__16974,G__16975,seq16973__$2);
});

chromex.ext.tabs.on_zoom_change_STAR_ = (function chromex$ext$tabs$on_zoom_change_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___17018 = arguments.length;
var i__4731__auto___17019 = (0);
while(true){
if((i__4731__auto___17019 < len__4730__auto___17018)){
args__4736__auto__.push((arguments[i__4731__auto___17019]));

var G__17020 = (i__4731__auto___17019 + (1));
i__4731__auto___17019 = G__17020;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.tabs.on_zoom_change_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.tabs.on_zoom_change_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_17001 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__17010 = config__6203__auto__;
var G__17011 = cljs.core.cst$kw$chromex$ext$tabs_SLASH_on_DASH_zoom_DASH_change;
var G__17012 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__17010,G__17011,G__17012) : handler__6205__auto__.call(null,G__17010,G__17011,G__17012));
})();
var handler_fn_17002 = ((function (event_fn_17001){
return (function (cb_zoom_change_info_17008){
return (event_fn_17001.cljs$core$IFn$_invoke$arity$1 ? event_fn_17001.cljs$core$IFn$_invoke$arity$1(cb_zoom_change_info_17008) : event_fn_17001.call(null,cb_zoom_change_info_17008));
});})(event_fn_17001))
;
var logging_fn_17003 = ((function (event_fn_17001,handler_fn_17002){
return (function (cb_param_zoom_change_info_17009){

return handler_fn_17002(cb_param_zoom_change_info_17009);
});})(event_fn_17001,handler_fn_17002))
;
var ns_obj_17006 = (function (){var target_obj_17013 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_17014 = (target_obj_17013["chrome"]);
var next_obj_17015 = (next_obj_17014["tabs"]);
return next_obj_17015;
})();
var missing_api_17007 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.tabs.onZoomChange",ns_obj_17006,"onZoomChange") : api_check_fn__6242__auto__.call(null,"chrome.tabs.onZoomChange",ns_obj_17006,"onZoomChange"));
})();
if(missing_api_17007 === true){
return null;
} else {
var event_obj_17004 = (function (){var target_obj_17016 = ns_obj_17006;
var next_obj_17017 = (target_obj_17016["onZoomChange"]);
return next_obj_17017;
})();
var result_17005 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_17004,logging_fn_17003,channel);
result_17005.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_17005;
}
});

chromex.ext.tabs.on_zoom_change_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.tabs.on_zoom_change_STAR_.cljs$lang$applyTo = (function (seq16998){
var G__16999 = cljs.core.first(seq16998);
var seq16998__$1 = cljs.core.next(seq16998);
var G__17000 = cljs.core.first(seq16998__$1);
var seq16998__$2 = cljs.core.next(seq16998__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__16999,G__17000,seq16998__$2);
});


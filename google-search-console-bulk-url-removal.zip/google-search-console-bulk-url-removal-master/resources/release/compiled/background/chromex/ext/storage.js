// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.storage');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.storage.sync_STAR_ = (function chromex$ext$storage$sync_STAR_(config){
var result_14787 = (function (){var final_args_array_14788 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.storage.sync");
var ns_14789 = (function (){var target_obj_14792 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14793 = (target_obj_14792["chrome"]);
var next_obj_14794 = (next_obj_14793["storage"]);
return next_obj_14794;
})();
var missing_api_14790 = null;
if(missing_api_14790 === true){
return null;
} else {

var target_14791 = (function (){var target_obj_14795 = ns_14789;
var next_obj_14796 = (target_obj_14795["sync"]);
if((!((next_obj_14796 == null)))){
return next_obj_14796;
} else {
return null;
}
})();
return target_14791;
}
})();
return chromex.marshalling.from_native_chrome_storage_area(config,result_14787);
});
chromex.ext.storage.local_STAR_ = (function chromex$ext$storage$local_STAR_(config){
var result_14797 = (function (){var final_args_array_14798 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.storage.local");
var ns_14799 = (function (){var target_obj_14802 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14803 = (target_obj_14802["chrome"]);
var next_obj_14804 = (next_obj_14803["storage"]);
return next_obj_14804;
})();
var missing_api_14800 = null;
if(missing_api_14800 === true){
return null;
} else {

var target_14801 = (function (){var target_obj_14805 = ns_14799;
var next_obj_14806 = (target_obj_14805["local"]);
if((!((next_obj_14806 == null)))){
return next_obj_14806;
} else {
return null;
}
})();
return target_14801;
}
})();
return chromex.marshalling.from_native_chrome_storage_area(config,result_14797);
});
chromex.ext.storage.managed_STAR_ = (function chromex$ext$storage$managed_STAR_(config){
var result_14807 = (function (){var final_args_array_14808 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.storage.managed");
var ns_14809 = (function (){var target_obj_14812 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14813 = (target_obj_14812["chrome"]);
var next_obj_14814 = (next_obj_14813["storage"]);
return next_obj_14814;
})();
var missing_api_14810 = null;
if(missing_api_14810 === true){
return null;
} else {

var target_14811 = (function (){var target_obj_14815 = ns_14809;
var next_obj_14816 = (target_obj_14815["managed"]);
if((!((next_obj_14816 == null)))){
return next_obj_14816;
} else {
return null;
}
})();
return target_14811;
}
})();
return chromex.marshalling.from_native_chrome_storage_area(config,result_14807);
});
chromex.ext.storage.on_changed_STAR_ = (function chromex$ext$storage$on_changed_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___14839 = arguments.length;
var i__4731__auto___14840 = (0);
while(true){
if((i__4731__auto___14840 < len__4730__auto___14839)){
args__4736__auto__.push((arguments[i__4731__auto___14840]));

var G__14841 = (i__4731__auto___14840 + (1));
i__4731__auto___14840 = G__14841;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.storage.on_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.storage.on_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14820 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__14831 = config__6203__auto__;
var G__14832 = cljs.core.cst$kw$chromex$ext$storage_SLASH_on_DASH_changed;
var G__14833 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__14831,G__14832,G__14833) : handler__6205__auto__.call(null,G__14831,G__14832,G__14833));
})();
var handler_fn_14821 = ((function (event_fn_14820){
return (function (cb_changes_14827,cb_area_name_14828){
return (event_fn_14820.cljs$core$IFn$_invoke$arity$2 ? event_fn_14820.cljs$core$IFn$_invoke$arity$2(cb_changes_14827,cb_area_name_14828) : event_fn_14820.call(null,cb_changes_14827,cb_area_name_14828));
});})(event_fn_14820))
;
var logging_fn_14822 = ((function (event_fn_14820,handler_fn_14821){
return (function (cb_param_changes_14829,cb_param_area_name_14830){

return handler_fn_14821(cb_param_changes_14829,cb_param_area_name_14830);
});})(event_fn_14820,handler_fn_14821))
;
var ns_obj_14825 = (function (){var target_obj_14834 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14835 = (target_obj_14834["chrome"]);
var next_obj_14836 = (next_obj_14835["storage"]);
return next_obj_14836;
})();
var missing_api_14826 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.storage.onChanged",ns_obj_14825,"onChanged") : api_check_fn__6242__auto__.call(null,"chrome.storage.onChanged",ns_obj_14825,"onChanged"));
})();
if(missing_api_14826 === true){
return null;
} else {
var event_obj_14823 = (function (){var target_obj_14837 = ns_obj_14825;
var next_obj_14838 = (target_obj_14837["onChanged"]);
return next_obj_14838;
})();
var result_14824 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14823,logging_fn_14822,channel);
result_14824.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14824;
}
});

chromex.ext.storage.on_changed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.storage.on_changed_STAR_.cljs$lang$applyTo = (function (seq14817){
var G__14818 = cljs.core.first(seq14817);
var seq14817__$1 = cljs.core.next(seq14817);
var G__14819 = cljs.core.first(seq14817__$1);
var seq14817__$2 = cljs.core.next(seq14817__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14818,G__14819,seq14817__$2);
});


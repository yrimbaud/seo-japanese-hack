// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.browser_action');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.browser_action.set_title_STAR_ = (function chromex$ext$browser_action$set_title_STAR_(config,details){
var callback_chan_13908 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_details_13910_13925 = (function (){var omit_test_13916 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_13916,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13916;
}
})();
var marshalled_callback_13911_13926 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13917 = config__6203__auto__;
var G__13918 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_set_DASH_title,cljs.core.cst$kw$name,"setTitle",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13919 = callback_chan_13908;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13917,G__13918,G__13919) : handler__6205__auto__.call(null,G__13917,G__13918,G__13919));
})();
var result_13909_13927 = (function (){var final_args_array_13912 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13910_13925,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13911_13926,"callback",true], null)], null),"chrome.browserAction.setTitle");
var ns_13913 = (function (){var target_obj_13920 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13921 = (target_obj_13920["chrome"]);
var next_obj_13922 = (next_obj_13921["browserAction"]);
return next_obj_13922;
})();
var missing_api_13914 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.setTitle",ns_13913,"setTitle") : api_check_fn__6242__auto__.call(null,"chrome.browserAction.setTitle",ns_13913,"setTitle"));
})();
if(missing_api_13914 === true){
return null;
} else {

var target_13915 = (function (){var target_obj_13923 = ns_13913;
var next_obj_13924 = (target_obj_13923["setTitle"]);
if((!((next_obj_13924 == null)))){
return next_obj_13924;
} else {
return null;
}
})();
return target_13915.apply(ns_13913,final_args_array_13912);
}
})();

return callback_chan_13908;
});
chromex.ext.browser_action.get_title_STAR_ = (function chromex$ext$browser_action$get_title_STAR_(config,details){
var callback_chan_13928 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_details_13930_13950 = (function (){var omit_test_13936 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_13936,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13936;
}
})();
var marshalled_callback_13931_13951 = ((function (marshalled_details_13930_13950,callback_chan_13928){
return (function (cb_result_13937){
var fexpr__13941 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13942 = config__6203__auto__;
var G__13943 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_get_DASH_title,cljs.core.cst$kw$name,"getTitle",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13944 = callback_chan_13928;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13942,G__13943,G__13944) : handler__6205__auto__.call(null,G__13942,G__13943,G__13944));
})();
return (fexpr__13941.cljs$core$IFn$_invoke$arity$1 ? fexpr__13941.cljs$core$IFn$_invoke$arity$1(cb_result_13937) : fexpr__13941.call(null,cb_result_13937));
});})(marshalled_details_13930_13950,callback_chan_13928))
;
var result_13929_13952 = (function (){var final_args_array_13932 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13930_13950,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13931_13951,"callback",null], null)], null),"chrome.browserAction.getTitle");
var ns_13933 = (function (){var target_obj_13945 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13946 = (target_obj_13945["chrome"]);
var next_obj_13947 = (next_obj_13946["browserAction"]);
return next_obj_13947;
})();
var missing_api_13934 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.getTitle",ns_13933,"getTitle") : api_check_fn__6242__auto__.call(null,"chrome.browserAction.getTitle",ns_13933,"getTitle"));
})();
if(missing_api_13934 === true){
return null;
} else {

var target_13935 = (function (){var target_obj_13948 = ns_13933;
var next_obj_13949 = (target_obj_13948["getTitle"]);
if((!((next_obj_13949 == null)))){
return next_obj_13949;
} else {
return null;
}
})();
return target_13935.apply(ns_13933,final_args_array_13932);
}
})();

return callback_chan_13928;
});
chromex.ext.browser_action.set_icon_STAR_ = (function chromex$ext$browser_action$set_icon_STAR_(config,details){
var callback_chan_13953 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_details_13955_13970 = (function (){var omit_test_13961 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_13961,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13961;
}
})();
var marshalled_callback_13956_13971 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13962 = config__6203__auto__;
var G__13963 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_set_DASH_icon,cljs.core.cst$kw$name,"setIcon",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13964 = callback_chan_13953;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13962,G__13963,G__13964) : handler__6205__auto__.call(null,G__13962,G__13963,G__13964));
})();
var result_13954_13972 = (function (){var final_args_array_13957 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13955_13970,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13956_13971,"callback",true], null)], null),"chrome.browserAction.setIcon");
var ns_13958 = (function (){var target_obj_13965 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13966 = (target_obj_13965["chrome"]);
var next_obj_13967 = (next_obj_13966["browserAction"]);
return next_obj_13967;
})();
var missing_api_13959 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.setIcon",ns_13958,"setIcon") : api_check_fn__6242__auto__.call(null,"chrome.browserAction.setIcon",ns_13958,"setIcon"));
})();
if(missing_api_13959 === true){
return null;
} else {

var target_13960 = (function (){var target_obj_13968 = ns_13958;
var next_obj_13969 = (target_obj_13968["setIcon"]);
if((!((next_obj_13969 == null)))){
return next_obj_13969;
} else {
return null;
}
})();
return target_13960.apply(ns_13958,final_args_array_13957);
}
})();

return callback_chan_13953;
});
chromex.ext.browser_action.set_popup_STAR_ = (function chromex$ext$browser_action$set_popup_STAR_(config,details){
var callback_chan_13973 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_details_13975_13990 = (function (){var omit_test_13981 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_13981,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_13981;
}
})();
var marshalled_callback_13976_13991 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13982 = config__6203__auto__;
var G__13983 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_set_DASH_popup,cljs.core.cst$kw$name,"setPopup",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13984 = callback_chan_13973;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13982,G__13983,G__13984) : handler__6205__auto__.call(null,G__13982,G__13983,G__13984));
})();
var result_13974_13992 = (function (){var final_args_array_13977 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13975_13990,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13976_13991,"callback",true], null)], null),"chrome.browserAction.setPopup");
var ns_13978 = (function (){var target_obj_13985 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13986 = (target_obj_13985["chrome"]);
var next_obj_13987 = (next_obj_13986["browserAction"]);
return next_obj_13987;
})();
var missing_api_13979 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.setPopup",ns_13978,"setPopup") : api_check_fn__6242__auto__.call(null,"chrome.browserAction.setPopup",ns_13978,"setPopup"));
})();
if(missing_api_13979 === true){
return null;
} else {

var target_13980 = (function (){var target_obj_13988 = ns_13978;
var next_obj_13989 = (target_obj_13988["setPopup"]);
if((!((next_obj_13989 == null)))){
return next_obj_13989;
} else {
return null;
}
})();
return target_13980.apply(ns_13978,final_args_array_13977);
}
})();

return callback_chan_13973;
});
chromex.ext.browser_action.get_popup_STAR_ = (function chromex$ext$browser_action$get_popup_STAR_(config,details){
var callback_chan_13993 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_details_13995_14015 = (function (){var omit_test_14001 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_14001,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14001;
}
})();
var marshalled_callback_13996_14016 = ((function (marshalled_details_13995_14015,callback_chan_13993){
return (function (cb_result_14002){
var fexpr__14006 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__14007 = config__6203__auto__;
var G__14008 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_get_DASH_popup,cljs.core.cst$kw$name,"getPopup",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14009 = callback_chan_13993;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__14007,G__14008,G__14009) : handler__6205__auto__.call(null,G__14007,G__14008,G__14009));
})();
return (fexpr__14006.cljs$core$IFn$_invoke$arity$1 ? fexpr__14006.cljs$core$IFn$_invoke$arity$1(cb_result_14002) : fexpr__14006.call(null,cb_result_14002));
});})(marshalled_details_13995_14015,callback_chan_13993))
;
var result_13994_14017 = (function (){var final_args_array_13997 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_13995_14015,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13996_14016,"callback",null], null)], null),"chrome.browserAction.getPopup");
var ns_13998 = (function (){var target_obj_14010 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14011 = (target_obj_14010["chrome"]);
var next_obj_14012 = (next_obj_14011["browserAction"]);
return next_obj_14012;
})();
var missing_api_13999 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.getPopup",ns_13998,"getPopup") : api_check_fn__6242__auto__.call(null,"chrome.browserAction.getPopup",ns_13998,"getPopup"));
})();
if(missing_api_13999 === true){
return null;
} else {

var target_14000 = (function (){var target_obj_14013 = ns_13998;
var next_obj_14014 = (target_obj_14013["getPopup"]);
if((!((next_obj_14014 == null)))){
return next_obj_14014;
} else {
return null;
}
})();
return target_14000.apply(ns_13998,final_args_array_13997);
}
})();

return callback_chan_13993;
});
chromex.ext.browser_action.set_badge_text_STAR_ = (function chromex$ext$browser_action$set_badge_text_STAR_(config,details){
var callback_chan_14018 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_details_14020_14035 = (function (){var omit_test_14026 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_14026,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14026;
}
})();
var marshalled_callback_14021_14036 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__14027 = config__6203__auto__;
var G__14028 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_set_DASH_badge_DASH_text,cljs.core.cst$kw$name,"setBadgeText",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14029 = callback_chan_14018;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__14027,G__14028,G__14029) : handler__6205__auto__.call(null,G__14027,G__14028,G__14029));
})();
var result_14019_14037 = (function (){var final_args_array_14022 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_14020_14035,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14021_14036,"callback",true], null)], null),"chrome.browserAction.setBadgeText");
var ns_14023 = (function (){var target_obj_14030 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14031 = (target_obj_14030["chrome"]);
var next_obj_14032 = (next_obj_14031["browserAction"]);
return next_obj_14032;
})();
var missing_api_14024 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.setBadgeText",ns_14023,"setBadgeText") : api_check_fn__6242__auto__.call(null,"chrome.browserAction.setBadgeText",ns_14023,"setBadgeText"));
})();
if(missing_api_14024 === true){
return null;
} else {

var target_14025 = (function (){var target_obj_14033 = ns_14023;
var next_obj_14034 = (target_obj_14033["setBadgeText"]);
if((!((next_obj_14034 == null)))){
return next_obj_14034;
} else {
return null;
}
})();
return target_14025.apply(ns_14023,final_args_array_14022);
}
})();

return callback_chan_14018;
});
chromex.ext.browser_action.get_badge_text_STAR_ = (function chromex$ext$browser_action$get_badge_text_STAR_(config,details){
var callback_chan_14038 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_details_14040_14060 = (function (){var omit_test_14046 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_14046,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14046;
}
})();
var marshalled_callback_14041_14061 = ((function (marshalled_details_14040_14060,callback_chan_14038){
return (function (cb_result_14047){
var fexpr__14051 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__14052 = config__6203__auto__;
var G__14053 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_get_DASH_badge_DASH_text,cljs.core.cst$kw$name,"getBadgeText",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$type,"string"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14054 = callback_chan_14038;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__14052,G__14053,G__14054) : handler__6205__auto__.call(null,G__14052,G__14053,G__14054));
})();
return (fexpr__14051.cljs$core$IFn$_invoke$arity$1 ? fexpr__14051.cljs$core$IFn$_invoke$arity$1(cb_result_14047) : fexpr__14051.call(null,cb_result_14047));
});})(marshalled_details_14040_14060,callback_chan_14038))
;
var result_14039_14062 = (function (){var final_args_array_14042 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_14040_14060,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14041_14061,"callback",null], null)], null),"chrome.browserAction.getBadgeText");
var ns_14043 = (function (){var target_obj_14055 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14056 = (target_obj_14055["chrome"]);
var next_obj_14057 = (next_obj_14056["browserAction"]);
return next_obj_14057;
})();
var missing_api_14044 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.getBadgeText",ns_14043,"getBadgeText") : api_check_fn__6242__auto__.call(null,"chrome.browserAction.getBadgeText",ns_14043,"getBadgeText"));
})();
if(missing_api_14044 === true){
return null;
} else {

var target_14045 = (function (){var target_obj_14058 = ns_14043;
var next_obj_14059 = (target_obj_14058["getBadgeText"]);
if((!((next_obj_14059 == null)))){
return next_obj_14059;
} else {
return null;
}
})();
return target_14045.apply(ns_14043,final_args_array_14042);
}
})();

return callback_chan_14038;
});
chromex.ext.browser_action.set_badge_background_color_STAR_ = (function chromex$ext$browser_action$set_badge_background_color_STAR_(config,details){
var callback_chan_14063 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_details_14065_14080 = (function (){var omit_test_14071 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_14071,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14071;
}
})();
var marshalled_callback_14066_14081 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__14072 = config__6203__auto__;
var G__14073 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_set_DASH_badge_DASH_background_DASH_color,cljs.core.cst$kw$name,"setBadgeBackgroundColor",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14074 = callback_chan_14063;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__14072,G__14073,G__14074) : handler__6205__auto__.call(null,G__14072,G__14073,G__14074));
})();
var result_14064_14082 = (function (){var final_args_array_14067 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_14065_14080,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14066_14081,"callback",true], null)], null),"chrome.browserAction.setBadgeBackgroundColor");
var ns_14068 = (function (){var target_obj_14075 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14076 = (target_obj_14075["chrome"]);
var next_obj_14077 = (next_obj_14076["browserAction"]);
return next_obj_14077;
})();
var missing_api_14069 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.setBadgeBackgroundColor",ns_14068,"setBadgeBackgroundColor") : api_check_fn__6242__auto__.call(null,"chrome.browserAction.setBadgeBackgroundColor",ns_14068,"setBadgeBackgroundColor"));
})();
if(missing_api_14069 === true){
return null;
} else {

var target_14070 = (function (){var target_obj_14078 = ns_14068;
var next_obj_14079 = (target_obj_14078["setBadgeBackgroundColor"]);
if((!((next_obj_14079 == null)))){
return next_obj_14079;
} else {
return null;
}
})();
return target_14070.apply(ns_14068,final_args_array_14067);
}
})();

return callback_chan_14063;
});
chromex.ext.browser_action.get_badge_background_color_STAR_ = (function chromex$ext$browser_action$get_badge_background_color_STAR_(config,details){
var callback_chan_14083 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_details_14085_14105 = (function (){var omit_test_14091 = details;
if(cljs.core.keyword_identical_QMARK_(omit_test_14091,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14091;
}
})();
var marshalled_callback_14086_14106 = ((function (marshalled_details_14085_14105,callback_chan_14083){
return (function (cb_result_14092){
var fexpr__14096 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__14097 = config__6203__auto__;
var G__14098 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_get_DASH_badge_DASH_background_DASH_color,cljs.core.cst$kw$name,"getBadgeBackgroundColor",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"details",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"result",cljs.core.cst$kw$type,"browserAction.ColorArray"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14099 = callback_chan_14083;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__14097,G__14098,G__14099) : handler__6205__auto__.call(null,G__14097,G__14098,G__14099));
})();
return (fexpr__14096.cljs$core$IFn$_invoke$arity$1 ? fexpr__14096.cljs$core$IFn$_invoke$arity$1(cb_result_14092) : fexpr__14096.call(null,cb_result_14092));
});})(marshalled_details_14085_14105,callback_chan_14083))
;
var result_14084_14107 = (function (){var final_args_array_14087 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_details_14085_14105,"details",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14086_14106,"callback",null], null)], null),"chrome.browserAction.getBadgeBackgroundColor");
var ns_14088 = (function (){var target_obj_14100 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14101 = (target_obj_14100["chrome"]);
var next_obj_14102 = (next_obj_14101["browserAction"]);
return next_obj_14102;
})();
var missing_api_14089 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.getBadgeBackgroundColor",ns_14088,"getBadgeBackgroundColor") : api_check_fn__6242__auto__.call(null,"chrome.browserAction.getBadgeBackgroundColor",ns_14088,"getBadgeBackgroundColor"));
})();
if(missing_api_14089 === true){
return null;
} else {

var target_14090 = (function (){var target_obj_14103 = ns_14088;
var next_obj_14104 = (target_obj_14103["getBadgeBackgroundColor"]);
if((!((next_obj_14104 == null)))){
return next_obj_14104;
} else {
return null;
}
})();
return target_14090.apply(ns_14088,final_args_array_14087);
}
})();

return callback_chan_14083;
});
chromex.ext.browser_action.enable_STAR_ = (function chromex$ext$browser_action$enable_STAR_(config,tab_id){
var callback_chan_14108 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_14110_14125 = (function (){var omit_test_14116 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14116,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14116;
}
})();
var marshalled_callback_14111_14126 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__14117 = config__6203__auto__;
var G__14118 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_enable,cljs.core.cst$kw$name,"enable",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14119 = callback_chan_14108;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__14117,G__14118,G__14119) : handler__6205__auto__.call(null,G__14117,G__14118,G__14119));
})();
var result_14109_14127 = (function (){var final_args_array_14112 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14110_14125,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14111_14126,"callback",true], null)], null),"chrome.browserAction.enable");
var ns_14113 = (function (){var target_obj_14120 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14121 = (target_obj_14120["chrome"]);
var next_obj_14122 = (next_obj_14121["browserAction"]);
return next_obj_14122;
})();
var missing_api_14114 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.enable",ns_14113,"enable") : api_check_fn__6242__auto__.call(null,"chrome.browserAction.enable",ns_14113,"enable"));
})();
if(missing_api_14114 === true){
return null;
} else {

var target_14115 = (function (){var target_obj_14123 = ns_14113;
var next_obj_14124 = (target_obj_14123["enable"]);
if((!((next_obj_14124 == null)))){
return next_obj_14124;
} else {
return null;
}
})();
return target_14115.apply(ns_14113,final_args_array_14112);
}
})();

return callback_chan_14108;
});
chromex.ext.browser_action.disable_STAR_ = (function chromex$ext$browser_action$disable_STAR_(config,tab_id){
var callback_chan_14128 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_tab_id_14130_14145 = (function (){var omit_test_14136 = tab_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_14136,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_14136;
}
})();
var marshalled_callback_14131_14146 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__14137 = config__6203__auto__;
var G__14138 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_disable,cljs.core.cst$kw$name,"disable",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"tab-id",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__14139 = callback_chan_14128;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__14137,G__14138,G__14139) : handler__6205__auto__.call(null,G__14137,G__14138,G__14139));
})();
var result_14129_14147 = (function (){var final_args_array_14132 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_tab_id_14130_14145,"tab-id",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_14131_14146,"callback",true], null)], null),"chrome.browserAction.disable");
var ns_14133 = (function (){var target_obj_14140 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14141 = (target_obj_14140["chrome"]);
var next_obj_14142 = (next_obj_14141["browserAction"]);
return next_obj_14142;
})();
var missing_api_14134 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.disable",ns_14133,"disable") : api_check_fn__6242__auto__.call(null,"chrome.browserAction.disable",ns_14133,"disable"));
})();
if(missing_api_14134 === true){
return null;
} else {

var target_14135 = (function (){var target_obj_14143 = ns_14133;
var next_obj_14144 = (target_obj_14143["disable"]);
if((!((next_obj_14144 == null)))){
return next_obj_14144;
} else {
return null;
}
})();
return target_14135.apply(ns_14133,final_args_array_14132);
}
})();

return callback_chan_14128;
});
chromex.ext.browser_action.on_clicked_STAR_ = (function chromex$ext$browser_action$on_clicked_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___14168 = arguments.length;
var i__4731__auto___14169 = (0);
while(true){
if((i__4731__auto___14169 < len__4730__auto___14168)){
args__4736__auto__.push((arguments[i__4731__auto___14169]));

var G__14170 = (i__4731__auto___14169 + (1));
i__4731__auto___14169 = G__14170;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.browser_action.on_clicked_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.browser_action.on_clicked_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_14151 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__14160 = config__6203__auto__;
var G__14161 = cljs.core.cst$kw$chromex$ext$browser_DASH_action_SLASH_on_DASH_clicked;
var G__14162 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__14160,G__14161,G__14162) : handler__6205__auto__.call(null,G__14160,G__14161,G__14162));
})();
var handler_fn_14152 = ((function (event_fn_14151){
return (function (cb_tab_14158){
return (event_fn_14151.cljs$core$IFn$_invoke$arity$1 ? event_fn_14151.cljs$core$IFn$_invoke$arity$1(cb_tab_14158) : event_fn_14151.call(null,cb_tab_14158));
});})(event_fn_14151))
;
var logging_fn_14153 = ((function (event_fn_14151,handler_fn_14152){
return (function (cb_param_tab_14159){

return handler_fn_14152(cb_param_tab_14159);
});})(event_fn_14151,handler_fn_14152))
;
var ns_obj_14156 = (function (){var target_obj_14163 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_14164 = (target_obj_14163["chrome"]);
var next_obj_14165 = (next_obj_14164["browserAction"]);
return next_obj_14165;
})();
var missing_api_14157 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.browserAction.onClicked",ns_obj_14156,"onClicked") : api_check_fn__6242__auto__.call(null,"chrome.browserAction.onClicked",ns_obj_14156,"onClicked"));
})();
if(missing_api_14157 === true){
return null;
} else {
var event_obj_14154 = (function (){var target_obj_14166 = ns_obj_14156;
var next_obj_14167 = (target_obj_14166["onClicked"]);
return next_obj_14167;
})();
var result_14155 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_14154,logging_fn_14153,channel);
result_14155.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_14155;
}
});

chromex.ext.browser_action.on_clicked_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.browser_action.on_clicked_STAR_.cljs$lang$applyTo = (function (seq14148){
var G__14149 = cljs.core.first(seq14148);
var seq14148__$1 = cljs.core.next(seq14148);
var G__14150 = cljs.core.first(seq14148__$1);
var seq14148__$2 = cljs.core.next(seq14148__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__14149,G__14150,seq14148__$2);
});


// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.windows');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.windows.window_id_none_STAR_ = (function chromex$ext$windows$window_id_none_STAR_(config){
var result_15571 = (function (){var final_args_array_15572 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.windows.WINDOW_ID_NONE");
var ns_15573 = (function (){var target_obj_15576 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_15577 = (target_obj_15576["chrome"]);
var next_obj_15578 = (next_obj_15577["windows"]);
return next_obj_15578;
})();
var missing_api_15574 = null;
if(missing_api_15574 === true){
return null;
} else {

var target_15575 = (function (){var target_obj_15579 = ns_15573;
var next_obj_15580 = (target_obj_15579["WINDOW_ID_NONE"]);
if((!((next_obj_15580 == null)))){
return next_obj_15580;
} else {
return null;
}
})();
return target_15575;
}
})();
return result_15571;
});
chromex.ext.windows.window_id_current_STAR_ = (function chromex$ext$windows$window_id_current_STAR_(config){
var result_15581 = (function (){var final_args_array_15582 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.windows.WINDOW_ID_CURRENT");
var ns_15583 = (function (){var target_obj_15586 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_15587 = (target_obj_15586["chrome"]);
var next_obj_15588 = (next_obj_15587["windows"]);
return next_obj_15588;
})();
var missing_api_15584 = null;
if(missing_api_15584 === true){
return null;
} else {

var target_15585 = (function (){var target_obj_15589 = ns_15583;
var next_obj_15590 = (target_obj_15589["WINDOW_ID_CURRENT"]);
if((!((next_obj_15590 == null)))){
return next_obj_15590;
} else {
return null;
}
})();
return target_15585;
}
})();
return result_15581;
});
chromex.ext.windows.get_STAR_ = (function chromex$ext$windows$get_STAR_(config,window_id,get_info){
var callback_chan_15591 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_window_id_15593_15615 = (function (){var omit_test_15600 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_15600,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_15600;
}
})();
var marshalled_get_info_15594_15616 = (function (){var omit_test_15601 = get_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_15601,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_15601;
}
})();
var marshalled_callback_15595_15617 = ((function (marshalled_window_id_15593_15615,marshalled_get_info_15594_15616,callback_chan_15591){
return (function (cb_window_15602){
var fexpr__15606 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__15607 = config__6203__auto__;
var G__15608 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$windows_SLASH_get,cljs.core.cst$kw$name,"get",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"get-info",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"window",cljs.core.cst$kw$type,"windows.Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__15609 = callback_chan_15591;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__15607,G__15608,G__15609) : handler__6205__auto__.call(null,G__15607,G__15608,G__15609));
})();
return (fexpr__15606.cljs$core$IFn$_invoke$arity$1 ? fexpr__15606.cljs$core$IFn$_invoke$arity$1(cb_window_15602) : fexpr__15606.call(null,cb_window_15602));
});})(marshalled_window_id_15593_15615,marshalled_get_info_15594_15616,callback_chan_15591))
;
var result_15592_15618 = (function (){var final_args_array_15596 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_15593_15615,"window-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_get_info_15594_15616,"get-info",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_15595_15617,"callback",null], null)], null),"chrome.windows.get");
var ns_15597 = (function (){var target_obj_15610 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_15611 = (target_obj_15610["chrome"]);
var next_obj_15612 = (next_obj_15611["windows"]);
return next_obj_15612;
})();
var missing_api_15598 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.windows.get",ns_15597,"get") : api_check_fn__6242__auto__.call(null,"chrome.windows.get",ns_15597,"get"));
})();
if(missing_api_15598 === true){
return null;
} else {

var target_15599 = (function (){var target_obj_15613 = ns_15597;
var next_obj_15614 = (target_obj_15613["get"]);
if((!((next_obj_15614 == null)))){
return next_obj_15614;
} else {
return null;
}
})();
return target_15599.apply(ns_15597,final_args_array_15596);
}
})();

return callback_chan_15591;
});
chromex.ext.windows.get_current_STAR_ = (function chromex$ext$windows$get_current_STAR_(config,get_info){
var callback_chan_15619 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_get_info_15621_15641 = (function (){var omit_test_15627 = get_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_15627,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_15627;
}
})();
var marshalled_callback_15622_15642 = ((function (marshalled_get_info_15621_15641,callback_chan_15619){
return (function (cb_window_15628){
var fexpr__15632 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__15633 = config__6203__auto__;
var G__15634 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$windows_SLASH_get_DASH_current,cljs.core.cst$kw$name,"getCurrent",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"get-info",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"window",cljs.core.cst$kw$type,"windows.Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__15635 = callback_chan_15619;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__15633,G__15634,G__15635) : handler__6205__auto__.call(null,G__15633,G__15634,G__15635));
})();
return (fexpr__15632.cljs$core$IFn$_invoke$arity$1 ? fexpr__15632.cljs$core$IFn$_invoke$arity$1(cb_window_15628) : fexpr__15632.call(null,cb_window_15628));
});})(marshalled_get_info_15621_15641,callback_chan_15619))
;
var result_15620_15643 = (function (){var final_args_array_15623 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_get_info_15621_15641,"get-info",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_15622_15642,"callback",null], null)], null),"chrome.windows.getCurrent");
var ns_15624 = (function (){var target_obj_15636 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_15637 = (target_obj_15636["chrome"]);
var next_obj_15638 = (next_obj_15637["windows"]);
return next_obj_15638;
})();
var missing_api_15625 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.windows.getCurrent",ns_15624,"getCurrent") : api_check_fn__6242__auto__.call(null,"chrome.windows.getCurrent",ns_15624,"getCurrent"));
})();
if(missing_api_15625 === true){
return null;
} else {

var target_15626 = (function (){var target_obj_15639 = ns_15624;
var next_obj_15640 = (target_obj_15639["getCurrent"]);
if((!((next_obj_15640 == null)))){
return next_obj_15640;
} else {
return null;
}
})();
return target_15626.apply(ns_15624,final_args_array_15623);
}
})();

return callback_chan_15619;
});
chromex.ext.windows.get_last_focused_STAR_ = (function chromex$ext$windows$get_last_focused_STAR_(config,get_info){
var callback_chan_15644 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_get_info_15646_15666 = (function (){var omit_test_15652 = get_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_15652,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_15652;
}
})();
var marshalled_callback_15647_15667 = ((function (marshalled_get_info_15646_15666,callback_chan_15644){
return (function (cb_window_15653){
var fexpr__15657 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__15658 = config__6203__auto__;
var G__15659 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$windows_SLASH_get_DASH_last_DASH_focused,cljs.core.cst$kw$name,"getLastFocused",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"get-info",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"window",cljs.core.cst$kw$type,"windows.Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__15660 = callback_chan_15644;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__15658,G__15659,G__15660) : handler__6205__auto__.call(null,G__15658,G__15659,G__15660));
})();
return (fexpr__15657.cljs$core$IFn$_invoke$arity$1 ? fexpr__15657.cljs$core$IFn$_invoke$arity$1(cb_window_15653) : fexpr__15657.call(null,cb_window_15653));
});})(marshalled_get_info_15646_15666,callback_chan_15644))
;
var result_15645_15668 = (function (){var final_args_array_15648 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_get_info_15646_15666,"get-info",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_15647_15667,"callback",null], null)], null),"chrome.windows.getLastFocused");
var ns_15649 = (function (){var target_obj_15661 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_15662 = (target_obj_15661["chrome"]);
var next_obj_15663 = (next_obj_15662["windows"]);
return next_obj_15663;
})();
var missing_api_15650 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.windows.getLastFocused",ns_15649,"getLastFocused") : api_check_fn__6242__auto__.call(null,"chrome.windows.getLastFocused",ns_15649,"getLastFocused"));
})();
if(missing_api_15650 === true){
return null;
} else {

var target_15651 = (function (){var target_obj_15664 = ns_15649;
var next_obj_15665 = (target_obj_15664["getLastFocused"]);
if((!((next_obj_15665 == null)))){
return next_obj_15665;
} else {
return null;
}
})();
return target_15651.apply(ns_15649,final_args_array_15648);
}
})();

return callback_chan_15644;
});
chromex.ext.windows.get_all_STAR_ = (function chromex$ext$windows$get_all_STAR_(config,get_info){
var callback_chan_15669 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_get_info_15671_15691 = (function (){var omit_test_15677 = get_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_15677,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_15677;
}
})();
var marshalled_callback_15672_15692 = ((function (marshalled_get_info_15671_15691,callback_chan_15669){
return (function (cb_windows_15678){
var fexpr__15682 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__15683 = config__6203__auto__;
var G__15684 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$windows_SLASH_get_DASH_all,cljs.core.cst$kw$name,"getAll",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"get-info",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"windows",cljs.core.cst$kw$type,"[array-of-windows.Windows]"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__15685 = callback_chan_15669;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__15683,G__15684,G__15685) : handler__6205__auto__.call(null,G__15683,G__15684,G__15685));
})();
return (fexpr__15682.cljs$core$IFn$_invoke$arity$1 ? fexpr__15682.cljs$core$IFn$_invoke$arity$1(cb_windows_15678) : fexpr__15682.call(null,cb_windows_15678));
});})(marshalled_get_info_15671_15691,callback_chan_15669))
;
var result_15670_15693 = (function (){var final_args_array_15673 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_get_info_15671_15691,"get-info",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_15672_15692,"callback",null], null)], null),"chrome.windows.getAll");
var ns_15674 = (function (){var target_obj_15686 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_15687 = (target_obj_15686["chrome"]);
var next_obj_15688 = (next_obj_15687["windows"]);
return next_obj_15688;
})();
var missing_api_15675 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.windows.getAll",ns_15674,"getAll") : api_check_fn__6242__auto__.call(null,"chrome.windows.getAll",ns_15674,"getAll"));
})();
if(missing_api_15675 === true){
return null;
} else {

var target_15676 = (function (){var target_obj_15689 = ns_15674;
var next_obj_15690 = (target_obj_15689["getAll"]);
if((!((next_obj_15690 == null)))){
return next_obj_15690;
} else {
return null;
}
})();
return target_15676.apply(ns_15674,final_args_array_15673);
}
})();

return callback_chan_15669;
});
chromex.ext.windows.create_STAR_ = (function chromex$ext$windows$create_STAR_(config,create_data){
var callback_chan_15694 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_create_data_15696_15716 = (function (){var omit_test_15702 = create_data;
if(cljs.core.keyword_identical_QMARK_(omit_test_15702,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_15702;
}
})();
var marshalled_callback_15697_15717 = ((function (marshalled_create_data_15696_15716,callback_chan_15694){
return (function (cb_window_15703){
var fexpr__15707 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__15708 = config__6203__auto__;
var G__15709 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$windows_SLASH_create,cljs.core.cst$kw$name,"create",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"create-data",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"window",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,"windows.Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__15710 = callback_chan_15694;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__15708,G__15709,G__15710) : handler__6205__auto__.call(null,G__15708,G__15709,G__15710));
})();
return (fexpr__15707.cljs$core$IFn$_invoke$arity$1 ? fexpr__15707.cljs$core$IFn$_invoke$arity$1(cb_window_15703) : fexpr__15707.call(null,cb_window_15703));
});})(marshalled_create_data_15696_15716,callback_chan_15694))
;
var result_15695_15718 = (function (){var final_args_array_15698 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_create_data_15696_15716,"create-data",true], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_15697_15717,"callback",true], null)], null),"chrome.windows.create");
var ns_15699 = (function (){var target_obj_15711 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_15712 = (target_obj_15711["chrome"]);
var next_obj_15713 = (next_obj_15712["windows"]);
return next_obj_15713;
})();
var missing_api_15700 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.windows.create",ns_15699,"create") : api_check_fn__6242__auto__.call(null,"chrome.windows.create",ns_15699,"create"));
})();
if(missing_api_15700 === true){
return null;
} else {

var target_15701 = (function (){var target_obj_15714 = ns_15699;
var next_obj_15715 = (target_obj_15714["create"]);
if((!((next_obj_15715 == null)))){
return next_obj_15715;
} else {
return null;
}
})();
return target_15701.apply(ns_15699,final_args_array_15698);
}
})();

return callback_chan_15694;
});
chromex.ext.windows.update_STAR_ = (function chromex$ext$windows$update_STAR_(config,window_id,update_info){
var callback_chan_15719 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_window_id_15721_15743 = (function (){var omit_test_15728 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_15728,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_15728;
}
})();
var marshalled_update_info_15722_15744 = (function (){var omit_test_15729 = update_info;
if(cljs.core.keyword_identical_QMARK_(omit_test_15729,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_15729;
}
})();
var marshalled_callback_15723_15745 = ((function (marshalled_window_id_15721_15743,marshalled_update_info_15722_15744,callback_chan_15719){
return (function (cb_window_15730){
var fexpr__15734 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__15735 = config__6203__auto__;
var G__15736 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$windows_SLASH_update,cljs.core.cst$kw$name,"update",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"update-info",cljs.core.cst$kw$type,"object"], null),new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback,cljs.core.cst$kw$callback,new cljs.core.PersistentArrayMap(null, 1, [cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"window",cljs.core.cst$kw$type,"windows.Window"], null)], null)], null)], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__15737 = callback_chan_15719;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__15735,G__15736,G__15737) : handler__6205__auto__.call(null,G__15735,G__15736,G__15737));
})();
return (fexpr__15734.cljs$core$IFn$_invoke$arity$1 ? fexpr__15734.cljs$core$IFn$_invoke$arity$1(cb_window_15730) : fexpr__15734.call(null,cb_window_15730));
});})(marshalled_window_id_15721_15743,marshalled_update_info_15722_15744,callback_chan_15719))
;
var result_15720_15746 = (function (){var final_args_array_15724 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_15721_15743,"window-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_update_info_15722_15744,"update-info",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_15723_15745,"callback",true], null)], null),"chrome.windows.update");
var ns_15725 = (function (){var target_obj_15738 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_15739 = (target_obj_15738["chrome"]);
var next_obj_15740 = (next_obj_15739["windows"]);
return next_obj_15740;
})();
var missing_api_15726 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.windows.update",ns_15725,"update") : api_check_fn__6242__auto__.call(null,"chrome.windows.update",ns_15725,"update"));
})();
if(missing_api_15726 === true){
return null;
} else {

var target_15727 = (function (){var target_obj_15741 = ns_15725;
var next_obj_15742 = (target_obj_15741["update"]);
if((!((next_obj_15742 == null)))){
return next_obj_15742;
} else {
return null;
}
})();
return target_15727.apply(ns_15725,final_args_array_15724);
}
})();

return callback_chan_15719;
});
chromex.ext.windows.remove_STAR_ = (function chromex$ext$windows$remove_STAR_(config,window_id){
var callback_chan_15747 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_window_id_15749_15764 = (function (){var omit_test_15755 = window_id;
if(cljs.core.keyword_identical_QMARK_(omit_test_15755,cljs.core.cst$kw$omit)){
return cljs.core.cst$kw$omit;
} else {
return omit_test_15755;
}
})();
var marshalled_callback_15750_15765 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__15756 = config__6203__auto__;
var G__15757 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$windows_SLASH_remove,cljs.core.cst$kw$name,"remove",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 2, [cljs.core.cst$kw$name,"window-id",cljs.core.cst$kw$type,"integer"], null),new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__15758 = callback_chan_15747;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__15756,G__15757,G__15758) : handler__6205__auto__.call(null,G__15756,G__15757,G__15758));
})();
var result_15748_15766 = (function (){var final_args_array_15751 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_window_id_15749_15764,"window-id",null], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_15750_15765,"callback",true], null)], null),"chrome.windows.remove");
var ns_15752 = (function (){var target_obj_15759 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_15760 = (target_obj_15759["chrome"]);
var next_obj_15761 = (next_obj_15760["windows"]);
return next_obj_15761;
})();
var missing_api_15753 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.windows.remove",ns_15752,"remove") : api_check_fn__6242__auto__.call(null,"chrome.windows.remove",ns_15752,"remove"));
})();
if(missing_api_15753 === true){
return null;
} else {

var target_15754 = (function (){var target_obj_15762 = ns_15752;
var next_obj_15763 = (target_obj_15762["remove"]);
if((!((next_obj_15763 == null)))){
return next_obj_15763;
} else {
return null;
}
})();
return target_15754.apply(ns_15752,final_args_array_15751);
}
})();

return callback_chan_15747;
});
chromex.ext.windows.on_created_STAR_ = (function chromex$ext$windows$on_created_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___15787 = arguments.length;
var i__4731__auto___15788 = (0);
while(true){
if((i__4731__auto___15788 < len__4730__auto___15787)){
args__4736__auto__.push((arguments[i__4731__auto___15788]));

var G__15789 = (i__4731__auto___15788 + (1));
i__4731__auto___15788 = G__15789;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.windows.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.windows.on_created_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_15770 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__15779 = config__6203__auto__;
var G__15780 = cljs.core.cst$kw$chromex$ext$windows_SLASH_on_DASH_created;
var G__15781 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__15779,G__15780,G__15781) : handler__6205__auto__.call(null,G__15779,G__15780,G__15781));
})();
var handler_fn_15771 = ((function (event_fn_15770){
return (function (cb_window_15777){
return (event_fn_15770.cljs$core$IFn$_invoke$arity$1 ? event_fn_15770.cljs$core$IFn$_invoke$arity$1(cb_window_15777) : event_fn_15770.call(null,cb_window_15777));
});})(event_fn_15770))
;
var logging_fn_15772 = ((function (event_fn_15770,handler_fn_15771){
return (function (cb_param_window_15778){

return handler_fn_15771(cb_param_window_15778);
});})(event_fn_15770,handler_fn_15771))
;
var ns_obj_15775 = (function (){var target_obj_15782 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_15783 = (target_obj_15782["chrome"]);
var next_obj_15784 = (next_obj_15783["windows"]);
return next_obj_15784;
})();
var missing_api_15776 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.windows.onCreated",ns_obj_15775,"onCreated") : api_check_fn__6242__auto__.call(null,"chrome.windows.onCreated",ns_obj_15775,"onCreated"));
})();
if(missing_api_15776 === true){
return null;
} else {
var event_obj_15773 = (function (){var target_obj_15785 = ns_obj_15775;
var next_obj_15786 = (target_obj_15785["onCreated"]);
return next_obj_15786;
})();
var result_15774 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_15773,logging_fn_15772,channel);
result_15774.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_15774;
}
});

chromex.ext.windows.on_created_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.windows.on_created_STAR_.cljs$lang$applyTo = (function (seq15767){
var G__15768 = cljs.core.first(seq15767);
var seq15767__$1 = cljs.core.next(seq15767);
var G__15769 = cljs.core.first(seq15767__$1);
var seq15767__$2 = cljs.core.next(seq15767__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__15768,G__15769,seq15767__$2);
});

chromex.ext.windows.on_removed_STAR_ = (function chromex$ext$windows$on_removed_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___15810 = arguments.length;
var i__4731__auto___15811 = (0);
while(true){
if((i__4731__auto___15811 < len__4730__auto___15810)){
args__4736__auto__.push((arguments[i__4731__auto___15811]));

var G__15812 = (i__4731__auto___15811 + (1));
i__4731__auto___15811 = G__15812;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.windows.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.windows.on_removed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_15793 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__15802 = config__6203__auto__;
var G__15803 = cljs.core.cst$kw$chromex$ext$windows_SLASH_on_DASH_removed;
var G__15804 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__15802,G__15803,G__15804) : handler__6205__auto__.call(null,G__15802,G__15803,G__15804));
})();
var handler_fn_15794 = ((function (event_fn_15793){
return (function (cb_window_id_15800){
return (event_fn_15793.cljs$core$IFn$_invoke$arity$1 ? event_fn_15793.cljs$core$IFn$_invoke$arity$1(cb_window_id_15800) : event_fn_15793.call(null,cb_window_id_15800));
});})(event_fn_15793))
;
var logging_fn_15795 = ((function (event_fn_15793,handler_fn_15794){
return (function (cb_param_window_id_15801){

return handler_fn_15794(cb_param_window_id_15801);
});})(event_fn_15793,handler_fn_15794))
;
var ns_obj_15798 = (function (){var target_obj_15805 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_15806 = (target_obj_15805["chrome"]);
var next_obj_15807 = (next_obj_15806["windows"]);
return next_obj_15807;
})();
var missing_api_15799 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.windows.onRemoved",ns_obj_15798,"onRemoved") : api_check_fn__6242__auto__.call(null,"chrome.windows.onRemoved",ns_obj_15798,"onRemoved"));
})();
if(missing_api_15799 === true){
return null;
} else {
var event_obj_15796 = (function (){var target_obj_15808 = ns_obj_15798;
var next_obj_15809 = (target_obj_15808["onRemoved"]);
return next_obj_15809;
})();
var result_15797 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_15796,logging_fn_15795,channel);
result_15797.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_15797;
}
});

chromex.ext.windows.on_removed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.windows.on_removed_STAR_.cljs$lang$applyTo = (function (seq15790){
var G__15791 = cljs.core.first(seq15790);
var seq15790__$1 = cljs.core.next(seq15790);
var G__15792 = cljs.core.first(seq15790__$1);
var seq15790__$2 = cljs.core.next(seq15790__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__15791,G__15792,seq15790__$2);
});

chromex.ext.windows.on_focus_changed_STAR_ = (function chromex$ext$windows$on_focus_changed_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___15833 = arguments.length;
var i__4731__auto___15834 = (0);
while(true){
if((i__4731__auto___15834 < len__4730__auto___15833)){
args__4736__auto__.push((arguments[i__4731__auto___15834]));

var G__15835 = (i__4731__auto___15834 + (1));
i__4731__auto___15834 = G__15835;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.windows.on_focus_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.windows.on_focus_changed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_15816 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__15825 = config__6203__auto__;
var G__15826 = cljs.core.cst$kw$chromex$ext$windows_SLASH_on_DASH_focus_DASH_changed;
var G__15827 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__15825,G__15826,G__15827) : handler__6205__auto__.call(null,G__15825,G__15826,G__15827));
})();
var handler_fn_15817 = ((function (event_fn_15816){
return (function (cb_window_id_15823){
return (event_fn_15816.cljs$core$IFn$_invoke$arity$1 ? event_fn_15816.cljs$core$IFn$_invoke$arity$1(cb_window_id_15823) : event_fn_15816.call(null,cb_window_id_15823));
});})(event_fn_15816))
;
var logging_fn_15818 = ((function (event_fn_15816,handler_fn_15817){
return (function (cb_param_window_id_15824){

return handler_fn_15817(cb_param_window_id_15824);
});})(event_fn_15816,handler_fn_15817))
;
var ns_obj_15821 = (function (){var target_obj_15828 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_15829 = (target_obj_15828["chrome"]);
var next_obj_15830 = (next_obj_15829["windows"]);
return next_obj_15830;
})();
var missing_api_15822 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.windows.onFocusChanged",ns_obj_15821,"onFocusChanged") : api_check_fn__6242__auto__.call(null,"chrome.windows.onFocusChanged",ns_obj_15821,"onFocusChanged"));
})();
if(missing_api_15822 === true){
return null;
} else {
var event_obj_15819 = (function (){var target_obj_15831 = ns_obj_15821;
var next_obj_15832 = (target_obj_15831["onFocusChanged"]);
return next_obj_15832;
})();
var result_15820 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_15819,logging_fn_15818,channel);
result_15820.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_15820;
}
});

chromex.ext.windows.on_focus_changed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.windows.on_focus_changed_STAR_.cljs$lang$applyTo = (function (seq15813){
var G__15814 = cljs.core.first(seq15813);
var seq15813__$1 = cljs.core.next(seq15813);
var G__15815 = cljs.core.first(seq15813__$1);
var seq15813__$2 = cljs.core.next(seq15813__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__15814,G__15815,seq15813__$2);
});


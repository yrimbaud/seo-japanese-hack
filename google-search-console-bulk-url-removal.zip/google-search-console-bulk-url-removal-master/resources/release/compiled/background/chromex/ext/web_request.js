// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.ext.web_request');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.core');
chromex.ext.web_request.max_handler_behavior_changed_calls_per10_minutes_STAR_ = (function chromex$ext$web_request$max_handler_behavior_changed_calls_per10_minutes_STAR_(config){
var result_13565 = (function (){var final_args_array_13566 = chromex.support.prepare_final_args_array(cljs.core.PersistentVector.EMPTY,"chrome.webRequest.MAX_HANDLER_BEHAVIOR_CHANGED_CALLS_PER_10_MINUTES");
var ns_13567 = (function (){var target_obj_13570 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13571 = (target_obj_13570["chrome"]);
var next_obj_13572 = (next_obj_13571["webRequest"]);
return next_obj_13572;
})();
var missing_api_13568 = null;
if(missing_api_13568 === true){
return null;
} else {

var target_13569 = (function (){var target_obj_13573 = ns_13567;
var next_obj_13574 = (target_obj_13573["MAX_HANDLER_BEHAVIOR_CHANGED_CALLS_PER_10_MINUTES"]);
if((!((next_obj_13574 == null)))){
return next_obj_13574;
} else {
return null;
}
})();
return target_13569;
}
})();
return result_13565;
});
chromex.ext.web_request.handler_behavior_changed_STAR_ = (function chromex$ext$web_request$handler_behavior_changed_STAR_(config){
var callback_chan_13575 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_channel_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$1 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__) : handler__6205__auto__.call(null,config__6203__auto__));
})();
var marshalled_callback_13577_13590 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$callback_DASH_fn_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13582 = config__6203__auto__;
var G__13583 = new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$id,cljs.core.cst$kw$chromex$ext$web_DASH_request_SLASH_handler_DASH_behavior_DASH_changed,cljs.core.cst$kw$name,"handlerBehaviorChanged",cljs.core.cst$kw$callback_QMARK_,true,cljs.core.cst$kw$params,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$name,"callback",cljs.core.cst$kw$optional_QMARK_,true,cljs.core.cst$kw$type,cljs.core.cst$kw$callback], null)], null),cljs.core.cst$kw$function_QMARK_,true], null);
var G__13584 = callback_chan_13575;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13582,G__13583,G__13584) : handler__6205__auto__.call(null,G__13582,G__13583,G__13584));
})();
var result_13576_13591 = (function (){var final_args_array_13578 = chromex.support.prepare_final_args_array(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [marshalled_callback_13577_13590,"callback",true], null)], null),"chrome.webRequest.handlerBehaviorChanged");
var ns_13579 = (function (){var target_obj_13585 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13586 = (target_obj_13585["chrome"]);
var next_obj_13587 = (next_obj_13586["webRequest"]);
return next_obj_13587;
})();
var missing_api_13580 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.webRequest.handlerBehaviorChanged",ns_13579,"handlerBehaviorChanged") : api_check_fn__6242__auto__.call(null,"chrome.webRequest.handlerBehaviorChanged",ns_13579,"handlerBehaviorChanged"));
})();
if(missing_api_13580 === true){
return null;
} else {

var target_13581 = (function (){var target_obj_13588 = ns_13579;
var next_obj_13589 = (target_obj_13588["handlerBehaviorChanged"]);
if((!((next_obj_13589 == null)))){
return next_obj_13589;
} else {
return null;
}
})();
return target_13581.apply(ns_13579,final_args_array_13578);
}
})();

return callback_chan_13575;
});
chromex.ext.web_request.on_before_request_STAR_ = (function chromex$ext$web_request$on_before_request_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13612 = arguments.length;
var i__4731__auto___13613 = (0);
while(true){
if((i__4731__auto___13613 < len__4730__auto___13612)){
args__4736__auto__.push((arguments[i__4731__auto___13613]));

var G__13614 = (i__4731__auto___13613 + (1));
i__4731__auto___13613 = G__13614;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.web_request.on_before_request_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.web_request.on_before_request_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13595 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13604 = config__6203__auto__;
var G__13605 = cljs.core.cst$kw$chromex$ext$web_DASH_request_SLASH_on_DASH_before_DASH_request;
var G__13606 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13604,G__13605,G__13606) : handler__6205__auto__.call(null,G__13604,G__13605,G__13606));
})();
var handler_fn_13596 = ((function (event_fn_13595){
return (function (cb_details_13602){
return (event_fn_13595.cljs$core$IFn$_invoke$arity$1 ? event_fn_13595.cljs$core$IFn$_invoke$arity$1(cb_details_13602) : event_fn_13595.call(null,cb_details_13602));
});})(event_fn_13595))
;
var logging_fn_13597 = ((function (event_fn_13595,handler_fn_13596){
return (function (cb_param_details_13603){

return handler_fn_13596(cb_param_details_13603);
});})(event_fn_13595,handler_fn_13596))
;
var ns_obj_13600 = (function (){var target_obj_13607 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13608 = (target_obj_13607["chrome"]);
var next_obj_13609 = (next_obj_13608["webRequest"]);
return next_obj_13609;
})();
var missing_api_13601 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.webRequest.onBeforeRequest",ns_obj_13600,"onBeforeRequest") : api_check_fn__6242__auto__.call(null,"chrome.webRequest.onBeforeRequest",ns_obj_13600,"onBeforeRequest"));
})();
if(missing_api_13601 === true){
return null;
} else {
var event_obj_13598 = (function (){var target_obj_13610 = ns_obj_13600;
var next_obj_13611 = (target_obj_13610["onBeforeRequest"]);
return next_obj_13611;
})();
var result_13599 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13598,logging_fn_13597,channel);
result_13599.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13599;
}
});

chromex.ext.web_request.on_before_request_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.web_request.on_before_request_STAR_.cljs$lang$applyTo = (function (seq13592){
var G__13593 = cljs.core.first(seq13592);
var seq13592__$1 = cljs.core.next(seq13592);
var G__13594 = cljs.core.first(seq13592__$1);
var seq13592__$2 = cljs.core.next(seq13592__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13593,G__13594,seq13592__$2);
});

chromex.ext.web_request.on_before_send_headers_STAR_ = (function chromex$ext$web_request$on_before_send_headers_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13635 = arguments.length;
var i__4731__auto___13636 = (0);
while(true){
if((i__4731__auto___13636 < len__4730__auto___13635)){
args__4736__auto__.push((arguments[i__4731__auto___13636]));

var G__13637 = (i__4731__auto___13636 + (1));
i__4731__auto___13636 = G__13637;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.web_request.on_before_send_headers_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.web_request.on_before_send_headers_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13618 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13627 = config__6203__auto__;
var G__13628 = cljs.core.cst$kw$chromex$ext$web_DASH_request_SLASH_on_DASH_before_DASH_send_DASH_headers;
var G__13629 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13627,G__13628,G__13629) : handler__6205__auto__.call(null,G__13627,G__13628,G__13629));
})();
var handler_fn_13619 = ((function (event_fn_13618){
return (function (cb_details_13625){
return (event_fn_13618.cljs$core$IFn$_invoke$arity$1 ? event_fn_13618.cljs$core$IFn$_invoke$arity$1(cb_details_13625) : event_fn_13618.call(null,cb_details_13625));
});})(event_fn_13618))
;
var logging_fn_13620 = ((function (event_fn_13618,handler_fn_13619){
return (function (cb_param_details_13626){

return handler_fn_13619(cb_param_details_13626);
});})(event_fn_13618,handler_fn_13619))
;
var ns_obj_13623 = (function (){var target_obj_13630 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13631 = (target_obj_13630["chrome"]);
var next_obj_13632 = (next_obj_13631["webRequest"]);
return next_obj_13632;
})();
var missing_api_13624 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.webRequest.onBeforeSendHeaders",ns_obj_13623,"onBeforeSendHeaders") : api_check_fn__6242__auto__.call(null,"chrome.webRequest.onBeforeSendHeaders",ns_obj_13623,"onBeforeSendHeaders"));
})();
if(missing_api_13624 === true){
return null;
} else {
var event_obj_13621 = (function (){var target_obj_13633 = ns_obj_13623;
var next_obj_13634 = (target_obj_13633["onBeforeSendHeaders"]);
return next_obj_13634;
})();
var result_13622 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13621,logging_fn_13620,channel);
result_13622.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13622;
}
});

chromex.ext.web_request.on_before_send_headers_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.web_request.on_before_send_headers_STAR_.cljs$lang$applyTo = (function (seq13615){
var G__13616 = cljs.core.first(seq13615);
var seq13615__$1 = cljs.core.next(seq13615);
var G__13617 = cljs.core.first(seq13615__$1);
var seq13615__$2 = cljs.core.next(seq13615__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13616,G__13617,seq13615__$2);
});

chromex.ext.web_request.on_send_headers_STAR_ = (function chromex$ext$web_request$on_send_headers_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13658 = arguments.length;
var i__4731__auto___13659 = (0);
while(true){
if((i__4731__auto___13659 < len__4730__auto___13658)){
args__4736__auto__.push((arguments[i__4731__auto___13659]));

var G__13660 = (i__4731__auto___13659 + (1));
i__4731__auto___13659 = G__13660;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.web_request.on_send_headers_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.web_request.on_send_headers_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13641 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13650 = config__6203__auto__;
var G__13651 = cljs.core.cst$kw$chromex$ext$web_DASH_request_SLASH_on_DASH_send_DASH_headers;
var G__13652 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13650,G__13651,G__13652) : handler__6205__auto__.call(null,G__13650,G__13651,G__13652));
})();
var handler_fn_13642 = ((function (event_fn_13641){
return (function (cb_details_13648){
return (event_fn_13641.cljs$core$IFn$_invoke$arity$1 ? event_fn_13641.cljs$core$IFn$_invoke$arity$1(cb_details_13648) : event_fn_13641.call(null,cb_details_13648));
});})(event_fn_13641))
;
var logging_fn_13643 = ((function (event_fn_13641,handler_fn_13642){
return (function (cb_param_details_13649){

return handler_fn_13642(cb_param_details_13649);
});})(event_fn_13641,handler_fn_13642))
;
var ns_obj_13646 = (function (){var target_obj_13653 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13654 = (target_obj_13653["chrome"]);
var next_obj_13655 = (next_obj_13654["webRequest"]);
return next_obj_13655;
})();
var missing_api_13647 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.webRequest.onSendHeaders",ns_obj_13646,"onSendHeaders") : api_check_fn__6242__auto__.call(null,"chrome.webRequest.onSendHeaders",ns_obj_13646,"onSendHeaders"));
})();
if(missing_api_13647 === true){
return null;
} else {
var event_obj_13644 = (function (){var target_obj_13656 = ns_obj_13646;
var next_obj_13657 = (target_obj_13656["onSendHeaders"]);
return next_obj_13657;
})();
var result_13645 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13644,logging_fn_13643,channel);
result_13645.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13645;
}
});

chromex.ext.web_request.on_send_headers_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.web_request.on_send_headers_STAR_.cljs$lang$applyTo = (function (seq13638){
var G__13639 = cljs.core.first(seq13638);
var seq13638__$1 = cljs.core.next(seq13638);
var G__13640 = cljs.core.first(seq13638__$1);
var seq13638__$2 = cljs.core.next(seq13638__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13639,G__13640,seq13638__$2);
});

chromex.ext.web_request.on_headers_received_STAR_ = (function chromex$ext$web_request$on_headers_received_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13681 = arguments.length;
var i__4731__auto___13682 = (0);
while(true){
if((i__4731__auto___13682 < len__4730__auto___13681)){
args__4736__auto__.push((arguments[i__4731__auto___13682]));

var G__13683 = (i__4731__auto___13682 + (1));
i__4731__auto___13682 = G__13683;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.web_request.on_headers_received_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.web_request.on_headers_received_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13664 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13673 = config__6203__auto__;
var G__13674 = cljs.core.cst$kw$chromex$ext$web_DASH_request_SLASH_on_DASH_headers_DASH_received;
var G__13675 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13673,G__13674,G__13675) : handler__6205__auto__.call(null,G__13673,G__13674,G__13675));
})();
var handler_fn_13665 = ((function (event_fn_13664){
return (function (cb_details_13671){
return (event_fn_13664.cljs$core$IFn$_invoke$arity$1 ? event_fn_13664.cljs$core$IFn$_invoke$arity$1(cb_details_13671) : event_fn_13664.call(null,cb_details_13671));
});})(event_fn_13664))
;
var logging_fn_13666 = ((function (event_fn_13664,handler_fn_13665){
return (function (cb_param_details_13672){

return handler_fn_13665(cb_param_details_13672);
});})(event_fn_13664,handler_fn_13665))
;
var ns_obj_13669 = (function (){var target_obj_13676 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13677 = (target_obj_13676["chrome"]);
var next_obj_13678 = (next_obj_13677["webRequest"]);
return next_obj_13678;
})();
var missing_api_13670 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.webRequest.onHeadersReceived",ns_obj_13669,"onHeadersReceived") : api_check_fn__6242__auto__.call(null,"chrome.webRequest.onHeadersReceived",ns_obj_13669,"onHeadersReceived"));
})();
if(missing_api_13670 === true){
return null;
} else {
var event_obj_13667 = (function (){var target_obj_13679 = ns_obj_13669;
var next_obj_13680 = (target_obj_13679["onHeadersReceived"]);
return next_obj_13680;
})();
var result_13668 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13667,logging_fn_13666,channel);
result_13668.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13668;
}
});

chromex.ext.web_request.on_headers_received_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.web_request.on_headers_received_STAR_.cljs$lang$applyTo = (function (seq13661){
var G__13662 = cljs.core.first(seq13661);
var seq13661__$1 = cljs.core.next(seq13661);
var G__13663 = cljs.core.first(seq13661__$1);
var seq13661__$2 = cljs.core.next(seq13661__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13662,G__13663,seq13661__$2);
});

chromex.ext.web_request.on_auth_required_STAR_ = (function chromex$ext$web_request$on_auth_required_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13706 = arguments.length;
var i__4731__auto___13707 = (0);
while(true){
if((i__4731__auto___13707 < len__4730__auto___13706)){
args__4736__auto__.push((arguments[i__4731__auto___13707]));

var G__13708 = (i__4731__auto___13707 + (1));
i__4731__auto___13707 = G__13708;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.web_request.on_auth_required_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.web_request.on_auth_required_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13687 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13698 = config__6203__auto__;
var G__13699 = cljs.core.cst$kw$chromex$ext$web_DASH_request_SLASH_on_DASH_auth_DASH_required;
var G__13700 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13698,G__13699,G__13700) : handler__6205__auto__.call(null,G__13698,G__13699,G__13700));
})();
var handler_fn_13688 = ((function (event_fn_13687){
return (function (cb_details_13694,cb_async_callback_13695){
return (event_fn_13687.cljs$core$IFn$_invoke$arity$2 ? event_fn_13687.cljs$core$IFn$_invoke$arity$2(cb_details_13694,cb_async_callback_13695) : event_fn_13687.call(null,cb_details_13694,cb_async_callback_13695));
});})(event_fn_13687))
;
var logging_fn_13689 = ((function (event_fn_13687,handler_fn_13688){
return (function (cb_param_details_13696,cb_param_async_callback_13697){

return handler_fn_13688(cb_param_details_13696,cb_param_async_callback_13697);
});})(event_fn_13687,handler_fn_13688))
;
var ns_obj_13692 = (function (){var target_obj_13701 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13702 = (target_obj_13701["chrome"]);
var next_obj_13703 = (next_obj_13702["webRequest"]);
return next_obj_13703;
})();
var missing_api_13693 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.webRequest.onAuthRequired",ns_obj_13692,"onAuthRequired") : api_check_fn__6242__auto__.call(null,"chrome.webRequest.onAuthRequired",ns_obj_13692,"onAuthRequired"));
})();
if(missing_api_13693 === true){
return null;
} else {
var event_obj_13690 = (function (){var target_obj_13704 = ns_obj_13692;
var next_obj_13705 = (target_obj_13704["onAuthRequired"]);
return next_obj_13705;
})();
var result_13691 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13690,logging_fn_13689,channel);
result_13691.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13691;
}
});

chromex.ext.web_request.on_auth_required_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.web_request.on_auth_required_STAR_.cljs$lang$applyTo = (function (seq13684){
var G__13685 = cljs.core.first(seq13684);
var seq13684__$1 = cljs.core.next(seq13684);
var G__13686 = cljs.core.first(seq13684__$1);
var seq13684__$2 = cljs.core.next(seq13684__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13685,G__13686,seq13684__$2);
});

chromex.ext.web_request.on_response_started_STAR_ = (function chromex$ext$web_request$on_response_started_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13729 = arguments.length;
var i__4731__auto___13730 = (0);
while(true){
if((i__4731__auto___13730 < len__4730__auto___13729)){
args__4736__auto__.push((arguments[i__4731__auto___13730]));

var G__13731 = (i__4731__auto___13730 + (1));
i__4731__auto___13730 = G__13731;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.web_request.on_response_started_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.web_request.on_response_started_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13712 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13721 = config__6203__auto__;
var G__13722 = cljs.core.cst$kw$chromex$ext$web_DASH_request_SLASH_on_DASH_response_DASH_started;
var G__13723 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13721,G__13722,G__13723) : handler__6205__auto__.call(null,G__13721,G__13722,G__13723));
})();
var handler_fn_13713 = ((function (event_fn_13712){
return (function (cb_details_13719){
return (event_fn_13712.cljs$core$IFn$_invoke$arity$1 ? event_fn_13712.cljs$core$IFn$_invoke$arity$1(cb_details_13719) : event_fn_13712.call(null,cb_details_13719));
});})(event_fn_13712))
;
var logging_fn_13714 = ((function (event_fn_13712,handler_fn_13713){
return (function (cb_param_details_13720){

return handler_fn_13713(cb_param_details_13720);
});})(event_fn_13712,handler_fn_13713))
;
var ns_obj_13717 = (function (){var target_obj_13724 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13725 = (target_obj_13724["chrome"]);
var next_obj_13726 = (next_obj_13725["webRequest"]);
return next_obj_13726;
})();
var missing_api_13718 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.webRequest.onResponseStarted",ns_obj_13717,"onResponseStarted") : api_check_fn__6242__auto__.call(null,"chrome.webRequest.onResponseStarted",ns_obj_13717,"onResponseStarted"));
})();
if(missing_api_13718 === true){
return null;
} else {
var event_obj_13715 = (function (){var target_obj_13727 = ns_obj_13717;
var next_obj_13728 = (target_obj_13727["onResponseStarted"]);
return next_obj_13728;
})();
var result_13716 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13715,logging_fn_13714,channel);
result_13716.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13716;
}
});

chromex.ext.web_request.on_response_started_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.web_request.on_response_started_STAR_.cljs$lang$applyTo = (function (seq13709){
var G__13710 = cljs.core.first(seq13709);
var seq13709__$1 = cljs.core.next(seq13709);
var G__13711 = cljs.core.first(seq13709__$1);
var seq13709__$2 = cljs.core.next(seq13709__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13710,G__13711,seq13709__$2);
});

chromex.ext.web_request.on_before_redirect_STAR_ = (function chromex$ext$web_request$on_before_redirect_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13752 = arguments.length;
var i__4731__auto___13753 = (0);
while(true){
if((i__4731__auto___13753 < len__4730__auto___13752)){
args__4736__auto__.push((arguments[i__4731__auto___13753]));

var G__13754 = (i__4731__auto___13753 + (1));
i__4731__auto___13753 = G__13754;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.web_request.on_before_redirect_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.web_request.on_before_redirect_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13735 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13744 = config__6203__auto__;
var G__13745 = cljs.core.cst$kw$chromex$ext$web_DASH_request_SLASH_on_DASH_before_DASH_redirect;
var G__13746 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13744,G__13745,G__13746) : handler__6205__auto__.call(null,G__13744,G__13745,G__13746));
})();
var handler_fn_13736 = ((function (event_fn_13735){
return (function (cb_details_13742){
return (event_fn_13735.cljs$core$IFn$_invoke$arity$1 ? event_fn_13735.cljs$core$IFn$_invoke$arity$1(cb_details_13742) : event_fn_13735.call(null,cb_details_13742));
});})(event_fn_13735))
;
var logging_fn_13737 = ((function (event_fn_13735,handler_fn_13736){
return (function (cb_param_details_13743){

return handler_fn_13736(cb_param_details_13743);
});})(event_fn_13735,handler_fn_13736))
;
var ns_obj_13740 = (function (){var target_obj_13747 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13748 = (target_obj_13747["chrome"]);
var next_obj_13749 = (next_obj_13748["webRequest"]);
return next_obj_13749;
})();
var missing_api_13741 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.webRequest.onBeforeRedirect",ns_obj_13740,"onBeforeRedirect") : api_check_fn__6242__auto__.call(null,"chrome.webRequest.onBeforeRedirect",ns_obj_13740,"onBeforeRedirect"));
})();
if(missing_api_13741 === true){
return null;
} else {
var event_obj_13738 = (function (){var target_obj_13750 = ns_obj_13740;
var next_obj_13751 = (target_obj_13750["onBeforeRedirect"]);
return next_obj_13751;
})();
var result_13739 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13738,logging_fn_13737,channel);
result_13739.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13739;
}
});

chromex.ext.web_request.on_before_redirect_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.web_request.on_before_redirect_STAR_.cljs$lang$applyTo = (function (seq13732){
var G__13733 = cljs.core.first(seq13732);
var seq13732__$1 = cljs.core.next(seq13732);
var G__13734 = cljs.core.first(seq13732__$1);
var seq13732__$2 = cljs.core.next(seq13732__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13733,G__13734,seq13732__$2);
});

chromex.ext.web_request.on_completed_STAR_ = (function chromex$ext$web_request$on_completed_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13775 = arguments.length;
var i__4731__auto___13776 = (0);
while(true){
if((i__4731__auto___13776 < len__4730__auto___13775)){
args__4736__auto__.push((arguments[i__4731__auto___13776]));

var G__13777 = (i__4731__auto___13776 + (1));
i__4731__auto___13776 = G__13777;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.web_request.on_completed_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.web_request.on_completed_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13758 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13767 = config__6203__auto__;
var G__13768 = cljs.core.cst$kw$chromex$ext$web_DASH_request_SLASH_on_DASH_completed;
var G__13769 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13767,G__13768,G__13769) : handler__6205__auto__.call(null,G__13767,G__13768,G__13769));
})();
var handler_fn_13759 = ((function (event_fn_13758){
return (function (cb_details_13765){
return (event_fn_13758.cljs$core$IFn$_invoke$arity$1 ? event_fn_13758.cljs$core$IFn$_invoke$arity$1(cb_details_13765) : event_fn_13758.call(null,cb_details_13765));
});})(event_fn_13758))
;
var logging_fn_13760 = ((function (event_fn_13758,handler_fn_13759){
return (function (cb_param_details_13766){

return handler_fn_13759(cb_param_details_13766);
});})(event_fn_13758,handler_fn_13759))
;
var ns_obj_13763 = (function (){var target_obj_13770 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13771 = (target_obj_13770["chrome"]);
var next_obj_13772 = (next_obj_13771["webRequest"]);
return next_obj_13772;
})();
var missing_api_13764 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.webRequest.onCompleted",ns_obj_13763,"onCompleted") : api_check_fn__6242__auto__.call(null,"chrome.webRequest.onCompleted",ns_obj_13763,"onCompleted"));
})();
if(missing_api_13764 === true){
return null;
} else {
var event_obj_13761 = (function (){var target_obj_13773 = ns_obj_13763;
var next_obj_13774 = (target_obj_13773["onCompleted"]);
return next_obj_13774;
})();
var result_13762 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13761,logging_fn_13760,channel);
result_13762.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13762;
}
});

chromex.ext.web_request.on_completed_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.web_request.on_completed_STAR_.cljs$lang$applyTo = (function (seq13755){
var G__13756 = cljs.core.first(seq13755);
var seq13755__$1 = cljs.core.next(seq13755);
var G__13757 = cljs.core.first(seq13755__$1);
var seq13755__$2 = cljs.core.next(seq13755__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13756,G__13757,seq13755__$2);
});

chromex.ext.web_request.on_error_occurred_STAR_ = (function chromex$ext$web_request$on_error_occurred_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13798 = arguments.length;
var i__4731__auto___13799 = (0);
while(true){
if((i__4731__auto___13799 < len__4730__auto___13798)){
args__4736__auto__.push((arguments[i__4731__auto___13799]));

var G__13800 = (i__4731__auto___13799 + (1));
i__4731__auto___13799 = G__13800;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.web_request.on_error_occurred_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.web_request.on_error_occurred_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13781 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13790 = config__6203__auto__;
var G__13791 = cljs.core.cst$kw$chromex$ext$web_DASH_request_SLASH_on_DASH_error_DASH_occurred;
var G__13792 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13790,G__13791,G__13792) : handler__6205__auto__.call(null,G__13790,G__13791,G__13792));
})();
var handler_fn_13782 = ((function (event_fn_13781){
return (function (cb_details_13788){
return (event_fn_13781.cljs$core$IFn$_invoke$arity$1 ? event_fn_13781.cljs$core$IFn$_invoke$arity$1(cb_details_13788) : event_fn_13781.call(null,cb_details_13788));
});})(event_fn_13781))
;
var logging_fn_13783 = ((function (event_fn_13781,handler_fn_13782){
return (function (cb_param_details_13789){

return handler_fn_13782(cb_param_details_13789);
});})(event_fn_13781,handler_fn_13782))
;
var ns_obj_13786 = (function (){var target_obj_13793 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13794 = (target_obj_13793["chrome"]);
var next_obj_13795 = (next_obj_13794["webRequest"]);
return next_obj_13795;
})();
var missing_api_13787 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.webRequest.onErrorOccurred",ns_obj_13786,"onErrorOccurred") : api_check_fn__6242__auto__.call(null,"chrome.webRequest.onErrorOccurred",ns_obj_13786,"onErrorOccurred"));
})();
if(missing_api_13787 === true){
return null;
} else {
var event_obj_13784 = (function (){var target_obj_13796 = ns_obj_13786;
var next_obj_13797 = (target_obj_13796["onErrorOccurred"]);
return next_obj_13797;
})();
var result_13785 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13784,logging_fn_13783,channel);
result_13785.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13785;
}
});

chromex.ext.web_request.on_error_occurred_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.web_request.on_error_occurred_STAR_.cljs$lang$applyTo = (function (seq13778){
var G__13779 = cljs.core.first(seq13778);
var seq13778__$1 = cljs.core.next(seq13778);
var G__13780 = cljs.core.first(seq13778__$1);
var seq13778__$2 = cljs.core.next(seq13778__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13779,G__13780,seq13778__$2);
});

chromex.ext.web_request.on_action_ignored_STAR_ = (function chromex$ext$web_request$on_action_ignored_STAR_(var_args){
var args__4736__auto__ = [];
var len__4730__auto___13821 = arguments.length;
var i__4731__auto___13822 = (0);
while(true){
if((i__4731__auto___13822 < len__4730__auto___13821)){
args__4736__auto__.push((arguments[i__4731__auto___13822]));

var G__13823 = (i__4731__auto___13822 + (1));
i__4731__auto___13822 = G__13823;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((2) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((2)),(0),null)):null);
return chromex.ext.web_request.on_action_ignored_STAR_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__4737__auto__);
});

chromex.ext.web_request.on_action_ignored_STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (config,channel,args){
var event_fn_13804 = (function (){var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$event_DASH_listener_DASH_factory;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

var G__13813 = config__6203__auto__;
var G__13814 = cljs.core.cst$kw$chromex$ext$web_DASH_request_SLASH_on_DASH_action_DASH_ignored;
var G__13815 = channel;
return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$3 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$3(G__13813,G__13814,G__13815) : handler__6205__auto__.call(null,G__13813,G__13814,G__13815));
})();
var handler_fn_13805 = ((function (event_fn_13804){
return (function (cb_details_13811){
return (event_fn_13804.cljs$core$IFn$_invoke$arity$1 ? event_fn_13804.cljs$core$IFn$_invoke$arity$1(cb_details_13811) : event_fn_13804.call(null,cb_details_13811));
});})(event_fn_13804))
;
var logging_fn_13806 = ((function (event_fn_13804,handler_fn_13805){
return (function (cb_param_details_13812){

return handler_fn_13805(cb_param_details_13812);
});})(event_fn_13804,handler_fn_13805))
;
var ns_obj_13809 = (function (){var target_obj_13816 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_13817 = (target_obj_13816["chrome"]);
var next_obj_13818 = (next_obj_13817["webRequest"]);
return next_obj_13818;
})();
var missing_api_13810 = (function (){var config__6241__auto__ = config;
var api_check_fn__6242__auto__ = cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn.cljs$core$IFn$_invoke$arity$1(config__6241__auto__);

return (api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3 ? api_check_fn__6242__auto__.cljs$core$IFn$_invoke$arity$3("chrome.webRequest.onActionIgnored",ns_obj_13809,"onActionIgnored") : api_check_fn__6242__auto__.call(null,"chrome.webRequest.onActionIgnored",ns_obj_13809,"onActionIgnored"));
})();
if(missing_api_13810 === true){
return null;
} else {
var event_obj_13807 = (function (){var target_obj_13819 = ns_obj_13809;
var next_obj_13820 = (target_obj_13819["onActionIgnored"]);
return next_obj_13820;
})();
var result_13808 = chromex.chrome_event_subscription.make_chrome_event_subscription(event_obj_13807,logging_fn_13806,channel);
result_13808.chromex$protocols$chrome_event_subscription$IChromeEventSubscription$subscribe_BANG_$arity$2(null,args);

return result_13808;
}
});

chromex.ext.web_request.on_action_ignored_STAR_.cljs$lang$maxFixedArity = (2);

/** @this {Function} */
chromex.ext.web_request.on_action_ignored_STAR_.cljs$lang$applyTo = (function (seq13801){
var G__13802 = cljs.core.first(seq13801);
var seq13801__$1 = cljs.core.next(seq13801);
var G__13803 = cljs.core.first(seq13801__$1);
var seq13801__$2 = cljs.core.next(seq13801__$1);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__13802,G__13803,seq13801__$2);
});


// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_storage_area');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.protocols.chrome_storage_area');
goog.require('chromex.support');
goog.require('oops.core');

/**
* @constructor
 * @implements {chromex.protocols.chrome_storage_area.IChromeStorageArea}
*/
chromex.chrome_storage_area.ChromeStorageArea = (function (native_chrome_storage_area,channel_factory,callback_factory){
this.native_chrome_storage_area = native_chrome_storage_area;
this.channel_factory = channel_factory;
this.callback_factory = callback_factory;
});
chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_native_storage_area$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_storage_area;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return this$__$1.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$2(null,null);
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12344_12364 = self__.native_chrome_storage_area;
var call_info_12346_12365 = [target_obj_12344_12364,(function (){var next_obj_12347 = (target_obj_12344_12364["get"]);
return next_obj_12347;
})()];
var fn_12345_12366 = (call_info_12346_12365[(1)]);
if((!((fn_12345_12366 == null)))){
fn_12345_12366.call((call_info_12346_12365[(0)]),keys,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return this$__$1.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$2(null,null);
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$get_bytes_in_use$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12348_12367 = self__.native_chrome_storage_area;
var call_info_12350_12368 = [target_obj_12348_12367,(function (){var next_obj_12351 = (target_obj_12348_12367["getBytesInUse"]);
return next_obj_12351;
})()];
var fn_12349_12369 = (call_info_12350_12368[(1)]);
if((!((fn_12349_12369 == null)))){
fn_12349_12369.call((call_info_12350_12368[(0)]),keys,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$set$arity$2 = (function (_this,items){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12352_12370 = self__.native_chrome_storage_area;
var call_info_12354_12371 = [target_obj_12352_12370,(function (){var next_obj_12355 = (target_obj_12352_12370["set"]);
return next_obj_12355;
})()];
var fn_12353_12372 = (call_info_12354_12371[(1)]);
if((!((fn_12353_12372 == null)))){
fn_12353_12372.call((call_info_12354_12371[(0)]),items,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$remove$arity$2 = (function (_this,keys){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12356_12373 = self__.native_chrome_storage_area;
var call_info_12358_12374 = [target_obj_12356_12373,(function (){var next_obj_12359 = (target_obj_12356_12373["remove"]);
return next_obj_12359;
})()];
var fn_12357_12375 = (call_info_12358_12374[(1)]);
if((!((fn_12357_12375 == null)))){
fn_12357_12375.call((call_info_12358_12374[(0)]),keys,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.prototype.chromex$protocols$chrome_storage_area$IChromeStorageArea$clear$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12360_12376 = self__.native_chrome_storage_area;
var call_info_12362_12377 = [target_obj_12360_12376,(function (){var next_obj_12363 = (target_obj_12360_12376["clear"]);
return next_obj_12363;
})()];
var fn_12361_12378 = (call_info_12362_12377[(1)]);
if((!((fn_12361_12378 == null)))){
fn_12361_12378.call((call_info_12362_12377[(0)]),(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_storage_area.ChromeStorageArea.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$native_DASH_chrome_DASH_storage_DASH_area,cljs.core.cst$sym$channel_DASH_factory,cljs.core.cst$sym$callback_DASH_factory], null);
});

chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$type = true;

chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$ctorStr = "chromex.chrome-storage-area/ChromeStorageArea";

chromex.chrome_storage_area.ChromeStorageArea.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"chromex.chrome-storage-area/ChromeStorageArea");
});

/**
 * Positional factory function for chromex.chrome-storage-area/ChromeStorageArea.
 */
chromex.chrome_storage_area.__GT_ChromeStorageArea = (function chromex$chrome_storage_area$__GT_ChromeStorageArea(native_chrome_storage_area,channel_factory,callback_factory){
return (new chromex.chrome_storage_area.ChromeStorageArea(native_chrome_storage_area,channel_factory,callback_factory));
});

chromex.chrome_storage_area.make_chrome_storage_area = (function chromex$chrome_storage_area$make_chrome_storage_area(config,native_chrome_storage_area){

return (new chromex.chrome_storage_area.ChromeStorageArea(native_chrome_storage_area,(function (){var config__6212__auto__ = config;
var handler_key__6213__auto__ = cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_channel_DASH_factory;
var handler__6214__auto__ = handler_key__6213__auto__.cljs$core$IFn$_invoke$arity$1(config__6212__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6214__auto__,config__6212__auto__);
})(),(function (){var config__6212__auto__ = config;
var handler_key__6213__auto__ = cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_fn_DASH_factory;
var handler__6214__auto__ = handler_key__6213__auto__.cljs$core$IFn$_invoke$arity$1(config__6212__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6214__auto__,config__6212__auto__);
})()));
});

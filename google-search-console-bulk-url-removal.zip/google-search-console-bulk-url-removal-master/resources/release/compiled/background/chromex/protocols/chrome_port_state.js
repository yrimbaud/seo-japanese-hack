// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.protocols.chrome_port_state');
goog.require('cljs.core');
goog.require('cljs.core.constants');

/**
 * @interface
 */
chromex.protocols.chrome_port_state.IChromePortState = function(){};

chromex.protocols.chrome_port_state.set_connected_BANG_ = (function chromex$protocols$chrome_port_state$set_connected_BANG_(this$,val){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_port_state$IChromePortState$set_connected_BANG_$arity$2 == null)))))){
return this$.chromex$protocols$chrome_port_state$IChromePortState$set_connected_BANG_$arity$2(this$,val);
} else {
var x__4433__auto__ = (((this$ == null))?null:this$);
var m__4434__auto__ = (chromex.protocols.chrome_port_state.set_connected_BANG_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(this$,val) : m__4434__auto__.call(null,this$,val));
} else {
var m__4431__auto__ = (chromex.protocols.chrome_port_state.set_connected_BANG_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(this$,val) : m__4431__auto__.call(null,this$,val));
} else {
throw cljs.core.missing_protocol("IChromePortState.set-connected!",this$);
}
}
}
});

chromex.protocols.chrome_port_state.put_message_BANG_ = (function chromex$protocols$chrome_port_state$put_message_BANG_(this$,message){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_port_state$IChromePortState$put_message_BANG_$arity$2 == null)))))){
return this$.chromex$protocols$chrome_port_state$IChromePortState$put_message_BANG_$arity$2(this$,message);
} else {
var x__4433__auto__ = (((this$ == null))?null:this$);
var m__4434__auto__ = (chromex.protocols.chrome_port_state.put_message_BANG_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(this$,message) : m__4434__auto__.call(null,this$,message));
} else {
var m__4431__auto__ = (chromex.protocols.chrome_port_state.put_message_BANG_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(this$,message) : m__4431__auto__.call(null,this$,message));
} else {
throw cljs.core.missing_protocol("IChromePortState.put-message!",this$);
}
}
}
});

chromex.protocols.chrome_port_state.close_resources_BANG_ = (function chromex$protocols$chrome_port_state$close_resources_BANG_(this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_port_state$IChromePortState$close_resources_BANG_$arity$1 == null)))))){
return this$.chromex$protocols$chrome_port_state$IChromePortState$close_resources_BANG_$arity$1(this$);
} else {
var x__4433__auto__ = (((this$ == null))?null:this$);
var m__4434__auto__ = (chromex.protocols.chrome_port_state.close_resources_BANG_[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4434__auto__.call(null,this$));
} else {
var m__4431__auto__ = (chromex.protocols.chrome_port_state.close_resources_BANG_["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4431__auto__.call(null,this$));
} else {
throw cljs.core.missing_protocol("IChromePortState.close-resources!",this$);
}
}
}
});


// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.protocols.chrome_content_setting');
goog.require('cljs.core');
goog.require('cljs.core.constants');

/**
 * a wrapper for https://developer.chrome.com/extensions/contentSettings#type-ContentSetting
 * @interface
 */
chromex.protocols.chrome_content_setting.IChromeContentSetting = function(){};

chromex.protocols.chrome_content_setting.get_native_content_setting = (function chromex$protocols$chrome_content_setting$get_native_content_setting(this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_native_content_setting$arity$1 == null)))))){
return this$.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_native_content_setting$arity$1(this$);
} else {
var x__4433__auto__ = (((this$ == null))?null:this$);
var m__4434__auto__ = (chromex.protocols.chrome_content_setting.get_native_content_setting[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4434__auto__.call(null,this$));
} else {
var m__4431__auto__ = (chromex.protocols.chrome_content_setting.get_native_content_setting["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4431__auto__.call(null,this$));
} else {
throw cljs.core.missing_protocol("IChromeContentSetting.get-native-content-setting",this$);
}
}
}
});

chromex.protocols.chrome_content_setting.get = (function chromex$protocols$chrome_content_setting$get(this$,details){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_content_setting$IChromeContentSetting$get$arity$2 == null)))))){
return this$.chromex$protocols$chrome_content_setting$IChromeContentSetting$get$arity$2(this$,details);
} else {
var x__4433__auto__ = (((this$ == null))?null:this$);
var m__4434__auto__ = (chromex.protocols.chrome_content_setting.get[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(this$,details) : m__4434__auto__.call(null,this$,details));
} else {
var m__4431__auto__ = (chromex.protocols.chrome_content_setting.get["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(this$,details) : m__4431__auto__.call(null,this$,details));
} else {
throw cljs.core.missing_protocol("IChromeContentSetting.get",this$);
}
}
}
});

chromex.protocols.chrome_content_setting.set = (function chromex$protocols$chrome_content_setting$set(this$,details){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_content_setting$IChromeContentSetting$set$arity$2 == null)))))){
return this$.chromex$protocols$chrome_content_setting$IChromeContentSetting$set$arity$2(this$,details);
} else {
var x__4433__auto__ = (((this$ == null))?null:this$);
var m__4434__auto__ = (chromex.protocols.chrome_content_setting.set[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(this$,details) : m__4434__auto__.call(null,this$,details));
} else {
var m__4431__auto__ = (chromex.protocols.chrome_content_setting.set["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(this$,details) : m__4431__auto__.call(null,this$,details));
} else {
throw cljs.core.missing_protocol("IChromeContentSetting.set",this$);
}
}
}
});

chromex.protocols.chrome_content_setting.clear = (function chromex$protocols$chrome_content_setting$clear(this$,details){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_content_setting$IChromeContentSetting$clear$arity$2 == null)))))){
return this$.chromex$protocols$chrome_content_setting$IChromeContentSetting$clear$arity$2(this$,details);
} else {
var x__4433__auto__ = (((this$ == null))?null:this$);
var m__4434__auto__ = (chromex.protocols.chrome_content_setting.clear[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$2(this$,details) : m__4434__auto__.call(null,this$,details));
} else {
var m__4431__auto__ = (chromex.protocols.chrome_content_setting.clear["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$2 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$2(this$,details) : m__4431__auto__.call(null,this$,details));
} else {
throw cljs.core.missing_protocol("IChromeContentSetting.clear",this$);
}
}
}
});

chromex.protocols.chrome_content_setting.get_resource_identifiers = (function chromex$protocols$chrome_content_setting$get_resource_identifiers(this$){
if((((!((this$ == null)))) && ((!((this$.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_resource_identifiers$arity$1 == null)))))){
return this$.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_resource_identifiers$arity$1(this$);
} else {
var x__4433__auto__ = (((this$ == null))?null:this$);
var m__4434__auto__ = (chromex.protocols.chrome_content_setting.get_resource_identifiers[goog.typeOf(x__4433__auto__)]);
if((!((m__4434__auto__ == null)))){
return (m__4434__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4434__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4434__auto__.call(null,this$));
} else {
var m__4431__auto__ = (chromex.protocols.chrome_content_setting.get_resource_identifiers["_"]);
if((!((m__4431__auto__ == null)))){
return (m__4431__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4431__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4431__auto__.call(null,this$));
} else {
throw cljs.core.missing_protocol("IChromeContentSetting.get-resource-identifiers",this$);
}
}
}
});


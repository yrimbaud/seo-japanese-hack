// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.version');
goog.require('cljs.core');
goog.require('cljs.core.constants');
chromex.version.current_version = "0.8.1";
chromex.version.get_current_version = (function chromex$version$get_current_version(){
return chromex.version.current_version;
});

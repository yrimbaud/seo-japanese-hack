// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.defaults');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.error');
goog.require('chromex.protocols.chrome_port');
goog.require('chromex.protocols.chrome_port_state');
goog.require('chromex.support');
goog.require('cljs.core.async');
goog.require('goog.object');
goog.require('oops.core');
chromex.defaults.log_prefix = "[chromex]";
chromex.defaults.console_log = (function chromex$defaults$console_log(var_args){
var args__4736__auto__ = [];
var len__4730__auto___12263 = arguments.length;
var i__4731__auto___12264 = (0);
while(true){
if((i__4731__auto___12264 < len__4730__auto___12263)){
args__4736__auto__.push((arguments[i__4731__auto___12264]));

var G__12265 = (i__4731__auto___12264 + (1));
i__4731__auto___12264 = G__12265;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

chromex.defaults.console_log.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return console.log.apply(console,cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(args));
});

chromex.defaults.console_log.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
chromex.defaults.console_log.cljs$lang$applyTo = (function (seq12262){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq12262));
});

chromex.defaults.console_error = (function chromex$defaults$console_error(var_args){
var args__4736__auto__ = [];
var len__4730__auto___12267 = arguments.length;
var i__4731__auto___12268 = (0);
while(true){
if((i__4731__auto___12268 < len__4730__auto___12267)){
args__4736__auto__.push((arguments[i__4731__auto___12268]));

var G__12269 = (i__4731__auto___12268 + (1));
i__4731__auto___12268 = G__12269;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return console.error.apply(console,cljs.core.into_array.cljs$core$IFn$_invoke$arity$1(args));
});

chromex.defaults.console_error.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
chromex.defaults.console_error.cljs$lang$applyTo = (function (seq12266){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq12266));
});

chromex.defaults.default_logger = (function chromex$defaults$default_logger(var_args){
var args__4736__auto__ = [];
var len__4730__auto___12271 = arguments.length;
var i__4731__auto___12272 = (0);
while(true){
if((i__4731__auto___12272 < len__4730__auto___12271)){
args__4736__auto__.push((arguments[i__4731__auto___12272]));

var G__12273 = (i__4731__auto___12272 + (1));
i__4731__auto___12272 = G__12273;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((0) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((0)),(0),null)):null);
return chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic(argseq__4737__auto__);
});

chromex.defaults.default_logger.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return cljs.core.apply.cljs$core$IFn$_invoke$arity$3(chromex.defaults.console_log,chromex.defaults.log_prefix,args);
});

chromex.defaults.default_logger.cljs$lang$maxFixedArity = (0);

/** @this {Function} */
chromex.defaults.default_logger.cljs$lang$applyTo = (function (seq12270){
var self__4718__auto__ = this;
return self__4718__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq12270));
});

chromex.defaults.default_callback_error_reporter = (function chromex$defaults$default_callback_error_reporter(descriptor,error){
var function$ = (function (){var or__4131__auto__ = [cljs.core.namespace(cljs.core.cst$kw$id.cljs$core$IFn$_invoke$arity$1(descriptor)),"/",cljs.core.name(cljs.core.cst$kw$id.cljs$core$IFn$_invoke$arity$1(descriptor))].join('');
if(cljs.core.truth_(or__4131__auto__)){
return or__4131__auto__;
} else {
return "an unknown function";
}
})();
var explanation = (function (){var target_obj_12274 = error;
var next_obj_12275 = (target_obj_12274["message"]);
return next_obj_12275;
})();
var message = ["an error occurred during the call to ",function$,(cljs.core.truth_(explanation)?[": ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(explanation)].join(''):null)].join('');
return chromex.defaults.console_error.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([chromex.defaults.log_prefix,message,"Details:",error], 0));
});
chromex.defaults.report_error_if_needed_BANG_ = (function chromex$defaults$report_error_if_needed_BANG_(config,descriptor,error){
var temp__5735__auto__ = cljs.core.cst$kw$callback_DASH_error_DASH_reporter.cljs$core$IFn$_invoke$arity$1(config);
if(cljs.core.truth_(temp__5735__auto__)){
var error_reporter = temp__5735__auto__;

return (error_reporter.cljs$core$IFn$_invoke$arity$2 ? error_reporter.cljs$core$IFn$_invoke$arity$2(descriptor,error) : error_reporter.call(null,descriptor,error));
} else {
return null;
}
});
chromex.defaults.normalize_args = (function chromex$defaults$normalize_args(args){
return cljs.core.vec(args);
});
chromex.defaults.default_callback_fn_factory = (function chromex$defaults$default_callback_fn_factory(config,descriptor,chan){
return (function() { 
var G__12280__delegate = function (args){
var normalized_args = chromex.defaults.normalize_args(args);
var temp__5737__auto__ = (function (){var target_obj_12276 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12277 = (target_obj_12276["chrome"]);
var next_obj_12278 = (next_obj_12277["runtime"]);
var next_obj_12279 = (next_obj_12278["lastError"]);
if((!((next_obj_12279 == null)))){
return next_obj_12279;
} else {
return null;
}
})();
if((temp__5737__auto__ == null)){
chromex.error.set_last_error_BANG_(null);

chromex.error.set_last_error_args_BANG_(null);

return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,normalized_args);
} else {
var error = temp__5737__auto__;
chromex.error.set_last_error_BANG_(error);

chromex.error.set_last_error_args_BANG_(normalized_args);

chromex.defaults.report_error_if_needed_BANG_(config,descriptor,error);

return cljs.core.async.close_BANG_(chan);
}
};
var G__12280 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__12281__i = 0, G__12281__a = new Array(arguments.length -  0);
while (G__12281__i < G__12281__a.length) {G__12281__a[G__12281__i] = arguments[G__12281__i + 0]; ++G__12281__i;}
  args = new cljs.core.IndexedSeq(G__12281__a,0,null);
} 
return G__12280__delegate.call(this,args);};
G__12280.cljs$lang$maxFixedArity = 0;
G__12280.cljs$lang$applyTo = (function (arglist__12282){
var args = cljs.core.seq(arglist__12282);
return G__12280__delegate(args);
});
G__12280.cljs$core$IFn$_invoke$arity$variadic = G__12280__delegate;
return G__12280;
})()
;
});
chromex.defaults.default_callback_channel_factory = (function chromex$defaults$default_callback_channel_factory(_config){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_event_listener_factory = (function chromex$defaults$default_event_listener_factory(_config,event_id,chan){
return (function() { 
var G__12283__delegate = function (args){
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [event_id,cljs.core.vec(args)], null));
};
var G__12283 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__12284__i = 0, G__12284__a = new Array(arguments.length -  0);
while (G__12284__i < G__12284__a.length) {G__12284__a[G__12284__i] = arguments[G__12284__i + 0]; ++G__12284__i;}
  args = new cljs.core.IndexedSeq(G__12284__a,0,null);
} 
return G__12283__delegate.call(this,args);};
G__12283.cljs$lang$maxFixedArity = 0;
G__12283.cljs$lang$applyTo = (function (arglist__12285){
var args = cljs.core.seq(arglist__12285);
return G__12283__delegate(args);
});
G__12283.cljs$core$IFn$_invoke$arity$variadic = G__12283__delegate;
return G__12283;
})()
;
});
chromex.defaults.default_missing_api_check = (function chromex$defaults$default_missing_api_check(api,obj,key){
if(cljs.core.truth_(goog.object.containsKey(obj,key))){
return null;
} else {
console.error((new Error(["Chromex library tried to access a missing Chrome API object '",cljs.core.str.cljs$core$IFn$_invoke$arity$1(api),"'.\n","Your Chrome version might be too old or too recent for running this extension.\n","This is a failure which probably requires a software update."].join(''))));

return true;
}
});
chromex.defaults.default_chrome_content_setting_callback_fn_factory = (function chromex$defaults$default_chrome_content_setting_callback_fn_factory(config,chan){
return (function() { 
var G__12290__delegate = function (args){
var last_error = (function (){var target_obj_12286 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12287 = (target_obj_12286["chrome"]);
var next_obj_12288 = (next_obj_12287["runtime"]);
var next_obj_12289 = (next_obj_12288["lastError"]);
if((!((next_obj_12289 == null)))){
return next_obj_12289;
} else {
return null;
}
})();
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.vec(args),last_error], null));
};
var G__12290 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__12291__i = 0, G__12291__a = new Array(arguments.length -  0);
while (G__12291__i < G__12291__a.length) {G__12291__a[G__12291__i] = arguments[G__12291__i + 0]; ++G__12291__i;}
  args = new cljs.core.IndexedSeq(G__12291__a,0,null);
} 
return G__12290__delegate.call(this,args);};
G__12290.cljs$lang$maxFixedArity = 0;
G__12290.cljs$lang$applyTo = (function (arglist__12292){
var args = cljs.core.seq(arglist__12292);
return G__12290__delegate(args);
});
G__12290.cljs$core$IFn$_invoke$arity$variadic = G__12290__delegate;
return G__12290;
})()
;
});
chromex.defaults.default_chrome_content_setting_callback_channel_factory = (function chromex$defaults$default_chrome_content_setting_callback_channel_factory(_config){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_chrome_storage_area_callback_fn_factory = (function chromex$defaults$default_chrome_storage_area_callback_fn_factory(config,chan){
return (function() { 
var G__12297__delegate = function (args){
var last_error = (function (){var target_obj_12293 = cljs.core.cst$kw$root.cljs$core$IFn$_invoke$arity$1(config);
var next_obj_12294 = (target_obj_12293["chrome"]);
var next_obj_12295 = (next_obj_12294["runtime"]);
var next_obj_12296 = (next_obj_12295["lastError"]);
if((!((next_obj_12296 == null)))){
return next_obj_12296;
} else {
return null;
}
})();
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.vec(args),last_error], null));
};
var G__12297 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__12298__i = 0, G__12298__a = new Array(arguments.length -  0);
while (G__12298__i < G__12298__a.length) {G__12298__a[G__12298__i] = arguments[G__12298__i + 0]; ++G__12298__i;}
  args = new cljs.core.IndexedSeq(G__12298__a,0,null);
} 
return G__12297__delegate.call(this,args);};
G__12297.cljs$lang$maxFixedArity = 0;
G__12297.cljs$lang$applyTo = (function (arglist__12299){
var args = cljs.core.seq(arglist__12299);
return G__12297__delegate(args);
});
G__12297.cljs$core$IFn$_invoke$arity$variadic = G__12297__delegate;
return G__12297;
})()
;
});
chromex.defaults.default_chrome_storage_area_callback_channel_factory = (function chromex$defaults$default_chrome_storage_area_callback_channel_factory(_config){
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_chrome_port_channel_factory = (function chromex$defaults$default_chrome_port_channel_factory(_config){
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();
});
chromex.defaults.default_chrome_port_on_message_fn_factory = (function chromex$defaults$default_chrome_port_on_message_fn_factory(config,chrome_port){
return (function (message){
if((message == null)){
var config__6203__auto__ = config;
var handler_key__6204__auto__ = cljs.core.cst$kw$chrome_DASH_port_DASH_received_DASH_nil_DASH_message;
var handler__6205__auto__ = handler_key__6204__auto__.cljs$core$IFn$_invoke$arity$1(config__6203__auto__);

return (handler__6205__auto__.cljs$core$IFn$_invoke$arity$2 ? handler__6205__auto__.cljs$core$IFn$_invoke$arity$2(config__6203__auto__,chrome_port) : handler__6205__auto__.call(null,config__6203__auto__,chrome_port));
} else {
chromex.protocols.chrome_port_state.put_message_BANG_(chrome_port,message);

return null;
}
});
});
chromex.defaults.default_chrome_port_on_disconnect_fn_factory = (function chromex$defaults$default_chrome_port_on_disconnect_fn_factory(_config,chrome_port){
return (function (){
chromex.protocols.chrome_port_state.close_resources_BANG_(chrome_port);

chromex.protocols.chrome_port_state.set_connected_BANG_(chrome_port,false);

return null;
});
});
chromex.defaults.default_chrome_port_disconnect_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_disconnect_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_post_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_post_message_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_on_disconnect_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_on_disconnect_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_on_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_on_message_called_on_disconnected_port(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_post_message_called_with_nil = (function chromex$defaults$default_chrome_port_post_message_called_with_nil(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_received_nil_message = (function chromex$defaults$default_chrome_port_received_nil_message(_config,_chrome_port){
return null;
});
chromex.defaults.default_chrome_port_put_message_called_on_disconnected_port = (function chromex$defaults$default_chrome_port_put_message_called_on_disconnected_port(_config,_chrome_port,message){
return null;
});
chromex.defaults.default_config = cljs.core.PersistentHashMap.fromArrays([cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_put_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_channel_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_post_DASH_message_DASH_called_DASH_with_DASH_nil,cljs.core.cst$kw$chrome_DASH_port_DASH_channel_DASH_factory,cljs.core.cst$kw$missing_DASH_api_DASH_check_DASH_fn,cljs.core.cst$kw$chrome_DASH_port_DASH_received_DASH_nil_DASH_message,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_message_DASH_fn_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_disconnect_DASH_called_DASH_on_DASH_disconnected_DASH_port,cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_channel_DASH_factory,cljs.core.cst$kw$root,cljs.core.cst$kw$event_DASH_listener_DASH_factory,cljs.core.cst$kw$callback_DASH_fn_DASH_factory,cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_fn_DASH_factory,cljs.core.cst$kw$chrome_DASH_storage_DASH_area_DASH_callback_DASH_fn_DASH_factory,cljs.core.cst$kw$callback_DASH_error_DASH_reporter,cljs.core.cst$kw$callback_DASH_channel_DASH_factory,cljs.core.cst$kw$chrome_DASH_port_DASH_on_DASH_disconnect_DASH_fn_DASH_factory],[chromex.defaults.default_chrome_port_post_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_put_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_on_disconnect_called_on_disconnected_port,chromex.defaults.default_chrome_storage_area_callback_channel_factory,chromex.defaults.default_chrome_port_post_message_called_with_nil,chromex.defaults.default_chrome_port_channel_factory,chromex.defaults.default_missing_api_check,chromex.defaults.default_chrome_port_received_nil_message,chromex.defaults.default_chrome_port_on_message_called_on_disconnected_port,chromex.defaults.default_chrome_port_on_message_fn_factory,chromex.defaults.default_chrome_port_disconnect_called_on_disconnected_port,chromex.defaults.default_chrome_content_setting_callback_channel_factory,goog.global,chromex.defaults.default_event_listener_factory,chromex.defaults.default_callback_fn_factory,chromex.defaults.default_chrome_content_setting_callback_fn_factory,chromex.defaults.default_chrome_storage_area_callback_fn_factory,chromex.defaults.default_callback_error_reporter,chromex.defaults.default_callback_channel_factory,chromex.defaults.default_chrome_port_on_disconnect_fn_factory]);

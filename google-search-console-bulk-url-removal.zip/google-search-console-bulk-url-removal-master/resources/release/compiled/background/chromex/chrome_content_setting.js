// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('chromex.chrome_content_setting');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('chromex.protocols.chrome_content_setting');
goog.require('chromex.support');
goog.require('oops.core');

/**
* @constructor
 * @implements {chromex.protocols.chrome_content_setting.IChromeContentSetting}
*/
chromex.chrome_content_setting.ChromeContentSetting = (function (native_chrome_content_setting,channel_factory,callback_factory){
this.native_chrome_content_setting = native_chrome_content_setting;
this.channel_factory = channel_factory;
this.callback_factory = callback_factory;
});
chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$ = cljs.core.PROTOCOL_SENTINEL;

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_native_content_setting$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
return self__.native_chrome_content_setting;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12314_12330 = self__.native_chrome_content_setting;
var call_info_12316_12331 = [target_obj_12314_12330,(function (){var next_obj_12317 = (target_obj_12314_12330["get"]);
return next_obj_12317;
})()];
var fn_12315_12332 = (call_info_12316_12331[(1)]);
if((!((fn_12315_12332 == null)))){
fn_12315_12332.call((call_info_12316_12331[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$set$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12318_12333 = self__.native_chrome_content_setting;
var call_info_12320_12334 = [target_obj_12318_12333,(function (){var next_obj_12321 = (target_obj_12318_12333["set"]);
return next_obj_12321;
})()];
var fn_12319_12335 = (call_info_12320_12334[(1)]);
if((!((fn_12319_12335 == null)))){
fn_12319_12335.call((call_info_12320_12334[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$clear$arity$2 = (function (_this,details){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12322_12336 = self__.native_chrome_content_setting;
var call_info_12324_12337 = [target_obj_12322_12336,(function (){var next_obj_12325 = (target_obj_12322_12336["clear"]);
return next_obj_12325;
})()];
var fn_12323_12338 = (call_info_12324_12337[(1)]);
if((!((fn_12323_12338 == null)))){
fn_12323_12338.call((call_info_12324_12337[(0)]),details,(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.prototype.chromex$protocols$chrome_content_setting$IChromeContentSetting$get_resource_identifiers$arity$1 = (function (_this){
var self__ = this;
var _this__$1 = this;
var channel = (self__.channel_factory.cljs$core$IFn$_invoke$arity$0 ? self__.channel_factory.cljs$core$IFn$_invoke$arity$0() : self__.channel_factory.call(null));
var target_obj_12326_12339 = self__.native_chrome_content_setting;
var call_info_12328_12340 = [target_obj_12326_12339,(function (){var next_obj_12329 = (target_obj_12326_12339["getResourceIdentifiers"]);
return next_obj_12329;
})()];
var fn_12327_12341 = (call_info_12328_12340[(1)]);
if((!((fn_12327_12341 == null)))){
fn_12327_12341.call((call_info_12328_12340[(0)]),(self__.callback_factory.cljs$core$IFn$_invoke$arity$1 ? self__.callback_factory.cljs$core$IFn$_invoke$arity$1(channel) : self__.callback_factory.call(null,channel)));
} else {
}

return channel;
});

chromex.chrome_content_setting.ChromeContentSetting.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.cst$sym$native_DASH_chrome_DASH_content_DASH_setting,cljs.core.cst$sym$channel_DASH_factory,cljs.core.cst$sym$callback_DASH_factory], null);
});

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$type = true;

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorStr = "chromex.chrome-content-setting/ChromeContentSetting";

chromex.chrome_content_setting.ChromeContentSetting.cljs$lang$ctorPrWriter = (function (this__4374__auto__,writer__4375__auto__,opt__4376__auto__){
return cljs.core._write(writer__4375__auto__,"chromex.chrome-content-setting/ChromeContentSetting");
});

/**
 * Positional factory function for chromex.chrome-content-setting/ChromeContentSetting.
 */
chromex.chrome_content_setting.__GT_ChromeContentSetting = (function chromex$chrome_content_setting$__GT_ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory){
return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,channel_factory,callback_factory));
});

chromex.chrome_content_setting.make_chrome_content_setting = (function chromex$chrome_content_setting$make_chrome_content_setting(config,native_chrome_content_setting){

return (new chromex.chrome_content_setting.ChromeContentSetting(native_chrome_content_setting,(function (){var config__6212__auto__ = config;
var handler_key__6213__auto__ = cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_channel_DASH_factory;
var handler__6214__auto__ = handler_key__6213__auto__.cljs$core$IFn$_invoke$arity$1(config__6212__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6214__auto__,config__6212__auto__);
})(),(function (){var config__6212__auto__ = config;
var handler_key__6213__auto__ = cljs.core.cst$kw$chrome_DASH_content_DASH_setting_DASH_callback_DASH_fn_DASH_factory;
var handler__6214__auto__ = handler_key__6213__auto__.cljs$core$IFn$_invoke$arity$1(config__6212__auto__);

return cljs.core.partial.cljs$core$IFn$_invoke$arity$2(handler__6214__auto__,config__6212__auto__);
})()));
});

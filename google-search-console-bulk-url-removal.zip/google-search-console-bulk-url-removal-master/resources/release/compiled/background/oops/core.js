// Compiled by ClojureScript 1.10.520 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('oops.core');
goog.require('cljs.core');
goog.require('cljs.core.constants');
goog.require('cljs.spec.alpha');
goog.require('goog.object');
goog.require('oops.sdefs');
goog.require('oops.state');
goog.require('oops.config');
goog.require('oops.messages');
goog.require('oops.helpers');
goog.require('oops.schema');
oops.core.report_error_dynamically = (function oops$core$report_error_dynamically(msg,data){
if(oops.state.was_error_reported_QMARK_()){
return null;
} else {
oops.state.mark_error_reported_BANG_();

var G__11935 = oops.config.get_error_reporting();
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$throw,G__11935)){
throw oops.state.prepare_error_from_call_site(msg,oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$console,G__11935)){
var G__11937 = (console["error"]);
var G__11938 = msg;
var G__11939 = oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data);
var fexpr__11936 = oops.state.get_console_reporter();
return (fexpr__11936.cljs$core$IFn$_invoke$arity$3 ? fexpr__11936.cljs$core$IFn$_invoke$arity$3(G__11937,G__11938,G__11939) : fexpr__11936.call(null,G__11937,G__11938,G__11939));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(false,G__11935)){
return null;
} else {
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__11935)].join('')));

}
}
}
}
});
oops.core.report_warning_dynamically = (function oops$core$report_warning_dynamically(msg,data){
var G__11940 = oops.config.get_warning_reporting();
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$throw,G__11940)){
throw oops.state.prepare_error_from_call_site(msg,oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$console,G__11940)){
var G__11942 = (console["warn"]);
var G__11943 = msg;
var G__11944 = oops.helpers.wrap_data_in_enveloper_if_possible(oops.config.use_envelope_QMARK_(),data);
var fexpr__11941 = oops.state.get_console_reporter();
return (fexpr__11941.cljs$core$IFn$_invoke$arity$3 ? fexpr__11941.cljs$core$IFn$_invoke$arity$3(G__11942,G__11943,G__11944) : fexpr__11941.call(null,G__11942,G__11943,G__11944));
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(false,G__11940)){
return null;
} else {
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__11940)].join('')));

}
}
}
});
oops.core.report_if_needed_dynamically = (function oops$core$report_if_needed_dynamically(var_args){
var args__4736__auto__ = [];
var len__4730__auto___11951 = arguments.length;
var i__4731__auto___11952 = (0);
while(true){
if((i__4731__auto___11952 < len__4730__auto___11951)){
args__4736__auto__.push((arguments[i__4731__auto___11952]));

var G__11953 = (i__4731__auto___11952 + (1));
i__4731__auto___11952 = G__11953;
continue;
} else {
}
break;
}

var argseq__4737__auto__ = ((((1) < args__4736__auto__.length))?(new cljs.core.IndexedSeq(args__4736__auto__.slice((1)),(0),null)):null);
return oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4737__auto__);
});

oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$variadic = (function (msg_id,p__11947){
var vec__11948 = p__11947;
var info = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__11948,(0),null);
return null;
});

oops.core.report_if_needed_dynamically.cljs$lang$maxFixedArity = (1);

/** @this {Function} */
oops.core.report_if_needed_dynamically.cljs$lang$applyTo = (function (seq11945){
var G__11946 = cljs.core.first(seq11945);
var seq11945__$1 = cljs.core.next(seq11945);
var self__4717__auto__ = this;
return self__4717__auto__.cljs$core$IFn$_invoke$arity$variadic(G__11946,seq11945__$1);
});

oops.core.validate_object_access_dynamically = (function oops$core$validate_object_access_dynamically(obj,mode,key,push_QMARK_,check_key_read_QMARK_,check_key_write_QMARK_){
if(((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && ((void 0 === obj))))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"undefined",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"undefined",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && ((obj == null))))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"nil",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"nil",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isBoolean(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"boolean",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"boolean",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isNumber(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"number",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"number",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isString(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"string",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"string",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):((cljs.core.not(goog.isObject(obj)))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"non-object",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"non-object",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return false;
})()
):(cljs.core.truth_(goog.isDateLike(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"date-like",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"date-like",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return true;
})()
):(cljs.core.truth_(oops.helpers.cljs_type_QMARK_(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs type",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs type",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return true;
})()
):(cljs.core.truth_(oops.helpers.cljs_instance_QMARK_(obj))?((cljs.core.contains_QMARK_(oops.config.get_suppress_reporting(),cljs.core.cst$kw$unexpected_DASH_object_DASH_value))?true:(function (){
(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs instance",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$unexpected_DASH_object_DASH_value,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$flavor,"cljs instance",cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

return true;
})()
):true
)))))))))){
if(cljs.core.truth_(push_QMARK_)){
oops.state.add_key_to_current_path_BANG_(key);

oops.state.set_last_access_modifier_BANG_(mode);
} else {
}

var and__4120__auto__ = (cljs.core.truth_(check_key_read_QMARK_)?((((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(0))) && (cljs.core.not(goog.object.containsKey(obj,key)))))?(oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$missing_DASH_object_DASH_key,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$missing_DASH_object_DASH_key,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null))):true):true);
if(cljs.core.truth_(and__4120__auto__)){
if(cljs.core.truth_(check_key_write_QMARK_)){
var temp__5737__auto__ = oops.helpers.get_property_descriptor(obj,key);
if((temp__5737__auto__ == null)){
if(cljs.core.truth_(oops.helpers.is_object_frozen_QMARK_(obj))){
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$object_DASH_is_DASH_frozen,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$object_DASH_is_DASH_frozen,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));
} else {
if(cljs.core.truth_(oops.helpers.is_object_sealed_QMARK_(obj))){
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$object_DASH_is_DASH_sealed,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$object_DASH_is_DASH_sealed,new cljs.core.PersistentArrayMap(null, 3, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));
} else {
return true;

}
}
} else {
var descriptor_11954 = temp__5737__auto__;
var temp__5737__auto____$1 = oops.helpers.determine_property_non_writable_reason(descriptor_11954);
if((temp__5737__auto____$1 == null)){
return true;
} else {
var reason_11955 = temp__5737__auto____$1;
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$object_DASH_key_DASH_not_DASH_writable,new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$frozen_QMARK_,oops.helpers.is_object_frozen_QMARK_(obj),cljs.core.cst$kw$reason,reason_11955,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$object_DASH_key_DASH_not_DASH_writable,new cljs.core.PersistentArrayMap(null, 5, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$key,key,cljs.core.cst$kw$frozen_QMARK_,oops.helpers.is_object_frozen_QMARK_(obj),cljs.core.cst$kw$reason,reason_11955,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));
}
}
} else {
return true;
}
} else {
return and__4120__auto__;
}
} else {
return null;
}
});
oops.core.validate_fn_call_dynamically = (function oops$core$validate_fn_call_dynamically(fn,mode){
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1))) && ((fn == null)))){
return true;
} else {
if(cljs.core.truth_(goog.isFunction(fn))){
return true;
} else {
return (oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2 ? oops.core.report_if_needed_dynamically.cljs$core$IFn$_invoke$arity$2(cljs.core.cst$kw$expected_DASH_function_DASH_value,new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$soft_QMARK_,cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1)),cljs.core.cst$kw$fn,fn,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)) : oops.core.report_if_needed_dynamically.call(null,cljs.core.cst$kw$expected_DASH_function_DASH_value,new cljs.core.PersistentArrayMap(null, 4, [cljs.core.cst$kw$path,oops.state.get_key_path_str(),cljs.core.cst$kw$soft_QMARK_,cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(mode,(1)),cljs.core.cst$kw$fn,fn,cljs.core.cst$kw$obj,oops.state.get_target_object()], null)));

}
}
});
oops.core.punch_key_dynamically_BANG_ = (function oops$core$punch_key_dynamically_BANG_(obj,key){
var child_factory_11957 = oops.config.get_child_factory();
var child_factory_11957__$1 = (function (){var G__11958 = child_factory_11957;
var G__11958__$1 = (((G__11958 instanceof cljs.core.Keyword))?G__11958.fqn:null);
switch (G__11958__$1) {
case "js-obj":
return ((function (G__11958,G__11958__$1,child_factory_11957){
return (function (){
return ({});
});
;})(G__11958,G__11958__$1,child_factory_11957))

break;
case "js-array":
return ((function (G__11958,G__11958__$1,child_factory_11957){
return (function (){
return [];
});
;})(G__11958,G__11958__$1,child_factory_11957))

break;
default:
return child_factory_11957;

}
})();

var child_obj_11956 = (child_factory_11957__$1.cljs$core$IFn$_invoke$arity$2 ? child_factory_11957__$1.cljs$core$IFn$_invoke$arity$2(obj,key) : child_factory_11957__$1.call(null,obj,key));
(obj[key] = child_obj_11956);

return child_obj_11956;
});
oops.core.build_path_dynamically = (function oops$core$build_path_dynamically(selector){
if(((typeof selector === 'string') || ((selector instanceof cljs.core.Keyword)))){
var selector_path_11962 = [];
oops.schema.prepare_simple_path_BANG_(selector,selector_path_11962);

return selector_path_11962;
} else {
var selector_path_11963 = [];
oops.schema.prepare_path_BANG_(selector,selector_path_11963);

return selector_path_11963;

}
});
oops.core.check_path_dynamically = (function oops$core$check_path_dynamically(path,op){
var temp__5739__auto__ = oops.schema.check_dynamic_path_BANG_(path,op);
if((temp__5739__auto__ == null)){
return null;
} else {
var issue_11964 = temp__5739__auto__;
return cljs.core.apply.cljs$core$IFn$_invoke$arity$2(oops.core.report_if_needed_dynamically,issue_11964);
}
});
oops.core.get_key_dynamically = (function oops$core$get_key_dynamically(obj,key,mode){
return (obj[key]);
});
oops.core.set_key_dynamically = (function oops$core$set_key_dynamically(obj,key,val,mode){
return (obj[key] = val);
});
oops.core.get_selector_dynamically = (function oops$core$get_selector_dynamically(obj,selector){
var path_11966 = (function (){var path_11965 = oops.core.build_path_dynamically(selector);

return path_11965;
})();
var len_11967 = path_11966.length;
var i_11968 = (0);
var obj_11969 = obj;
while(true){
if((i_11968 < len_11967)){
var mode_11970 = (path_11966[i_11968]);
var key_11971 = (path_11966[(i_11968 + (1))]);
var next_obj_11972 = oops.core.get_key_dynamically(obj_11969,key_11971,mode_11970);
var G__11973 = mode_11970;
switch (G__11973) {
case (0):
var G__11975 = (i_11968 + (2));
var G__11976 = next_obj_11972;
i_11968 = G__11975;
obj_11969 = G__11976;
continue;

break;
case (1):
if((!((next_obj_11972 == null)))){
var G__11977 = (i_11968 + (2));
var G__11978 = next_obj_11972;
i_11968 = G__11977;
obj_11969 = G__11978;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_11972 == null)))){
var G__11979 = (i_11968 + (2));
var G__11980 = next_obj_11972;
i_11968 = G__11979;
obj_11969 = G__11980;
continue;
} else {
var G__11981 = (i_11968 + (2));
var G__11982 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_11969,key_11971) : oops.core.punch_key_dynamically_BANG_.call(null,obj_11969,key_11971));
i_11968 = G__11981;
obj_11969 = G__11982;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__11973)].join('')));

}
} else {
return obj_11969;
}
break;
}
});
oops.core.get_selector_call_info_dynamically = (function oops$core$get_selector_call_info_dynamically(obj,selector){
var path_11984 = (function (){var path_11983 = oops.core.build_path_dynamically(selector);

return path_11983;
})();
var len_11985 = path_11984.length;
if((len_11985 < (4))){
return [obj,(function (){var path_11987 = path_11984;
var len_11988 = path_11987.length;
var i_11989 = (0);
var obj_11990 = obj;
while(true){
if((i_11989 < len_11988)){
var mode_11991 = (path_11987[i_11989]);
var key_11992 = (path_11987[(i_11989 + (1))]);
var next_obj_11993 = oops.core.get_key_dynamically(obj_11990,key_11992,mode_11991);
var G__12008 = mode_11991;
switch (G__12008) {
case (0):
var G__12012 = (i_11989 + (2));
var G__12013 = next_obj_11993;
i_11989 = G__12012;
obj_11990 = G__12013;
continue;

break;
case (1):
if((!((next_obj_11993 == null)))){
var G__12014 = (i_11989 + (2));
var G__12015 = next_obj_11993;
i_11989 = G__12014;
obj_11990 = G__12015;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_11993 == null)))){
var G__12016 = (i_11989 + (2));
var G__12017 = next_obj_11993;
i_11989 = G__12016;
obj_11990 = G__12017;
continue;
} else {
var G__12018 = (i_11989 + (2));
var G__12019 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_11990,key_11992) : oops.core.punch_key_dynamically_BANG_.call(null,obj_11990,key_11992));
i_11989 = G__12018;
obj_11990 = G__12019;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__12008)].join('')));

}
} else {
return obj_11990;
}
break;
}
})()];
} else {
var target_obj_11986 = (function (){var path_11994 = path_11984.slice((0),(len_11985 - (2)));
var len_11995 = path_11994.length;
var i_11996 = (0);
var obj_11997 = obj;
while(true){
if((i_11996 < len_11995)){
var mode_11998 = (path_11994[i_11996]);
var key_11999 = (path_11994[(i_11996 + (1))]);
var next_obj_12000 = oops.core.get_key_dynamically(obj_11997,key_11999,mode_11998);
var G__12009 = mode_11998;
switch (G__12009) {
case (0):
var G__12021 = (i_11996 + (2));
var G__12022 = next_obj_12000;
i_11996 = G__12021;
obj_11997 = G__12022;
continue;

break;
case (1):
if((!((next_obj_12000 == null)))){
var G__12023 = (i_11996 + (2));
var G__12024 = next_obj_12000;
i_11996 = G__12023;
obj_11997 = G__12024;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_12000 == null)))){
var G__12025 = (i_11996 + (2));
var G__12026 = next_obj_12000;
i_11996 = G__12025;
obj_11997 = G__12026;
continue;
} else {
var G__12027 = (i_11996 + (2));
var G__12028 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_11997,key_11999) : oops.core.punch_key_dynamically_BANG_.call(null,obj_11997,key_11999));
i_11996 = G__12027;
obj_11997 = G__12028;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__12009)].join('')));

}
} else {
return obj_11997;
}
break;
}
})();
return [target_obj_11986,(function (){var path_12001 = [(path_11984[(len_11985 - (2))]),(path_11984[(len_11985 - (1))])];
var len_12002 = path_12001.length;
var i_12003 = (0);
var obj_12004 = target_obj_11986;
while(true){
if((i_12003 < len_12002)){
var mode_12005 = (path_12001[i_12003]);
var key_12006 = (path_12001[(i_12003 + (1))]);
var next_obj_12007 = oops.core.get_key_dynamically(obj_12004,key_12006,mode_12005);
var G__12010 = mode_12005;
switch (G__12010) {
case (0):
var G__12030 = (i_12003 + (2));
var G__12031 = next_obj_12007;
i_12003 = G__12030;
obj_12004 = G__12031;
continue;

break;
case (1):
if((!((next_obj_12007 == null)))){
var G__12032 = (i_12003 + (2));
var G__12033 = next_obj_12007;
i_12003 = G__12032;
obj_12004 = G__12033;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_12007 == null)))){
var G__12034 = (i_12003 + (2));
var G__12035 = next_obj_12007;
i_12003 = G__12034;
obj_12004 = G__12035;
continue;
} else {
var G__12036 = (i_12003 + (2));
var G__12037 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_12004,key_12006) : oops.core.punch_key_dynamically_BANG_.call(null,obj_12004,key_12006));
i_12003 = G__12036;
obj_12004 = G__12037;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__12010)].join('')));

}
} else {
return obj_12004;
}
break;
}
})()];
}
});
oops.core.set_selector_dynamically = (function oops$core$set_selector_dynamically(obj,selector,val){
var path_12039 = (function (){var path_12038 = oops.core.build_path_dynamically(selector);

return path_12038;
})();
var len_12042 = path_12039.length;
var parent_obj_path_12043 = path_12039.slice((0),(len_12042 - (2)));
var key_12040 = (path_12039[(len_12042 - (1))]);
var mode_12041 = (path_12039[(len_12042 - (2))]);
var parent_obj_12044 = (function (){var path_12045 = parent_obj_path_12043;
var len_12046 = path_12045.length;
var i_12047 = (0);
var obj_12048 = obj;
while(true){
if((i_12047 < len_12046)){
var mode_12049 = (path_12045[i_12047]);
var key_12050 = (path_12045[(i_12047 + (1))]);
var next_obj_12051 = oops.core.get_key_dynamically(obj_12048,key_12050,mode_12049);
var G__12052 = mode_12049;
switch (G__12052) {
case (0):
var G__12054 = (i_12047 + (2));
var G__12055 = next_obj_12051;
i_12047 = G__12054;
obj_12048 = G__12055;
continue;

break;
case (1):
if((!((next_obj_12051 == null)))){
var G__12056 = (i_12047 + (2));
var G__12057 = next_obj_12051;
i_12047 = G__12056;
obj_12048 = G__12057;
continue;
} else {
return null;
}

break;
case (2):
if((!((next_obj_12051 == null)))){
var G__12058 = (i_12047 + (2));
var G__12059 = next_obj_12051;
i_12047 = G__12058;
obj_12048 = G__12059;
continue;
} else {
var G__12060 = (i_12047 + (2));
var G__12061 = (oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2 ? oops.core.punch_key_dynamically_BANG_.cljs$core$IFn$_invoke$arity$2(obj_12048,key_12050) : oops.core.punch_key_dynamically_BANG_.call(null,obj_12048,key_12050));
i_12047 = G__12060;
obj_12048 = G__12061;
continue;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__12052)].join('')));

}
} else {
return obj_12048;
}
break;
}
})();
return oops.core.set_key_dynamically(parent_obj_12044,key_12040,val,mode_12041);
});
